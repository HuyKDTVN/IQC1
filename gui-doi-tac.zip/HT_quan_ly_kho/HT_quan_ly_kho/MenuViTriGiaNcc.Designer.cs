﻿namespace HT_quan_ly_kho
{
    partial class MenuViTriGiaNcc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuViTriGiaNcc));
            phieuNhapKho = new Button();
            button1 = new Button();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            button3 = new Button();
            helloText = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // phieuNhapKho
            // 
            phieuNhapKho.BackColor = Color.DeepSkyBlue;
            phieuNhapKho.Cursor = Cursors.Hand;
            phieuNhapKho.FlatStyle = FlatStyle.Flat;
            phieuNhapKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            phieuNhapKho.ForeColor = Color.Black;
            phieuNhapKho.Location = new Point(554, 230);
            phieuNhapKho.Name = "phieuNhapKho";
            phieuNhapKho.Size = new Size(220, 92);
            phieuNhapKho.TabIndex = 28;
            phieuNhapKho.Text = "Cập nhật đơn vị";
            phieuNhapKho.UseVisualStyleBackColor = false;
            phieuNhapKho.Click += phieuNhapKho_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DeepSkyBlue;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(276, 230);
            button1.Name = "button1";
            button1.Size = new Size(220, 92);
            button1.TabIndex = 29;
            button1.Text = "Cập nhật vị trí";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DeepSkyBlue;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            button2.ForeColor = Color.Black;
            button2.Location = new Point(827, 230);
            button2.Name = "button2";
            button2.Size = new Size(220, 92);
            button2.TabIndex = 30;
            button2.Text = "Cập nhật đối tác";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(14, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 69;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Transparent;
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.Brown;
            button3.Location = new Point(1165, 19);
            button3.Name = "button3";
            button3.Size = new Size(162, 49);
            button3.TabIndex = 66;
            button3.Text = "Đăng xuất";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(93, 27);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 68;
            helloText.Text = "Xin chào Đức";
            // 
            // MenuViTriGiaNcc
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1344, 712);
            Controls.Add(pictureBox1);
            Controls.Add(button3);
            Controls.Add(helloText);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(phieuNhapKho);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MenuViTriGiaNcc";
            Text = "Cập nhật vị trí - Đơn vị - Nhà cung cấp";
            Load += MenuViTriGiaNcc_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button phieuNhapKho;
        private Button button1;
        private Button button2;
        private PictureBox pictureBox1;
        private Button button3;
        private Label helloText;
    }
}