﻿namespace HT_quan_ly_kho
{
    partial class CapNhatViTri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CapNhatViTri));
            pictureBox1 = new PictureBox();
            button2 = new Button();
            helloText = new Label();
            lblTitle = new Label();
            txt = new TextBox();
            btnSuaVatLieu = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 69;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(1163, 22);
            button2.Name = "button2";
            button2.Size = new Size(162, 49);
            button2.TabIndex = 66;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(91, 30);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 68;
            helloText.Text = "Xin chào Đức";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.FromArgb(64, 64, 64);
            lblTitle.Location = new Point(534, 28);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(257, 43);
            lblTitle.TabIndex = 67;
            lblTitle.Text = "Cập nhật vị trí";
            // 
            // txt
            // 
            txt.Location = new Point(39, 118);
            txt.Multiline = true;
            txt.Name = "txt";
            txt.Size = new Size(1286, 497);
            txt.TabIndex = 70;
            // 
            // btnSuaVatLieu
            // 
            btnSuaVatLieu.BackColor = Color.DeepSkyBlue;
            btnSuaVatLieu.Cursor = Cursors.Hand;
            btnSuaVatLieu.FlatStyle = FlatStyle.Flat;
            btnSuaVatLieu.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnSuaVatLieu.Location = new Point(39, 633);
            btnSuaVatLieu.Name = "btnSuaVatLieu";
            btnSuaVatLieu.Size = new Size(191, 67);
            btnSuaVatLieu.TabIndex = 71;
            btnSuaVatLieu.Text = "Cập nhật";
            btnSuaVatLieu.UseVisualStyleBackColor = false;
            btnSuaVatLieu.Click += btnSuaVatLieu_Click;
            // 
            // CapNhatViTri
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1344, 712);
            Controls.Add(btnSuaVatLieu);
            Controls.Add(txt);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(helloText);
            Controls.Add(lblTitle);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "CapNhatViTri";
            Text = "Cập nhật vị trí";
            Load += CapNhatViTri_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button2;
        private Label helloText;
        private Label lblTitle;
        private TextBox txt;
        private Button btnSuaVatLieu;
    }
}