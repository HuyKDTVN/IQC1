﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HT_quan_ly_kho
{
    public partial class LichSuGiaoDich : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVatLieu;

        public string maLK;
        public LichSuGiaoDich(string maCodeNV, string tenNV, int phanQuyen, string maVL)
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVatLieu = maVL;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {
            // Ví dụ: cho một button nằm ở giữa form
            //button1.Left = (this.ClientSize.Width - button1.Width) / 2;
            //button1.Top = (this.ClientSize.Height - button1.Height) / 2;

            dataGridView1.Width = this.ClientSize.Width - 60;
        }

        private void LichSuGiaoDich_Load(object sender, EventArgs e)
        {
            
            helloText.Text = "Xin chào " + hoTen;

            //set default for datepicter & dropdownlist
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd/MM/yyyy";
            inputKhoLuuTru.Items.Add("Nhập kho");
            inputKhoLuuTru.Items.Add("Xuất kho");
            inputKhoLuuTru.Items.Add("Tái nhập");
            inputKhoLuuTru.Items.Add("Hủy");
            inputKhoLuuTru.Items.Add("Tất cả");
        }

        private void back_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void dangXuat_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void btnSuaVatLieu_Click(object sender, EventArgs e)
        {
            DateTime dateFrom = dateTimePicker1.Value.Date;
            DateTime dateTo = dateTimePicker2.Value.Date;
            //MessageBox.Show(dateFrom.ToString() + "|" + date2To.ToString());

            DataTable table = new DataTable();

            // Tạo cột
            table.Columns.Add("Mã giao dịch", typeof(string));
            table.Columns.Add("Mã vật liệu", typeof(string));
            table.Columns.Add("Tên vật liệu", typeof(string));
            table.Columns.Add("Số lượng", typeof(string));
            table.Columns.Add("Loại giao dịch", typeof(string));
            table.Columns.Add("Số lượng tối thiểu", typeof(string));
            table.Columns.Add("Đơn vị", typeof(string));
            table.Columns.Add("Đơn giá", typeof(string));
            table.Columns.Add("Code người giao dịch", typeof(string));
            table.Columns.Add("Mã hàng", typeof(string));
            table.Columns.Add("Nhà cung cấp", typeof(string));
            table.Columns.Add("Ký tự", typeof(string));
            table.Columns.Add("Nhóm vật liệu", typeof(string));
            table.Columns.Add("Vị trí", typeof(string));
            table.Columns.Add("Ghi chú", typeof(string));

            // Gán dữ liệu vào DataGridView
            dataGridView1.DataSource = table;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.Visible = true;
            string pathFileTaiBangLK;
            for (int i = 0; i <= (dateTo - dateFrom).Days; i++)
            {
                DateTime d = dateFrom.AddDays(i);
                string p = Variable.pathGiaDich + d.Year + "\\" + d.ToString("MM") + "\\" + d.ToString("dd") + "\\";

                string[] filePaths = Directory.GetFiles(p, "*.cnm",
                                         SearchOption.TopDirectoryOnly);
                
                foreach (string filePath in filePaths)
                {
                    string[] arrFileName = Path.GetFileName(filePath).Split("##");
                    pathFileTaiBangLK = Variable.pathBangLK + arrFileName[1] + ".cnm";
                    table.Rows.Add(arrFileName[0], arrFileName[1], arrFileName[2], arrFileName[3], arrFileName[3].Replace(".cnm", ""), "", "", "", "", "", "", "", "", "", "");

                    if (File.Exists(pathFileTaiBangLK))
                    {
                        // Open the text file using a stream reader.
                        using StreamReader reader = new(pathFileTaiBangLK);

                        // Read the stream as a string.
                        string text = reader.ReadToEnd();
                        string[] infor = text.Split("##");

                        
                        string nhomVL = "Chính";
                        if (infor[2] == "P")
                        {
                            nhomVL = "Phụ";
                        }
                        if (infor[2] == "TB")
                        {
                            nhomVL = "Thiết bị";
                        }
                        //kiem tra con ton kho hay khong
                        string pathTonKho1 = Variable.pathTonKho + infor[1] + ".cnm";
                        //string maVL = Path.GetFileNameWithoutExtension(filePath);
                        if (File.Exists(pathTonKho1))
                        {

                            using (StreamReader reader1 = new StreamReader(pathTonKho1))
                            {
                                string text1 = reader1.ReadToEnd();
                                string[] infor1 = text1.Split("##");
                               
                                //table.Rows.Add(maVL, infor[0], infor1[0], infor[1], infor[3], infor1[1], infor1[2], infor[2], infor[7], infor[8], infor1[3], infor1[5], infor1[4], infor1[6]);


                            } // <-- tại đây StreamReader sẽ được đóng
                        }
                        else
                        {
                            //table.Rows.Add(maVL, infor[0], 0, infor[1], infor[3], "", "", infor[2], infor[7], infor[8], "", "", "", "");
                        }

                    }
                }
            }

            
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
