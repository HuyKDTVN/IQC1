﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class MenuViTriGiaNcc : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;

        public MenuViTriGiaNcc(string maCodeNV, string tenNV, int phanQuyen)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {

        }

        private void MenuViTriGiaNcc_Load(object sender, EventArgs e)
        {
            helloText.Text = "Xin chào " + hoTen;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CapNhatViTri f = new CapNhatViTri(maNV, hoTen, phanQuyenInt, 1);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void phieuNhapKho_Click(object sender, EventArgs e)
        {
            CapNhatViTri f = new CapNhatViTri(maNV, hoTen, phanQuyenInt, 2);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CapNhatViTri f = new CapNhatViTri(maNV, hoTen, phanQuyenInt, 3);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
    }
}
