﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing.Aztec.Internal;
using static System.Net.Mime.MediaTypeNames;

namespace HT_quan_ly_kho
{
    public partial class CapNhatViTri : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public int typeInt; //1 - vi tri kho, 2 - don vi, 3 - doi tac
        public string tenFile = "vi-tri-gia.cnm";
        public CapNhatViTri(string maCodeNV, string tenNV, int phanQuyen, int type)
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            typeInt = type;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MenuViTriGiaNcc f = new MenuViTriGiaNcc(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void CapNhatViTri_Load(object sender, EventArgs e)
        {
            helloText.Text = "Xin chào " + hoTen;

            
            if (typeInt == 2) {
                lblTitle.Text = "Cập nhật đơn vị";
                tenFile = "don-vi.cnm";
            }
            if (typeInt == 3)
            {
                lblTitle.Text = "Cập nhật đối tác";
                tenFile = "ncc.cnm";
            }

            //load vi tri
            string p = Variable.pathOther + tenFile;
            using StreamReader reader = new(p);

            // Read the stream as a string.
            string text = reader.ReadToEnd();
            string result = text.Replace("##", Environment.NewLine);
            txt.Text = result;
        }

        private void btnSuaVatLieu_Click(object sender, EventArgs e)
        {
            string p = Variable.pathOther + tenFile;
            string data = "";
            string result = txt.Text.Trim();
            string[] arr = result.Split(Environment.NewLine);
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] != "")
                {
                    if (i == arr.Length - 1)
                    {
                        data = data + arr[i];
                    }
                    else
                    {
                        data = data + arr[i] + "##";
                    }
                }
                
            }
            Huy_functions.createFile(p, data);
            MessageBox.Show("Đã cập nhật thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
