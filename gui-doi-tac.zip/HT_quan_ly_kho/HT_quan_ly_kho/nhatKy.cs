﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class nhatKy : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVatLieu;

        public string maLK;
        public nhatKy(string maCodeNV, string tenNV, int phanQuyen, string maVL)
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVatLieu = maVL;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {
            // Ví dụ: cho một button nằm ở giữa form
            //button1.Left = (this.ClientSize.Width - button1.Width) / 2;
            //button1.Top = (this.ClientSize.Height - button1.Height) / 2;

            dataGridView1.Width = this.ClientSize.Width - 60;
            dataGridView1.Height = this.ClientSize.Height - 20 - dataGridView1.Top;
        }

        private void nhatKy_Load(object sender, EventArgs e)
        {
            helloText.Text = "Xin chào " + hoTen;

            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd/MM/yyyy";
        }

        private void back_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void dangXuat_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void btnSuaVatLieu_Click(object sender, EventArgs e)
        {
            DateTime dateFrom = dateTimePicker1.Value.Date;
            DateTime dateTo = dateTimePicker2.Value.Date;
           

            //MessageBox.Show(dateFrom.ToString() + "|" + date2To.ToString());

            DataTable table = new DataTable();

            // Tạo cột
            table.Columns.Add("Ngày thực hiện", typeof(string));
            table.Columns.Add("Code người thực hiện", typeof(string));
            table.Columns.Add("Loại thay đổi", typeof(string));
            table.Columns.Add("Mã vật liệu", typeof(string));
            table.Columns.Add("Trường bị thay đổi", typeof(string));
            table.Columns.Add("Giá trị cũ", typeof(string));
            table.Columns.Add("Giá trị mới", typeof(string));
            table.Columns.Add("Lý do thay đổi", typeof(string));
            table.Columns.Add("Tên PC thay đổi", typeof(string));


            // Gán dữ liệu vào DataGridView
            dataGridView1.DataSource = table;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.Visible = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string pathFileNhatKy;
            for (int i = 0; i <= (dateTo - dateFrom).Days; i++)
            {
                DateTime d = dateFrom.AddDays(i);
                string p = Variable.pathNhatKy + d.Year + "\\" + d.ToString("MM") + "\\" + d.ToString("dd") + "\\";
                if (Directory.Exists(p))
                {
                    string[] filePaths = Directory.GetFiles(p, "*.cnm",
                                         SearchOption.TopDirectoryOnly);

                    foreach (string filePath in filePaths)
                    {
                        string[] arrFileNameNhatKy = Path.GetFileName(filePath).Split("##");
                        

                        string ngayThuHien = Variable.ConvertStringToDateTime(arrFileNameNhatKy[0]) + "";
                        string codeNguoiThucHien = arrFileNameNhatKy[1];
                        string LoaiThayDoi = "Sửa thông tin vật liệu";
                        if(arrFileNameNhatKy[2] == "2")
                        {
                            LoaiThayDoi = "Sửa tồn kho";
                        }
                        string MaVL = arrFileNameNhatKy[3];
                        string truongBiThayDoi = Variable.ConvertColumnName(arrFileNameNhatKy[4].Replace(".cnm", ""));
                        string giaTriCu = "";
                        string giaTriMoi = "";
                        string lyDoThayDoi = "";
                        string pcThayDoi = "";

                        using StreamReader reader = new(filePath);
                        // Read the stream as a string.
                        string text = reader.ReadToEnd();
                        string[] arrContentNK = text.Split("##");
                        giaTriCu = arrContentNK[0];
                        giaTriMoi = arrContentNK[1];
                        lyDoThayDoi = arrContentNK[2];
                        pcThayDoi = arrContentNK[3];
                        table.Rows.Add(ngayThuHien, codeNguoiThucHien, LoaiThayDoi, MaVL, truongBiThayDoi, giaTriCu, giaTriMoi, lyDoThayDoi, pcThayDoi);

                    }
                }

            }
        }
    }
}
