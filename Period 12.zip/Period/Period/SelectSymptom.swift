//
//  SelectSymptom.swift
//  Period - BMI
//
//  Created by Huy Le on 18/4/25.
//
import SwiftUI
import GoogleMobileAds

struct SelectSymptom: View {
    //var ads: Interstitial?
    @State private var willMoveToNextScreen = false
    var variable:Variable = Variable()
    @Environment(\.presentationMode) var presentationMode
    let currentMonth = Calendar.current.component(.month, from: Date())
    let currentYear = Calendar.current.component(.year, from: Date())
    let currentDay = Calendar.current.component(.day, from: Date())

    @State private var toggleStates: [Bool] = Array(repeating: false, count: 4)
    @State private var toggleStatesBody: [Bool] = Array(repeating: false, count: 13)
    @State private var toggleStatesBuomBuom: [Bool] = Array(repeating: false, count: 4)
    @State private var selectedSymptoms: Set<String> = []
    @StateObject private var viewModel = MoodViewModel()
  
    init(){
        //ads = Interstitial()
        //ads?.loadInterstitial()
    }
    var body: some View {
        VStack {
            HStack {
                Text(NSLocalizedString("themtrieuchung", comment: ""))
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .font(.custom("NunitoSans-Bold", size: 27))
                    .foregroundColor(.black)
                    .opacity(0.8)
                    .padding(.leading, 30)
                Button(action: {
                    viewModel.addSymptoms(Array(selectedSymptoms))
                   
                    if let symptomNoti = selectedSymptoms.first {
                        print("co trieu chung")
                        var thongBaoTrieuChung = String(format: NSLocalizedString("homnaybanthenaodacotrieuchung", comment: ""), NSLocalizedString(symptomNoti, comment: "").lowercased())
                        
                        UserDefaults.standard.set(thongBaoTrieuChung, forKey: "thongbaotrieuchung")
                        variable.setNotiDaily(mtitle: thongBaoTrieuChung, mcontent: "",  gio: 8, phut: 16, myName: "nhacnhotamtrang")
                    } else {
                        UserDefaults.standard.set("no", forKey: "thongbaotrieuchung")
                        variable.setNotiDaily(mtitle: NSLocalizedString("homnaybanthenao", comment: ""), mcontent: "", gio: 8, phut: 16, myName: "nhacnhotamtrang")
                        print("khong co trieu chung")
                    }
                    
                    
                    willMoveToNextScreen = true
                    //self.ads?.showAd();
                }) {
                    Image(systemName: "checkmark")
                        .font(.system(size: 28))
                        .foregroundColor(Color("buttonSymptom2"))
                        //.offset(x: 0, y: 70)
                        .padding(.top, 0)
                        .padding(.leading, 0)
                }
                .padding(.trailing, 30)
                .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                    ContentView(mydata: 0, mucDich: 0)
                })
            }
            .padding(.top, 10)
            .padding(.bottom, 20)
            
            ScrollView(.vertical, showsIndicators: false) {
                VStack {
                    ZStack(alignment: .top){
                        VStack(alignment: .leading) {
                            Spacer()
                                .frame(height: 30)
                            
                            ForEach(toggleStates.indices, id: \.self) { index in
                                Button(action: {
                                    toggleStates[index].toggle()
                                    let symptom = variable.arrTrieuChungDau[index]
                                    if toggleStates[index] {
                                        selectedSymptoms.insert(symptom)
                                    } else {
                                        selectedSymptoms.remove(symptom)
                                    }
                                    
                                }) {
                                    HStack {
                                        Image(systemName: toggleStates[index] ? "checkmark.circle" : "circle")
                                            .font(.system(size: 25))
                                            .foregroundColor(toggleStates[index] ? Color("buttonSymptom2") : .gray)
                                            .padding(.top, 0)
                                            .padding(.leading, 10)
                                        Text(NSLocalizedString(variable.arrTrieuChungDau[index], comment: ""))
                                            .foregroundColor(.black)
                                            .opacity(0.8)
                                            .font(.custom("NunitoSans-Bold", size: 17))
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        Spacer()
                                    }
                                }
                                if index != toggleStates.count - 1 {
                                    Divider()
                                        .background(Color.gray)
                                        .opacity(0.3)
                                        .padding(.leading, 50)
                                        .padding(.trailing, 20)
                                }
                                
                            }
                        }
                        .padding(.vertical, 20)
                        .padding(.horizontal, 10)
                        .background(Color("bgSymptom").opacity(0.5))
                        .cornerRadius(40)
                        
                        Image("head")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 60, height: 60)
                            .offset(x:0, y: -30)
                    }
                    .padding(.top, 30)
                    Spacer()
                        .frame(height: 30)
                    ZStack(alignment: .top){
                        VStack(alignment: .leading) {
                            Spacer()
                                .frame(height: 30)
                            ForEach(toggleStatesBody.indices, id: \.self) { index in
                                Button(action: {
                                    toggleStatesBody[index].toggle()
                                    let symptom = variable.arrTrieuChungBody[index]
                                    if toggleStatesBody[index] {
                                        selectedSymptoms.insert(symptom)
                                    } else {
                                        selectedSymptoms.remove(symptom)
                                    }
                                }) {
                                    HStack {
                                        Image(systemName: toggleStatesBody[index] ? "checkmark.circle" : "circle")
                                            .font(.system(size: 25))
                                            .foregroundColor(toggleStatesBody[index] ? Color("buttonSymptom2") : .gray)
                                            .padding(.top, 0)
                                            .padding(.leading, 10)
                                        Text(NSLocalizedString(variable.arrTrieuChungBody[index], comment: ""))
                                            .foregroundColor(.black)
                                            .opacity(0.8)
                                            .font(.custom("NunitoSans-Bold", size: 17))
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        Spacer()
                                    }
                                }
                                if index != toggleStatesBody.count - 1 {
                                    Divider()
                                        .background(Color.gray)
                                        .opacity(0.3)
                                        .padding(.leading, 50)
                                        .padding(.trailing, 20)
                                }
                                
                            }
                            
                        }
                        .padding(.vertical, 20)
                        .padding(.horizontal, 10)
                        .background(Color("bgSymptom").opacity(0.5))
                        .cornerRadius(40)
                        
                        Image("body")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 60, height: 60)
                            .offset(x:0, y: -30)
                    }
                    .padding(.top, 30)
                    
                    Spacer()
                        .frame(height: 30)
                    ZStack(alignment: .top){
                        VStack(alignment: .leading) {
                            Spacer()
                                .frame(height: 30)
                            ForEach(toggleStatesBuomBuom.indices, id: \.self) { index in
                                Button(action: {
                                    toggleStatesBuomBuom[index].toggle()
                                    let symptom = variable.arrTrieuChungBuomBuom[index]
                                    if toggleStatesBuomBuom[index] {
                                        selectedSymptoms.insert(symptom)
                                    } else {
                                        selectedSymptoms.remove(symptom)
                                    }
                                }) {
                                    HStack {
                                        Image(systemName: toggleStatesBuomBuom[index] ? "checkmark.circle" : "circle")
                                            .font(.system(size: 25))
                                            .foregroundColor(toggleStatesBuomBuom[index] ? Color("buttonSymptom2") : .gray)
                                            .padding(.top, 0)
                                            .padding(.leading, 10)
                                        Text(NSLocalizedString(variable.arrTrieuChungBuomBuom[index], comment: ""))
                                            .foregroundColor(.black)
                                            .opacity(0.8)
                                            .font(.custom("NunitoSans-Bold", size: 17))
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        Spacer()
                                    }
                                }
                                if index != toggleStatesBuomBuom.count - 1 {
                                    Divider()
                                        .background(Color.gray)
                                        .opacity(0.3)
                                        .padding(.leading, 50)
                                        .padding(.trailing, 20)
                                }
                                
                            }
                            
                        }
                        .padding(.vertical, 20)
                        .padding(.horizontal, 10)
                        .background(Color("bgSymptom").opacity(0.5))
                        .cornerRadius(40)
                        
                        Image("buom-buom")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 60, height: 60)
                            .offset(x:0, y: -30)
                    }
                    .padding(.top, 30)
                }
            }
            .padding(.horizontal, 30)
            Spacer()
        }
        .onAppear(){
            if let entry =  variable.entryForDay(currentYear: currentYear, currentMonth: currentMonth, currentDay: currentDay) {
                if !entry.symptoms.isEmpty {
                    let arraySymptom = entry.symptoms
                    let symptom = arraySymptom.joined(separator: ", ")
                    toggleStates = variable.getNSelectedSymptomDau(symptom: symptom)
                    toggleStatesBody = variable.getNSelectedSymptomBody(symptom: symptom)
                    toggleStatesBuomBuom = variable.getNSelectedSymptomBuomBuom(symptom: symptom)
                    selectedSymptoms = Set(arraySymptom)
                    
                    
                }
            }
        }
        //.navigate(to: ContentView(mydata: 0, mucDich: 0), when: $willMoveToNextScreen)
         .environment(\.colorScheme, .light).preferredColorScheme(.light)
    }
}
struct SelectSymptom_Previews: PreviewProvider {
    static var previews: some View {
        SelectSymptom()
    }
}

