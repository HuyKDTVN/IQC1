//
//  TmpScreen.swift
//  Period - BMI
//
//  Created by Huy Le on 26/06/2022.
//

import SwiftUI

struct TmpScreen: View {
   var variable:Variable = Variable()
   
    var body: some View {
       VStack {
          Spacer()
             .background(Color.black.opacity(0.8))
             .frame(width: .infinity, height: 500)
          ZStack (alignment: .top){
              ZStack{
                  ZStack (alignment: .topLeading){
                      ZStack(alignment: .trailing){
                         
                          VStack{
                             Text(variable.getDanhNgon())
                                  .font(Font.custom("NunitoSans-Italic", size: 16))
                                  .foregroundColor(variable.colorCircleTimBorder)
                                  .padding(.leading, 34)
                                  .padding(.top, 25)
                                  .padding(.bottom, 30)
                                  .padding(.trailing, 30)
                                  
                              
                          }.offset(x: 10, y: 0)
                      }
                      //.clipShape(RoundedRectangle(cornerRadius: 40))
                      .background(
                        Circle()
                            .strokeBorder(Color.blue,lineWidth: 0)
                            .background(Circle().foregroundColor(Color("bgTim2"))).frame(width: 220, height: 220)
                            .offset(x: 150, y: 0)

                      )
                      Image("icon-thongbao").resizable()
                          .frame(width: 30, height: 27, alignment: .top)
                          .padding(20)
                          .offset(x: -10, y: 0)
                  }
              }
              .frame(
                    minWidth: 0,
                    maxWidth: .infinity,
                    minHeight: 90
                  )
              
              .background(
                          Rectangle()
                              .foregroundColor(Color("bgTim"))
                              .opacity(0.9)
              )
              .cornerRadius(30)
              .shadow(color: Color("bgTim2").opacity(1), radius: 17, x: 0, y: 5)
          }.padding(15)
          Spacer()
             .background(Color.black)
             .frame(width: .infinity, height: 500)
       }
       
    }
}

struct TmpScreen_Previews: PreviewProvider {
    static var previews: some View {
        TmpScreen()
    }
}
