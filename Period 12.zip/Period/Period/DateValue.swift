//
//  DateValue.swift
//  Period - BMI
//
//  Created by Huy Le on 30/05/2022.
//

import SwiftUI

struct DateValue: Identifiable{
    var id = UUID().uuidString
    var day: Int
    var date: Date
}
