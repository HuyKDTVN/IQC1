//
//  ManHinhLanDau.swift
//  Period - BMI
//
//  Created by Huy Le on 11/05/2022.
//

import SwiftUI

struct ManHinhLanDau: View {
     var variable:Variable = Variable()
     @State var areYouGoingToSecondView: Bool
     @State var selectType: Int
     let defaults = UserDefaults.standard
        var body: some View {

            NavigationView {
                
                ZStack{
                    
                    VStack {
                        HStack {
                            Spacer()
                            Image("bg-top1").resizable().scaledToFit()
                                .frame(width: 130, height: 130, alignment: .top)
                                
                        }
                        Spacer()

                        HStack {
                            
                            Image("bg-bottom").resizable().scaledToFill()
                                .frame(width: 100, height: 100)
                            Spacer()
                        }
                    }.edgesIgnoringSafeArea(.all)
              
                    VStack {
                        //NavigationLink(destination: ManHinhKhaiBao(redirectToHomeView: false, mydata: selectType), isActive: $areYouGoingToSecondView) { EmptyView() }
                        HStack {
                            Text(NSLocalizedString("select", comment: "")).padding(.leading, 30)
                                .font(.custom("comfortaa.ttf", size: 30))
                                .foregroundColor(variable.textColor)
                            
                            Spacer()
                        }.padding(.bottom, 1)

                        HStack {
                            Text(NSLocalizedString("target", comment: "")).padding(.leading, 30)
                                .font(.custom("comfortaa.ttf", size: 50))
                                .foregroundColor(variable.textColorPink)
                            
                            Spacer()
                        }.padding(.top, -7)

                        Button(action: {
                            defaults.set(1, forKey: "mucdich")
                            defaults.set("mucdich1", forKey: "mdsetting")
                           
                            //self.areYouGoingToSecondView = true
                            //self.selectType = 1
                        }) {
                            ZStack {
                                Image("select1").resizable().scaledToFill().frame(width: UIScreen.main.bounds.size.width).clipped()
                                HStack {
                                    Spacer()
                                    Text(NSLocalizedString("selectTitle1", comment: "")).font(.custom("comfortaa.ttf", size: 28))
                                        .foregroundColor(variable.textColorSelect1).multilineTextAlignment(.leading).padding(.top, -20)
                                    Spacer()
                                    Spacer()
                                }
                            }
                        }.padding(.top, -30)
                        
                     
                        
                        Button(action: {
                           defaults.set(2, forKey: "mucdich")
                           defaults.set("mucdich2", forKey: "mdsetting")
                            self.areYouGoingToSecondView = true
                            self.selectType = 2
                        }) {
                            ZStack {
                                Image("select2").resizable().scaledToFill().frame(width: UIScreen.main.bounds.size.width).clipped()
                                HStack {
                                    Spacer()
                                    Spacer()
                                    Text(NSLocalizedString("selectTitle2", comment: "")).font(.custom("comfortaa.ttf", size: 28))
                                        .foregroundColor(variable.textColorSelect2).multilineTextAlignment(.leading).padding(.top, -10)
                                    
                                    Spacer()
                                }
                            }
                        }.padding(.top, -50)
                        
                        
                        Button(action: {
                           defaults.set(3, forKey: "mucdich")
                           defaults.set("mucdich3", forKey: "mdsetting")
                            self.areYouGoingToSecondView = true
                            self.selectType = 3
                        }) {
                            ZStack {
                                Image("select3").resizable().scaledToFill().frame(width: UIScreen.main.bounds.size.width).clipped()
                                HStack {
                                    Spacer()
                                    Text(NSLocalizedString("selectTitle3", comment: "")).font(.custom("comfortaa.ttf", size: 28))
                                        .foregroundColor(variable.textColorSelect3).multilineTextAlignment(.leading).padding(.top, -20)
                                    Spacer()
                                    Spacer()
                                }
                            }
                        }.padding(.top, -50)
                        
                        Spacer()
                    }
                    Spacer()
                }
            }.environment(\.colorScheme, .light).preferredColorScheme(.light)
        }
}

struct ManHinhLanDau_Previews: PreviewProvider {
    static var previews: some View {
        ManHinhLanDau(areYouGoingToSecondView: false, selectType: 0)
    }
}
