//
//  ListRemind.swift
//  Period - BMI
//
//  Created by Huy Le on 21/07/2022.
//

import SwiftUI

struct ListRemind: View {
   let variable = Variable()
   
   @State private var willMoveToNextScreen = false
   
   
    var body: some View {
       ZStack {
          VStack {
              HStack {
                  Spacer()
                  Image("bg-top").resizable().scaledToFit()
                      .frame(width: 130, height: 130, alignment: .top)
                      
              }
              Spacer()

              HStack {
                  
                  Image("bg-bottom").resizable().scaledToFill()
                      .frame(width: 100, height: 100)
                  Spacer()
              }
          }.edgesIgnoringSafeArea(.all)
          
          VStack{
             HStack {
                 Text(NSLocalizedString("add", comment: "")).padding(.leading, 30)
                     .font(.custom("comfortaa.ttf", size: 30))
                     .foregroundColor(variable.textColor)
                 
                 Spacer()
             }.padding(.bottom, 1)
              HStack {
                  Text(NSLocalizedString("remind2", comment: "")).padding(.leading, 30)
                      .font(.custom("comfortaa.ttf", size: 50))
                      .foregroundColor(variable.textColorPink)
                  
                  Spacer()
              }.padding(.top, -5)
             
             Spacer()
             
             
             Button(action: {
                print("add remind")
                
                withAnimation(.easeOut(duration:0.5)){
                   willMoveToNextScreen = true
                }
             }) {
                 Image(systemName: "plus.circle.fill")
                     .font(.system(size: 60))
                     .foregroundColor(variable.textColorPink)
                     .shadow(color: variable.textColorPink.opacity(0.7), radius: 8, x: 0, y: 5)
                     //.offset(x: 0, y: 70)
                     //.padding(.top, 63)
                 
             }
             Spacer()
             
          }
       }.navigate(to: AddRemind(), when: $willMoveToNextScreen)
          .environment(\.colorScheme, .light).preferredColorScheme(.light)
       
    }
}

struct ListRemind_Previews: PreviewProvider {
    static var previews: some View {
        ListRemind()
    }
}
