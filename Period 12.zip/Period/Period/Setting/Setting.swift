//
//  Setting.swift
//  Period - BMI
//
//  Created by Huy Le on 21/05/2022.
//

import SwiftUI

struct Setting: View {
    var variable:Variable = Variable()
    @State var identifier = "vi"
    @State private var previewIndex: Int = 0
    @State private var showNgayDau = true
    @State private var showNgayKetThuc = true
    @State private var showNgayBatDauThuThai = true
    @State private var showNgayKetThucThuThai = true
    @State private var showNgayRungTrung = true
    @State private var showNhacNhoTamTrang = true
    @State private var touchID = false
    
    @State private var isActive = false
    
   @State private var soLanUongThuoc: Int = 0
   let calendar = Calendar.current
   
   @State private var nhacUongNuoc = true
   
   @State private var nhacUongThuoc = true
    
    var donViTrongLuong = ["kg", "lbs"]
   @State private var selectDonViTrongLuong = "kg"

    var donViChieuCao = ["cm", "ft"]
    @State private var selectDonViChieuCao = "cm"
    
    var ngonNgu = ["aa", "en", "vi"] //["en", "fr", "de", "vi"]
    @State private var selectNgonNgu = "vi"
   
   //var mucDich = ["Theo dõi chu kỳ", "Tính ngày tránh thai", "Tăng khả năng thụ thai"]
   var mucDich = ["mucdich1", "mucdich2", "mucdich3"]
   @State private var selectMucDich = "mucdich1"
    
    @State var showPrivacyPage: Bool = false
    @State var showTermsPage: Bool = false
   
   @State private var namDauToiThang: Int = 1
   @State private var namKetThuc: Int = 2022
   @State private var namBatDauThuThai: Int = 2022
   @State private var namRungTrung: Int = 2022
   @State private var namKetThucThuThai: Int = 2022

   @State private var thangDauToiThang: Int = 1
   @State private var thangKetThuc: Int = 1
   @State private var thangBatDauThuThai: Int = 1
   @State private var thangRungTrung: Int = 1
   @State private var thangKetThucThuThai: Int = 1
    
    @State private var nhacNhoCapNhatTamTrang: Int = 1
   
   @State private var ngayDauToiThang: Int = 1
   @State private var ngayKetThuc: Int = 1
   @State private var ngayBatDauThuThai: Int = 1
   @State private var ngayRungTrung: Int = 1
   @State private var ngayKetThucThuThai: Int = 1

    var body: some View {
        ZStack{
            VStack {
                
                NavigationView {
                   
                    List {
                      
                        Section {
                           //ZStack {
//                                 NavigationLink(destination:
//                                                   UongThuoc()
//                                 ) {
//                                     EmptyView()
//                                 }
//                                 .opacity(0.0)
//                                 .buttonStyle(PlainButtonStyle())
//                                 HStack {
//                                    Circle()
//                                        .strokeBorder(variable.colorCircleDo,lineWidth: 2)
//                                        .background(Circle().foregroundColor(variable.colorCircleDo.opacity(0.2))).frame(width: 20, height: 20)
//                                    
//                                    VStack(alignment: .leading) {
//                                       Toggle(NSLocalizedString("uongthuoc", comment: ""), isOn: $nhacUongThuoc)
//                                          .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
//                                           .onChange(of: nhacUongThuoc) { value in
//                                              UserDefaults.standard.set(nhacUongThuoc, forKey: "nhacUongThuoc")
//                                              if(nhacUongThuoc == true) {
//                                                 
//                                                 if(soLanUongThuoc > 0) {
//                                                    let tinNhanUongThuoc = UserDefaults.standard.string(forKey: "tinNhanUongThuoc") ?? NSLocalizedString("tinNhanUongThuoc", comment: "")
//                                                    
//                                                    var currentDate1 = Date()
//                                                    var currentDate2 = Date()
//                                                    var currentDate3 = Date()
//                                                    var currentDate4 = Date()
//                                                    
//                                                    let dateFormatter1 = DateFormatter()
//                                                    dateFormatter1.timeZone = TimeZone.ReferenceType.local
//                                                    dateFormatter1.dateFormat = "yyyy_MM_dd"
//                                                    
//                                                    let currentDate = dateFormatter1.string(from: Date())
//                                                    
//                                                    dateFormatter1.dateFormat = "yyyy_MM_dd HH:mm:ss"
//                                                    dateFormatter1.locale = .current
//                                                    
//                                                    if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan1") != "") {
//                                                       //print(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan1"))
//                                                      
//                                                       let a1:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan1") ?? "07:30")  + ":00"
//                                                       
//                                                       currentDate1 = dateFormatter1.date(from: a1)!
//                                                       print(currentDate1)
//                                                       
//                                                    }else{
//                                                       currentDate1 = dateFormatter1.date(from: currentDate + " " + "07:30:00")!
//                                                    }
//                                                    
//                                                    if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan2") != "") {
//                                                       let a2:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan2") ?? "11:30")  + ":00"
//                                                       
//                                                       currentDate2 = dateFormatter1.date(from: a2)!
//                                                      
//                                                    }else{
//                                                       currentDate2 = dateFormatter1.date(from: currentDate + " " + "11:30:00")!
//                                                    }
//                                                    
//                                                    if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan3") != "") {
//                                                       let a3:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan3") ?? "18:30")  + ":00"
//                                                       
//                                                       currentDate3 = dateFormatter1.date(from: a3)!
//                                                    }else{
//                                                       currentDate3 = dateFormatter1.date(from: currentDate + " " + "18:30:00")!
//                                                    }
//                                                    
//                                                    if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan4") != "") {
//                                                       let a4:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan4") ?? "21:30")  + ":00"
//                                                       
//                                                       currentDate4 = dateFormatter1.date(from: a4)!
//                                                       
//                                                    }else{
//                                                       currentDate4 = dateFormatter1.date(from: currentDate + " " + "21:30:00")!
//                                                    }
//                                                    
//                                                    
//                                                    for i in 1...soLanUongThuoc{
//                                                       if i == 1{
//                                                          variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate1), phut: calendar.component(.minute, from: currentDate1), myName: "uongthuoc\(i)")
//                                                       }
//                                                       
//                                                       if i == 2{
//                                                          variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate2), phut: calendar.component(.minute, from: currentDate2), myName: "uongthuoc\(i)")
//                                                       }
//                                                       
//                                                       if i == 3{
//                                                          variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate3), phut: calendar.component(.minute, from: currentDate3), myName: "uongthuoc\(i)")
//                                                       }
//                                                       
//                                                       if i == 4{
//                                                          variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate4), phut: calendar.component(.minute, from: currentDate4), myName: "uongthuoc\(i)")
//                                                       }
//                                                    }
//                                                 } //if(soLanUongThuoc > 0) {
//                                                    
//
//                                              }
//                                              else{
//                                                 variable.removeNoti(myName: "uongthuoc1")
//                                                 variable.removeNoti(myName: "uongthuoc2")
//                                                 variable.removeNoti(myName: "uongthuoc3")
//                                                 variable.removeNoti(myName: "uongthuoc4")
//                                              }
//                                           }
//                                       Text(variable.showSoLanUOngThuoc(soLan: soLanUongThuoc))
//                                          .font(.system(size: 12))
//                                          .padding(.top, -10)
//                                          .foregroundColor(Color.black.opacity(0.7))
//                                         
//                                    }
//                                     //Spacer()
//                                 }
                           //}
//                            HStack {
//                                Circle()
//                                    .strokeBorder(variable.textColorPink,lineWidth: 2)
//                                    .background(Circle().foregroundColor(variable.textColorPink.opacity(0.2))).frame(width: 20, height: 20)
//
//                               NavigationLink(destination: TmpScreen()) {
//                                  Text(NSLocalizedString("thuoctranhthai", comment: ""))
//                               }
//                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(variable.colorCircleXanhBorder,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleXanhBorder.opacity(0.2))).frame(width: 20, height: 20)
                               
                               Toggle(NSLocalizedString("nhacnhouongnuoc", comment: ""), isOn: $nhacUongNuoc)
                                  .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
                                   .onChange(of: nhacUongNuoc) { value in
                                      UserDefaults.standard.set(nhacUongNuoc, forKey: "nhacUongNuoc")
                                      if(nhacUongNuoc == true) {
                                         
                                         for i in 8...11 {
                                            variable.setNotiDaily(mtitle: NSLocalizedString("notiUongNuoc", comment: ""), mcontent: "", gio: i, phut: 5, myName: "uongnuoc\(i)")
                                         }
                                         
                                         for i in 14...20 {
                                            variable.setNotiDaily(mtitle: NSLocalizedString("notiUongNuoc", comment: ""), mcontent: "", gio: i, phut: 5, myName: "uongnuoc\(i)")
                                         }
                                        
                                      }
                                      else{
                                          for i in 8...11 {
                                              variable.removeNoti(myName: "uongnuoc\(i)")
                                          }
                                          
                                          for i in 14...20 {
                                              variable.removeNoti(myName: "uongnuoc\(i)")
                                          }
                                         
                                      }
                                   }
                            }
//                            HStack {
//                                Circle()
//                                    .strokeBorder(Color("orange"),lineWidth: 2)
//                                    .background(Circle().foregroundColor(Color("orange").opacity(0.2))).frame(width: 20, height: 20)
//
//                               NavigationLink(destination: ListRemind()) {
//                                  Text(NSLocalizedString("addRemind", comment: ""))
//                               }
//                            }
                        }
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(variable.colorCircleDo,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleDo.opacity(0.2))).frame(width: 20, height: 20)
                                Toggle(NSLocalizedString("ngayDauToiThang", comment: ""), isOn: $showNgayDau)
                                  .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
                                    .onChange(of: showNgayDau) { value in
                                       UserDefaults.standard.set(showNgayDau, forKey: "showNgayDau")
                                       if(showNgayDau == true) {
                                          variable.setNoti(mtitle: NSLocalizedString("ngaydautoithang", comment: ""), mcontent: "", nam: namDauToiThang,thang: thangDauToiThang, ngay: ngayDauToiThang, gio: 9, phut: 0, myName: "ngaydautoithang")
                                       }
                                       else{
                                          variable.removeNoti(myName: "ngaydautoithang")
                                       }
                                    }
                                
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(Color.black,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleXam.opacity(0.4))).frame(width: 20, height: 20)
                                Toggle(NSLocalizedString("ngayKetThuc", comment: ""), isOn: $showNgayKetThuc)
                                  .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
                                    .onChange(of: showNgayKetThuc) { value in
                                       UserDefaults.standard.set(showNgayKetThuc, forKey: "showNgayKetThuc")
                                       
                                       if(showNgayKetThuc == true) {
                                          variable.setNoti(mtitle: NSLocalizedString("ngayketthuc", comment: ""), mcontent: "", nam: namKetThuc,thang: thangKetThuc, ngay: ngayKetThuc, gio: 9, phut: 0, myName: "ngayketthuc")
                                       }
                                       else{
                                          variable.removeNoti(myName: "ngayketthuc")
                                       }
                                    }
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(variable.colorCircleXanhBorder,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleXanhBorder.opacity(0.2))).frame(width: 20, height: 20)
                                Toggle(NSLocalizedString("ngayBatDauThuThai", comment: ""), isOn: $showNgayBatDauThuThai)
                                  .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
                                    .onChange(of: showNgayBatDauThuThai) { value in
                                       UserDefaults.standard.set(showNgayBatDauThuThai, forKey: "showNgayBatDauThuThai")
                                       
                                       if(showNgayBatDauThuThai == true) {
                                          variable.setNoti(mtitle: NSLocalizedString("batdauthuthai", comment: ""), mcontent: "", nam: namBatDauThuThai,thang: thangBatDauThuThai, ngay: ngayBatDauThuThai, gio: 9, phut: 0, myName: "batdauthuthai")
                                       }
                                       else{
                                          variable.removeNoti(myName: "batdauthuthai")
                                       }
                                    }
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(variable.colorCircleTim,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleTim.opacity(0.2))).frame(width: 20, height: 20)
                                Toggle(NSLocalizedString("ngayRungTrung", comment: ""), isOn: $showNgayRungTrung)
                                  .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
                                    .onChange(of: showNgayRungTrung) { value in
                                       UserDefaults.standard.set(showNgayRungTrung, forKey: "showNgayRungTrung")
                                       
                                       if(showNgayRungTrung == true) {
                                          variable.setNoti(mtitle: NSLocalizedString("ngayrungtrung", comment: ""), mcontent: "", nam: namRungTrung,thang: thangRungTrung, ngay: ngayRungTrung, gio: 9, phut: 0, myName: "ngayrungtrung")
                                       }
                                       else{
                                          variable.removeNoti(myName: "ngayrungtrung")
                                       }
                                    }
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(variable.colorCircleXanhBorder,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleXanhBorder.opacity(0.2))).frame(width: 20, height: 20)
                                Toggle(NSLocalizedString("ngayThuThaiKetThuc", comment: ""), isOn: $showNgayKetThucThuThai)
                                  .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
                                    .onChange(of: showNgayKetThucThuThai) { value in
                                       UserDefaults.standard.set(showNgayKetThucThuThai, forKey: "showNgayKetThucThuThai")
                                       
                                       if(showNgayKetThucThuThai == true) {
                                          variable.setNoti(mtitle: NSLocalizedString("ketthucthuthai", comment: ""), mcontent: "", nam: namKetThucThuThai,thang: thangKetThucThuThai, ngay: ngayKetThucThuThai, gio: 9, phut: 0, myName: "ketthucthuthai")
                                       }
                                       else{
                                          variable.removeNoti(myName: "ketthucthuthai")
                                       }
                                    }
                            }
                        }
                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("buttonTamTrang"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("buttonTamTrang").opacity(0.2))).frame(width: 20, height: 20)
                                Toggle(NSLocalizedString("nhacnhotamtrang", comment: ""), isOn: $showNhacNhoTamTrang)
                                  .toggleStyle(SwitchToggleStyle(tint: variable.textColorPink))
                                    .onChange(of: showNhacNhoTamTrang) { value in
                                       UserDefaults.standard.set(showNhacNhoTamTrang, forKey: "showNhacNhoTamTrang")
                                       
                                       if(showNhacNhoTamTrang == true) {
                                          //variable.setNoti(mtitle: NSLocalizedString("homnaybanthenao", comment: ""), mcontent: "", nam: namRungTrung,thang: thangRungTrung, ngay: ngayRungTrung, gio: 9, phut: 18, myName: "nhacnhotamtrang")
                                           variable.setNotiDaily(mtitle: NSLocalizedString("homnaybanthenao", comment: ""), mcontent: "", gio: 8, phut: 16, myName: "nhacnhotamtrang")
                                       }
                                       else{
                                          variable.removeNoti(myName: "nhacnhotamtrang")
                                       }
                                    }
                            }
                        }
                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow").opacity(0.2))).frame(width: 20, height: 20)
                                Picker(NSLocalizedString("donViTrongLuong", comment: ""), selection: $selectDonViTrongLuong) {
                                    ForEach(donViTrongLuong, id: \.self) {
                                        Text("\($0)")
                                    }
                                }.onReceive([self.selectDonViTrongLuong].publisher.first()) { (value) in
                                   UserDefaults.standard.set(value, forKey: "donViTrongLuong")
                                }
                               
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(Color("green"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("green").opacity(0.2))).frame(width: 20, height: 20)
                                Picker(NSLocalizedString("donViChieuCao", comment: ""), selection: $selectDonViChieuCao) {
                                    ForEach(donViChieuCao, id: \.self) {
                                        Text("\($0)")
                                    }
                                }
                                .onReceive([self.selectDonViChieuCao].publisher.first()) { (value) in
                                   UserDefaults.standard.set(value, forKey: "donViChieuCao")
                                }
                            }
                        }

//                        Section{
//                            HStack {
//                                Circle()
//                                    .strokeBorder(Color("blue2"),lineWidth: 2)
//                                    .background(Circle().foregroundColor(Color("blue2").opacity(0.2))).frame(width: 20, height: 20)
//                                Picker(NSLocalizedString("language", comment: ""), selection: $selectNgonNgu) {
//                                    ForEach(ngonNgu, id: \.self) {
//                                        Text(NSLocalizedString("\($0)", comment: ""))
//                                    }
//                                }
//                                .onReceive([self.selectNgonNgu].publisher.first()) { (value) in
//                                   UserDefaults.standard.set(value, forKey: "language")
//
//                                }
//                            }
//                        }
                       
                       Section{
                           HStack {
                               Circle()
                                 .strokeBorder(Color("blue2"),lineWidth: 2)
                                 .background(Circle().foregroundColor(Color("blue2").opacity(0.2))).frame(width: 20, height: 20)
                              //Text("item1")
                               Picker(NSLocalizedString("target", comment: ""), selection: $selectMucDich) {
                                   ForEach(mucDich, id: \.self) {
                                      Text(NSLocalizedString("\($0)", comment: ""))
                                   }
//                                  Text("item1")
//                                  Text("item2")
//                                  Text("item3")
                               }
                               
                               .onReceive([self.selectMucDich].publisher.first()) { (value) in
                                  print("Muc dich: \(value)")
                                  UserDefaults.standard.set(value, forKey: "mdsetting")
                                  
                                  
                               }
                           }
                       }
                        
//                        Section{
//                            HStack {
//                                Circle()
//                                    .strokeBorder(variable.colorCircleDo,lineWidth: 2)
//                                    .background(Circle().foregroundColor(variable.colorCircleDo.opacity(0.2))).frame(width: 20, height: 20)
//
//                               Toggle(NSLocalizedString("khoa", comment: ""), isOn: $touchID)
//                                   .tint(variable.textColorPink)
//                                   .onChange(of: touchID) { value in
//                                      UserDefaults.standard.set(touchID, forKey: "touchID")
//                                   }
//
//                            }
//                        }
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow").opacity(0.2))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("rate", comment: ""), destination: URL(string: variable.link_app)!).foregroundColor(.black)
                                
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(variable.colorCircleTimBorder,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleTim.opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("more", comment: ""), destination: URL(string: variable.link_dev)!).foregroundColor(.black)
                                
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(Color.black,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleXam.opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("help", comment: ""), destination: URL(string: variable.link_facebook_message)!).foregroundColor(.black)
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(Color.black,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleXam.opacity(0.4))).frame(width: 20, height: 20)
                                Button(action: {
                                    self.showPrivacyPage = true
                                    
                                }) {
                                    Text(NSLocalizedString("privacy", comment: ""))
                                        .foregroundColor(.black)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                                NavigationLink(destination: Privacy(), isActive: $showPrivacyPage) { EmptyView() }
                                  .navigationBarTitle("", displayMode: .inline)
                                  .navigationBarBackButtonHidden(true)
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(Color.black,lineWidth: 2)
                                    .background(Circle().foregroundColor(variable.colorCircleXam.opacity(0.4))).frame(width: 20, height: 20)
                                Button(action: {
                                    self.showTermsPage = true
                                    
                                }) {
                                    Text(NSLocalizedString("dieuKhoan", comment: ""))
                                        .foregroundColor(.black)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                                NavigationLink(destination: Terms(), isActive: $showTermsPage) { EmptyView() }
                                  .navigationBarTitle("", displayMode: .inline)
                                  .navigationBarBackButtonHidden(true)
                            }
                        }
                        
                        Section{
                            HStack {
                                Circle()
                                  .strokeBorder(Color("bgRed3"),lineWidth: 2)
                                  .background(Circle().foregroundColor(Color("bgRed3").opacity(0.2))).frame(width: 20, height: 20)
                                
                                Button(action: {
                                    variable.deleteAllData()
                                    isActive = true
                                    //dismiss()
                                    //self.mucDich = 1
                                    
                                }) {
                                    Text(NSLocalizedString("Delete All Data", comment: ""))
                                        .foregroundColor(.red)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                            }
                        }
//                        NavigationLink(destination:
//                            ContentView()
//                        ) {
//                            EmptyView()
//                        }
                        
                    }.padding(.top, 1)
                    .navigationTitle(NSLocalizedString("setting", comment: ""))
                    .navigationBarTitleDisplayMode(.inline)
               
                   
                }//.navigationBarTitle(NSLocalizedString("setting", comment: ""), displayMode: .inline)
            }//.navigationBarTitle(NSLocalizedString("setting", comment: ""), displayMode: .inline)
            
//            VStack {
//                HStack {
//                    Spacer()
//                    Image("bg-top").resizable().scaledToFit()
//                        .frame(width: 130, height: 130, alignment: .top)
//                        .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? -20: -40)
//                }
//                Spacer()
//            }
        }
        .fullScreenCover(isPresented: $isActive, content: {
           ContentView(mydata: 0, mucDich: 0, tabSelection: 1)
        })
//        .navigationTitle("Setting") // Tiêu đề
//        .navigationBarTitleDisplayMode(.inline) // Hiển thị cố định
        //.navigationBarBackButtonHidden(true)
        .onAppear(){
           soLanUongThuoc = UserDefaults.standard.integer(forKey: "soLanUongThuoc")
           
           showNgayDau = UserDefaults.standard.bool(forKey: "showNgayDau")
           showNgayKetThuc = UserDefaults.standard.bool(forKey: "showNgayKetThuc")
           showNgayBatDauThuThai = UserDefaults.standard.bool(forKey: "showNgayBatDauThuThai")
           showNgayKetThucThuThai = UserDefaults.standard.bool(forKey: "showNgayKetThucThuThai")
           showNgayRungTrung = UserDefaults.standard.bool(forKey: "showNgayRungTrung")
           
           touchID = UserDefaults.standard.bool(forKey: "touchID")
           nhacUongNuoc = UserDefaults.standard.bool(forKey: "nhacUongNuoc")
           nhacUongThuoc = UserDefaults.standard.bool(forKey: "nhacUongThuoc")
           
           selectDonViTrongLuong = UserDefaults.standard.string(forKey: "donViTrongLuong") ?? "kg"
           selectDonViChieuCao = UserDefaults.standard.string(forKey: "donViChieuCao") ?? "cm"
           
           selectNgonNgu = UserDefaults.standard.string(forKey: "language") ?? "en"
           
           selectMucDich = UserDefaults.standard.string(forKey: "mdsetting") ?? ""
           if(selectMucDich == "") {
              if(UserDefaults.standard.integer(forKey: "mucdich") == 1) {
                 selectMucDich = "mucdich1"
              }else if(UserDefaults.standard.integer(forKey: "mucdich") == 2){
                 selectMucDich = "mucdich2"
              }else{
                 selectMucDich = "mucdich3"
              }
           }
           if(selectNgonNgu == "aa") {
              identifier = NSLocale.current.languageCode!
           } else{
              identifier = selectNgonNgu
           }
           
           print("Ngon ngu setting page: \(identifier)")
           
           //lay cac ngay dac biet trong thang
           let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
           
           if((periodData?.isEmpty) != nil) {
              let currentData = periodData![0]
              let arrCurrentData = currentData.components(separatedBy: "+")
              
              let dateFormatter = DateFormatter()
              dateFormatter.dateFormat = "dd-MM-yyyy"
              dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
              let result:Date = dateFormatter.date(from: arrCurrentData[0]) ?? Date()
              //let calendarDate = Calendar.current.dateComponents([.day, .year, .month], from: result)
              
              let resultBatDauThangSau = Calendar.current.date(byAdding: .day, value: Int(arrCurrentData[1])!, to: result)
              let calendarBatDauThangSau = Calendar.current.dateComponents([.day, .year, .month], from: resultBatDauThangSau!)
              
              let soNgayDenThang = Int(arrCurrentData[2])!
              let soNgayanToan1 = variable.tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!)
              let soNgayThuThai = variable.tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!)
              
              let resultKetThuc = Calendar.current.date(byAdding: .day, value: soNgayDenThang, to: result)
              let calendarKetThuc = Calendar.current.dateComponents([.day, .year, .month], from: resultKetThuc!)
              
              let resultBatDauthuThai = Calendar.current.date(byAdding: .day, value: soNgayanToan1, to: result)
              let calendarBatDauthuThai = Calendar.current.dateComponents([.day, .year, .month], from: resultBatDauthuThai!)
              
              let resultKetThucThuThai = Calendar.current.date(byAdding: .day, value: soNgayThuThai, to: result)
              let calendarKetThucThuThai = Calendar.current.dateComponents([.day, .year, .month], from: resultKetThucThuThai!)
              
              let resultRungTrung = Calendar.current.date(byAdding: .day, value: variable.tinhNgayRungTrungTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!), to: result)
              let calendarRungTrung = Calendar.current.dateComponents([.day, .year, .month], from: resultRungTrung!)

              print("Setting: calendar period")
              print(calendarBatDauThangSau.day!)
              print(soNgayDenThang)
              
              namDauToiThang = calendarBatDauThangSau.year!
              thangDauToiThang = calendarBatDauThangSau.month!
              ngayDauToiThang = calendarBatDauThangSau.day! - 1
              print("set Ngay toi thang: \(namDauToiThang)-\(thangDauToiThang)-\(ngayDauToiThang)")
              
              namKetThuc = calendarKetThuc.year!
              thangKetThuc = calendarKetThuc.month!
              ngayKetThuc = calendarKetThuc.day! - 1
              //print("set Ngay ket thuc toi thang: \(namKetThuc)-\(thangKetThuc)-\(ngayKetThuc)")
              
              namBatDauThuThai = calendarBatDauthuThai.year!
              thangBatDauThuThai = calendarBatDauthuThai.month!
              ngayBatDauThuThai = calendarBatDauthuThai.day! - 1
              print("set Ngay bat dau thu thai: \(namBatDauThuThai)-\(thangBatDauThuThai)-\(ngayBatDauThuThai)")
              
              namRungTrung = calendarRungTrung.year!
              thangRungTrung = calendarRungTrung.month!
              ngayRungTrung = calendarRungTrung.day! - 1
              //print("set Ngay rung trung: \(namRungTrung)-\(thangRungTrung)-\(ngayRungTrung)")
              
              namKetThucThuThai = calendarKetThucThuThai.year!
              thangKetThucThuThai = calendarKetThucThuThai.month!
              ngayKetThucThuThai = calendarKetThucThuThai.day! - 2
              //print("set Ngay ket thuc thu thai: \(namKetThucThuThai)-\(thangKetThucThuThai)-\(ngayKetThucThuThai)")
           }
        }
        .environment(\.locale, .init(identifier: identifier))
        .edgesIgnoringSafeArea(.all)

            .tabItem{
               Image(systemName: "ellipsis.circle")
                   .font(.system(size: 26))
                   //.frame(width: 100, height: 100)
                  
            }
            .tag(4)
    }
}
struct Setting_Previews: PreviewProvider {
    static var previews: some View {
        Setting()
    }
}
