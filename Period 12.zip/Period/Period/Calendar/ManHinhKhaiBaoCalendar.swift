//
//  ManHinhKhaiBaoCalendar.swift
//  Period - BMI
//
//  Created by Huy Le on 19/06/2022.
//

import SwiftUI
import SwiftUICalendar

struct ManHinhKhaiBaoCalendar: View {
   
   // Start & End date should be configured based on your needs.
   let variable = Variable()
   @ObservedObject var controller = CalendarController(orientation: .vertical)
       var informations = [YearMonthDay: [(Int)]]()
       @State var focusDate: YearMonthDay? = nil
       @State var focusInfo: [(String, Color)]? = nil
      
   let dateFormatter = DateFormatter()
   let defaults = UserDefaults.standard
  
   @State var currentDate: YearMonthDay = YearMonthDay.current
   
   @State private var willMoveToNextScreen = false
   
       init() {
          dateFormatter.dateFormat = "yyyy-MM-dd"
         
          //var date = YearMonthDay.current
//           informations[date] = []
//           informations[date]?.append((1))
          
       }
   
    var body: some View {
        ZStack{
            
            
            VStack{
               VStack {
                   HStack {
                       Spacer()
                       Image("bg-top").resizable().scaledToFit()
                           .frame(width: 130, height: 100, alignment: .top)
                           
                   }
                  
               }.edgesIgnoringSafeArea(.all)
               HStack {
                   Text(NSLocalizedString("calendar", comment: "")).padding(.leading, 0)
                     .font(Font.custom("NunitoSans-Bold", size: 37))
                     .foregroundColor(variable.textColorPink)
                     //.multilineTextAlignment(.center)
                   //Spacer()
               }
               .padding(.bottom, variable.getRatioScreen() > 1.8 ? 30 : 5)
               .padding(.top, variable.getRatioScreen() > 1.8 ? -50 : -80)
               
               
               GeometryReader { reader in
                  VStack (alignment: .leading){
                     
                     Text("\(controller.yearMonth.monthShortString.capitalizingFirstLetter()), \(String(controller.yearMonth.year))")
                        .font(Font.custom("comfortaa", size: 22))
                        .textCase(.uppercase)
                        .padding(EdgeInsets(top: 8, leading: 10, bottom: 0, trailing: 0))
                     
                      CalendarView(controller, header: { week in
                         
                          GeometryReader { geometry in
                              Text(week.shortString)
                                .font(.custom("comfortaa.ttf", size: 19))
                                //.textCase(.uppercase)
                                  .frame(width: geometry.size.width, height: geometry.size.height, alignment: .center)
                          }
                      }, component: { date in
                          GeometryReader { geometry in
                              VStack(alignment: .center, spacing: 2) {
                                 if date.isToday {
                                     Text("\(date.day)")
                                         .font(Font.custom("comfortaa", size: 17))
                                       
                                         .padding(4)
                                         .padding(.bottom, 3)
                                         .padding(.top, 42)
                                         .foregroundColor(.black)
                                         //.background(Color.red.opacity(0.75))
                                         .cornerRadius(14)
                                         .frame(maxWidth: .infinity, alignment: .center)
                                         
                                    Circle()
                                        .strokeBorder(Color.blue,lineWidth: 0)
                                        .background(Circle())
                                        .foregroundColor(variable.textColorPink)
                                           .frame(width: 38, height: 38)
                                           .opacity(0.4)
                                           .offset(x: 0, y: -38)
                                    
                                 } else {
                                     Text("\(date.day)")
                                         //.font(.system(size: 18, weight: .semibold, design: .default))
                                         .font(Font.custom("comfortaa", size: 17))
                                         .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                         .foregroundColor(.black.opacity(0.7))
                                         .frame(maxWidth: .infinity, alignment: .center)
                                         .padding(4)
                                         .padding(.bottom, 3)
                                         .padding(.top, 42)
                                 }
                                 //
                                 if(dateFormatter.date(from: String(date.year) + "-" + String(date.month) + "-" + String(date.day)) ?? Date() <= Date()){
                                    
                                    if date.isToday {
                                       Circle()
                                          .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                           .background(Circle()
                                             .foregroundColor(focusDate == date ? variable.textColorPink: .white))
                                              .frame(width: 15, height: 15)
                                              .offset(x: 0, y: -38)
                                    }else{
                                       Circle()
                                          .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                           .background(Circle()
                                             .foregroundColor(focusDate == date ? variable.textColorPink: .white))
                                              .frame(width: 15, height: 15)
                                    }
                                 }
//                                 else{
//
//                                 }
                              }
//                              .frame(width: geometry.size.width, alignment: .center)//height: geometry.size.height,
//                              .border(.green.opacity(0.8), width: (focusDate == date ? 1 : 0))
//                              .cornerRadius(2)
//                              .contentShape(Rectangle())
                              .onTapGesture {
                                  withAnimation {
                                      if focusDate == date {
                                          focusDate = nil
                                          focusInfo = nil
                                      } else {
                                          focusDate = date
                                          //focusInfo = informations[date]
                                         //print(focusDate?.day)
                                         
                                         //print(dateFormatter.date(from: String(date.year) + "-" + String(date.month) + "-" + String(date.day)) ?? Date())
                                        
                                         
                                         
                                      }
                                  }
                              }
                          }
                      })
//                               if let infos = focusInfo {
//                                   List(infos.indices, id: \.self) { index in
//                                       let info = infos[index]
//                                       HStack(alignment: .center, spacing: 0) {
//                                           Circle()
//                                               .fill(info.1.opacity(0.75))
//                                               .frame(width: 12, height: 12)
//                                           Text(info.0)
//                                               .padding(.leading, 8)
//                                       }
//                                   }
//                                   .frame(width: reader.size.width, height: 160, alignment: .center)
//                               }
                  }
                  .frame(width: reader.size.width, height: reader.size.width * 1.2, alignment: .center)
                  
                  
                  
               }
               .padding(.top, variable.getRatioScreen() > 1.8 ? 0 : -20)
               
               Spacer()
               
              VStack{
                 Button(action: {
                     //self.redirectToHomeView = true
                    if(focusDate?.day != nil){
                       defaults.set(1, forKey: "khaibao")
                       defaults.set(focusDate?.day, forKey: "khaibao-ngay")
                       defaults.set(focusDate?.month, forKey: "khaibao-thang")
                       defaults.set(focusDate?.year, forKey: "khaibao-nam")
                       willMoveToNextScreen = true
                    }
                    //print(focusDate?.day)
                    //print(focusDate?.month)
                    
                     }) {
                         Text(NSLocalizedString("Select", comment: ""))
                             .frame(minWidth: 0, maxWidth: 200)
                             .font(.custom("comfortaa.ttf", size: 22))
                             .padding()
                             .foregroundColor(.white)
                             .overlay(
                                 RoundedRectangle(cornerRadius: 20)
                                     .stroke(Color.white, lineWidth: 2)
                         )
                     }
                     .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                          ContentView(mydata: 0, mucDich: 2)
                      })
                     .background(variable.textColorPink) // If you have this
                     .cornerRadius(20)         // You also need the cornerRadius here
              }
            }
            //.navigate(to: ContentView(mydata: 0, mucDich: 2), when: $willMoveToNextScreen)
            .environment(\.colorScheme, .light).preferredColorScheme(.light)
            
        }.tabItem{
            Image(systemName: "calendar").font(.system(size: 26))
           
        }
        
    }
   private func getColor(_ date: YearMonthDay) -> Color {
//           if date.dayOfWeek == .sun {
//               return Color.red
//           } else if date.dayOfWeek == .sat {
//               return Color.blue
//           } else {
//               return Color.black
//           }
      
      return Color.black.opacity(0.7)
       }
}




struct ManHinhKhaiBaoCalendar_Previews: PreviewProvider {
    static var previews: some View {
        ManHinhKhaiBaoCalendar()
    }
}
