//
//  HomeThongBao.swift
//  Period - BMI
//
//  Created by Huy Le on 14/08/2022.
//
import SwiftUI
struct HomeThongBao: View {
   @Environment(\.scenePhase) var scenePhase
   
   @State var giaiDoan = 0
   
    var body: some View {
       VStack{
          switch UserDefaults.standard.string(forKey: "mdsetting") {
           case "mucdich1":
         
             switch giaiDoan {
              case 0:
               //giai doan den thang
                 Text(NSLocalizedString("dangtoithang", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                HStack{
                   if(variable.isChina() == true) {
                      Text("第").padding(1).padding(.top, -10)
                          .font(.custom("NunitoSans-Bold", size: 28))
                          .foregroundColor(Color.white)
                      Text("\(variable.convertToChinaNumber(n: variable.getSoNgayConLai()))").padding(1).padding(.top, -10)
                          .font(.custom("NunitoSans-Bold", size: 28))
                          .foregroundColor(Color.white)
                      Text("天").padding(1).padding(.top, -10)
                          .font(.custom("NunitoSans-Bold", size: 28))
                          .foregroundColor(Color.white)
                   }else{
                      Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -10)
                          .font(.custom("NunitoSans-Bold", size: 28))
                          .foregroundColor(Color.white)
                      Text("\(variable.getSoNgayConLai())").padding(1).padding(.top, -10)
                          .font(.custom("NunitoSans-Bold", size: 28))
                          .foregroundColor(Color.white)
                   }
                 }
                 Text(NSLocalizedString("coHoiMangThaiThap", comment: "")).padding(0)
                   .font(.custom("NunitoSans-Bold", size: NSLocale.current.languageCode! == "de" ? 12 : 16))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
              case 1:
               //giai doan an toan 1
                 Text(NSLocalizedString("coHoiMangThai", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
                 Text(NSLocalizedString("thap", comment: "")).padding(1).padding(.top, -5)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
                     
              case 2:
               //giai doan thu thai truoc rung trung
                 Text(NSLocalizedString("rungTrungTrong", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                 
                 HStack{
                    
                    if(variable.getSoNgayChuanBiRungTrung() == 1) {
                       
                       Text(NSLocalizedString("ngaymai", comment: "")).padding(1).padding(.top, -5)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }else{
                       if(variable.isChina() == true) {
                         
                          Text("\(variable.convertToChinaNumber(n: variable.getSoNgayChuanBiRungTrung()))").padding(1).padding(.top, -10)
                              .font(.custom("NunitoSans-Bold", size: 28))
                              .foregroundColor(Color.white)
                          Text("天").padding(1).padding(.top, -10)
                              .font(.custom("NunitoSans-Bold", size: 28))
                              .foregroundColor(Color.white)
                       }else{
                          Text("\(variable.getSoNgayChuanBiRungTrung())").padding(1).padding(.top, -5)
                              .font(.custom("NunitoSans-Bold", size: 28))
                              .foregroundColor(Color.white)
                          if(variable.getSoNgayChuanBiRungTrung() > 1 ) {
                             Text(NSLocalizedString("Ngays", comment: "")).padding(1).padding(.top, -5)
                                 .font(.custom("NunitoSans-Bold", size: 28))
                                 .foregroundColor(Color.white)
                          }else{
                             Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -5)
                                 .font(.custom("NunitoSans-Bold", size: 28))
                                 .foregroundColor(Color.white)
                          }
                       }
                       
                    }
                 }
                 Text(NSLocalizedString("coHoiMangThaiCao", comment: "")).padding(0)
                   .font(.custom("NunitoSans-Bold", size: NSLocale.current.languageCode! == "de" ? 13 : 16))
                     .foregroundColor(Color.white)
              case 3:
               //giai doan rung trung
                 Text(NSLocalizedString("rungTrung", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 25))
                     .foregroundColor(Color.white)
                     .padding(.bottom, 5)
                 Text(NSLocalizedString("coHoiMangThai2", comment: "")).padding(0)
                   .font(.custom("NunitoSans-Bold", size: NSLocale.current.languageCode! == "de" ? 14 : 16))
                     .foregroundColor(Color.white)
                 Text(NSLocalizedString("cao", comment: "")).padding(1).padding(.top, -5)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
                    
              case 4:
               //giai doan thu thai sau rung trung
                 Text(NSLocalizedString("coHoiMangThai", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
                 
                 Text(NSLocalizedString("cao", comment: "")).padding(1).padding(.top, -5)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
                 
              case 5:
               //giai doan thu thai sau rung trung
                 Text(NSLocalizedString("tre", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                 
                 HStack{
                    Text("\(variable.ngayTre())").padding(1).padding(.top, -10)
                        .font(.custom("NunitoSans-Bold", size: 28))
                        .foregroundColor(Color.white)
                    if(variable.ngayTre() > 1) {
                       Text(NSLocalizedString("Ngays", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }else{
                       Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }
                    
                 }
                 Text(NSLocalizedString("ghilaichuky", comment: "")).padding(0)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
              
              default:
                 Text(NSLocalizedString("coHoiMangThaiCao", comment: "")).padding(0)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
              }
           case "mucdich2":
              switch variable.getGiaiDoan() {
              case 0:
               //giai doan den thang
                 Text(NSLocalizedString("ketthuckykinh", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                 
                 HStack{
                    Text("\(variable.getSoNgayConLaiTranhThai())").padding(1).padding(.top, -10)
                        .font(.custom("NunitoSans-Bold", size: 28))
                        .foregroundColor(Color.white)
                    if(variable.getSoNgayConLaiTranhThai() > 1) {
                       Text(NSLocalizedString("Ngays", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }else{
                       Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }
                 }
              case 1:
               //giai doan an toan 1
                
                 Text(NSLocalizedString("coHoiMangThai", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
                 Text(NSLocalizedString("thap", comment: "")).padding(1).padding(.top, -10)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
                    
              case 2:
               //giai doan thu thai truoc rung trung
                 Text(NSLocalizedString("coHoiMangThai", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
                     .padding(.bottom, 3)
                 
                 Text(NSLocalizedString("cao", comment: "")).padding(1).padding(.top, -10)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
                 
                 Text(NSLocalizedString("nendungtranhthai", comment: "")).padding(0)
                                 .font(.custom("NunitoSans-Bold", size: 14))
                                 .foregroundColor(Color.white)
              case 3:
               //giai doan rung trung
                 Text(NSLocalizedString("rungTrung", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 25))
                     .foregroundColor(Color.white)
                     .padding(.bottom, 15)
                 Text(NSLocalizedString("nendungtranhthai", comment: "")).padding(1).padding(.top, -10)
                     .font(.custom("NunitoSans-Bold", size: 14))
                     .foregroundColor(Color.white)
              case 4:
               //giai doan thu thai sau rung trung
                 Text(NSLocalizedString("coHoiMangThai", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
                     .padding(.bottom, 3)
                 
                 Text(NSLocalizedString("cao", comment: "")).padding(1).padding(.top, -10)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
                 Text(NSLocalizedString("nendungtranhthai", comment: "")).padding(0)
                                 .font(.custom("NunitoSans-Bold", size: 14))
                                 .foregroundColor(Color.white)
              case 5:
               //giai doan thu thai sau rung trung
                 Text(NSLocalizedString("tre", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                 
                 HStack{
                    Text("\(variable.ngayTre())").padding(1).padding(.top, -10)
                        .font(.custom("NunitoSans-Bold", size: 28))
                        .foregroundColor(Color.white)
                    if(variable.ngayTre() > 1) {
                       Text(NSLocalizedString("Ngays", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }else{
                       Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }
                 }
                 Text(NSLocalizedString("ghilaichuky", comment: "")).padding(0)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
              default:
                 Text(NSLocalizedString("coHoiMangThaiCao", comment: "")).padding(0)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
              }
           case "mucdich3":
              switch variable.getGiaiDoan() {
              case 0:
               //giai doan den thang
                 Text(NSLocalizedString("dangtoithang", comment: "")).padding(0).padding(.top, 15)
                    //.padding(.bottom, 1)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                 //Text(String(format: NSLocalizedString(""Ngayf", comment: "")), ))
                 HStack{
                   
                    if(variable.isChina() == true) {
                       Text("第").padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                       Text("\(variable.convertToChinaNumber(n: variable.getSoNgayConLai()) )").padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                       Text("天").padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }else{
                       Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                       Text("\(variable.getSoNgayConLai())").padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }
                 }
                 
                 Text(NSLocalizedString("coHoiMangThaiThap", comment: "")).padding(0)
                    .font(.custom("NunitoSans-Bold", size: NSLocale.current.languageCode! == "de" ? 12 : 16))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
              case 1:
               //giai doan an toan 1
                
                 Text(NSLocalizedString("coHoiMangThai", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
                 Text(NSLocalizedString("thap", comment: "")).padding(1).padding(.top, -10)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
              case 2:
               //giai doan thu thai truoc rung trung
                 Text(NSLocalizedString("rungTrungTrong", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                 
                 HStack{
                    
                    if(variable.getSoNgayConLai() == 1) {
                       
                       Text(NSLocalizedString("ngaymai", comment: "")).padding(1).padding(.top, -5)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }else{
                       if(variable.isChina() == true) {
                         
                          Text("\(variable.convertToChinaNumber(n: variable.getSoNgayConLai()))").padding(1).padding(.top, -10)
                              .font(.custom("NunitoSans-Bold", size: 28))
                              .foregroundColor(Color.white)
                          Text("天").padding(1).padding(.top, -10)
                              .font(.custom("NunitoSans-Bold", size: 28))
                              .foregroundColor(Color.white)
                       }else{
                          Text("\(variable.getSoNgayConLai())").padding(1).padding(.top, -5)
                              .font(.custom("NunitoSans-Bold", size: 28))
                              .foregroundColor(Color.white)
                          if(variable.getSoNgayConLai() > 1 ) {
                             Text(NSLocalizedString("Ngays", comment: "")).padding(1).padding(.top, -5)
                                 .font(.custom("NunitoSans-Bold", size: 28))
                                 .foregroundColor(Color.white)
                          }else{
                             Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -5)
                                 .font(.custom("NunitoSans-Bold", size: 28))
                                 .foregroundColor(Color.white)
                          }
                       }
                    }
                 }
                 
                 Text(NSLocalizedString("coHoiMangThaiCao", comment: "")).padding(0)
                    .font(.custom("NunitoSans-Bold", size: NSLocale.current.languageCode! == "de" ? 13 : 17))
                     .foregroundColor(Color.white)
              case 3:
               //giai doan rung trung
                 Text(NSLocalizedString("rungTrung", comment: "")).padding(3).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 25))
                     .foregroundColor(Color.white)
                     
                 Text(NSLocalizedString("coHoiMangThai2", comment: "")).padding(0)
                    .font(.custom("NunitoSans-Bold", size: NSLocale.current.languageCode! == "de" ? 13 : 15))
                     .foregroundColor(Color.white)
                 Text(NSLocalizedString("cao", comment: "")).padding(1).padding(.top, -5)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
              case 4:
               //giai doan thu thai sau rung trung
                 Text(NSLocalizedString("coHoiMangThai", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                     .multilineTextAlignment(.center)
                 
                 Text(NSLocalizedString("cao", comment: "")).padding(1).padding(.top, -10)
                     .font(.custom("NunitoSans-Bold", size: 28))
                     .foregroundColor(Color.white)
              case 5:
               //giai doan thu thai sau rung trung
                 Text(NSLocalizedString("tre", comment: "")).padding(0).padding(.top, 15)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
                 HStack{
                    Text("\(variable.ngayTre())").padding(1).padding(.top, -10)
                        .font(.custom("NunitoSans-Bold", size: 28))
                        .foregroundColor(Color.white)
                    if(variable.ngayTre() > 1) {
                       Text(NSLocalizedString("Ngays", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }else{
                       Text(NSLocalizedString("Ngay", comment: "")).padding(1).padding(.top, -10)
                           .font(.custom("NunitoSans-Bold", size: 28))
                           .foregroundColor(Color.white)
                    }
                 }
                 Text(NSLocalizedString("ghilaichuky", comment: "")).padding(0)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
              default:
                 Text(NSLocalizedString("coHoiMangThaiCao", comment: "")).padding(0)
                     .font(.custom("NunitoSans-Bold", size: 17))
                     .foregroundColor(Color.white)
              }
           default:
              Text(NSLocalizedString("coHoiMangThaiCao", comment: "")).padding(0)
                  .font(.custom("NunitoSans-Bold", size: 17))
                  .foregroundColor(Color.white)
           }
       }
       .onChange(of: scenePhase) { phase in
           if phase == .active {
              giaiDoan = variable.getGiaiDoan()
              
           }
        }
       .onAppear(){
          giaiDoan = variable.getGiaiDoan()
       }
    }
      
}

struct HomeThongBao_Previews: PreviewProvider {
    static var previews: some View {
        HomeThongBao()
    }
}
