//
//  SelectTamTrang.swift
//  Period - BMI
//
//  Created by Huy Le on 18/4/25.
//

import SwiftUI
import GoogleMobileAds

struct SelectTamTrang: View {
   let variable = Variable()
    @StateObject private var viewModel = MoodViewModel()
    //var ads: Interstitial?
   @State private var willMoveToNextScreen = false
   @Environment(\.presentationMode) var presentationMode
    init(){
        //ads = Interstitial()
        //ads?.loadInterstitial()
    }
    var body: some View {
        ZStack {
            VStack {
                Text(NSLocalizedString("homnaybanthenao", comment: ""))
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .font(.custom("NunitoSans-Bold", size: 27))
                    .foregroundColor(variable.textColorPink)
                    .padding(.vertical, variable.getRatioScreen() > 1.8 ? 40: 20)
                Button(action: {
                    viewModel.addMoods(1)
                    //ads?.showAd()
                    willMoveToNextScreen = true
                }) {
                    HStack {
                        Image("rat-de-chiu")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70, height: 70)
                            .padding(.leading, 20)
                        Text(NSLocalizedString("ratdechiu", comment: ""))
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .font(.custom("NunitoSans-Bold", size: 17))
                            .padding(.vertical, variable.getRatioScreen() > 1.8 ? 40: 33)
                            .foregroundColor(.black)
                            .opacity(0.8)
                        
                        Spacer()
                            .frame(width: 90)
                    }
                }
                .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                    ContentView(mydata: 0, mucDich: 0)
                })
                
                .background(
                    Image("flower")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .padding(.trailing, 20)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                            .opacity(0.1)
                )
                .background(Color("tamTrang1"))
                .cornerRadius(50)
                .padding(.bottom, 20)
                
                Button(action: {
                    viewModel.addMoods(2)
                    //ads?.showAd()
                    willMoveToNextScreen = true
                }) {
                    HStack {
                        Image("de-chiu")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70, height: 70)
                            .padding(.leading, 20)
                        Text(NSLocalizedString("dechiu", comment: ""))
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .font(.custom("NunitoSans-Bold", size: 17))
                            .padding(.vertical, variable.getRatioScreen() > 1.8 ? 40: 33)
                            .foregroundColor(.black)
                            .opacity(0.8)
                        
                        Spacer()
                            .frame(width: 90)
                    }
                }
                .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                    ContentView(mydata: 0, mucDich: 0)
                })
                
                .background(
                    Image("flower2")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .padding(.trailing, 70)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                            .opacity(0.1)
                )
                .background(Color("tamTrang2"))
                .cornerRadius(50)
                .padding(.bottom, 20)
                Button(action: {
                    viewModel.addMoods(3)
                    //ads?.showAd()
                    willMoveToNextScreen = true
                }) {
                    HStack {
                        Image("binh-thuong")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70, height: 70)
                            .padding(.leading, 20)
                        Text(NSLocalizedString("binhthuong", comment: ""))
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .font(.custom("NunitoSans-Bold", size: 17))
                            .padding(.vertical, variable.getRatioScreen() > 1.8 ? 40: 33)
                            .foregroundColor(.black)
                            .opacity(0.8)
                        
                        Spacer()
                            .frame(width: 90)
                    }
                }
                .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                    ContentView(mydata: 0, mucDich: 0)
                })
                
                .background(
                    Image("flower3")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 130)
                            .padding(.trailing, 60)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                            .opacity(0.1)
                )
                .background(Color("tamTrang3"))
                .cornerRadius(50)
                .padding(.bottom, 20)
                
                Button(action: {
                    viewModel.addMoods(4)
                    willMoveToNextScreen = true
                }) {
                    HStack {
                        Image("kho-chiu")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70, height: 70)
                            .padding(.leading, 20)
                        Text(NSLocalizedString("khochiu", comment: ""))
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .font(.custom("NunitoSans-Bold", size: 17))
                            .padding(.vertical, variable.getRatioScreen() > 1.8 ? 40: 33)
                            .foregroundColor(.black)
                            .opacity(0.8)
                        
                        Spacer()
                            .frame(width: 90)
                    }
                }
                .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                    ContentView(mydata: 0, mucDich: 0)
                })
                
                .background(
                    Image("flower4")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 140)
                            .padding(.trailing, 40)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                            .opacity(0.1)
                )
                .background(Color("tamTrang4"))
                .cornerRadius(50)
                .padding(.bottom, 20)
                
                Button(action: {
                    viewModel.addMoods(5)
                    willMoveToNextScreen = true
                }) {
                    HStack {
                        Image("rat-kho-chiu")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70, height: 70)
                            .padding(.leading, 20)
                        Text(NSLocalizedString("ratkhochiu", comment: ""))
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .font(.custom("NunitoSans-Bold", size: 17))
                            .padding(.vertical, variable.getRatioScreen() > 1.8 ? 40: 30)
                            .foregroundColor(.black)
                            .opacity(0.8)
                        
                        Spacer()
                            .frame(width: 90)
                    }
                }
                .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                    ContentView(mydata: 0, mucDich: 0)
                })
                
                .background(
                    Image("flower5")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 140)
                            .padding(.trailing, 30)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                            .opacity(0.1)
                )
                .background(Color("tamTrang5"))
                .cornerRadius(50)
                .padding(.bottom, 20)
                
                
                Spacer()
            }
        }
        .padding(.vertical, 20)
        .padding(.horizontal, 20)
        //.navigate(to: ContentView(mydata: 0, mucDich: 0), when: $willMoveToNextScreen)
         .environment(\.colorScheme, .light).preferredColorScheme(.light)
    }
}

struct SelectTamTrang_Previews: PreviewProvider {
    static var previews: some View {
        SelectTamTrang()
    }
}

