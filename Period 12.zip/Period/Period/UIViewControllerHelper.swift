import UIKit
import SwiftUI

struct ViewControllerHelper: UIViewControllerRepresentable {
    class Coordinator {
        var parent: ViewControllerHelper
        init(parent: ViewControllerHelper) { self.parent = parent }

        func showAd() {
            if let rootVC = UIApplication.shared.windows.first?.rootViewController {
                AppOpenAdManager.shared.showAdIfAvailable(from: rootVC)
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIViewController {
        let viewController = UIViewController()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { // Đợi 1 giây để đảm bảo UI đã sẵn sàng
            context.coordinator.showAd()
        }
        return viewController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
}
