//
//  BMI.swift
//  Period - BMI
//
//  Created by Huy Le on 20/06/2022.
//

import SwiftUI

struct BMI: View {
   let variable = Variable()
   @State private var willMoveToNextScreen = false
   
   @State private var canNang = "50"
   
   @State private var chieuCao = "160"
   
   @Environment(\.presentationMode) var presentationMode
   
   init() {
      
   }
    var body: some View {
       ZStack{
          VStack {
              HStack {
                  Spacer()
                  Image("bg-top").resizable().scaledToFit()
                      .frame(width: 130, height: 130, alignment: .top)
                      .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? 0: -40)
              }
              Spacer()

              HStack {
                  
                  Image("bg-bottom").resizable().scaledToFill()
                      .frame(width: 100, height: 100)
                  Spacer()
              }
          }.edgesIgnoringSafeArea(.all)
          VStack{
             Spacer().frame(height: 30)
             VStack{
                HStack {
                    Text(NSLocalizedString("chiso", comment: "")).padding(.leading, 30)
                        .font(.custom("NunitoSans-Bold", size: 25))
                        .foregroundColor(variable.textColor)
                    Spacer()
                }.padding(.bottom, 1)
                 HStack {
                     Text(NSLocalizedString("titleBMI1", comment: "")).padding(.leading, 30)
                         .font(.custom("NunitoSans-Bold", size: 37))
                         .foregroundColor(variable.textColorPink)
                     
                     Spacer()
                 }.padding(.top, -5)
                 
             }
            VStack{
               VStack(alignment: .leading) {
                  HStack {
                     Text(NSLocalizedString("cannang", comment: "") + " (" + (UserDefaults.standard.string(forKey: "donViTrongLuong") ?? "kg") + ")")
                          .font(.custom("comfortaa.ttf", size: 18))
                          .foregroundColor(variable.textColor)
                      
                      Spacer()
                  }.padding(.top, 25)
                   HStack {
                      TextField("50", text: $canNang).keyboardType(.decimalPad)
                      Spacer()
                      Image("weight-2").resizable()
                          .frame(width: 30, height: 30, alignment: .center)
                          .offset(x: 0, y: 2)
                   }.modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
               }
                  .padding(.leading, 30)
                  .padding(.trailing, 30)

            }
             
             VStack{
                VStack(alignment: .leading) {
                   HStack {
                       Text(NSLocalizedString("chieucao", comment: "") + " (" + (UserDefaults.standard.string(forKey: "donViChieuCao") ?? "cm") + ")")
                           .font(.custom("comfortaa.ttf", size: 18))
                           .foregroundColor(variable.textColor)
                       
                       Spacer()
                   }.padding(.top, 25)
                    HStack {
                       TextField("160", text: $chieuCao).keyboardType(.decimalPad)
                       Spacer()
                       Image("rule").resizable()
                           .frame(width: 30, height: 30, alignment: .center)
                           .offset(x: 0, y: 2)
                    }.modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
                }
                   .padding(.leading, 30)
                   .padding(.trailing, 30)

             }
             Spacer()
             VStack{
                HStack {
                   if(NSLocale.current.languageCode! == "en") {
                      Text("We calculate and evaluate BMI index based on this [source](https://en.wikipedia.org/wiki/Body_mass_index).")
                          //.frame(minWidth: 0, maxWidth: 200)
                          .font(.custom("comfortaa.ttf", size: 14))
                          .padding(30)
                          .padding(.bottom, -40)
                          .padding(.top, 0)
                          .foregroundColor(.black.opacity(0.8))
                          .multilineTextAlignment(.center)
                   }else if(NSLocale.current.languageCode! == "zh") {
                      Text("BMI是根据这里的文章计算的 [source](https://en.wikipedia.org/wiki/Body_mass_index).")
                      //.frame(minWidth: 0, maxWidth: 200)
                         .font(.custom("comfortaa.ttf", size: 14))
                         .padding(30)
                         .padding(.bottom, -40)
                         .padding(.top, 0)
                         .foregroundColor(.black.opacity(0.8))
                         .multilineTextAlignment(.center)
                      
                   }else if(NSLocale.current.languageCode! == "de") {
                         Text("Wir berechnen und bewerten den BMI-Index basierend auf diesem [Quelle](https://en.wikipedia.org/wiki/Body_mass_index).")
                         //.frame(minWidth: 0, maxWidth: 200)
                            .font(.custom("comfortaa.ttf", size: 14))
                            .padding(30)
                            .padding(.bottom, -40)
                            .padding(.top, 0)
                            .foregroundColor(.black.opacity(0.8))
                            .multilineTextAlignment(.center)
                   }else{
                      Text("Chỉ số BMI được tính dựa theo cơ sở trong bài viết tại [đây](https://en.wikipedia.org/wiki/Body_mass_index).")
                          //.frame(minWidth: 0, maxWidth: 200)
                          .font(.custom("comfortaa.ttf", size: 14))
                          .padding(30)
                          .padding(.top, 0)
                          .padding(.bottom, -40)
                          .foregroundColor(.black.opacity(0.8))
                          .multilineTextAlignment(.center)
                   }
                }
                HStack{
                   Button(action: {
                      if(canNang.trimmingCharacters(in: .whitespacesAndNewlines) != "" && chieuCao.trimmingCharacters(in: .whitespacesAndNewlines) != "") {
                         var canNangDb = Double(canNang) ?? 0
                         var chieuCaoDb = Double(chieuCao) ?? 0
                          
                         if canNangDb > 0 && chieuCaoDb > 0 {
                            //convert lbs -> Kg; ft -> cm
                            let donViTrongLuong = UserDefaults.standard.string(forKey: "donViTrongLuong") ?? "kg"
                            let donViChieuCao = UserDefaults.standard.string(forKey: "donViChieuCao") ?? "cm"
                            
                            if(donViTrongLuong != "kg") {
                               canNangDb = canNangDb * 0.4536
                            }
                            
                            if(donViChieuCao != "cm") {
                               chieuCaoDb = chieuCaoDb * 30.48
                            }
                            let dateF = DateFormatter()
                            dateF.dateStyle = .short
                            let today = Date()
                            let bmiData = UserDefaults.standard.string(forKey: "bmi_data") ?? ""
                            let bmiIndex = round(canNangDb * 100000 / chieuCaoDb / chieuCaoDb) / 10
                            if(bmiIndex > 0) {
                               let newData = dateF.string(from: today) + "+" + String(bmiIndex)
                               if(bmiData == "") {
                                  UserDefaults.standard.set(newData, forKey: "bmi_data")
                               }
                               else{
                                  UserDefaults.standard.set(newData + "-" + bmiData, forKey: "bmi_data")
                               }
                            }
                            
          //                  print("check can nang - chieu cao")
          //                  print(canNang)
          //                  print(chieuCao)
          //                  print(newData)
          //
                            
                            //withAnimation(.easeOut(duration:0.5)){
                               willMoveToNextScreen = true
                            //}
                         }
                      }//if canNang? != 0 and chieuCao? != 0 {
                          }) {
                              Text(NSLocalizedString("done", comment: ""))
                                  .frame(minWidth: 0, maxWidth: 200)
                                  .font(.custom("comfortaa.ttf", size: 22))
                                  .padding(variable.getRatioScreen() > 1.8 ? 15 : 9)
                                  .foregroundColor(.white)
                                  .overlay(
                                      RoundedRectangle(cornerRadius: 20)
                                          .stroke(Color.white, lineWidth: 2)
                              )
                          }
                          .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                               ContentView(mydata: 0, mucDich: 0)
                           })
                          .background(variable.textColorPink)
                          .cornerRadius(20)
                      
                      
                    Button(action: {
                       self.presentationMode.wrappedValue.dismiss()
                       
                        }) {
                            Text("cancel")
                                .frame(minWidth: 0, maxWidth: 180)
                                .font(.custom("comfortaa.ttf", size: 22))
                                .padding(variable.getRatioScreen() > 1.8 ? 15 : 9)
                                .foregroundColor(variable.textColorPinkBorder)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white, lineWidth: 2)
                            )
                        }
                        .background(variable.textColorPink.opacity(0.15))
                        .cornerRadius(20)
                }
                .padding(30)
            }
             Spacer()
          }
       }
         //.navigate(to: ContentView(mydata: 0, mucDich: 0), when: $willMoveToNextScreen)
         .environment(\.colorScheme, .light).preferredColorScheme(.light)
    }
}

struct BMI_Previews: PreviewProvider {
    static var previews: some View {
        BMI()
    }
}

extension TextField {
    
    func extensionTextFieldView(roundedCornes: CGFloat, startColor: Color,  endColor: Color) -> some View {
        self
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [startColor, endColor]), startPoint: .topLeading, endPoint: .bottomTrailing))
            .cornerRadius(roundedCornes)
            .shadow(color: .purple, radius: 10)
    }
}

struct customViewModifier: ViewModifier {
    var roundedCornes: CGFloat
    var startColor: Color
    var endColor: Color
    var textColor: Color
    
    func body(content: Content) -> some View {
        content
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [startColor, endColor]), startPoint: .topLeading, endPoint: .bottomTrailing))
            .cornerRadius(roundedCornes)
            .padding(0)
            .foregroundColor(textColor)
            .font(.custom("Open Sans", size: 18))
            
            .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 2)
    }
}
