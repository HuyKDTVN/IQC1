//
//  variable.swift
//  Period - BMI
//
//  Created by Huy Le on 08/05/2022.
//

import Foundation
import UIKit
import SwiftUI
import SwiftUICalendar
class Variable {
    var production:Bool = false
    let proVersion:Bool = false
    var soNgayMax:Int = 10
    let id_user:Int = 11
    var appID:String = "1623035516"
    let adUnitOpenIDTest = "ca-app-pub-3940256099942544/5575463023"
    let adUnitOpenIDReal = "ca-app-pub-8120442673877896/8286902791"
    
    let adUnitXenKeDTest = "ca-app-pub-3940256099942544/4411468910"
    let adUnitXenKeDReal = "ca-app-pub-8120442673877896/5529625941"
    
    let arrTamTrang: [String] = ["ratdechiu", "dechiu", "binhthuong", "khochiu", "ratkhochiu"]
    let arrTamTrangImg: [String] = ["rat-de-chiu", "de-chiu", "binh-thuong", "kho-chiu", "rat-kho-chiu"]
    let arrTrieuChungDau: [String] = ["nhucdau", "chongmat", "matngu", "buonnon"]
    let arrTrieuChungBody: [String] = ["moico", "nhucvai", "daulung", "daulungduoi", "moico2", "dauhong", "metmoi", "sotnhe", "decaugat", "daubung", "taobon", "tieuchay", "nguccang"]
    let arrTrieuChungBuomBuom: [String] = ["luongkinhit", "luongkinhnhieu", "dichnhayit", "dichnhaynhieu"]
    
    var textColor:Color = Color.init(red: 54/255, green: 54/255, blue: 54/255)
    var textW:Color = Color.init(red: 1, green: 1, blue: 1)
    var textColorPink:Color = Color.init(red: 205/255, green: 45/255, blue: 123/255)
    var textColorPinkBorder:Color = Color.init(red: 161/255, green: 23/255, blue: 90/255)
    var textColorYellow:Color = Color.init(red: 49/255, green: 45/255, blue: 44/255)
    var textColorRed:Color = Color.init(red: 138/255, green: 28/255, blue: 0/255)
    var textColorSelect1:Color = Color.init(red: 69/255, green: 2/255, blue: 22/255)
    var textColorSelect2:Color = Color.init(red: 1/255, green: 45/255, blue: 39/255)
    var textColorSelect3:Color = Color.init(red: 49/255, green: 45/255, blue: 44/255)
    //var colorTim:Color = Color.init(red: 181/255, green: 98/255, blue: 215/255)
    
    var bgColorButton:Color = Color.init(red: 49/255, green: 45/255, blue: 44/255)
    
    var colorCircleXam:Color = Color.init(red: 223/255, green: 230/255, blue: 233/255)
    var colorCircleDo:Color = Color.init(red: 231/255, green: 76/255, blue: 60/255)
    var colorCircleXanh:Color = Color.init(red: 0/255, green: 206/255, blue: 201/255)
    var colorCircleXanhBorder:Color = Color.init(red: 67/255, green: 174/255, blue: 207/255)
    var colorCircleTim:Color = Color.init(red: 181/255, green: 98/255, blue: 215/255)
    var colorCircleTimBorder:Color = Color.init(red: 89/255, green: 28/255, blue: 114/255)
   
    var link_app:String = "https://itunes.apple.com/app/period-calendar-bmi-tracker/1623035516"
 
    var link_facebook_message: String = "https://docs.google.com/forms/d/e/1FAIpQLSfeemFflicuO1YHq36nrQLOvbxYUq1YrwMjbGxIJv5pfULISQ/viewform?usp=dialog" //"https://www.facebook.com/Fitness-Workout-at-Home-106587324389687"
    
    
    var link_dev:String = "https://itunes.apple.com/developer/huy-le/id1279607371"
    var link_privacy: URL = URL(string: "https://sites.google.com/view/fitness-lady-privacy/")!
    var link_terms: URL = URL(string: "https://sites.google.com/view/my-period-terms-of-service/")!
   
    let arrCacGiaiDoanCK: [String] = ["dangtoithang", "coHoiMangThaiThap", "coHoiMangThaiCao", "rungTrung"]
    
    let dataHuongDanTrieuChung : [String: InfoHuongDanKhacPhucTrieuChung] = [
        "daubung": InfoHuongDanKhacPhucTrieuChung(value: "uongnuocam", priority: 3),
        "buonnon": InfoHuongDanKhacPhucTrieuChung(value: "macquanaorongrai", priority: 2),
        "daulung": InfoHuongDanKhacPhucTrieuChung(value: "nenmangtheobvs", priority: 1),
        "tieuchay": InfoHuongDanKhacPhucTrieuChung(value: "khongnenandochienran", priority: 6),
        "luongkinhit": InfoHuongDanKhacPhucTrieuChung(value: "tranhdungdolanh", priority: 5),
        "luongkinhnhieu": InfoHuongDanKhacPhucTrieuChung(value: "tranhdungdolanh", priority: 4),
        "nguccang": InfoHuongDanKhacPhucTrieuChung(value: "tranhdungdomanvacaynnong", priority: 7)
    ]
    
    let arrButtonOnboarding = ["Bắt đầu", "Cho phép", "Cho phép", ""]
    
    var isLargeScreen: Bool { // > 6.1inch
        max(UIScreen.main.bounds.width, UIScreen.main.bounds.height) > 844
    }
    
    func requestNotificationPermission() async -> Bool {
        do {
            return try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
        } catch {
            return false
        }
    }
    
    
    func catText(_ text: String, limit: Int = 45) -> String {
        if text.count <= limit {
            return text
        } else {
            let index = text.index(text.startIndex, offsetBy: limit)
            return String(text[..<index]) + "..."
        }
    }
    
    func moodForDay(currentYear: Int, currentMonth: Int, currentDay: Int) -> Int {
        var viewModel = MoodViewModel()
//        print("nam-thang-ngay")
//        print(String(currentDay) + "|" + String(currentMonth) + "|" + String(currentYear))
        
        for entry in viewModel.moods {
            let entryDate = entry.date
            let calendar = Calendar.current
            let components = calendar.dateComponents([.year, .month, .day], from: entryDate)
            
            if components.year == currentYear &&
                components.month == currentMonth &&
                components.day == currentDay {
                return entry.mood
            }
        }
        return 0
    }
    func entryForDay(currentYear: Int, currentMonth: Int, currentDay: Int) -> MoodEntry? {
        var viewModel = MoodViewModel()
        for entry in viewModel.moods {
            let entryDate = entry.date
            let calendar = Calendar.current
            let components = calendar.dateComponents([.year, .month, .day], from: entryDate)

            if components.year == currentYear &&
                components.month == currentMonth &&
                components.day == currentDay {
                return entry
            }
        }
        return nil
    }
    func getSymptomDau (symptom: String) -> String {
        var arrResult : [String] = []
        var has : Bool = false
        for i in arrTrieuChungDau {
            if symptom.contains(i) {
                arrResult.append(NSLocalizedString(i, comment: ""))
                has = true
            }
        }
        if has {
            return String(arrResult.joined(separator: ", "))
        } else {
            return ""
        }
    }
    func getSymptomBody (symptom: String) -> String {
        var arrResult : [String] = []
        var has : Bool = false
        for i in arrTrieuChungBody {
            if symptom.contains(i) {
                arrResult.append(NSLocalizedString(i, comment: ""))
                has = true
            }
        }
        if has {
            return String(arrResult.joined(separator: ", "))
        } else {
            return ""
        }
    }
    func getSymptomBuomBuom (symptom: String) -> String {
        var arrResult : [String] = []
        var has : Bool = false
        for i in arrTrieuChungBuomBuom {
            if symptom.contains(i) {
                arrResult.append(NSLocalizedString(i, comment: ""))
                has = true
            }
        }
        if has {
            return String(arrResult.joined(separator: ", "))
        } else {
            return ""
        }
    }
    func getNSelectedSymptomDau (symptom: String) -> [Bool] {
        var result : [Bool] = []
        for i in arrTrieuChungDau {
            if symptom.contains(i) {
                result.append(true)
            }else{
                result.append(false)
            }
        }
        return result;
    }
    func getNSelectedSymptomBody (symptom: String) -> [Bool] {
        var result : [Bool] = []
        for i in arrTrieuChungBody {
            if symptom.contains(i) {
                result.append(true)
            }else{
                result.append(false)
            }
        }
        return result;
    }
    func getNSelectedSymptomBuomBuom (symptom: String) -> [Bool] {
        var result : [Bool] = []
        for i in arrTrieuChungBuomBuom {
            if symptom.contains(i) {
                result.append(true)
            }else{
                result.append(false)
            }
        }
        return result;
    }
    func getNumberSymptomDau (symptom: String) -> Int {
        var result = 0
        for i in arrTrieuChungDau {
            if symptom.contains(i) {
                result = result + 1
            }
        }
        return result;
    }
    func getNumberSymptomBody (symptom: String) -> Int {
        var result = 0
        for i in arrTrieuChungBody {
            if symptom.contains(i) {
                result = result + 1
            }
        }
        return result;
    }
    func getNumberSymptomBuomBuom (symptom: String) -> Int {
        var result = 0
        for i in arrTrieuChungBuomBuom {
            if symptom.contains(i) {
                result = result + 1
            }
        }
        return result;
    }
    
   func rate() {
      let randomInt = Int.random(in: 1..<10)
      
      if randomInt == 3 {
         rateApp() { success in
             //self.redirectTo(screen: "home")
         }
          
      }
   }
   func rateApp(completion: @escaping ((_ success: Bool)->())) {
       guard let url = URL(string : link_app) else {
           completion(false)
           return
       }
       guard #available(iOS 10, *) else {
           completion(UIApplication.shared.openURL(url))
           return
       }
       UIApplication.shared.open(url, options: [:], completionHandler: completion)
   }
   
   func tinhNgayRungTrungTuDoDaiChuKy(chuKy: Int) -> Int {
      
      return chuKy - 15
   }
   
   func tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: Int) -> Int {
      
      return chuKy - 19
   }
   
   func tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: Int) -> Int {
      
      return chuKy - 13 + 3
   }
   
   func getCurrentPeriod() -> String {
      let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
      if(periodData != nil){
         return periodData![0]
      }else{
         return ""
      }
      
   }
   
   func setDefaultForNoti() {
      UserDefaults.standard.set(true, forKey: "showNgayDau")
      UserDefaults.standard.set(true, forKey: "showNgayKetThuc")
      UserDefaults.standard.set(true, forKey: "showNgayBatDauThuThai")
      UserDefaults.standard.set(true, forKey: "showNgayKetThucThuThai")
      UserDefaults.standard.set(true, forKey: "showNgayRungTrung")
      UserDefaults.standard.set(true, forKey: "showNhacNhoTamTrang")
   }
   func clearNotiPeriod() {
      removeNoti(myName: "ngaydautoithang")
      removeNoti(myName: "ngayketthuc")
      removeNoti(myName: "batdauthuthai")
      removeNoti(myName: "ngayrungtrung")
      removeNoti(myName: "ketthucthuthai")
      removeNoti(myName: "nhacnhotamtrang")
   }
   
   func convertToChinaNumber(n: Int) -> String {
      
      var result: String = ""
      switch n {
      case 1:
         result = "一"
      case 2:
         result = "二"
      case 3:
         result = "三"
      case 4:
         result = "四"
      case 5:
         result = "五"
      case 6:
         result = "六"
      case 7:
         result = "七"
      case 8:
         result = "八"
      case 9:
         result = "九"
      case 10:
         result = "十"
      default:
         result = ""
      }
      
      
      return result
   }
   
   func setNotiAllPeriod(selectDoDai1Thang: Int, selectDoDaiChuky: Int, ngayDauDMY: String) {
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "dd-MM-yyyy"
      dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
      let result:Date = dateFormatter.date(from: ngayDauDMY) ?? Date()
      //let calendarDate = Calendar.current.dateComponents([.day, .year, .month], from: result)
      
      let resultBatDauThangSau = Calendar.current.date(byAdding: .day, value: selectDoDai1Thang, to: result)
      let calendarBatDauThangSau = Calendar.current.dateComponents([.day, .year, .month], from: resultBatDauThangSau!)
      
      let soNgayDenThang = selectDoDaiChuky
      let soNgayanToan1 = variable.tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: selectDoDai1Thang)
      let soNgayThuThai = variable.tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: selectDoDai1Thang)
      
      let resultKetThuc = Calendar.current.date(byAdding: .day, value: soNgayDenThang, to: result)
      let calendarKetThuc = Calendar.current.dateComponents([.day, .year, .month], from: resultKetThuc!)
      
      let resultBatDauthuThai = Calendar.current.date(byAdding: .day, value: soNgayanToan1, to: result)
      let calendarBatDauthuThai = Calendar.current.dateComponents([.day, .year, .month], from: resultBatDauthuThai!)
      
      let resultKetThucThuThai = Calendar.current.date(byAdding: .day, value: soNgayThuThai, to: result)
      let calendarKetThucThuThai = Calendar.current.dateComponents([.day, .year, .month], from: resultKetThucThuThai!)
      
      let resultRungTrung = Calendar.current.date(byAdding: .day, value: variable.tinhNgayRungTrungTuDoDaiChuKy(chuKy: selectDoDai1Thang), to: result)
      let calendarRungTrung = Calendar.current.dateComponents([.day, .year, .month], from: resultRungTrung!)
      
      let namDauToiThang = calendarBatDauThangSau.year!
      let thangDauToiThang = calendarBatDauThangSau.month!
      let ngayDauToiThang = calendarBatDauThangSau.day! - 1
      print("set Ngay toi thang - thang sau: \(namDauToiThang)-\(thangDauToiThang)-\(ngayDauToiThang)")

      let namKetThuc = calendarKetThuc.year!
      let thangKetThuc = calendarKetThuc.month!
      let ngayKetThuc = calendarKetThuc.day! - 1
      print("set Ngay ket thuc toi thang: \(namKetThuc)-\(thangKetThuc)-\(ngayKetThuc)")
      
      let namBatDauThuThai = calendarBatDauthuThai.year!
      let thangBatDauThuThai = calendarBatDauthuThai.month!
      let ngayBatDauThuThai = calendarBatDauthuThai.day! - 1
      print("set Ngay bat dau thu thai: \(namBatDauThuThai)-\(thangBatDauThuThai)-\(ngayBatDauThuThai)")
      
      let namRungTrung = calendarRungTrung.year!
      let thangRungTrung = calendarRungTrung.month!
      let ngayRungTrung = calendarRungTrung.day! - 1
      print("set Ngay rung trung: \(namRungTrung)-\(thangRungTrung)-\(ngayRungTrung)")
      
      let namKetThucThuThai = calendarKetThucThuThai.year!
      let thangKetThucThuThai = calendarKetThucThuThai.month!
      let ngayKetThucThuThai = calendarKetThucThuThai.day! - 2
      print("set Ngay ket thuc thu thai: \(namKetThucThuThai)-\(thangKetThucThuThai)-\(ngayKetThucThuThai)")
      
      let showNgayDau = UserDefaults.standard.bool(forKey: "showNgayDau")
      let showNgayKetThuc = UserDefaults.standard.bool(forKey: "showNgayKetThuc")
      let showNgayBatDauThuThai = UserDefaults.standard.bool(forKey: "showNgayBatDauThuThai")
      let showNgayKetThucThuThai = UserDefaults.standard.bool(forKey: "showNgayKetThucThuThai")
      let showNgayRungTrung = UserDefaults.standard.bool(forKey: "showNgayRungTrung")
      let showNhacNhoTamTrang = UserDefaults.standard.bool(forKey: "showNhacNhoTamTrang")
      
       let displayName = Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String
       
       
      if(showNgayDau == true) {
         variable.setNoti(mtitle: NSLocalizedString("ngaydautoithang", comment: ""), mcontent: "", nam: namDauToiThang,thang: thangDauToiThang, ngay: ngayDauToiThang, gio: 9, phut: 0, myName: "ngaydautoithang")
      }
      
      if(showNgayKetThuc == true) {
         variable.setNoti(mtitle: displayName!, mcontent: NSLocalizedString("ngayketthuc", comment: ""), nam: namKetThuc,thang: thangKetThuc, ngay: ngayKetThuc, gio: 9, phut: 0, myName: "ngayketthuc")
      }
      if(showNgayBatDauThuThai == true) {
         variable.setNoti(mtitle: displayName!, mcontent: NSLocalizedString("batdauthuthai", comment: ""), nam: namBatDauThuThai,thang: thangBatDauThuThai, ngay: ngayBatDauThuThai, gio: 9, phut: 0, myName: "batdauthuthai")
      }
      
      if(showNgayKetThucThuThai == true) {
         variable.setNoti(mtitle: displayName!, mcontent: NSLocalizedString("ngayrungtrung", comment: ""), nam: namRungTrung,thang: thangRungTrung, ngay: ngayRungTrung, gio: 9, phut: 0, myName: "ngayrungtrung")
      }
      if(showNgayRungTrung == true) {
         variable.setNoti(mtitle: displayName!, mcontent: NSLocalizedString("ketthucthuthai", comment: ""), nam: namKetThucThuThai,thang: thangKetThucThuThai, ngay: ngayKetThucThuThai, gio: 9, phut: 0, myName: "ketthucthuthai")
      }
      if(showNhacNhoTamTrang == true) {
           setNotiDaily(mtitle: NSLocalizedString("homnaybanthenao", comment: ""), mcontent: "", gio: 8, phut: 16, myName: "nhacnhotamtrang")
      }
   }
   func getRatioScreen() -> Double {
      let screenSize: CGRect = UIScreen.main.bounds
      //print("ratio: \(screenSize.height / screenSize.width) - \(screenSize.height) - \(screenSize.width)")
      return screenSize.height / screenSize.width
   }
   func getWidthScreen() -> Int {
      let screenSize: CGRect = UIScreen.main.bounds
      return Int(screenSize.width)
   }
   
   func ngayHomNay(chuKy: Int) -> Int {
      let arr = getCurrentPeriod().components(separatedBy: "+")
      if(arr.count > 1) {
         //let startString = String(UserDefaults.standard.integer(forKey: "khaibao-nam")) + "-" + String(UserDefaults.standard.integer(forKey: "khaibao-thang")) + "-" + String(UserDefaults.standard.integer(forKey: "khaibao-ngay"))
         let startString = arr[0]
         let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "dd-MM-yyyy"
         let start:Date = dateFormatter.date(from: startString) ?? Date()
         let soNgayHienTai = Calendar.current.dateComponents([.day], from: start, to: Date())
         // print("so ngay hien tai: \(soNgayHienTai.day!)")
         return soNgayHienTai.day!
      }
      else{
         return 0
      }
 
   }
   func stringToDate(data: String, congThem: Int) -> String {
      
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "dd-MM-yyyy"
      let result:Date = dateFormatter.date(from: data) ?? Date()
      let data = Calendar.current.date(byAdding: .day, value: congThem, to: result)
      return dateFormatter.string(from: data!)
   }
   
    func getColor(i:Int) -> Color {
       var myColor: Color = colorCircleXam
       
       let arr = getCurrentPeriod().components(separatedBy: "+")
       if(arr.count > 2) {
          let chuKy = Int(arr[1])!
          let period = Int(arr[2])!
          let anToandau:Int = tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: chuKy) - period
          let khongAnToan:Int = tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: chuKy) - tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: chuKy)
          let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)
          
          if (i < period) {
              myColor = colorCircleDo
          }else if (i >= period && i < (period + anToandau)) {
              myColor = colorCircleXam
          }
          else if (i >= (period + anToandau)  && i < (period + anToandau + khongAnToan)) {
              myColor = colorCircleXanh
          }else{
              myColor = colorCircleXam
          }
          if i == rungTrung {
              myColor = colorCircleTim
          }
       }
        return myColor
    }
   
   func getColorCalendar(i:Int) -> Color {
      var myColor: Color
      switch i {
      case 0:
         myColor = colorCircleDo
      case 1:
         myColor = colorCircleXam
      case 3:
         myColor = colorCircleTimBorder

      case 2:
         myColor = colorCircleXanh

      default:
         myColor = .white
      }
      
       return myColor
   }
    func getBorderColor(i:Int) -> Color {

       var myColor2: Color = colorCircleTimBorder
       
       let arr = getCurrentPeriod().components(separatedBy: "+")
       
       if(arr.count > 2) {
          let period = Int(arr[2])!
          let chuKy = getDoDaiCaChuKy()
          let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)
          //let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
           
           
          if i < period {
              myColor2 = Color("gradianDoDam")
          } else if i < tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: chuKy) {
             myColor2 = Color("gradianXamDam").opacity(0.8)
          } else if i < tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: chuKy) {
             myColor2 = colorCircleXanhBorder
          } else {
             myColor2 = Color("gradianXamDam").opacity(0.8)
          }
          
           if i == rungTrung {
               myColor2 = colorCircleTimBorder
           }
       }

        return myColor2
    }
   func ngayTre() -> Int {
      
      let result = ngayHomNay(chuKy: getDoDaiCaChuKy() ) - getDoDaiCaChuKy() + 1
       print("ngay hom nay : do dai ca chu ky")
       print(ngayHomNay(chuKy: getDoDaiCaChuKy() ) )
       print(getDoDaiCaChuKy())
      return result
   }
   
   func ngayBatDauThuThai() -> Int {
      
      let result = ngayHomNay(chuKy: getDoDaiCaChuKy() ) - tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: getDoDaiCaChuKy()) + 1
      
      print("ABD: \(result)")
      return result
   }
    func ngayKetThucThuThai() -> Int {
       let result = ngayHomNay(chuKy: getDoDaiCaChuKy() ) - tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: getDoDaiCaChuKy()) + 1
       print("ABD: \(result)")
       return result
    }
    func deleteAllData() {
        if let appDomain = Bundle.main.bundleIdentifier {
            UserDefaults.standard.removePersistentDomain(forName: appDomain)
            UserDefaults.standard.synchronize()
            //print("All UserDefaults cleared.")
        }
    }
   func getGradian(i: Int) -> Gradient {

      var myColor2: Gradient = Gradient(colors: [Color("gradianTimDam"), Color("gradianTimNhat")])
      
      let arr = getCurrentPeriod().components(separatedBy: "+")
      
      if(arr.count > 2){
         let period = Int(arr[2])!
         let chuKy = getDoDaiCaChuKy()
         let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)
         //let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
          
          
         if i < period {
             myColor2 = Gradient(colors: [Color("gradianDoDam"), Color("gradianDoNhat")])
         } else if i < tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: chuKy) {
            myColor2 = Gradient(colors: [Color("gradianXamDam"), Color("gradianXamNhat")])
         } else if i < tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: chuKy) {
            myColor2 = Gradient(colors: [Color("gradianXanhDam"), Color("gradianXanhNhat")])
         }else if i < chuKy {
            myColor2 = Gradient(colors: [Color("gradianXamDam"), Color("gradianXamNhat")])
         } else {
            myColor2 = Gradient(colors: [Color("gradianDoDam"), Color("gradianDoNhat")])
            
         }
         
          if i == rungTrung {
              myColor2 = Gradient(colors: [Color("gradianTimDam"), Color("gradianTimNhat")])
          }
         
//         print("check color border")
//         print(i)
//         print(chuKy)
      }
      
      
      return myColor2
   }
   
   
    func getBorderWidth(i:Int) -> CGFloat {
        var result: CGFloat = 0
        let chuKy = getDoDaiCaChuKy()
        let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)
        let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
        if i == rungTrung || i == ngayHomNay {
            result = 2
        }
        
        return result
    }
    
    func getCricleSize(i:Int) -> CGFloat {
        var result: CGFloat = 8
       let chuKy = getDoDaiCaChuKy()
       let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)
       let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
        if i == rungTrung {
            result = 20
        }
        
        if i == ngayHomNay {
            result = 25
        }
        return result
    }
   func getGiaiDoan() -> Int {
      
      var result = 0
      
      let arr = getCurrentPeriod().components(separatedBy: "+")
      
      print("arr period: \(arr)")
      if(arr.count > 2) {
         let period = Int(arr[2])!
         let chuKy = getDoDaiCaChuKy()
         
         let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
         print("chu ky: \(chuKy) - \(ngayHomNay)")
         let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)

         if ngayHomNay < period {
             result = 0
         } else if ngayHomNay < tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: chuKy) {
            result = 1
         } else if ngayHomNay < rungTrung {
            result = 2
         }else if ngayHomNay < tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: chuKy) {
            result = 4
            
         }else if ngayHomNay < chuKy {
            result = 1
            
         }
         else {
            result = 5
         }
         
         print("tinh ngay 1")
         print(rungTrung)
         print(ngayHomNay)
         print(tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: chuKy))
          if ngayHomNay == rungTrung {
              result = 3
          }
      }
       //result = 3
      return result
   }
    
    func getGoiY(symptom: [String]) -> String {
        /**
        Input: 1 mảng triệu chứng
        Output: Trả về gợi ý thích hợp
        Logic: - Nếu không có triệu chứng => cơ thể khỏe mạnh => hiển thị gợi ý theo từng giai đoạn chu kỳ
                 + đến tháng: tập nhẹ
                 + Trước rụng trứng: tập cường độ cao
                 + Sau rụng trứng: tập trung bình
             - Nếu có triệu chứng
                 + Triệu chứng nằm trong list các triệu chứng có gợi ý => tìm triệu chứng có priority cao nhất và hiển thị gợi ý tương ứng và câu nói hãy tập nhẹ nhàng.
                 + Triệu chứng không nằm trong list các triệu chứng có gợi ý => trả về kết quả tập nhẹ nhàng.
         */
        var result = NSLocalizedString("khoetap1", comment: "")
        
        if symptom.isEmpty {
            if getGiaiDoan() == 0 {
                result = NSLocalizedString("khoetap1", comment: "")
            }
            else if getGiaiDoan() == 1 || getGiaiDoan() == 2 || getGiaiDoan() == 3 {
                result = NSLocalizedString("khoetap2", comment: "")
            }else {
                result = NSLocalizedString("khoetap3", comment: "")
            }
        } else{
            var priority  = 0
            var bestSymptom = ""
            for symptomItem in symptom {
                for (key, value) in dataHuongDanTrieuChung {
                    if priority == 0 {
                        if symptomItem == key {
                            priority = value.priority
                            bestSymptom = value.value
                        }
                    } else {
                        if symptomItem == key && priority > value.priority {
                            priority = value.priority
                            bestSymptom = value.value
                        }
                    }
                }
            }
            
            if priority == 0 {
                result = NSLocalizedString("khoetap1", comment: "")
            }else {
                result = NSLocalizedString(bestSymptom, comment: "") + NSLocalizedString("tapnhenhang", comment: "")
            }
        }
        return result
    }
    
   func getSoNgayConLai() -> Int {
      var result = 1
      
      let arr = getCurrentPeriod().components(separatedBy: "+")
      
      if(arr.count > 2) {
         let period = Int(arr[2])!
         let chuKy = getDoDaiCaChuKy()
         let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
         let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)

         
         if ngayHomNay < rungTrung && ngayHomNay > tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: chuKy) {
             result = rungTrung - ngayHomNay
         }
         
         if ngayHomNay < period {
             result = ngayHomNay + 1
         }
      }
  
       return result
   }
       
    func getSoNgayChuanBiRungTrung() -> Int {
          var result = 1
          
          let arr = getCurrentPeriod().components(separatedBy: "+")
          
          if(arr.count > 2) {
             let period = Int(arr[2])!
             let chuKy = getDoDaiCaChuKy()
             let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
             let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)

         
             if ngayHomNay < rungTrung {
                 result = rungTrung - ngayHomNay
             }
              print ("getCurrentPeriod: \(getCurrentPeriod())")
              print ("ngayHomNay: \(ngayHomNay)")
              print ("rungTrung: \(rungTrung)")
              print ("period: \(period)")
              
    //         print("tinh ngay")
    //         print(ngayHomNay)
    //         print(rungTrung - ngayHomNay)
          }
      
      return result
   }
   
   func getSoNgayConLaiTranhThai() -> Int {
      var result = 1
      
      let arr = getCurrentPeriod().components(separatedBy: "+")
      
      if(arr.count > 2) {
         let period = Int(arr[2])!
         let chuKy = getDoDaiCaChuKy()
         let ngayHomNay:Int = ngayHomNay(chuKy: chuKy)
         let rungTrung:Int = tinhNgayRungTrungTuDoDaiChuKy(chuKy: chuKy)

         if ngayHomNay < period {
             result = period - ngayHomNay
         }
         if ngayHomNay < rungTrung && ngayHomNay > tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: chuKy) {
             result = rungTrung - ngayHomNay
         }
         
//         print("tinh ngay")
//         print(ngayHomNay)
//         print(rungTrung - ngayHomNay)
      }
      
      return result
   }
   
   func demoUserDefault() -> Int{
      let defaults = UserDefaults.standard
      
      defaults.set(25, forKey: "Age")

      let age = defaults.integer(forKey: "Age")
      return age
   }
   
   func getDanhNgon() -> String {
      var selectNgonNgu = "en"
      let langStr = Locale.current.languageCode
      if(langStr == "vi"){
         selectNgonNgu = "vi"
      }
      
      if(langStr == "zh"){
         selectNgonNgu = "zh"
      }
      
      if(langStr == "de"){
         selectNgonNgu = "de"
      }
     
      //let selectNgonNgu = UserDefaults.standard.string(forKey: "language") ?? "en"
      return (arrDN[selectNgonNgu]?.randomElement())!
      //return "Bạn không cần là bất cứ ai, hãy là chính mình."
   }
   
   func isChina() -> Bool{
      var result = false
      let langStr = Locale.current.languageCode
      
      if(langStr == "zh"){
         result = true
      }
     return result
   }
   
   func showSoLanUOngThuoc(soLan: Int) -> String {
      var result = ""
      if(soLan > 0) {
         result = "\(soLan) " + NSLocalizedString("lanngay", comment: "")
      }else{
         result = NSLocalizedString("caidatuongthuoc", comment: "")
      }

      return result
   }
   func getBMIarr() -> [Double] {
      
      let bmiData = UserDefaults.standard.string(forKey: "bmi_data") ?? ""
      let arrBMIData = bmiData.components(separatedBy: "-")
      var arrMBI = [Double]()
      var tmp = [String]()
      for bmi in arrBMIData {
         tmp = bmi.components(separatedBy: "+")
         if(tmp.count > 1) {
            arrMBI.append(Double(tmp[1])!)
         }
      }
      
      return arrMBI.reversed()
   }
   func getBMIPercent() -> Int {
      var result = 0
      let BMIarr = getBMIarr()
      if(BMIarr.count > 1) {
//         print("BMI data")
         result = Int((BMIarr[BMIarr.count - 1] - BMIarr[BMIarr.count - 2] ) / BMIarr[BMIarr.count - 2] * 100 )
//         print(result)
//         print(BMIarr)
//         print(BMIarr[BMIarr.count - 1])
      }
      
      return result
   }
   func getBMICurrent() -> Double {
      
      var result: Double = 0.0
      
      let bmiData = UserDefaults.standard.string(forKey: "bmi_data") ?? ""
      let arrBMIData = bmiData.components(separatedBy: "-")
      let arrcurrentBMI = arrBMIData[0].components(separatedBy: "+")
      if arrcurrentBMI.count > 1{
         result = Double(arrcurrentBMI[1])!
      }
      
      return result
   }
   func getBMITitle() -> String {
      var result: String = ""
      let BMIindex = getBMICurrent()
      
      if(BMIindex > 0) {
         if(BMIindex < 16) {
            result = "quanhecan"
         }else if(BMIindex >= 16 && BMIindex < 17) {
            result = "ratnhecan"
         }else if(BMIindex >= 17 && BMIindex < 18.5) {
            result = "nhecan"
         }else if(BMIindex >= 18.5 && BMIindex <= 24.9) {
            result = "binhthuong"
         }else if(BMIindex > 24.9 && BMIindex < 30) {
            result = "thuacan"
         }else if(BMIindex >= 30 && BMIindex < 35) {
            result = "beophiloai1"
         }else if(BMIindex >= 35 && BMIindex < 40) {
            result = "beophiloai2"
         }else{
            result = "beophiloai3"
         }
      }
      return result
   }
   
   func getPositionBMICurrent(value: Double, banKinh: Double) -> CGSize{
      
//      let xOrigin:Double = -125
//      let yOrigin:Double = 256
      
      let xOrigin:Double = 0
      let yOrigin:Double = 265
      
      let x = xOrigin - banKinh * cos(1.2217 * value / 16.4)
      let y = yOrigin - banKinh * sin(1.2217 * value / 16.4)
      
      return CGSize(width: x, height: y)
   }
   
   func getDoDaiCaChuKy() -> Int {
      var soNgay = 28
      let arr = getCurrentPeriod().components(separatedBy: "+")
      if(arr.count > 2) {
         soNgay = Int(arr[1])!
      }
      
      return soNgay
   }
   
   func saveSoNuoc(i: Int) {
      let defaults = UserDefaults.standard
      
      //defaults.set(i, forKey: "sonuoc")
      
      let date = Date()
      
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "yyyy_MM_dd"
      
      var dataUongNuoc = UserDefaults.standard.string(forKey: "data_uongnuoc") ?? ""
      let arrUongNuoc = dataUongNuoc.components(separatedBy: "-")
      if(arrUongNuoc.count == 1) {
         let arr = arrUongNuoc[0].components(separatedBy: "+")
         if(arr.count == 1) {
            dataUongNuoc = dateFormatter.string(from: date) + "+" + String(i)
         }else{
            let dateUongNuoc = dateFormatter.date(from:arr[0])!
            if (Calendar.current.isDateInToday(dateUongNuoc)) {
               dataUongNuoc = arr[0] + "+" + String(i)
            }else{
               dataUongNuoc = dateFormatter.string(from: date) + "+" + String(i) + "-" + arrUongNuoc[0]
            }
            
            
         }
         
      }else{
         let arr = arrUongNuoc[0].components(separatedBy: "+")
         if(arr.count > 1) {
            
            let dateUongNuoc:Date = dateFormatter.date(from:arr[0])!
            if (Calendar.current.isDateInToday(dateUongNuoc)) {
               dataUongNuoc = dateFormatter.string(from: date) + "+" + String(i) + "-" + arrUongNuoc[1]
            }else{
               dataUongNuoc = dateFormatter.string(from: date) + "+" + String(i) + "-" + arrUongNuoc[0]
            }
            
            
         }
      }
      print("soNuoc: \(i)")
      print(dataUongNuoc)
      
      defaults.set(dataUongNuoc, forKey: "data_uongnuoc")
      
      
   }
   
   func getSoNuoc() -> Int {
      var soNuoc: Int = 0
      let dataUongNuoc = UserDefaults.standard.string(forKey: "data_uongnuoc") ?? ""
       print("data_uongnuoc: \(dataUongNuoc)")
      let arrUongNuoc = dataUongNuoc.components(separatedBy: "-")
      let arr = arrUongNuoc[0].components(separatedBy: "+")
      if(arr.count == 2) {
         let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "yyyy_MM_dd"
         let dateUongNuoc:Date = dateFormatter.date(from:arr[0])!
         
         if (Calendar.current.isDateInToday(dateUongNuoc)) {
            soNuoc = Int(arr[1])!
         }else{
            soNuoc = 0
         }
      }
      return soNuoc
   }
   
   func getSoNuocHomQua() -> Int {
      var soNuoc: Int = 0
      let dataUongNuoc = UserDefaults.standard.string(forKey: "data_uongnuoc") ?? ""
      let arrUongNuoc = dataUongNuoc.components(separatedBy: "-")
      if arrUongNuoc.count > 1 {
         let arr = arrUongNuoc[1].components(separatedBy: "+")
         if(arr.count == 2) {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy_MM_dd"
            dateFormatter.locale = .current
            let dateUongNuoc:Date = dateFormatter.date(from:arr[0])!

            var dayComponent = DateComponents()
            dayComponent.day = +1
            let calendar = Calendar.current
            let nextDay =  calendar.date(byAdding: dayComponent, to: dateUongNuoc)!
                     
            print(dataUongNuoc )
            print(nextDay )

            if (Calendar.current.isDateInToday(nextDay)) {
               
               soNuoc = Int(arr[1])!
            }else{
               soNuoc = 0
               
            }
         }
      }
      return soNuoc
   }
   
   func setNotiDaily(mtitle: String, mcontent: String, gio: Int, phut: Int, myName: String) {
      removeNoti(myName: myName)
      
      //set noti repeat daily
      let notificationContent = UNMutableNotificationContent()
      notificationContent.title = mtitle
      notificationContent.body = mcontent
      let currentBadge = UIApplication.shared.applicationIconBadgeNumber
      let newBadge = currentBadge + 1
      notificationContent.badge = NSNumber(value: newBadge)
      notificationContent.sound = .default
                  
      var datComp = DateComponents()
      datComp.hour = gio
      datComp.minute = phut
      
      
      let trigger = UNCalendarNotificationTrigger(dateMatching: datComp, repeats: true)
      let request = UNNotificationRequest(identifier: myName, content: notificationContent, trigger: trigger)
             UNUserNotificationCenter.current().add(request) { (error : Error?) in
                 if let theError = error {
                     print(theError.localizedDescription)
                 }
             }
   }
   
   func setNoti(mtitle: String, mcontent: String, nam: Int, thang: Int,  ngay: Int, gio: Int, phut: Int, myName: String) {
      removeNoti(myName: myName)
      
      //set noti repeat daily
      let notificationContent = UNMutableNotificationContent()
      notificationContent.title = mtitle
      notificationContent.body = mcontent
       let currentBadge = UIApplication.shared.applicationIconBadgeNumber
       let newBadge = currentBadge + 1
       notificationContent.badge = NSNumber(value: newBadge)
 
      notificationContent.sound = .default
                  
      var datComp = DateComponents()
      datComp.day = ngay
      datComp.month = thang
      datComp.year = nam
      datComp.hour = gio
      datComp.minute = phut
      
      let trigger = UNCalendarNotificationTrigger(dateMatching: datComp, repeats: false)
      let request = UNNotificationRequest(identifier: myName, content: notificationContent, trigger: trigger)
             UNUserNotificationCenter.current().add(request) { (error : Error?) in
                 if let theError = error {
                     print(theError.localizedDescription)
                 }
             }
   }
   
   func removeNoti(myName: String) {
      //remove noti before
      UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [myName])
      UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [myName])
   }
   
   func homePageGetThoiGianUongThuoc() -> String {
      
      let soLan: Int = UserDefaults.standard.integer(forKey: "soLanUongThuoc")
      
      
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "yyyy_MM_dd"
      let currentDate = dateFormatter.string(from: Date())
      
      dateFormatter.dateFormat = "yyyy_MM_dd HH:mm:ss"
      dateFormatter.locale = .current
      //dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
      
      print("date")
      print(soLan)
      var result: String = ""
      
      if(soLan > 0) {
         for i in 1...soLan {
            let t = UserDefaults.standard.string(forKey: "thoiGianUongThuocLan\(i)") ?? ""
            print("testT")
            print(t)
            //print(NSLocale.system)
            print(currentDate)
             var dateUongNuoc:Date = Date()
            if let date = dateFormatter.date(from: currentDate + " " + t + ":00") {
                 dateUongNuoc = date
                
            } else {
                 print("Lỗi parse date, kiểm tra lại định dạng.")
            }
            if(dateUongNuoc > Date()) {
               //dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
               //dateFormatter.dateFormat = "HH:mm"
//               let d = dateFormatter.date(from: t)
//               print(d)
               dateFormatter.dateFormat = "hh:mm a"
               result = dateFormatter.string(from:  dateUongNuoc)
               break
            }else{
            }
         }
      }
      
      return result
   }
   func getCurrentDate() -> String{
      let date = Date()
      let dateFormatter = DateFormatter()
       
      dateFormatter.dateFormat = "dd-MM-yyyy"
       
      let result = dateFormatter.string(from: date)
      return result
   }
   func getCurrentDay() -> String{
      let date = Date()
      let dateFormatter = DateFormatter()
       
      dateFormatter.dateFormat = "dd"
       
      let result = dateFormatter.string(from: date)
      return result
   }
   
   func getCurrentMonth() -> String{
      let date = Date()
      let dateFormatter = DateFormatter()
       
      dateFormatter.dateFormat = "MM"
       
      let result = dateFormatter.string(from: date)
      return result
   }
   func getCurrentYear() -> String{
      let date = Date()
      let dateFormatter = DateFormatter()
       
      dateFormatter.dateFormat = "yyyy"
       
      let result = dateFormatter.string(from: date)
      return result
   }
   
   func getGapDate(startYMD : String, endYMD: String) -> Int {
      
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "dd-MM-yyyy"
      
      let calendar = Calendar.current
      let date1 = calendar.startOfDay(for: dateFormatter.date(from: startYMD)!)
      
      //print("endYMD: \(endYMD)")
      
      let date2 = calendar.startOfDay(for: dateFormatter.date(from: endYMD)!)

      let components = calendar.dateComponents([.day], from: date1, to: date2)
      
      
      return components.day!
   }
   
   func updateChuKy(ob: [YearMonthDay: [(Int)]]) -> Bool{
      
      var result: Bool = true
      var min: String = "01-01-3000"
      var minString: String = "01-01-3000"
      var max: String = "01-01-1990"
      
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "dd-MM-yyyy"
      
      var count: Int = 0
      for (date, _) in ob{
         if(count == 0) {
              
         }else{
            if( dateFormatter.date(from: String(date.day) + "-" + String(date.month) + "-" + String(date.year)) ?? Date() < dateFormatter.date(from: min) ?? Date() ){
               min = String(date.day) + "-" + String(date.month) + "-" + String(date.year)
               minString = String(date.day) + "-" + String(date.month) + "-" + String(date.year)
               
            }
            if( dateFormatter.date(from: String(date.day) + "-" + String(date.month) + "-" + String(date.year)) ?? Date() > dateFormatter.date(from: max) ?? Date() ){
               max = String(date.day) + "-" + String(date.month) + "-" + String(date.year)
            }
         }
         count += 1
      }
      
      print("min")
      print(min)
      print(max)
      print(ob)

//      let calendar = Calendar.current
//      let date1 = calendar.startOfDay(for: dateFormatter.date(from: min)!)
//      let date2 = calendar.startOfDay(for: dateFormatter.date(from: max)!)
//
//      let components = calendar.dateComponents([.day], from: date1, to: date2)

      let gap = getGapDate(startYMD: min, endYMD: max)
      if(gap >= soNgayMax) {
       result = false
      }else{
         
         var periodString: String = ""
          var periodNewString: String = ""
         
         let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
         
         let currentPerior = periodData?[0]
         let arrCurrentPerior = currentPerior?.components(separatedBy: "+")
         print("min2")
         print(arrCurrentPerior![0])
          print(arrCurrentPerior![1])
          print(arrCurrentPerior![2])
         
          let soNgayCK = arrCurrentPerior![1]
         //print(currentPerior)
          let currentPeriorNew:String = minString + "+" + soNgayCK + "+" + String(gap + 1)
         print(currentPeriorNew)
         
         var i:Int = 0
         if(periodData!.count > 1) { //tu chu ky thu 2 tro di
            for val in periodData!{
               if(i == 0) { // chu ky gan nhat
                   periodNewString = currentPeriorNew
                   print("buoc 1")
               }else if(i == 1) {
                   print("buoc 2")
                  let arrPreviousPerior = val.components(separatedBy: "+")
                  let g: Int = getGapDate(startYMD: arrPreviousPerior[0], endYMD: minString)
                   print("Period new string")
                   periodNewString = minString + "+" + String(g) + "+" + arrPreviousPerior[2]
                   print(periodNewString)
                  if(g != Int(arrPreviousPerior[1]) ) {
                      
                      
                     periodString = periodString + "_" + arrPreviousPerior[0] + "+" + String(g) + "+" + arrPreviousPerior[2]
                     
                  }else{
                     periodString = periodString + "_" + val
                  }
               }else{
                   print("buoc 3")
                  periodString = periodString + "_" + val
               }
               
               i += 1
               
            }
             periodString = periodNewString + periodString
         }else{
             print("buoc 4")
            periodString = currentPeriorNew
         }
//         print("periodData")
//         print(minString)
//         print(soNgayCK)
//         print(gap+1)
         
         print("Period update")
         print(periodString)
         UserDefaults.standard.set(periodString, forKey: "period")
         
         variable.clearNotiPeriod()
         variable.setNotiAllPeriod(selectDoDai1Thang: Int(soNgayCK)!, selectDoDaiChuky: gap + 1, ngayDauDMY: minString)
      }
      
      
      return result
   }
   func getWidthMaxScreen(myVal: CGFloat, myMax: CGFloat) -> CGFloat {
      var result = myVal * myMax / 35
      if(result > 330) {
         result = 330
      }
      
      return result
   }
   var arrDN = [
       "vi" : [
         "Phụ nữ hãy đẹp mỗi ngày, đừng chỉ đẹp khi cần.",
         "Là phụ nữ, hãy sống như cây như hoa, dù không ai nhìn ngắm chiêm ngưỡng, vẫn luôn tươi xanh, vẫn luôn nở rộ.",
         "Bạn không cần là bất cứ ai, hãy là chính mình.",
         "Tự nhiên mang lại cho bạn một gương mặt trẻ đẹp ở tuổi hai mươi, và đem lại cho bạn cả sự tự tin trên khuôn mặt khi ở tuổi năm mươi.",
         "Bạn độc thân, nhưng bạn là một cô gái có giá trị nhé.",
         "Phụ nữ khôn ngoan hơn đàn ông vì họ biết ít hơn nhưng hiểu nhiều hơn.",
         "Mọi phụ nữ đều đẹp và đôi khi chỉ có cánh mày râu mới nhìn thấy vẻ đẹp tiềm ẩn này.",
         "Sắc đẹp tự nó đủ sức thuyết phục đôi mắt của người đàn ông mà chẳng cần nhà hùng biện.",
         "Rượu ngon và lời nói ngọt ngào của người phụ nữ là hai độc dược dịu dàng, mê hoặc lòng người.",
         "Phụ nữ ngốc là chăm chăm nhìn vào khuyết điểm của đàn ông. Phụ nữ thông minh là luôn nhìn vào ưu điểm của đàn ông.",
         "Những bộ quần áo mà bạn mặc không bao giờ làm cho bạn đẹp lên. Chính bạn đã làm cho chúng trở nên đẹp hơn."
       ],
       "en" : [
         "Everything has beauty, but not everyone sees it.",
         "When you are balanced, and when you listen and attend to the needs of your body, mind, and spirit, your natural beauty comes out.",
         "Be your own kind of beautiful.",
         "A girl should be two things: who and what she wants.",
         "Beauty is not in the face, beauty is a light in the heart.",
         "A woman whose smile is open and whose expression is glad has a kind of beauty no matter what she wears.",
         "Beauty is power, a smile is its sword.",
         "Beauty is not flawless. It makes you shine even through your flaws.",
         "You look beautiful today, just like every other day.",
         "You are worth millions of compliments, and I will spend my entire life telling you how wonderful and stunning you are.",
         "Because of your smile, you make life more beautiful.",
         "Trust your beauty to shine from your eyes and into the souls of that deserve you.",
         "Every girl is beautiful in her own unique way.",
         "You are the most beautiful woman in the world because nothing compares with you.",
         "Your eyes are beautiful because they are filled with kindness and intelligence."
       ],
       "zh" : [
         "青春时代是一个短暂的美梦，当醒来时，它早已消逝得无影无踪了。",
         "女人爱自己就会千方万计地善待自己。",
         "女人，你要漂亮，你可以长得不是很完美，但是一定要让你自己打扮得漂亮、精致、有气质。如果你是已婚女人，更要漂亮。",
         "越是漂亮的人越爱美并自恋着，若是她没有自恋，是因为她没有被自身的美貌所勾勒精神所倾倒。",
         "女人有百千回妩媚，亿万次风情。而女人无论是哪一种美丽都源于女人对自己的爱。",
         "只有不成熟的男人，永远没有不成熟的女人。",
         "与生俱来的漂亮不漂亮只是上苍考验女人的方式。",
         "想要使你自己够坚强与增加你的自信，最好的办法就是拿出胆量去做那些你认为没有把握的事。",
          
         "美的形象是丰富多彩的，而美也是到处出现的……人类本性中就有普遍的爱美的要求。",
         "一颗美丽的心胜过千张美丽的面孔。 ——玛丽安·科尔比托",
         "一个女孩最大的资产不是她漂亮的脸蛋，而是她美丽的心。",
         "虽然我们周游世界寻找美丽，但我们必须随身携带它，否则我们找不到它。——拉尔夫·沃尔多·爱默生",
         "我不喜欢标准的美，没有陌生就没有美。 ——卡尔·拉格菲尔德",
         "你是不完美的，永远存在着不可避免的缺陷。 而且你很漂亮。 -艾米·布鲁姆",
         "美丽并非完美无缺。 即使你有缺陷，它也会让你闪耀。",
         "真正的女孩不完美，完美的女孩也不真实。 –哈利样式",
         "美得让人瞩目，但个性更能俘获人心。 -玛丽莲·梦露",
         "如果你意识到自己有多美丽，你会倒在自己的脚下。 ——拜伦·凯蒂"
       ],
       "de": [
         "Sei ein Mädchen mit Verstand, eine Frau mit Haltung und eine Dame mit Klasse.",
         "Deine Augen sind die hellsten Dinge, die ich je gesehen habe, vielleicht sogar heller als die Sterne darüber.",
         "Die Welt ist voller schöner Dinge, genau wie du. - Trudy Vesotsky",
         "Ein echtes Mädchen ist nicht perfekt, und ein perfektes Mädchen ist nicht echt –Harry Styles",
         "Du bist schöner als die Sonnenuntergänge Sommer",
         "Ein weises Mädchen kennt ihre Grenzen, ein kluges Mädchen weiß, dass sie keine hat. -Marilyn Monroe",
         "Auf sie zu warten ist so entzückend wie auf den Sonnenuntergang zu warten. -Imran Shaikh",
         "Der Körper einer schönen Frau ist nicht für die Liebe gemacht; es ist zu exquisit. Henri de Toulouse. -Lautrec",
         "Schönheit erregt die Aufmerksamkeit, aber die Persönlichkeit erobert das Herz. -Marilyn Monroe",
         "Schön zu sein bedeutet, man selbst zu sein. Du musst dich selbst akzeptieren. -Thich Nhat Hanh",
         "Wenn du wüsstest, wie schön du bist, würdest du dir selbst zu Füßen fallen. - Byron Katie",
         "Lächeln ist die schönste Kurve am Körper eines Mädchens.",
         "Schönheit liegt im Herzen des Betrachters. - HG Wells",
         "Das größte Kapital eines Mädchens ist nicht ihr hübsches Gesicht, sondern ihr schönes Herz.",
         "Es gibt kein lächelndes Gesicht auf dieser Welt, das es nicht ist schön",
         "Du bist unvollkommen, dauerhaft und unvermeidlich fehlerhaft. Und du bist schön. -Amy Bloom",
         "Eine schöne Frau muss damit rechnen, mehr Verantwortung für ihre Schritte zu übernehmen, als eine weniger attraktive. - Samuel Richardson",
         "Hübsche Mädchen, die sich ihres Aussehens nicht bewusst sind, sind attraktiver als wunderschöne Mädchen, die es zur Schau stellen.",
         "Die Schönheit einer Frau liegt nicht in der Kleidung, die sie trägt, der Figur, die sie trägt, oder der Art, wie sie ihr Haar kämmt.",
         "Sei deine eigene Art von Schönheit.",
         "Schmuck, was für eine Wissenschaft! Schönheit, was für eine Waffe! Bescheidenheit, welche Eleganz! -Coco Chan",
         "Verbringen Sie weniger Zeit im Spiegel und mehr Zeit, sich wunderbar zu fühlen. -Frederic Fekkai",
         "Die Schönheit einer Frau wächst mit den Jahren.",
         "Schönheit ist nicht makellos. Es lässt dich trotz deiner Fehler glänzen.",
         "Wahre Schönheit ist, sich selbst treu zu bleiben. - Laetitia Casta",
         "Hübsche Mädchen sind aus Mut und Anmut gemacht.",
       ]
   ]
}


struct InfoHuongDanKhacPhucTrieuChung {
    var value: String
    var priority: Int
}
