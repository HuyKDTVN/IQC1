import ctypes

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)  # For Windows 8.1 or later
except:
    try:
        ctypes.windll.user32.SetProcessDPIAware()   # Fallback for older Windows
    except:
        pass
import csv
import os
import tkinter as tk
from tkinter import filedialog, messagebox


def gop_file_csv():
    # Ẩn cửa sổ Tkinter chính
    root = tk.Tk()
    root.withdraw()

    # Dialog chọn thư mục chứa các file CSV
    folder = filedialog.askdirectory(
        title="Chọn thư mục chứa các file CSV"
    )

    if not folder:
        root.destroy()
        return

    output_file = os.path.join(folder, "merged.csv")
    total_files = 0
    total_rows = 0
    header = None

    try:
        # Mở file kết quả, sử dụng UTF-8 BOM để Excel đọc tiếng Việt tốt
        with open(output_file, "w", newline="", encoding="utf-8-sig") as outfile:
            writer = csv.writer(outfile)

            # Duyệt tất cả file CSV trong thư mục
            for filename in sorted(os.listdir(folder)):
                if not filename.lower().endswith(".csv"):
                    continue

                # Bỏ qua file kết quả nếu chạy lại chương trình
                if os.path.abspath(os.path.join(folder, filename)) == os.path.abspath(output_file):
                    continue

                file_path = os.path.join(folder, filename)

                try:
                    # utf-8-sig hỗ trợ CSV có hoặc không có BOM
                    with open(
                        file_path, "r", newline="", encoding="utf-8-sig"
                    ) as infile:
                        reader = csv.reader(infile)

                        file_header = next(reader, None)
                        if file_header is None:
                            continue

                        # File đầu tiên xác định tiêu đề cột
                        if header is None:
                            header = file_header
                            writer.writerow(header)
                        elif file_header != header:
                            messagebox.showwarning(
                                "Bỏ qua file",
                                f"File {filename} có tiêu đề cột khác "
                                "với các file trước đó nên sẽ bị bỏ qua."
                            )
                            continue

                        # Ghi dữ liệu, không lặp lại tiêu đề
                        for row in reader:
                            writer.writerow(row)
                            total_rows += 1

                        total_files += 1

                except (OSError, UnicodeError, csv.Error) as e:
                    messagebox.showwarning(
                        "Lỗi đọc file",
                        f"Không thể đọc file {filename}:\n{e}"
                    )

        if total_files == 0:
            # Xóa file kết quả rỗng nếu không có CSV hợp lệ
            if os.path.exists(output_file):
                os.remove(output_file)

            messagebox.showwarning(
                "Thông báo",
                "Không tìm thấy file CSV hợp lệ để gộp."
            )
        else:
            messagebox.showinfo(
                "Hoàn thành",
                f"Gộp CSV thành công!\n\n"
                f"Số file đã gộp: {total_files}\n"
                f"Tổng số dòng dữ liệu: {total_rows}\n\n"
                f"File kết quả:\n{output_file}"
            )

    except OSError as e:
        messagebox.showerror(
            "Lỗi",
            f"Không thể tạo file kết quả:\n{e}"
        )

    finally:
        root.destroy()


if __name__ == "__main__":
    gop_file_csv()