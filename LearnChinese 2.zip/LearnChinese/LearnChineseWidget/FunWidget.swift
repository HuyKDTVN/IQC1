import Foundation

class FuncWidget {
    
    func getVocaShowInWidget() -> Vocabulary {
        let variable:Variable = Variable()
        
        var hsk: [Vocabulary] = variable.getDataVocaLiked()
        print("hsk liked")
        print(hsk)
        let hskBaiHocGanNHat: [Vocabulary] = variable.getDataHocGanNhat()
        hsk.append(contentsOf: hskBaiHocGanNHat)
        print("hsk liked")
        print(hsk)
        if hsk.count == 0 {
            hsk = variable.loadVocabulary(hsk: "hsk1")
        }
        print("hsk1")
        print(hsk)
        //hsk = variable.loadVocabulary(hsk: "hsk1")
        
        let soTuToiDa: Int = hsk.count - 1
        let numberRand = Int.random(in: 0...soTuToiDa)
        return hsk[numberRand]
    }
}
