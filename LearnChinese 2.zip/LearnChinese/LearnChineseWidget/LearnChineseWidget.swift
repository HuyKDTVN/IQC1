//
//  LearnChineseWidget.swift
//  LearnChineseWidget
//
//  Created by Huy Le on 11/1/26.
//

import WidgetKit
import SwiftUI

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        SimpleEntry(date: Date(), emoji: "😀")
    }

    func getSnapshot(in context: Context, completion: @escaping (SimpleEntry) -> ()) {
        let entry = SimpleEntry(date: Date(), emoji: "😀")
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        var entries: [SimpleEntry] = []

        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .hour, value: hourOffset, to: currentDate)!
            let entry = SimpleEntry(date: entryDate, emoji: "😀")
            entries.append(entry)
        }

        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }

//    func relevances() async -> WidgetRelevances<Void> {
//        // Generate a list containing the contexts this widget is relevant in.
//    }
}

struct SimpleEntry: TimelineEntry {
    let date: Date
    let emoji: String
}

struct LearnChineseWidgetEntryView : View {
    var entry: Provider.Entry

    @Environment(\.widgetFamily) var family
        @Environment(\.colorScheme) var colorScheme
        @State private var voca = FuncWidget().getVocaShowInWidget()
        var body: some View {
            switch family {
            case .systemSmall:
                VStack {
                    Text(voca.chinese)
                        .font(.system(size: 33).bold())
                        .foregroundColor(Color("textTim"))
                        .padding(.bottom, 5)
                    Text("[\(voca.pinyin)]")
                        .font(.system(size: 18))
                        .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .black.opacity(0.7))
                    Text(voca.vietnamese)
                        .foregroundColor(colorScheme == .dark ? .textGreen : .black)
                        .font(.system(size: 20).bold())
                        .padding(.top, 1)
                }
            case .systemMedium:
                HStack(spacing: 0){
                    VStack(spacing: 0) {
                        Text(voca.chinese)
                            .font(.system(size: 33).bold())
                            .foregroundColor(Color("textTim"))
                            .padding(.bottom, 5)
                        Text("[\(voca.pinyin)]")
                            .font(.system(size: 18))
                            .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .black.opacity(0.7))
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(3)
                    Spacer()
                        .frame(maxHeight: .infinity)
                        .frame(width: 1)
                        .background(colorScheme == .dark ? .gray.opacity(0.1) : .gray.opacity(0.2))
                    VStack{
                        
                    }.frame(width: 3, height: .infinity)
                        .background(.red)
                    VStack(spacing: 0) {
                        Text(voca.vietnamese)
                            .foregroundColor(colorScheme == .dark ? .textGreen : .black)
                            .font(.system(size: 20).bold())
                            .padding(.top, 1)
                    }
                  
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(3)
                
                }
               
                
                
            case .systemLarge:
                VStack(spacing: 0){
                    VStack(spacing: 0) {
                        Text(voca.chinese)
                            .font(.system(size: 50).bold())
                            .foregroundColor(.textTim)
                            .padding(.bottom, 5)
                        Text("[\(voca.pinyin)]")
                            .font(.system(size: 20))
                            .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .black.opacity(0.7))
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    //.layoutPriority(1)
                    VStack{
                        
                    }.frame(width: 3, height: .infinity)
                        
                    Spacer()
                        .frame(maxWidth: .infinity)
                        .frame(height: 1)
                        .background(colorScheme == .dark ? .gray.opacity(0.1) : .gray.opacity(0.2))
                    VStack(spacing: 0) {
                        Text(voca.vietnamese)
                            .font(.system(size: 23).bold())
                            .foregroundColor(.textTim)
                            .padding(.bottom, 10)
                        
                        Text(voca.example)
                            .font(.system(size: 18))
                            .padding(.top, 1)
                    }
                    //.layoutPriority(1)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    //.background(.gray.opacity(0.1))
                }
                .padding(0)
                
                
            default:
                VStack {
                    Text(voca.chinese)
                        .font(.system(size: 33).bold())
                        .foregroundColor(Color("textTim"))
                        .padding(.bottom, 5)
                    Text("[\(voca.pinyin)]")
                        .font(.system(size: 18))
                        .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .black.opacity(0.7))
                    Text(voca.vietnamese)
                        .foregroundColor(colorScheme == .dark ? .textGreen : .black)
                        .font(.system(size: 20).bold())
                        .padding(.top, 1)
                }
            }
            
        }
}

struct LearnChineseWidget: Widget {
    let kind: String = "LearnChineseWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            if #available(iOS 17.0, *) {
                LearnChineseWidgetEntryView(entry: entry)
                    .containerBackground(.fill.tertiary, for: .widget)
            } else {
                LearnChineseWidgetEntryView(entry: entry)
                    .padding()
                    .background()
            }
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}

@available(iOS 17.0, *)
#Preview(as: .systemSmall) {
    LearnChineseWidget()
} timeline: {
    SimpleEntry(date: .now, emoji: "😀")
    SimpleEntry(date: .now, emoji: "🤩")
}
