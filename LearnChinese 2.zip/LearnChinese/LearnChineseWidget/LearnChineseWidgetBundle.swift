//
//  LearnChineseWidgetBundle.swift
//  LearnChineseWidget
//
//  Created by Huy Le on 11/1/26.
//

import WidgetKit
import SwiftUI

@main
struct LearnChineseWidgetBundle: WidgetBundle {
    var body: some Widget {
        LearnChineseWidget()
    }
}
