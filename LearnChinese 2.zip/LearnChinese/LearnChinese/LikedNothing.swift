//
//  LikedNothing.swift
//  LearnChinese
//
//  Created by Huy Le on 4/1/26.
//

import SwiftUI

struct LikedNothing: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack{
            Image(systemName: "star.fill")
                .foregroundColor(.textTim)
                .padding(30)
                .background(.bgTimMo)
                .clipShape(Circle())
                .font(.system(size: 40))
            Text ("Bạn đã học hết các từ khó")
                .font(.system(size: 24).bold())
                .padding(7)
                .multilineTextAlignment(.center)
            Text("Hãy nhấn nút dấu sao tại mỗi từ để thêm vào danh sách từ khó")
                .multilineTextAlignment(.center)
            
            Spacer()
            Button {
                dismiss()
            }label: {
                Image(systemName: "house.fill")
                    .foregroundColor(.white)
                    .padding(20)
                    .background(.textTim)
                    .clipShape(Circle())
                    .font(.system(size: 25))
            }
            
            Spacer()
                .frame(height: 50)
            
        }
        .padding(.leading, 20)
        .padding(.trailing, 20)
        .padding(.top, 150)
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
        .ignoresSafeArea(.container, edges: .top)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color("textTim"))
                        .clipShape(Circle())
                }
            }
        }
    }
}

#Preview {
    LikedNothing()
}
