//
//  SelectLoaiBai.swift
//  LearnChinese
//
//  Created by Huy Le on 24/12/25.
//

import SwiftUI

struct SelectLoaiBai: View {
    let capDo: Int //HSK1
    let soBai: Int // bai 10
    let isFinish : Bool
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    let items = Array(1...3)
    let columns = [
        GridItem(.flexible())
    ]
    @State private var redirect: Bool = false
    
    var arrDataHSK: [[Int]] = [[]]
    
    
    
    init(capDo: Int, soBai: Int, isFinish: Bool) {
        self.capDo = capDo
        self.soBai = soBai
        self.isFinish = isFinish
        
        switch capDo {
            case 1:
                self.arrDataHSK = variable.getDataHSK1()
            case 2:
                self.arrDataHSK = variable.getDataHSK2()
            case 3:
                self.arrDataHSK = variable.getDataHSK3()
            case 8:
                self.arrDataHSK = variable.getDataBoThu50()
            case 7:
                self.arrDataHSK = variable.getDataBoThuAll()
            case 9:
                self.arrDataHSK = variable.getDataLiked()
            default:
                self.arrDataHSK = variable.getDataHSK1()
        }
     
    }
    
    var body: some View {
        //ScrollView{
            VStack {
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text(variable.getTenCapDo(capDo: capDo))
                        .padding(10)
                        .font(.system(size: 18).bold())
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                        .foregroundColor(Color("textTim"))
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color("bgTimMo"))
                        )
                        //.bold()
                        
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                VStack(spacing: 0) {
                    
                    HStack{
                        
                        Spacer()
                        VStack{
                            
                            Text(variable.getSoBai(soBai: soBai))
                                .font(.system(size: 22).bold())
                                .padding(10)
                                .padding(.leading, 20)
                                .padding(.trailing, 20)
                                .foregroundColor(Color("textTim"))
                                .padding(.top, 0)
                        }
                        Spacer()
                    }
                }
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(items, id: \.self) { item in
                        NavigationLink {
                            switch item
                            {
                            case 1:
                                HocFlashCard(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                            case 2:
                                HocTracNghiem(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                            case 3:
                                HocViet(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                            default:
                                HocFlashCard(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                            }
                            
                        } label: {
                            VStack(spacing: 7) {
                                Text("\(Variable().loaiBaiHoc[item - 1])")
                                    .foregroundColor(.black)
                                    .bold()
                                    .font(.system(size: 20))
                                    .padding(.bottom, 20)
                                HStack{
                                    ZStack{
                                        Image("\(Variable().loaiBaiHocIcon[item - 1])")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(height: 50)
                                            .padding(.leading, 15)
                                    }
                                    .frame(width: 100)
                                    if capDo != 9 {
                                    ZStack{
                                        HStack(spacing: 1) {
                                            ForEach(1...5, id: \.self) { i in
                                                Image(systemName: "star.fill")
                                                    .foregroundColor(.gray.opacity(0.5))
                                                    .padding(0)
                                                    .font(.system(size: 18))
                                            }
                                            Spacer()
                                        }
                                            let count = arrDataHSK[soBai - 1][item - 1]
                                            if count > 0 {
                                                HStack(spacing: 1) {
                                                    
                                                    ForEach(1...count, id: \.self) { i in
                                                        Image(systemName: "star.fill")
                                                            .foregroundColor(.yellow)
                                                            .padding(0)
                                                            .font(.system(size: 18))
                                                    }
                                                    Spacer()
                                                }
                                            }
                                        }
                                    }
                                    Spacer()
                                }
                                
                               
                                
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 150)
                            .cornerRadius(40)
                            .background(
                                RoundedRectangle(cornerRadius: 40)
                                    .fill(Color.white)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 40)
                                            .stroke(Color("textTim"), lineWidth: 1)
                                    )
                            )
                        }
                        .buttonStyle(PlainButtonStyle()) // Giữ style gốc, không bị mặc định NavigationLink
                    }
                }
                .padding(.horizontal)
            
                .padding(.vertical, 20)
                .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
                Spacer()
                NavigationLink("", isActive: $redirect) {
                    ContentView()
                }
            }
            
        //}
        .padding(.top, 50)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                if isFinish == false {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                }
            }
        }
    }
}


#Preview {
    SelectLoaiBai(capDo: 1, soBai: 1, isFinish: true)
}
