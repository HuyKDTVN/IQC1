//
//  HuyFunc.swift
//  LearnChinese
//
//  Created by Huy Le on 10/1/26.
//
import Foundation
import UIKit
import UserNotifications
class HuyFunc {
    func rateApp(completion: @escaping ((_ success: Bool)->())) {
        guard let url = URL(string : Variable().link_app) else {
            completion(false)
            return
        }
        guard #available(iOS 10, *) else {
            completion(UIApplication.shared.openURL(url))
            return
        }
        UIApplication.shared.open(url, options: [:], completionHandler: completion)
    }
    func notiNhacTuMoiMoiNgay() -> Void {
        let variable = Variable()
        if variable.getUserDefaultBool(name: "nhacnhotumoi") {
            var hsk: [Vocabulary] = variable.getDataVocaLiked()
            let hskBaiHocGanNHat: [Vocabulary] = variable.getDataHocGanNhat()
            hsk.append(contentsOf: hskBaiHocGanNHat)
            
            if hsk.count == 0 {
                hsk = variable.loadVocabulary(hsk: "hsk1")
            }
           
            let soTuToiDa: Int = hsk.count - 1
            var numberRand = Int.random(in: 0...soTuToiDa)
            var voca = hsk[numberRand]
            var content = voca.vietnamese
            if voca.example != "" {
                content = "\(content). Ví dụ: \(voca.example)"
            }
            setNotiDaily(mtitle: "\(voca.chinese) [\(voca.pinyin)]" , mcontent: content, gio: 8, phut: 34, myName: "nhactumoi1")
            
            numberRand = Int.random(in: 0...soTuToiDa)
            voca = hsk[numberRand]
            content = voca.vietnamese
            if voca.example != "" {
                content = "\(content). Ví dụ: \(voca.example)"
            }
            setNotiDaily(mtitle: "\(voca.chinese) [\(voca.pinyin)]" , mcontent: content, gio: 10, phut: 9, myName: "nhactumoi2")
            
            numberRand = Int.random(in: 0...soTuToiDa)
            voca = hsk[numberRand]
            content = voca.vietnamese
            if voca.example != "" {
                content = "\(content). Ví dụ: \(voca.example)"
            }
            setNotiDaily(mtitle: "\(voca.chinese) [\(voca.pinyin)]" , mcontent: content, gio: 14, phut: 5, myName: "nhactumoi3")
            
            numberRand = Int.random(in: 0...soTuToiDa)
            voca = hsk[numberRand]
            content = voca.vietnamese
            if voca.example != "" {
                content = "\(content). Ví dụ: \(voca.example)"
            }
            setNotiDaily(mtitle: "\(voca.chinese) [\(voca.pinyin)]" , mcontent: content, gio: 16, phut: 3, myName: "nhactumoi4")
            
           
            numberRand = Int.random(in: 0...soTuToiDa)
            voca = hsk[numberRand]
            content = voca.vietnamese
            if voca.example != "" {
                content = "\(content). Ví dụ: \(voca.example)"
            }
            setNotiDaily(mtitle: "\(voca.chinese) [\(voca.pinyin)]" , mcontent: content, gio: 17, phut: 12, myName: "nhactumoi5")//17:12
        }
    }
     func setNotiDaily(mtitle: String, mcontent: String, gio: Int, phut: Int, myName: String) {
        removeNoti(myName: myName)
        
        //set noti repeat daily
        let notificationContent = UNMutableNotificationContent()
        notificationContent.title = mtitle
        notificationContent.body = mcontent
        let currentBadge = UIApplication.shared.applicationIconBadgeNumber
        let newBadge = currentBadge + 1
        notificationContent.badge = NSNumber(value: newBadge)
        notificationContent.sound = .default
                    
        var datComp = DateComponents()
        datComp.hour = gio
        datComp.minute = phut
        
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: datComp, repeats: true)
        let request = UNNotificationRequest(identifier: myName, content: notificationContent, trigger: trigger)
               UNUserNotificationCenter.current().add(request) { (error : Error?) in
                   if let theError = error {
                       print(theError.localizedDescription)
                   }
               }
     }
     
     
     
     func setNoti(mtitle: String, mcontent: String, nam: Int, thang: Int,  ngay: Int, gio: Int, phut: Int, myName: String) {
        removeNoti(myName: myName)
        
        //set noti repeat daily
        let notificationContent = UNMutableNotificationContent()
        notificationContent.title = mtitle
        notificationContent.body = mcontent
         let currentBadge = UIApplication.shared.applicationIconBadgeNumber
         let newBadge = currentBadge + 1
         notificationContent.badge = NSNumber(value: newBadge)
   
        notificationContent.sound = .default
                    
        var datComp = DateComponents()
        datComp.day = ngay
        datComp.month = thang
        datComp.year = nam
        datComp.hour = gio
        datComp.minute = phut
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: datComp, repeats: false)
        let request = UNNotificationRequest(identifier: myName, content: notificationContent, trigger: trigger)
               UNUserNotificationCenter.current().add(request) { (error : Error?) in
                   if let theError = error {
                       print(theError.localizedDescription)
                   }
               }
     }
     
    func setNoti2(
        mtitle: String,
        mcontent: String,
        soNgayCong: Int,   // n ngày cộng thêm
        gio: Int,
        phut: Int,
        myName: String
    ) {
        removeNoti(myName: myName)

        let notificationContent = UNMutableNotificationContent()
        notificationContent.title = mtitle
        notificationContent.body = mcontent

        let currentBadge = UIApplication.shared.applicationIconBadgeNumber
        notificationContent.badge = NSNumber(value: currentBadge + 1)
        notificationContent.sound = .default

        let calendar = Calendar.current
        let today = Date()

        // 👉 Ngày hiện tại + n ngày
        guard let futureDate = calendar.date(byAdding: .day, value: soNgayCong, to: today) else {
            return
        }

        // 👉 Lấy year/month/day từ futureDate
        var datComp = calendar.dateComponents([.year, .month, .day], from: futureDate)

        // 👉 Giờ & phút do người dùng nhập
        datComp.hour = gio
        datComp.minute = phut

        let trigger = UNCalendarNotificationTrigger(
            dateMatching: datComp,
            repeats: false
        )

        let request = UNNotificationRequest(
            identifier: myName,
            content: notificationContent,
            trigger: trigger
        )

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print(error.localizedDescription)
            }
        }
    }

    
     func removeNoti(myName: String) {
        //remove noti before
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [myName])
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [myName])
     }
    func removeDefaultNoti() -> Void {
        removeNoti(myName: "nhacvaohocngay2")
        removeNoti(myName: "nhacvaohocngay3")
        removeNoti(myName: "nhacvaohocngay4")
        removeNoti(myName: "nhacvaohocngay5")
        removeNoti(myName: "nhacvaohocngay6")
        removeNoti(myName: "nhacvaohocngay7")
    }
    func setNotiDefault() -> Void {
        setNoti2(mtitle: NSLocalizedString("🌟 Cột mốc đầu tiên của bạn", comment: ""), mcontent: "Chỉ 5 phút để hoàn thành bài học tiếng Trung đầu tiên!",soNgayCong: 1, gio: 19, phut: 24, myName: "nhacvaohocngay2")
        
        setNoti2(mtitle: NSLocalizedString("⏱ Bạn đang đi chậm hơn", comment: ""), mcontent: "Một từ tiếng Trung là đủ để không bị bỏ lại",soNgayCong: 2, gio: 19, phut: 23, myName: "nhacvaohocngay3")
        
        setNoti2(mtitle: NSLocalizedString("⏳ Từ vựng cần được gặp lại", comment: ""), mcontent: "Quay lại hôm nay bằng 1 từ tiếng Trung nhé",soNgayCong: 3, gio: 19, phut: 26, myName: "nhacvaohocngay4")
        
        setNoti2(mtitle: NSLocalizedString("🌿 Mỗi ngày một chút", comment: ""), mcontent: "Hôm nay vẫn là một ngày tốt để bắt đầu học từ vựng tiếng Trung",soNgayCong: 4, gio: 19, phut: 21, myName: "nhacvaohocngay5")
    }
    
    func setNotiNgay1DaHoc() -> Void {
        removeNoti(myName: "nhacvaohocngay2")
        let randomIndex = Int.random(in: 0..<Variable().arrNotiDatDuocSteak2.count)
        let content = Variable().arrNotiDatDuocSteak2[randomIndex]
        setNoti2(mtitle: NSLocalizedString("Đừng bỏ cuộc lúc này! 🔥", comment: ""), mcontent: content,soNgayCong: 1, gio: 19, phut: 24, myName: "nhacvaohocngay2")
    }
    
    func setNotiNgay2DaHoc() -> Void {
        removeNoti(myName: "nhacvaohocngay3")
        let randomIndex = Int.random(in: 0..<Variable().arrNotiDatDuocSteak3.count)
        let content = Variable().arrNotiDatDuocSteak3[randomIndex]
        setNoti2(mtitle: NSLocalizedString("Đừng bỏ cuộc lúc này! 🔥", comment: ""), mcontent: content,soNgayCong: 2, gio: 19, phut: 24, myName: "nhacvaohocngay3")
    }
    
    func setNotiNgay3DaHoc() -> Void {
        removeNoti(myName: "nhacvaohocngay4")
        let randomIndex = Int.random(in: 0..<Variable().arrNotiDatDuocSteak4.count)
        let content = Variable().arrNotiDatDuocSteak4[randomIndex]
        setNoti2(mtitle: Variable().arrNotiDatDuocSteak4Title[randomIndex], mcontent: content,soNgayCong: 3, gio: 19, phut: 24, myName: "nhacvaohocngay4")
    }
    
    func setNotiNgay4DaHoc() -> Void {
        removeNoti(myName: "nhacvaohocngay5")
        let randomIndex = Int.random(in: 0..<Variable().arrNotiDatDuocSteak5.count)
        let content = Variable().arrNotiDatDuocSteak5[randomIndex]
        setNoti2(mtitle: NSLocalizedString("Đừng bỏ cuộc lúc này! 🔥", comment: ""), mcontent: content,soNgayCong: 4, gio: 19, phut: 24, myName: "nhacvaohocngay5")
    }
    
    func setNotiNgay5DaHoc() -> Void {
        removeNoti(myName: "nhacvaohocngay6")
        let randomIndex = Int.random(in: 0..<Variable().arrNotiDatDuocSteak6.count)
        let content = Variable().arrNotiDatDuocSteak6[randomIndex]
        setNoti2(mtitle: NSLocalizedString("Đừng bỏ cuộc lúc này! 🔥", comment: ""), mcontent: content,soNgayCong: 5, gio: 19, phut: 24, myName: "nhacvaohocngay6")
    }
    func setNotiNgay6DaHoc() -> Void {
        removeNoti(myName: "nhacvaohocngay7")
        let randomIndex = Int.random(in: 0..<Variable().arrNotiDatDuocSteak7.count)
        var content = Variable().arrNotiDatDuocSteak7[randomIndex]
        content = content.replacingOccurrences(of: "[chuoingay]", with: "\(Variable().getChuoiNgay())")
        //content = content.replacingOccurrences(of: "[sotu]", with: "\(Variable().getSoTuDaHoc())")
        setNoti2(mtitle: Variable().arrNotiDatDuocSteak7Title[randomIndex], mcontent: content,soNgayCong: 6, gio: 19, phut: 24, myName: "nhacvaohocngay7")
    }
}
