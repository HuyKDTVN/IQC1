//
//  ModelJson.swift
//  LearnChinese
//
//  Created by Huy Le on 27/12/25.
//
 
import Foundation

struct VocabularyResponse: Codable {
    let vocabulary: [Vocabulary]
}

struct Vocabulary: Codable, Identifiable {
    let id = UUID()
    let chinese: String
    let pinyin: String
    let vietnamese: String
    let example: String
    let cauChuyen: String
//    let example_vi: String
}

