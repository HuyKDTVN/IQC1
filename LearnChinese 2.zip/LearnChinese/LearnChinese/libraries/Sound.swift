//
//  Sound.swift
//  LearnChinese
//
//  Created by Huy Le on 28/12/25.
//

import AVFoundation

class SoundManager {
    static let shared = SoundManager()
    var player: AVAudioPlayer?

    func playSound(name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "mp3") else {
            print("Không tìm thấy file \(name).mp3")
            return
        }

        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch {
            print("Lỗi phát âm thanh:", error)
        }
    }
}
