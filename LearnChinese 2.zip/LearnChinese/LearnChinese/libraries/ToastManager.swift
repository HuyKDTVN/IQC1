
import SwiftUI
import Combine

class ToastManager: ObservableObject {
    @Published var message: String = ""
    @Published var isShowing = false

    func show(_ message: String) {
        self.message = message
        self.isShowing = true

        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.isShowing = false
        }
    }
}
