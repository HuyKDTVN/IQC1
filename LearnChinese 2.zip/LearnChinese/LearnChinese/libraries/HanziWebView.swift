import SwiftUI
import WebKit
struct HanziWebView: UIViewRepresentable {
    let hanzi: String
    let webView: WKWebView  // ✅ nhận từ ngoài

    func makeUIView(context: Context) -> WKWebView {
        webView.navigationDelegate = context.coordinator

        if let url = Bundle.main.url(forResource: "hanzi", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url)
        }

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(hanzi: hanzi)
    }

    class Coordinator: NSObject, WKNavigationDelegate {
        let hanzi: String

        init(hanzi: String) {
            self.hanzi = hanzi
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            let js = "drawHanzi('\(hanzi)');"
            webView.evaluateJavaScript(js)
        }
    }
}

