//
//  ToastView.swift
//  LearnChinese
//
//  Created by Huy Le on 3/1/26.
//

import SwiftUI

import SwiftUI

struct ToastView: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.subheadline)
            .padding()
            .background(.textTim)
            .foregroundColor(.white)
            .cornerRadius(20)
            .padding(.horizontal, 20)
    }
}


#Preview {
    ToastView(message: "demo toast")
}
