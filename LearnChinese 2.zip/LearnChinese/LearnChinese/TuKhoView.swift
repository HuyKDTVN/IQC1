//
//  TuKhoView.swift
//  LearnChinese
//
//  Created by Huy Le on 15/1/26.
//

import SwiftUI

struct TuKhoView: View {
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    
    @State private var redirect: Bool = false
    @State private var data = Variable().getDataVocaLiked()
    var arrDataHSK: [[Int]] = [[]]
    
    var body: some View {
        //ScrollView{
        
            VStack {
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text("Từ khó")
                        .padding(10)
                        .font(.system(size: 18).bold())
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                        .foregroundColor(Color("textTim"))
//                        .background(
//                            RoundedRectangle(cornerRadius: 20)
//                                .fill(Color("bgTimMo"))
//                        )
                        //.bold()
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                    .opacity(0)
                        
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                
                if data.count == 0 {
                    VStack{
                        Image(systemName: "star.fill")
                            .foregroundColor(.textTim)
                            .padding(30)
                            .background(.bgTimMo)
                            .clipShape(Circle())
                            .font(.system(size: 40))
                            .padding(.bottom, 20)
                        Text ("Bạn đã học hết các từ khó")
                            .font(.system(size: 24).bold())
                            .padding(7)
                            .multilineTextAlignment(.center)
                        Text("Hãy nhấn nút dấu sao tại mỗi từ để thêm vào danh sách từ khó")
                            .multilineTextAlignment(.center)
                        
                        Spacer()
                        Button {
                            dismiss()
                        }label: {
                            Image(systemName: "house.fill")
                                .foregroundColor(.white)
                                .padding(20)
                                .background(.textTim)
                                .clipShape(Circle())
                                .font(.system(size: 25))
                        }
                        
                        Spacer()
                            .frame(height: 50)
                        
                    }
                    .padding(.leading, 20)
                    .padding(.trailing, 20)
                    .padding(.top, 150)
                    .ignoresSafeArea(.container, edges: .top)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .navigationBarBackButtonHidden(true)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button {
                                dismiss()
                            } label: {
                                Image(systemName: "chevron.left")
                                    .foregroundColor(.white)
                                    .padding(10)
                                    .background(Color("textTim"))
                                    .clipShape(Circle())
                            }
                        }
                    }
                }else{
                    ScrollView(.vertical,  showsIndicators: false) {
                        LazyVStack(spacing: 0) {
                            
                            ForEach(Array(data.enumerated()), id: \.element.id) { index, voca in
                                TuKhoCard(voca: voca, viTri: index, dataLike: $data)
                            }
                        }
                    }
                    .padding(.vertical, 0)
                    if data.count > 1 {
                        NavigationLink {
                            SelectLoaiBai(capDo: 9, soBai: 1, isFinish: false)
                                .navigationBarHidden(true)
                            
                        }label: {
                            Spacer()
                            Text("Học ngay")
                                .foregroundColor(Color("textTim"))
                                .font(.system(size: 22).bold())
                              
                                .frame(height: 30)
                                .padding(15)
                                .padding(.leading, 20)
                                .padding(.trailing, 20)
                                .background(
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(.textTim.opacity(0.1) )
        //                                .overlay(
        //                                    RoundedRectangle(cornerRadius: 40)
        //                                        .stroke(Color("textTim"), lineWidth: 1)
        //                                )
                                )
                                .padding(5)
                                .padding(.leading, 20)
                                //.frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
                                Spacer()
                        }
                    }
                    
                    
                    Spacer()
                }
                
                    
                
            }
            
        //}
        .padding(.top, 50)
        .background(.gray.opacity(0.1))
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
               
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                
            }
        }
    }
}

#Preview {
    TuKhoView()
}
