//
//  Term.swift
//  LearnChinese
//
//  Created by Huy Le on 30/12/25.
//

import SwiftUI
struct Terms: View {
    var variable:Variable = Variable()
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack{
            WebView(url: variable.link_terms)
        }
        .edgesIgnoringSafeArea(.all)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color("textTim"))
                        .clipShape(Circle())
                }
            }
        }
    }
    
}

struct Terms_Previews: PreviewProvider {
    static var previews: some View {
        Terms()
    }
}
