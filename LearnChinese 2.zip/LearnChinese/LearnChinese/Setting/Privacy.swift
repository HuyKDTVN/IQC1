//
//  Privacy.swift
//  LearnChinese
//
//  Created by Huy Le on 31/12/25.
//

import SwiftUI

struct Privacy: View {
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    
    var body: some View {
        VStack{
            WebView(url: variable.link_privacy)
        }
        .edgesIgnoringSafeArea(.all)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color("textTim"))
                        .clipShape(Circle())
                }
            }
        }
    }
    
}

struct Privacy_Previews: PreviewProvider {
    static var previews: some View {
        Privacy()
    }
}
