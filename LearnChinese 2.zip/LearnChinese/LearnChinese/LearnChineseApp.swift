//
//  LearnChineseApp.swift
//  LearnChinese
//
//  Created by Huy Le on 23/12/25.
//

import SwiftUI

@main
struct LearnChineseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.light)
                //.padding(.top, 50)
                //.navigationBarHidden(true)
        }
    }
}
