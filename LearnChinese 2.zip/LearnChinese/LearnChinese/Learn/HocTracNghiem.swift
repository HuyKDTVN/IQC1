//
//  HocTracNghiem.swift
//  LearnChinese
//
//  Created by Huy Le on 23/12/25.
//

import SwiftUI

struct HocTracNghiem: View {
    let capDo: Int //HSK1
    let soBai: Int // bai 10
    var variable:Variable = Variable()
    @Environment(\.dismiss) var dismiss
    @State private var rotation: Double = 0
    @State private var isFlipped = false
    @State private var hasRedirect = false
    @State private var isPressed = false
    @State private var daDocLanDau = false
    @State private var showToast = false
    @State private var toastMessage = ""  
    @State private var liked: Bool = false
    @State private var hasUpdateChuoiNgay = false
    @State private var showText = true
    @State private var scaleText: CGFloat = 1
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var turnOnSound: Bool = Variable().getUserDefaultBool(name: "amThanh")
    
    var turnOnVoid: Bool = Variable().getUserDefaultBool(name: "giongDoc")
    @State private var hsk: [Vocabulary] = []
    @State private var soTuToiDa : Int  = 0
    @State private var arrCauHoi: [Int] = []
    @State private var arrDapAn: [String] = Array(repeating: "", count: 6)
    let dataHSK: [[Int]] = []
    @State private var arrDataHSK: [[Int]] = Array(repeating: Array(repeating: 0, count: 3), count: 15)
    @State private var disableButton: Bool = false
    
    @State private var step: Int = 0
    @State private var stepLoadingBar: Int = 0
    @State private var prevStep: Int = 0
    @State private var dapAn1Dung: Bool = false
    @State private var dapAn2Dung: Bool = false
    @State private var dapAn3Dung: Bool = false
    @State private var dapAn4Dung: Bool = false
    
    @State private var dapAn1Sai: Bool = false
    @State private var dapAn2Sai: Bool = false
    @State private var dapAn3Sai: Bool = false
    @State private var dapAn4Sai: Bool = false
    
    var body: some View {
        //NavigationView {
            VStack{
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text(variable.getTenCapDo(capDo: capDo))
                        .padding(10)
                        .font(.system(size: 18).bold())
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                        .foregroundColor(Color("textTim"))
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color("bgTimMo"))
                        )
                        //.bold()
                        
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                VStack(spacing: 0){
                    HStack {
                        Text(variable.getSoBai(soBai: soBai))
                        
                            .foregroundColor(Color("textTim"))
                            .font(.system(size: 30))
                            .bold()
                            .padding(.top, 0)
                    }
                    ZStack(alignment: .leading) {
                        GeometryReader { geo in
                            // Thanh nền xám
                            RoundedRectangle(cornerRadius: 7)
                                .fill(Color("bgXam"))
                                .frame(height: 14) // chiều cao thanh
                            // Thanh tiến trình tím
                            RoundedRectangle(cornerRadius: 7)
                                .fill(Color("bgTim"))
                                .frame(width: geo.size.width  * CGFloat(stepLoadingBar) / CGFloat(soTuToiDa), height: 14)
                                .animation(.easeInOut(duration: 0.3), value: stepLoadingBar)
                            
                        }
                        .frame(height: 10) // 14 + padding 20 trên + 20 dưới
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, Variable().getRatioScreen() > 1.8 ? 20 : 10)
                    .padding(.bottom, Variable().getRatioScreen() > 1.8 ? 10 : 0)
                    
                    VStack {
                        HStack{
                            if capDo != 9 {
                                Button{
                                    if liked == false {
                                        //add
                                        if variable.addDataLiked(capDo: capDo, viTriTuCong1: arrCauHoi[step] + 1) {
                                            liked.toggle()
                                            toastMessage = "Đã thêm \(hsk[arrCauHoi[step]].chinese) vào danh sách từ khó"
                                            
                                        }else{
                                            print("Khong the Insert them vi da co du 100 phan tu cua mang liked")
                                            toastMessage = "Không thể thêm \(hsk[arrCauHoi[step]].chinese) vào danh sách từ khó. Hãy giảm bớt số lượng từ khó cần học."
                                        }
                                        showToast = true
                                    }else {
                                        //remove
                                        
                                        if variable.removeDataLiked(capDo: capDo, viTriTuCong1: arrCauHoi[step] + 1) {
                                            toastMessage = "Đã loại bỏ \(hsk[arrCauHoi[step]].chinese) khỏi danh sách từ khó"
                                            showToast = true
                                        }
                                        liked.toggle()
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                        showToast = false
                                    }
                                    print("liked")
                                    print(variable.getDataLiked())
                                }label: {
                                    Image(systemName: liked ? "star.fill" : "star")
                                        .foregroundColor(.textTim)
                                        .padding(0)
                                        .font(.system(size: 22))
                                    
                                }
                                .padding(0)
                                .padding(.leading, 20)
                                .padding(.top, -5)}
                            
                            Spacer()
                            Button {
                                SpeechManager.shared.speak(arrDapAn[5])
                                isPressed = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                                    isPressed = false
                                }
                            } label: {
                                Image(systemName: "speaker.wave.2.fill")
                                    .foregroundColor(Color("bgTim"))
                                    .padding(15)
                                    .background(Color("bgTimMo"))
                                    .clipShape(Circle())
                                    .font(.system(size: 30))
                                    .scaleEffect(isPressed ? 0.85 : 1)
                                    .opacity(isPressed ? 0.6 : 1)
                                    .animation(.easeInOut(duration: 0.15), value: isPressed)
                            }
                        }
                        Spacer()
                        //Text("\(stepLoadingBar)/\(soTuToiDa)")
                        Text(arrDapAn[5])
                            .font(.system(size: 100))
                            .foregroundColor(Color("textTim"))
                            .opacity(showText ? 1 : 0)
                            .scaleEffect(scaleText)
                            .animation(.easeInOut(duration: 0.25), value: showText)
                            .onAppear(){
                                if !daDocLanDau {
                                    daDocLanDau = true
                                    if turnOnVoid {
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                            SpeechManager.shared.speak(arrDapAn[5])
                                        }
                                    }
                                    
                                }
                                
                            }
                        Spacer()
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(
                        RoundedRectangle(cornerRadius: 70)
                            .fill(Color("bgTim2"))
                    )
                    .padding()
                    
                    //Spacer()
                    HStack{
                        Spacer()
                        Button {
                            submitButton(dapAn: 1)
                        } label: {
                            Text(arrDapAn[1])
                            
                                .foregroundColor((dapAn1Dung || dapAn1Sai) ? Color.white : Color("textTim"))
                                .font(.system(size: Variable().getRatioScreen() > 1.8 ? 22 : 19))
                                .frame(maxWidth: .infinity)
                                .frame(height: Variable().getRatioScreen() > 1.8 ? 80 : 70)
                                .padding(20)
                                .padding(.leading, 7)
                                .padding(.trailing, 7)
                                .background(
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(dapAn1Dung ? Color("bgTim") : dapAn1Sai ? Color.red : Color.white )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 40)
                                                .stroke(Color("textTim"), lineWidth: 1)
                                        )
                                )
                                .padding(5)
                                .padding(.leading, 20)
                        }
                        .disabled(disableButton)
                        .opacity(showText ? 1 : 0)
                        .scaleEffect(scaleText)
                        .animation(.easeInOut(duration: 0.25), value: showText)
                        Spacer()
                        Button {
                            submitButton(dapAn: 2)
                        } label: {
                            Text(arrDapAn[2])
                                .foregroundColor((dapAn2Dung || dapAn2Sai) ? Color.white : Color("textTim"))
                                .font(.system(size: Variable().getRatioScreen() > 1.8 ? 22 : 19))
                                .frame(maxWidth: .infinity)
                                .frame(height: Variable().getRatioScreen() > 1.8 ? 80 : 70)
                                .padding(20)
                                .padding(.leading, 7)
                                .padding(.trailing, 7)
                                .background(
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(dapAn2Dung ? Color("bgTim") : dapAn2Sai ? Color.red : Color.white )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 40)
                                                .stroke(Color("textTim"), lineWidth: 1)
                                        )
                                )
                                .padding(5)
                                .padding(.trailing, 20)
                            
                        }.disabled(disableButton)
                            .opacity(showText ? 1 : 0)
                            .scaleEffect(scaleText)
                            .animation(.easeInOut(duration: 0.25), value: showText)
                        Spacer()
                    }
                    .padding(.bottom, 0)
                    HStack{
                        Spacer()
                        Button {
                            submitButton(dapAn: 3)
                        } label: {
                            Text(arrDapAn[3])
                                .foregroundColor((dapAn3Dung || dapAn3Sai) ? Color.white : Color("textTim"))
                                .font(.system(size: Variable().getRatioScreen() > 1.8 ? 22 : 19))
                                .frame(maxWidth: .infinity)
                                .frame(height: Variable().getRatioScreen() > 1.8 ? 80 : 70)
                                .padding(20)
                                .padding(.leading, 7)
                                .padding(.trailing, 7)
                                .background(
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(dapAn3Dung ? Color("bgTim") : dapAn3Sai ? Color.red : Color.white )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 40)
                                                .stroke(Color("textTim"), lineWidth: 1)
                                        )
                                )
                                .padding(5)
                                .padding(.leading, 20)
                        }.disabled(disableButton)
                            .opacity(showText ? 1 : 0)
                            .scaleEffect(scaleText)
                            .animation(.easeInOut(duration: 0.25), value: showText)
                        Spacer()
                        Button {
                            submitButton(dapAn: 4)
                        } label: {
                            Text(arrDapAn[4])
                                .foregroundColor((dapAn4Dung || dapAn4Sai) ? Color.white : Color("textTim"))
                                .font(.system(size: Variable().getRatioScreen() > 1.8 ? 22 : 19))
                                .frame(maxWidth: .infinity)
                                .frame(height: Variable().getRatioScreen() > 1.8 ? 80 : 70)
                                .padding(20)
                                .padding(.leading, 7)
                                .padding(.trailing, 7)
                                .background(
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(dapAn4Dung ? Color("bgTim") : dapAn4Sai ? Color.red : Color.white )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 40)
                                                .stroke(Color("textTim"), lineWidth: 1)
                                        )
                                )
                                .padding(5)
                                .padding(.trailing, 20)
                            
                        }.disabled(disableButton)
                            .opacity(showText ? 1 : 0)
                            .scaleEffect(scaleText)
                            .animation(.easeInOut(duration: 0.25), value: showText)
                        Spacer()
                        NavigationLink("", isActive: $hasRedirect) {
                            Finish(capDo: capDo, soBai: soBai, loaiBai: 2, updateChuoiNgay: hasUpdateChuoiNgay)
                        }
                    }
                    .padding(.bottom, 0)
                }
                .onAppear(){
                    if capDo == 9 {
                        hsk = variable.getDataVocaLiked()
                    }else if capDo == 8{
                        hsk = variable.loadVocabulary(hsk: "bothu50")
                    }else if capDo == 7{
                        hsk = variable.loadVocabulary(hsk: "bothuall")
                    }
                    else{
                        
                        hsk = variable.loadVocabulary(hsk: "hsk\(capDo)")
                    }
                    
                    
                    switch capDo {
                        case 1:
                        arrDataHSK = variable.getDataHSK1()
                        case 2:
                        arrDataHSK = variable.getDataHSK2()
                        case 8:
                        arrDataHSK = variable.getDataBoThu50()
                        case 7:
                        arrDataHSK = variable.getDataBoThuAll()
                        case 3:
                        arrDataHSK = variable.getDataHSK3()
                        case 9:
                        arrDataHSK = variable.getDataLiked()
                        default:
                        arrDataHSK = variable.getDataHSK1()
                        }
                    
                    liked = variable.hasHanziLiked(capDo: capDo, viTriTuCong1: 1, dataLiked: dataHSK)
                    if soBai > 0{
                        if capDo == 9 {
                            arrCauHoi = variable.getArrBaiHoc(a: soBai, doDaiArray: variable.getTotalLinked()).shuffled()
                            
                        } else {
                            
                            arrCauHoi = variable.getArrBaiHoc(a: soBai, doDaiArray: hsk.count).shuffled()
                            
                        }
                    }
                    
                    if step >= 0 && step < arrCauHoi.count {
                        arrDapAn = variable.get4DapAn(voca: hsk, viTriTu: arrCauHoi[step])
                    }
                    
                    if capDo == 9 || soBai == 99 {
                        soTuToiDa = hsk.count
                    }
                    else {
                        soTuToiDa = variable.soTuTrong1Bai
                        if soTuToiDa > arrCauHoi.count {
                            soTuToiDa = arrCauHoi.count
                        }
                    }
                    
                }
                
                .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
            //}
            
            //.background(Color.green.opacity(0.3))
            .navigationBarBackButtonHidden(true)
            //.ignoresSafeArea()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                }
            }
            
        }
            
            .padding(.top, 50)
            .ignoresSafeArea(.container, edges: .top)
            
            .overlay(
                Group {
                    if showToast {
                        VStack {
                            Spacer()
                            ToastView(message: toastMessage)
                                .padding(.bottom, 40)
                                .transition(.opacity)
                        }
                    }
                }
            )
            .animation(.easeInOut, value: showToast)
    }
    private func submitButton(dapAn: Int) -> Void {//next
        if disableButton {
            return
        }
        disableButton = true
        
        let dapAnDung = Int(arrDapAn[0])
        if dapAn == dapAnDung {
            print("tra loi dung")
            stepLoadingBar = stepLoadingBar + 1
            let impact = UIImpactFeedbackGenerator(style: .rigid)
            impact.impactOccurred()
            //stepLoadingBar = stepLoadingBar + 1
            if turnOnSound {
                SoundManager.shared.playSound(name: "hit")
            }
        }else {
            arrCauHoi.append(arrCauHoi[step])
            if turnOnSound {
                SoundManager.shared.playSound(name: "crash2")
            }
            print ("tra loi sai")
            let impact = UIImpactFeedbackGenerator(style: .heavy)
            impact.impactOccurred()
            switch dapAn {
            case 1:
                dapAn1Sai = true
            case 2:
                dapAn2Sai = true
            case 3:
                dapAn3Sai = true
            case 4:
                dapAn4Sai = true
            default:
                dapAn1Sai = true
            }
        }
        
        switch dapAnDung {
        case 1:
            dapAn1Dung = true
        case 2:
            dapAn2Dung = true
        case 3:
            dapAn3Dung = true
        case 4:
            dapAn4Dung = true
        default:
            dapAn1Dung = true
        }
        
        
        //chuyen sang cau hoi moi
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            step = step + 1
            if stepLoadingBar == soTuToiDa {
                //get thanh tich hien tai
                let thanhTichHienTai = arrDataHSK[soBai - 1][1]//1 la trac nghiem
                
                if thanhTichHienTai < 5 {
                    //save Data to UserDefault
                    arrDataHSK[soBai - 1][1] = thanhTichHienTai + 1
                    variable.saveDataHSK(arrHsk: arrDataHSK, capDo: capDo)
                }
                hasUpdateChuoiNgay = variable.updateChuoiNgay()
                
                //luu cap do va so arrCauHoiGanNhat
                
                defaults?.set(arrCauHoi, forKey: "arrCauHoiGanNhat")
                HuyFunc().notiNhacTuMoiMoiNgay()
                let hasUpdateCapDoSoBai = variable.updateCapDoBaiHocCaoNhat(capDo: capDo, baiHoc: soBai)
                HuyFunc().removeDefaultNoti()
                switch variable.getChuoiNgay() {
                case 1:
                    HuyFunc().setNotiNgay2DaHoc()
                case 2:
                    HuyFunc().setNotiNgay3DaHoc()
                case 3:
                    HuyFunc().setNotiNgay4DaHoc()
                case 4:
                    HuyFunc().setNotiNgay5DaHoc()
                case 5:
                    HuyFunc().setNotiNgay6DaHoc()
                default:
                    HuyFunc().setNotiNgay6DaHoc()
                }
                hasRedirect = true
            }else {
                withAnimation {
                    showText = false
                    scaleText = 0.8
                }

                
                //chuyen sang cau hoi tiep theo
                print("step: \(step)")
                print("chu han thu: \(arrCauHoi[step])")
                prevStep = step
                
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    arrDapAn = variable.get4DapAn(voca: hsk, viTriTu: arrCauHoi[step])
                    withAnimation {
                        showText = true
                        scaleText = 1
                    }
                }
                
                if turnOnVoid {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        SpeechManager.shared.speak(arrDapAn[5])
                    }
                }
                liked = variable.hasHanziLiked(capDo: capDo, viTriTuCong1: arrCauHoi[step] + 1, dataLiked: arrDataHSK)
                //reset
                dapAn1Sai = false
                dapAn2Sai = false
                dapAn3Sai = false
                dapAn4Sai = false
                
                dapAn1Dung = false
                dapAn2Dung = false
                dapAn3Dung = false
                dapAn4Dung = false
                
                //DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    disableButton = false
                //}
                
            }
        }
        
        
    }
}


#Preview {
    HocTracNghiem(capDo: 1, soBai: 1)
}
