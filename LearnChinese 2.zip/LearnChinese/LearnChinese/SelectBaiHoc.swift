//
//  SelectBaiHoc.swift
//  LearnChinese
//
//  Created by Huy Le on 23/12/25.
//

import SwiftUI

struct SelectBaiHoc: View {
    var capDo: Int
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    var items: [Int] = [] 
    
        // Cấu hình 2 cột
        let columns = [
            GridItem(.flexible()),
            GridItem(.flexible())
        ]

    var arrDataHSK: [[Int]] = [[]]
  
    init(capDo: Int) {
        self.capDo = capDo
        print("load data hsk: \(capDo)")
        switch capDo {
        case 1:
            self.arrDataHSK = variable.getDataHSK1()
            self.items = Array(1...11)
        case 2:
            self.arrDataHSK = variable.getDataHSK2()
            self.items = Array(1...12)
        case 3:
            self.arrDataHSK = variable.getDataHSK3()
            self.items = Array(1...23)
        case 8:
            self.arrDataHSK = variable.getDataBoThu50()
            self.items = Array(1...4)
        case 7:
            self.arrDataHSK = variable.getDataBoThuAll()
            self.items = Array(1...15)
        case 9:
            self.arrDataHSK = variable.getDataHSK3()
            self.items = Array(1...20)
        default:
            self.arrDataHSK = variable.getDataHSK1()
            self.items = Array(1...10)
        }
        print("arrDataHSK")
        print(arrDataHSK)
    }
        var body: some View {
            //NavigationView {
//                Spacer()
//                    .frame(height: 10)
            VStack{
//                VStack(spacing: 0) {
//                    HStack{
//                        Text(variable.getTenCapDo(capDo: capDo))
//                            .padding(10)
//                            .font(.system(size: 18).bold())
//                            .padding(.leading, 20)
//                            .padding(.trailing, 20)
//                            .foregroundColor(Color("textTim"))
//                            .background(
//                                RoundedRectangle(cornerRadius: 20)
//                                    .fill(Color("bgTimMo"))
//                            )
//                        //.padding(.leading, 20)
//                            .layoutPriority(5)
//                        //                            Spacer()
//                        //                                .frame(height: 10)
//                        //                                .layoutPriority(1)
//                    }
//                }
//                .frame(maxWidth: .infinity)
//                .background(.white)
//                .zIndex(10)
                    ScrollView {
                        VStack(spacing: 0) {
                            
                            HStack{
                                Button {
                                    dismiss()
                                } label: {
                                    Image(systemName: "chevron.left")
                                        .foregroundColor(.white)
                                        .padding(10)
                                        .background(Color("textTim"))
                                        .clipShape(Circle())
                                }
                                Spacer()
                                Text(variable.getTenCapDo(capDo: capDo))
                                    .padding(10)
                                    .font(.system(size: 18).bold())
                                    .padding(.leading, 20)
                                    .padding(.trailing, 20)
                                    .foregroundColor(Color("textTim"))
                                    .background(
                                        RoundedRectangle(cornerRadius: 20)
                                            .fill(Color("bgTimMo"))
                                    )
                                //.padding(.leading, 20)
                                    .layoutPriority(5)
                                Spacer()
                                Button {
                                    
                                } label: {
                                    Image(systemName: "chevron.left")
                                        .foregroundColor(.white)
                                        .padding(10)
                                        .background(Color("textTim"))
                                        .clipShape(Circle())
                                }.opacity(0)
                                //                            Spacer()
                                //                                .frame(height: 10)
                                //                                .layoutPriority(1)
                            }.padding(.horizontal, 20)
                                .padding(.top, 10)
                                
                        }
                        NavigationLink {
                            SelectLoaiBai(capDo: capDo, soBai: 99, isFinish: false)
                                .navigationBarHidden(true)
                        } label: {
                            ZStack() {
                                HStack{
                                    Spacer()
                                        .frame(width: 50)
                                    Text("Ôn tập \(variable.getTenCapDo(capDo: capDo))")
                                        .foregroundColor(.black)
                                        .bold()
                                        .font(.system(size: 20))
                                        .frame(maxWidth: .infinity, alignment: .center)
                                        
                                    HStack{
                                        
                                        Image(systemName: "arrow.right")
                                            .foregroundColor(.textTim)
                                            .padding(10)
                                            .background(Color(.bgTimMo))
                                            .clipShape(Circle())
                                    }
                                    
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 60)
                            .cornerRadius(30)
                            .background(
                                RoundedRectangle(cornerRadius: 40)
                                    .fill(.bgTim2)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 25)
                                            .stroke(Color("textTim"), lineWidth: 1)
                                    )
                            )
                            .padding(.horizontal, 20)
                            .padding(.top,10)
                        }
                        .buttonStyle(PlainButtonStyle()) // Giữ style gốc, không bị mặc định NavigationLink
                        LazyVGrid(columns: columns, spacing: 10) {
                            ForEach(items, id: \.self) { item in
                                NavigationLink {
                                    SelectLoaiBai(capDo: capDo, soBai: item, isFinish: false)
                                        .navigationBarHidden(true)
                                } label: {
                                    VStack(spacing: 7) {
                                        Text("Bài \(item)")
                                            .foregroundColor(.black)
                                            .bold()
                                            .font(.system(size: 20))
                                        
                                        HStack{
                                            Spacer()
                                            ZStack{
                                                Image("\(Variable().loaiBaiHocIcon[0])")
                                                    .resizable()
                                                    .aspectRatio(contentMode: .fit)
                                                    .frame(height: 25)
                                                    //.padding(.leading, 15)
                                            }
                                            .frame(width: 25)
                                            
                                            ZStack{
                                                let count = arrDataHSK[item - 1][0]
                                                HStack(spacing: 1) {
                                                    ForEach(1...5, id: \.self) { i in
                                                        Image(systemName: "star.fill")
                                                            .foregroundColor(count >= i ? .yellow : .gray.opacity(0.5) )
                                                            .padding(0)
                                                            .font(.system(size: 14))
                                                    }
                                                    //Spacer()
                                                }
                                                //let count = arrDataHSK1[safe: item - 1]?[safe: 0] ?? 0
                                                //print("test: \(item)")
                                                
                                                
                                                
                                            }
                                            Spacer()
                                        }
                                        HStack{
                                            Spacer()
                                            ZStack{
                                                Image("\(Variable().loaiBaiHocIcon[1])")
                                                    .resizable()
                                                    .aspectRatio(contentMode: .fit)
                                                    .frame(height: 25)
                                                    //.padding(.leading, 15)
                                            }
                                            .frame(width: 25)
                                            
                                            ZStack{
                                                let count = arrDataHSK[item - 1][1]
                                                HStack(spacing: 1) {
                                                    ForEach(1...5, id: \.self) { i in
                                                        Image(systemName: "star.fill")
                                                            .foregroundColor(count >= i ? .yellow : .gray.opacity(0.5) )
                                                            .padding(0)
                                                            .font(.system(size: 14))
                                                    }
                                                    //Spacer()
                                                }
                                            }
                                            Spacer()
                                        }
                                        HStack{
                                            Spacer()
                                            ZStack{
                                                Image("\(Variable().loaiBaiHocIcon[2])")
                                                    .resizable()
                                                    .aspectRatio(contentMode: .fit)
                                                    .frame(height: 25)
                                                    //.padding(.leading, 15)
                                            }
                                            .frame(width: 25)
                                            
                                            ZStack{
                                                let count = arrDataHSK[item - 1][2]
                                                HStack(spacing: 1) {
                                                    ForEach(1...5, id: \.self) { i in
                                                        Image(systemName: "star.fill")
                                                            .foregroundColor(count >= i ? .yellow : .gray.opacity(0.5) )
                                                            .padding(0)
                                                            .font(.system(size: 14))
                                                    }
                                                    //Spacer()
                                                }
                                                
                                            }
                                            //.background(.greenland)
                                            Spacer()
                                        }//.background(.red)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 150)
                                    .cornerRadius(40)
                                    .background(
                                        RoundedRectangle(cornerRadius: 40)
                                            .fill(Color.white)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 40)
                                                    .stroke(Color("textTim"), lineWidth: 1)
                                            )
                                    )
                                }
                                .buttonStyle(PlainButtonStyle()) // Giữ style gốc, không bị mặc định NavigationLink
                            }
                        }
                        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
                        .padding(.horizontal)
                        .padding(.vertical, 20)
                        
                    }
                    
                }
                .padding(.top, 50)
                .ignoresSafeArea(.container, edges: .top)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .navigationBarBackButtonHidden(true)
                
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button {
                            dismiss()
                        } label: {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Color("textTim"))
                                .clipShape(Circle())
                        }
                    }
                }
                .navigationBarTitleDisplayMode(.inline)
                
            }
        
    

        //}

}

//extension Array {
//    subscript(safe index: Int) -> Element? {
//        return indices.contains(index) ? self[index] : nil
//    }
//}
    
#Preview {
    SelectBaiHoc(capDo: 1)
}

