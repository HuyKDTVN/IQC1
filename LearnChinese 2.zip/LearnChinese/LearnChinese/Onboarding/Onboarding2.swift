//
//  Onboarding2.swift
//  LearnChinese
//
//  Created by Huy Le on 18/1/26.
//

import SwiftUI

struct Onboarding2: View {
    @State private var show = false
    var body: some View {
        VStack {
            ZStack{
                Image("iphonex-frame")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    //.frame(width: .infinity)
                    
                VStack{
                    if show {
                        VStack (alignment: .leading){
                            HStack{
                                Image("noti-icon")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 40)
                                    .padding(.leading, 15)
                                    .padding(.trailing, 10)
                                Spacer()
                                    .frame(width: 3)
                                VStack (alignment: .leading){
                                    Text("她[tā]")
                                        .foregroundColor(.white)
                                        .font(.system(size: 18).bold())
                                    Text("Cô ấy, bà ấy")
                                        .foregroundColor(.white)
                                        .font(.system(size: 16))
                                    
                                }
                                Spacer()
                            }
                            
                        }
                        
                        .padding(10)
                        .background(
                            RoundedRectangle(cornerRadius: 30)
                                .fill(Color(.white).opacity(0.1))
                        )
                        .padding(.horizontal, Variable().getRatioScreen() > 1.8 ? 20 : 30)
                        .padding(.top, 120)
                        .transition(.opacity)
                        
                        VStack (alignment: .leading){
                            HStack{
                                Image("noti-icon")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 40)
                                    .padding(.leading, 15)
                                    .padding(.trailing, 10)
                                Spacer()
                                    .frame(width: 3)
                                VStack (alignment: .leading){
                                    Text("漂亮[piàoliang]")
                                        .foregroundColor(.white)
                                        .font(.system(size: 18).bold())
                                    Text("Xinh đẹp")
                                        .foregroundColor(.white)
                                        .font(.system(size: 16))
                                    
                                }
                                Spacer()
                            }
                            
                        }
                        .padding(10)
                        .background(
                            RoundedRectangle(cornerRadius: 30)
                                .fill(Color(.white).opacity(0.1))
                        )
                        .padding(.horizontal, Variable().getRatioScreen() > 1.8 ? 20 : 30)
                        .padding(.top, 10)
                        .transition(.opacity)
                    }
                    
                    Spacer()
                }.onAppear {
                    withAnimation(.easeInOut(duration: 0.5).delay(1)) {
                        show = true
                    }
                }
                
                
            }
            .padding(.top, 0)
            .padding(.horizontal, 45)
            Text("Nhớ từ lâu với thông báo")
                .font(.system(size: 22).bold())
                .multilineTextAlignment(.center)
                .padding(.top, 20)
                .padding(.bottom, 5)
            Text("Ứng dụng sẽ gửi thông báo về các từ bạn đang học giúp bạn nhớ lâu hơn ")
                .multilineTextAlignment(.center)
                .font(.system(size: 16))
            Spacer()
        }
        .padding(.horizontal, 20)
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
    }
}

#Preview {
    Onboarding2()
}
