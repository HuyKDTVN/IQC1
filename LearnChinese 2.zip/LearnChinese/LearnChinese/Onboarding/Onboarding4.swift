//
//  Onboarding4.swift
//  LearnChinese
//
//  Created by Huy Le on 18/1/26.
//

import SwiftUI

struct Onboarding4: View {
    @Binding var text: String
    @Binding var daTraLoiSai: Bool
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        VStack {
            Text("Bạn tên là gì?")
                .font(.system(size: 25).bold())
                .multilineTextAlignment(.center)
                .padding(.top, 20)
                .padding(.bottom, 20)
            TextField("", text: $text)
                .padding(15)
               // .focused($isFocused)
                .font(.system(size: 20))
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(daTraLoiSai ? Color.red: Color.gray.opacity(0.5), lineWidth: 1)
                )
                
               
                .onSubmit {
                    let submitVal =  submitButton()
                }
            Image("avatar2")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 200)
                .padding(.top, 50)
            Spacer()
        }
        .padding(.horizontal, 20)
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
    }
    
    private func submitButton() -> Bool {
        var result = false
        if text != "" {
            defaults?.set(text, forKey: "yourName")
            daTraLoiSai = false
            
            result = true
        }else{
            daTraLoiSai = true
        }
        return result
    }
}

#Preview {
    @State var text = ""
    @State var daTraLoiSai = false
    Onboarding4(text: $text, daTraLoiSai: $daTraLoiSai)
}
