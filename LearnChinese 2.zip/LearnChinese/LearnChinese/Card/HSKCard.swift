//
//  HSKCard.swift
//  LearnChinese
//
//  Created by Huy Le on 2/1/26.
//

import SwiftUI
struct HSKCard: View {
    @State var myTitle : String
    @State var soTu: String
    @State var percent: CGFloat
    @State var colorText: String
    @State var colorBg: String
    var body: some View {
        VStack{
            GeometryReader { geo in
                HStack(spacing: 0) {
                    VStack{
                        Spacer()
                        HStack{
                            Text(myTitle)
                                .textCase( .uppercase)
                                .font(.system(size: 23).bold())
                                .foregroundColor(Color(colorText))
                            Spacer()
                                
                        }
                        Spacer()
                        HStack{
                            HStack(alignment: .center, spacing: 2){
                                
                                Text(soTu)
                                    .font(.system(size: 23))
                                    .foregroundColor(.black)
                                    
                                Text("từ")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                            }
                            .padding(.leading, 15)
                            .padding(.trailing, 15)
                            .padding(.top, 4)
                            .padding(.bottom, 4)
                            .background(
                                RoundedRectangle(cornerRadius: 40)
                                    .fill(Color(colorBg))
                            )
                            .padding(.bottom, -20)
                            Spacer()
                                
                        }
                    }
                    .frame(width: geo.size.width / 3)

                    HStack{
                        Spacer()
                        CircleCardView(tiLeMucTieuAll: percent, myColor: colorText)
                    }
                        .frame(width: geo.size.width / 3)
                     
                    VStack(alignment: .trailing){
                        Spacer()
                            .frame(height: 40)
                        HStack{
                            Spacer()
                            Image(systemName: "arrow.right")
                                .foregroundColor(Color(colorText))
                                .padding(10)
                                .background(Color(colorBg))
                                .clipShape(Circle())
                        }
                    }
                    .padding(.bottom, -20)
                        .frame(width: geo.size.width / 3)
                       
                        
                }
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 40)
                .fill(Color(colorBg).opacity(0.5))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 40)
                .stroke(Color(colorBg), lineWidth: 2)
        )
        .frame(height: 110)
        .padding(.leading, 20)
        .padding(.trailing, 20)
        .padding(.top, 10)
        .padding(.bottom, 0)
        
    }
}

#Preview {
    HSKCard(myTitle: "HSK 1", soTu: "150", percent: 0.8, colorText: "textTim", colorBg: "bgTimMo")
}
