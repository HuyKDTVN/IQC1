//
//  CircleCardView.swift
//  LearnChinese
//
//  Created by Huy Le on 2/1/26.
//

import SwiftUI


struct CircleCardView: View {
    @State private var destArc: CGFloat = 0
    @State var tiLeMucTieuAll: CGFloat
    @State var myColor: String
    var body: some View {
        
        let colorCircleActive:Color = Color(myColor)
        let colorCircle:Color = colorCircleActive.opacity(0.2)
        let widthCircle:CGFloat = 60
        
        let percentMucTieu: Int = Int(tiLeMucTieuAll * 100)
        
        ZStack{
//            Circle()
//                .trim(from: 0, to: 1)
//                .stroke(colorCircle.opacity(0.15), lineWidth: 5)
//                .frame(width: widthCircle, height: widthCircle)
           
            Circle()
                .trim(from: 0, to: destArc)
                .stroke(colorCircleActive, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .frame(width: widthCircle, height: widthCircle)
                .rotationEffect(.init(degrees: -90))
                .onAppear {
                    withAnimation(.easeInOut(duration: 0.7)) {
                        destArc = tiLeMucTieuAll
                    }
                }
            Text("\(percentMucTieu)%")
                .font(.system(size: 16))
                .fontWeight(.bold)
                .foregroundColor(colorCircleActive)
            
        }
        
        
    }
}
#Preview {
    CircleCardView(tiLeMucTieuAll: 0.8, myColor: "textTim")
}
