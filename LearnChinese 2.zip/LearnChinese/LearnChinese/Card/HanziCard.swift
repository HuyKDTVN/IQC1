//
//  HanziCard.swift
//  LearnChinese
//
//  Created by Huy Le on 1/1/26.
//

import SwiftUI
import WebKit

struct HanziCard: View {
    let hanzi: String
    @State private var webView = WKWebView()  // ✅ giữ instance

    var body: some View {
        VStack(spacing: 0) {
            HStack{
                Spacer()
                Button {
                    webView.evaluateJavaScript("replay();") // ✅ replay trên cùng webView
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 25).bold())
                        .padding(13)
                        .foregroundColor(Color("bgTim"))
                        .background(Color("bgTimMo"))
                        .clipShape(Circle())
                }
                .padding(.trailing, 10)
            }
            HanziWebView(hanzi: hanzi, webView: webView) // ✅ truyền cùng instance
                .frame(width: 300, height: 250)
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 40)
                .fill(Color.white)
                .overlay(
                    RoundedRectangle(cornerRadius: 40)
                        .stroke(Color("bgTim"), lineWidth: 1)
                )
        )
        .padding(.bottom, 20)
    }
}

#Preview {
    HanziCard(hanzi: "几")
}
