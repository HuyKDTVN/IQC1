//
//  TuKhoCard.swift
//  LearnChinese
//
//  Created by Huy Le on 15/1/26.
//

import SwiftUI
struct TuKhoCard: View {
    let voca: Vocabulary
    let viTri: Int
    @Binding var dataLike : [Vocabulary]
    @State private var dataLiked = Variable().getDataLiked()
    
    var body: some View {
        HStack {
            VStack(alignment: .leading){
                Spacer()
                Text(voca.chinese)
                    .font(.system(size: 30).bold())
                    .foregroundColor(.textTim)
                    .padding(.bottom, 5)
                    .multilineTextAlignment(.leading)
                Text(voca.vietnamese)
                    .font(.system(size: 19))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            Spacer()
            VStack{
                Button{
                    withAnimation {
                        dataLike.remove(at: viTri) // ✅ CHỈ XOÁ 1 ITEM
                    }
                    let result = Variable().removeDataLiked(capDo: dataLiked[viTri][0], viTriTuCong1: dataLiked[viTri][1])
                }label: {
                    Image(systemName: "trash")
                        .foregroundColor(.textTim)
                        .padding(15)
                        .background(Color("textTim").opacity(0.2))
                        .clipShape(Circle())
                        .font(.system(size: 25))
                }
            }
        }
        .padding(10)
        .padding(.leading, 20)
        .padding(.trailing, 20)
        .background(
            RoundedRectangle(cornerRadius: 30)
                .fill(Color.white)
                .overlay(
                    RoundedRectangle(cornerRadius: 30)
                        .stroke(Color("textTim").opacity(0.1), lineWidth: 1)
                )
        )
//        .padding()
        .padding(.top, 5)
        .padding(.bottom, 5)
        .padding(.horizontal, 20)
        //.background(.green)
        .ignoresSafeArea(edges: .all)
    }
}

#Preview {
    //TuKhoCard(voca: Variable().loadVocabulary(hsk: "hsk1")[0], viTri: 0)
}
