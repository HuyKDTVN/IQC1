//
//  ChuoiNgayView.swift
//  LearnChinese
//
//  Created by Huy Le on 2/1/26.
//

import SwiftUI

struct ChuoiNgayView: View {
    let isHome: Bool
    let items = Array(1...7)
    let itemsChuoi = Variable().getArrChuoiNgayInWeek()
    let yourName = Variable().getUserDefaultString(name: "yourName")
    var body: some View {
        VStack (alignment: .leading) {
            HStack{
                Text(isHome ? "Xin chào \(yourName)" : "Chuỗi ngày liên tiếp")
                    .font(.system(size: 22).bold())
                    .foregroundColor(Color("textXam").opacity(0.8))
                    .padding(2)
                    .padding(.top, 0)
                // .background(.red)
                Spacer()
                HStack(spacing: 2) {
                    Image("fire")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 25)
                    Text ("\(Variable().getChuoiNgay())")
                        .font(.system(size: 16).bold())
                        //.foregroundColor(.white)
                }
                .padding(7)
                .padding(.top, 0)
                .padding(.bottom, 0)
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color("bgGreen2"))
                )
            }
            Text("Hãy bắt đầu học để giữ chuỗi")
                .font(.system(size: 16).italic())
                .padding(.top, -10)
                //.foregroundColor(Color("textTim"))
                //.background(.red)
            
//                    Text("HSK\(variable.capDoHienTai()) (\(variable.capDoHienTaiPerCent(capDo: variable.capDoHienTai()))%)")
//                        .font(.title.bold())
//                        .foregroundColor(Color("textTim"))
            HStack{
                ForEach(items, id: \.self) { item in
                    VStack{
                        HStack(spacing: 1) {
                            Image("fire")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: 25)
                                .padding(7)
                                .padding(.top, 5)
                                .padding(.bottom, 5)
                                .opacity(itemsChuoi[item - 1] == 1 ? 1 : 0)
                        }
                        
                        .background(Variable().checkToday(thu: item) ? .bgGreen2 : Color.white)
                        .clipShape(Circle())
                        Text (Variable().getDayOfW(thu: item + 1))
                            .font(.system(size: 15))
                            .foregroundColor(Variable().checkToday(thu: item) ? .textGreen: Color.black)
                            .padding(.top, 0)
                    }
                }
            }
        }
        .padding(15)
        .padding(.leading, 15)
        .padding(.trailing, 15)
        .frame(maxWidth: .infinity)
        //.frame(height: 300)
        .background(
            RoundedRectangle(cornerRadius: 45)
                .fill(Color("bgGreen1").opacity(0.8))
        )
        
        .padding()
    }
}
#Preview {
    ChuoiNgayView(isHome: true)
}
