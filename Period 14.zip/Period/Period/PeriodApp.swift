//
//  PeriodApp.swift
//  Period
//
//  Created by Huy Le on 08/05/2022.
//

import SwiftUI
import GoogleMobileAds
import AppTrackingTransparency
import AdSupport

@main
struct PeriodApp: App {
    //@UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @Environment(\.scenePhase) var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(mydata: 0, mucDich: 0)
                .onAppear() {
                    //requestAppTrackingPermission()
                    
                    if let displayName = Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String {
                        print("App Display Name: \(displayName)")
                    }
                }
//                .onAppear {
//                    // Tải quảng cáo ngay khi ứng dụng bắt đầu
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//                        if let rootVC = UIApplication.shared.windows.first?.rootViewController {
//                            AppOpenAdManager.shared.loadAd()  // Tải quảng cáo ngay khi mở ứng dụng
//                            // Đảm bảo tải quảng cáo và hiển thị khi có sẵn
//                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
//                                AppOpenAdManager.shared.showAdIfAvailable(from: rootVC)
//                            }
//                        }
//                    }
//                }
                
                .onChange(of: scenePhase) { newPhase in
                    if newPhase == .active {
                        // Tải và hiển thị quảng cáo khi quay lại từ nền
                        if let rootVC = UIApplication.shared.windows.first?.rootViewController {
                            AppOpenAdManager.shared.showAdIfAvailable(from: rootVC)
                        }
                    }
                }
        }
        
    }
}

//class AppDelegate: UIResponder, UIApplicationDelegate {
//    func application(_ application: UIApplication,
//                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
//        
//        
//        
//        MobileAds.shared.start(completionHandler: nil)
//        
//        
//        return true
//    }
//    func applicationDidBecomeActive(_ application: UIApplication) {
//       
//
//    }
//}

func requestAppTrackingPermission() async -> Bool {
    if #available(iOS 14, *) {
        return await withCheckedContinuation { continuation in
            ATTrackingManager.requestTrackingAuthorization { status in
                DispatchQueue.main.async {
                    switch status {
                    case .authorized:
                        print("✅ Cho phép tracking")
                        continuation.resume(returning: true)

                    case .denied:
                        print("❌ Từ chối tracking")
                        continuation.resume(returning: false)

                    case .notDetermined:
                        print("🕒 Chưa xác định")
                        continuation.resume(returning: false)

                    case .restricted:
                        print("🚫 Bị giới hạn")
                        continuation.resume(returning: false)

                    @unknown default:
                        continuation.resume(returning: false)
                    }
                }
            }
        }
    } else {
        // iOS < 14 không có App Tracking Transparency
        return false
    }
}
