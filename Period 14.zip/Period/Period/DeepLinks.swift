//
//  DeepLinks.swift
//  Period - BMI
//
//  Created by Huy Le on 12/11/2023.
//

import Foundation

enum DeepLink : String {
    case home = "home"
    case report = "report"
}
