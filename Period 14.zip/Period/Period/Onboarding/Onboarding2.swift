//
//  Onboarding2.swift
//  Period - BMI
//
//  Created by Huy Le on 7/2/26.
//

import SwiftUI

struct Onboarding2: View {
    @State private var show = false
    var body: some View {
        VStack {
            ZStack{
                Image("iphonex-frame")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    //.frame(width: .infinity)
                    
                VStack{
                    if show {
                        VStack (alignment: .leading){
                            HStack{
                                Image("logo")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 38)
                                    .padding(.leading, 7)
                                    .padding(.trailing, 7)
                                Spacer()
                                    .frame(width: 3)
                                VStack (alignment: .leading){
                                    Text("ngayrungtrung")
                                        .foregroundColor(.white)
                                        .font(.system(size: 16))
                                }
                                Spacer()
                            }
                            
                            
                        }
                        
                        .padding(10)
                        .background(
                            RoundedRectangle(cornerRadius: 30)
                                .fill(Color(.white).opacity(0.1))
                        )
                        .padding(.horizontal, Variable().getRatioScreen() > 1.8 ? 20 : 30)
                        .padding(.top, 120)
                        .transition(.opacity)
                        
                        VStack (alignment: .leading){
                            HStack{
                                Image("logo")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 38)
                                    .padding(.leading, 7)
                                    .padding(.trailing, 7)
                                Spacer()
                                    .frame(width: 3)
                                VStack (alignment: .leading){
                                    Text(String(format: NSLocalizedString("homnaybanthenaodacotrieuchung", comment: ""), NSLocalizedString("nhucdau", comment: "").lowercased()))
                                        .foregroundColor(.white)
                                        .font(.system(size: 16))
                                    
                                }
                                Spacer()
                            }
                            
                        }
                        .padding(10)
                        .background(
                            RoundedRectangle(cornerRadius: 30)
                                .fill(Color(.white).opacity(0.1))
                        )
                        .padding(.horizontal, Variable().getRatioScreen() > 1.8 ? 20 : 30)
                        .padding(.top, 10)
                        .transition(.opacity)
                    }
                    
                    Spacer()
                }.onAppear {
                    withAnimation(.easeInOut(duration: 0.5).delay(1)) {
                        show = true
                    }
                }
                
                
            }
            .padding(.top, 0)
            .padding(.horizontal, 45)
            Text("nhacbandungluc")
                .font(.system(size: 22).bold())
                .multilineTextAlignment(.center)
                .padding(.top, 20)
                .padding(.bottom, 5)
            Text("nhacbandunglucDESC")
                .multilineTextAlignment(.center)
                .font(.system(size: 16))
            Spacer()
        }
        .padding(.horizontal, 20)
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
    }
}

#Preview {
    Onboarding2()
}
