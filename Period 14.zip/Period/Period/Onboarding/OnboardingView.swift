//
//  OnboardingView.swift
//  Period - BMI
//
//  Created by Huy Le on 8/2/26.
//
import SwiftUI

struct OnBoardingView: View {
    @Binding var firstOpen: Bool
    @State private var page = 0
    @State var daTraLoiSai = false
    
    @State var text = ""
    var body: some View {
        VStack {
            TabView (selection: $page){
                Onboarding1(isActive: page == 0).tag(0)
                Onboarding2().tag(1)
                Onboarding3(isActive: page == 2).tag(2)
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            CustomPageIndicator(count: 3, current: page)
            HStack{
                Button {
                    print("Huy")
                    print(page)
                    if page < 2 {
                        if page == 1 {
                            Task {
                                _ = await Variable().requestNotificationPermission()

                                withAnimation(.easeInOut(duration: 0.3)) {
                                    page += 1
                                }
                            }
                        }else{
                            withAnimation(.easeInOut(duration: 0.3)) {
                                page += 1
                            }
                        }
                    }
                    else{
                        Task {
                            _ = await requestAppTrackingPermission()

                            withAnimation(.easeInOut(duration: 0.3)) {
                                firstOpen = true
                            }
                            
                        }
                        
                        
                    }
                }label: {
                    Spacer()
                    Text(NSLocalizedString(Variable().arrButtonOnboarding[page], comment: ""))
                        .foregroundColor(.white)
                        .font(.system(size: 20).bold())
                        .frame(height: 30)
                        .padding(15)
                        .padding(.leading, 30)
                        .padding(.trailing, 30)
                        .background(
                            RoundedRectangle(cornerRadius: 40)
                                .fill(variable.textColorPink)
    //                                .overlay(
    //                                    RoundedRectangle(cornerRadius: 40)
    //                                        .stroke(Color("textTim"), lineWidth: 1)
    //                                )
                        )
                        .padding(5)
                        //.padding(.leading, 20)
                        Spacer()
                }
                
                
            }
        }
    }
}

#Preview {
    @State var firstOpen: Bool = false
    OnBoardingView(firstOpen: $firstOpen)
}
struct CustomPageIndicator: View {
    let count: Int
    let current: Int
    var body: some View {
        HStack(spacing: 8) {
            ForEach(0..<count, id: \.self) { index in
                Circle()
                    .fill(index == current ? variable.textColorPink : Color.gray.opacity(0.3))
                    .frame(
                        width: index == current ? 10 : 8,
                        height: 8
                    )
                    .animation(.easeInOut(duration: 0.25), value: current)
            }
        }
    }
}
