//
//  Onboarding1.swift
//  Period - BMI
//
//  Created by Huy Le on 7/2/26.
//

import SwiftUI

struct Onboarding1: View {
    let isActive: Bool
    var variable:Variable = Variable()
    @State private var show: Bool = false
    var body: some View {
        VStack{
            Text("Wellcome to")
                .font(.system(size: 23).bold())
                .padding(.top, 50)
                .padding(.bottom, 0)
            Text("Period - BMI")
                .font(.system(size: 30).bold())
                .foregroundColor(variable.textColorPink)
                .padding(.bottom, 20)
            
            VStack{
                //if show {
                    VStack{
                        HStack{
                            ZStack{
                                Image("chuky")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 45)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text("trackperiod")
                                .padding(.leading, 10)
                            Spacer()
                        }
                        Rectangle()
                            .stroke(
                                variable.textColorPink.opacity(0.2),
                                style: StrokeStyle(
                                    lineWidth: 1 / UIScreen.main.scale,
                                    dash: [4, 4]
                                )
                            )
                            .frame(height: 1)
                            .padding(.top, 10)
                            .padding(.bottom, 13)
                        HStack{
                            ZStack{
                                Image("de-chiu")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 45)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text("ghinhantamtrangtrieuchung")
                                .padding(.leading, 10)
                            Spacer()
                        }
                        Rectangle()
                            .stroke(
                                variable.textColorPink.opacity(0.2),
                                style: StrokeStyle(
                                    lineWidth: 1 / UIScreen.main.scale,
                                    dash: [4, 4]
                                )
                            )
                            .frame(height: 1)
                            .padding(.top, 10)
                            .padding(.bottom, 13)
                        HStack{
                            ZStack{
                                Image("no-login")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 45)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text("nologin")
                                .padding(.leading, 10)
                            Spacer()
                        }
                    }
                    .padding()
                    .padding(.top, 20)
                    .padding(.bottom, 20)
                    .background(
                        RoundedRectangle(cornerRadius: 45)
                            .fill(variable.textColorPink.opacity(0.05))
                    )
                    .padding(.horizontal, 40)
                //}
            }
            .onAppear{
                withAnimation(.easeInOut(duration: 0.5).delay(1)) {
                    show = true
                }
            }
            Spacer()
        }
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
    }
}

#Preview {
    Onboarding1(isActive: true)
}
