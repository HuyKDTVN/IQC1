//
//  Onboarding3.swift
//  Period - BMI
//
//  Created by Huy Le on 8/2/26.
//
import SwiftUI

struct Onboarding3: View {
    let isActive: Bool
    @State private var show2 = false
    var body: some View {
        VStack {
            ZStack{
                Image("no-pay")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                //.frame(width: .infinity)
            }
            .padding(.top, 50)
            .padding(.bottom, 80)
            .onAppear{//.onChange(of: isActive) { active in
                withAnimation(.easeInOut(duration: 0.5).delay(1)) {
                    show2 = true
                }
            }
            .padding(.top, Variable().getRatioScreen() > 1.8 ? 0 : -30)
            .padding(.horizontal, 45)
            
            Text("allowTitle")
                .font(.system(size: 22).bold())
                .multilineTextAlignment(.center)
                .padding(.top, 20)
                .padding(.bottom, 5)
            Text("allowDesc")
                .multilineTextAlignment(.center)
                .font(.system(size: 16))
            Spacer()
        }
        .padding(.horizontal, 20)
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
    }
}

#Preview {
    Onboarding3(isActive: true)
}

