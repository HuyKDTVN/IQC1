//
//  ManHinhKhaiBao.swift
//  Period - BMI
//
//  Created by Huy Le on 08/05/2022.
//

import SwiftUI

struct ManHinhKhaiBao: View {
    var variable:Variable = Variable()
    //@State var redirectToHomeView: Bool
    
    
    //@Environment(\.presentationMode) var presentationMode
    
    @State var selectedDate = Date()
    
    var doDai1Thang = [22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
    @State private var selectDoDai1Thang = 29
    
    var doDaiChuky = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    @State private var selectDoDaiChuky = 6
   
    var mydata: Int
    var body: some View {
        
        //NavigationView {
            
       VStack{
          ZStack{
              
              VStack {
                  HStack {
                      Spacer()
                      Image("bg-top").resizable().scaledToFit()
                          .frame(width: 130, height: 130, alignment: .top)
                          
                  }
                  Spacer()

                  HStack {
                      
                      Image("bg-bottom").resizable().scaledToFill()
                          .frame(width: 100, height: 100)
                      Spacer()
                  }
              }.edgesIgnoringSafeArea(.all)
              VStack {
                 //NavigationLink(destination: ContentView(mydata: 0, mucDich: 0), isActive: $redirectToHomeView) { EmptyView() }
                  VStack{
                      HStack {
                         
                          Text(NSLocalizedString("sap", comment: "")).padding(.leading, 30)
                              .font(.custom("comfortaa.ttf", size: 30))
                              .foregroundColor(variable.textColor)
                          
                          Spacer()
                      }.padding(.bottom, 1)
              
                      
                     
                      HStack {
                          Text(NSLocalizedString("batdau", comment: "")).padding(.leading, 30)
                              .font(.custom("comfortaa.ttf", size: 50))
                              .foregroundColor(variable.textColorPink)
                          
                          Spacer()
                      }.padding(.top, -5)
                      
                  }
                  
                  
//                 VStack{
//                    HStack {
//                        Text(NSLocalizedString("ngayBatdauKyKinhCuoi", comment: "")).padding(.leading, 30)
//                            .font(.custom("comfortaa.ttf", size: 18))
//                            .foregroundColor(variable.textColor)
//
//                        Spacer()
//                    }.padding(.top, -5)
//
//                   HStack {
//                      DatePicker("", selection: $selectedDate, displayedComponents: .date)
//
//                       Spacer()
//                   }.padding(.top, -5)
//                 }
                  
                 VStack{
                    HStack {
                        Text(NSLocalizedString("ngayBatdauKyKinhCuoi", comment: "")).padding(.leading, 30)
                            .font(.custom("comfortaa.ttf", size: 18))
                            .foregroundColor(variable.textColor)
                        
                        Spacer()
                    }.padding(.top, -5)
                    
                    Button(action: {
                       withAnimation(.easeOut(duration:0.5)){
                          print("show picker date")
                       }
                    }) {
                       HStack {
                          Text(String("...")).padding(0)
                              .font(.custom("comfortaa.ttf", size: 21))
                          Spacer()
                          Image("calendar").resizable()
                              .frame(width: 30, height: 30, alignment: .center)
                              .offset(x: 0, y: 2)
                       }
                       .frame(width: UIScreen.main.bounds.size.width - 90, alignment: .leading)
                       .padding()
                       //.background(.white)
                       .cornerRadius(20)
                       .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 2)
                       .foregroundColor(.black.opacity(0.8))
                    }.padding(.top, 5)
                 }
                 
                 VStack{
                    HStack {
                        Text(NSLocalizedString("dodaiChuKy", comment: "")).padding(.leading, 30)
                            .font(.custom("comfortaa.ttf", size: 18))
                            .foregroundColor(variable.textColor)
                        
                        Spacer()
                    }.padding(.top, 25)
                    
                   Menu {
                       Picker(NSLocalizedString("dodaiChuKy", comment: ""), selection: $selectDoDaiChuky) {
                           ForEach(doDaiChuky, id: \.self) {
                               Text("\($0)")
                                 
                           }
                       }
                          
                   }label: {
                      customLabelDoDaiChuKy
                   }.padding(.top, 5)
                 }
                 
                 VStack{
                    HStack {
                        Text(NSLocalizedString("daoDai1Thang", comment: "")).padding(.leading, 30)
                            .font(.custom("comfortaa.ttf", size: 18))
                            .foregroundColor(variable.textColor)
                        
                        Spacer()
                    }.padding(.top, 25)
                    
                   Menu {
                       Picker(NSLocalizedString("dodaiChuKy", comment: ""), selection: $selectDoDai1Thang) {
                           ForEach(doDai1Thang, id: \.self) {
                               Text("\($0)")

                           }
                       }
                          
                   }label: {
                      customLabelDoDai1Thang
                   }.padding(.top, 5)
                 }
                 
                  
//                  HStack {
//                      Text("\(mydata)").padding(.leading, 30)
//                          .font(.custom("comfortaa.ttf", size: 18))
//                          .foregroundColor(variable.textColor)
//
//                      Spacer()
//                  }.padding(.top, -5)
                  
                  Spacer()
                  
                 VStack{
                    Button(action: {
                        //self.redirectToHomeView = true
                       //ContentView.init(mydata: 0, mucDich: 2)
                        }) {
                            Text(NSLocalizedString("batDau", comment: ""))
                                .frame(minWidth: 0, maxWidth: 250)
                                .font(.custom("comfortaa.ttf", size: 24))
                                .padding()
                                .foregroundColor(.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white, lineWidth: 2)
                            )
                        }
                        .background(variable.textColorPink) // If you have this
                        .cornerRadius(20)         // You also need the cornerRadius here
                 }
              }

          }
              
          Spacer(minLength: 0)
       }
            
//        }.navigationBarBackButtonHidden(true).environment(\.colorScheme, .light).preferredColorScheme(.light)
//            .navigationBarItems(leading:
//                Button(action: goBack) {
//                    HStack {
//                        Image("back").resizable().scaledToFit()
//                            .frame(width: 30, height: 30, alignment: .top)
//                        Spacer()
//                    }
//                }
//            )
            //.onAppear(){
               //let defaults = UserDefaults.standard
               //defaults.set(0, forKey: "mucdich")
            //}
        
       
       
    }
    func goBack(){
            //here I save CoreData context if it changes
            //self.presentationMode.wrappedValue.dismiss()
        }
   var customLabelDoDaiChuKy: some View {
       HStack {
          
          Text(String(selectDoDaiChuky)).padding(0)
              .font(.custom("comfortaa.ttf", size: 21))
          Spacer()
          Image("chuky").resizable()
              .frame(width: 30, height: 30, alignment: .center)
              .offset(x: 0, y: 2)
       }
       .frame(width: UIScreen.main.bounds.size.width - 90, alignment: .leading)
       .padding()
       //.background(.white)
       .cornerRadius(20)
       .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 2)
       .foregroundColor(.black.opacity(0.8))
   }
   
   var customLabelDoDai1Thang: some View {
       HStack {
          Text(String(selectDoDai1Thang)).padding(0)
              .font(.custom("comfortaa.ttf", size: 21))
          Spacer()
          Image("calendar2").resizable()
              .frame(width: 30, height: 30, alignment: .center)
              .offset(x: 0, y: 2)
       }
       .frame(width: UIScreen.main.bounds.size.width - 90, alignment: .leading)
       .padding()
       //.background(.white)
       .cornerRadius(20)
       .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 2)
       .foregroundColor(.black.opacity(0.8))
   }

}

struct ManHinhKhaiBao_Previews: PreviewProvider {
    static var previews: some View {
        ManHinhKhaiBao(mydata: 0)
    }
}
