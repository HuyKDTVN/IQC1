//
//  ManHinhUpdateCalendar.swift
//  Period - BMI
//
//  Created by Huy Le on 20/08/2022.
//

import SwiftUI
import SwiftUICalendar
import ToastUI

struct ManHinhUpdateCalendar: View {
   
   @State var informations = [YearMonthDay: [(Int)]]()
   @Environment(\.presentationMode) var presentationMode
   
   @State private var presentingToast: Bool = false
   
   // Start & End date should be configured based on your needs.
   let variable = Variable()
   @ObservedObject var controller = CalendarController(orientation: .vertical)
       
       @State var focusDate: YearMonthDay? = nil
       @State var focusInfo: [(String, Color)]? = nil
   
   @State private var willMoveToNextScreen = false
   
       init() {
             
       }
   
    var body: some View {
        ZStack{
            VStack{
               VStack {
                   HStack {
                       Spacer()
                       Image("bg-top").resizable().scaledToFit()
                           .frame(width: 130, height: 100, alignment: .top)
                   }
               }.edgesIgnoringSafeArea(.all)
               HStack {
                   Text("update").padding(.leading, 10)
                       .font(.custom("NunitoSans-Bold", size: variable.getRatioScreen() > 1.8 ? 25 : 23))
                       .foregroundColor(variable.textColor)
                   
                   Spacer()
               }
               .padding(.bottom, 1)
               .padding(.top, variable.getRatioScreen() > 1.8 ? -10 : -70)

               HStack {
                   Text("ngaytoithang").padding(.leading, 10)
                       .font(.custom("NunitoSans-Bold", size: variable.getRatioScreen() > 1.8 ? 37 : 25))
                       .foregroundColor(variable.textColorPink)
                   Spacer()
               }
               .padding(.top, variable.getRatioScreen() > 1.8 ? -6 : -45)
               .padding(.bottom, variable.getRatioScreen() > 1.8 ? 25 : -5)
               GeometryReader { reader in
                  VStack (alignment: .leading){
                     
                   
                     Text("\(controller.yearMonth.monthShortString.capitalizingFirstLetter()) \(String(controller.yearMonth.year))")
                        .multilineTextAlignment(.center)
                        .font(Font.custom("comfortaa", size: 22))
                        .textCase(.uppercase)
                        .padding(EdgeInsets(top: 8, leading: 10, bottom: 8, trailing: 0))
                     
                      CalendarView(controller, header: { week in
                         
                          GeometryReader { geometry in
                              Text(week.shortString)
                                .font(Font.custom("comfortaa", size: 16))
                                .textCase(.uppercase)
                                  .frame(width: geometry.size.width, height: geometry.size.height, alignment: .center)
                          }
                      }, component: { date in
                          GeometryReader { geometry in
                              VStack(alignment: .center, spacing: 2) {
                                  
                                  if let infos = informations[date] {
                                      ForEach(infos.indices) { index in
                                          let info = infos[index]
                                          //if focusInfo != nil {
//                                             Rectangle()
//                                                 .fill(info.1.opacity(0.75))
//                                                 .frame(width: geometry.size.width, height: 4, alignment: .center)
//                                                 .cornerRadius(20)
//                                                 .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                          //} else {
//                                              Text(info.0 + "s")
//                                                  .lineLimit(1)
//                                                  .foregroundColor(.white)
//                                                  .font(.system(size: 14, weight: .bold, design: .default))
//                                                  .padding(EdgeInsets(top: 2, leading: 4, bottom: 2, trailing: 4))
//                                                  .frame(width: geometry.size.width, alignment: .center)
//                                                  .background(info.1.opacity(0.75))
//                                                  .cornerRadius(4)
//                                                  .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                          //}
                                         if date.isToday {
                                            Text("\(date.day)")
                                                //.font(.system(size: 18, weight: .semibold, design: .default))
                                                .font(Font.custom("comfortaa", size: 17))
                                                .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                                .foregroundColor(.black.opacity(0.7))
                                                .frame(maxWidth: .infinity, alignment: .center)
                                                .padding(4)
                                                .padding(.bottom, 2)
                                                .padding(.top, 18)
                                            Circle()
                                                .strokeBorder(Color.blue,lineWidth: 0)
                                                .background(Circle())
                                                .foregroundColor(variable.textColorPink)
                                                   .frame(width: 38, height: 38)
                                                   .opacity(0.4)
                                                   .offset(x: 0, y: -38)
                                            Circle()
                                               .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                                .background(Circle()
                                                   .foregroundColor(variable.getColorCalendar(i: (info))))
                                                   .frame(width: 15, height: 15)
                                                   .padding(.bottom, 25)
                                                   .offset(x: 0, y: -38)
                                         }else{
                                            Text("\(date.day)")
                                                //.font(.system(size: 18, weight: .semibold, design: .default))
                                                .font(Font.custom("comfortaa", size: 17))
                                                .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                                .foregroundColor(.black.opacity(0.7))
                                                .frame(maxWidth: .infinity, alignment: .center)
                                                .padding(4)
                                                .padding(.bottom, 2)
                                                .padding(.top, 18)
                                            Circle()
                                               .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                                .background(Circle()
                                                   .foregroundColor(variable.getColorCalendar(i: (info)))
                                                )
                                                   .frame(width: 15, height: 15)
                                                   .padding(.bottom, 25)
                                         }
                                      }
                                  }else{
                                     if date.isToday {
                                        Text("\(date.day)")
                                            //.font(.system(size: 18, weight: .semibold, design: .default))
                                            .font(Font.custom("comfortaa", size: 17))
                                            .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                            .foregroundColor(.black.opacity(0.7))
                                            .frame(maxWidth: .infinity, alignment: .center)
                                            .padding(4)
                                            .padding(.bottom, 2)
                                            .padding(.top, 18)
                                        Circle()
                                            .strokeBorder(Color.blue,lineWidth: 0)
                                            .background(Circle())
                                            .foregroundColor(variable.textColorPink)
                                               .frame(width: 38, height: 38)
                                               .opacity(0.4)
                                               .offset(x: 0, y: -38)
                                        Circle()
                                           .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                            .background(Circle()
                                             .foregroundColor(.white))
                                               .frame(width: 15, height: 15)
                                               .padding(.bottom, 25)
                                               .offset(x: 0, y: -38)
                                     } else {
                                         Text("\(date.day)")
                                             //.font(.system(size: 18, weight: .semibold, design: .default))
                                             .font(Font.custom("comfortaa", size: 17))
                                             .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                             //.foregroundColor(.black.opacity(0.7))
                                             .frame(maxWidth: .infinity, alignment: .center)
                                             .padding(4)
                                             .padding(.bottom, 2)
                                             .padding(.top, 18)
                                        Circle()
                                           .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                            .background(Circle()
                                             .foregroundColor(focusDate == date ? variable.textColorPink: .white))
                                               .frame(width: 15, height: 15)
                                               .padding(.bottom, 25)
                                     }
                                  }
                              }
                              .frame(width: geometry.size.width, alignment: .center)//height: geometry.size.height,
                              //.border(.green.opacity(0.8), width: (focusDate == date ? 1 : 0))
                              .cornerRadius(2)
                              .contentShape(Rectangle())
                              .onTapGesture {
                                  withAnimation {
                                     if (informations[date] != nil) {
                                        focusDate = nil
                                        focusInfo = nil
                                        informations.removeValue(forKey: date)
                                        
                                        
                                     }else{
                                         if focusDate == date {
                                             focusDate = nil
                                             focusInfo = nil
                                            informations.removeValue(forKey: date)
                                            
                                            
                                         } else {

                                             focusDate = date
                                            print("focus date")
                                           //print(focusDate)
                                            //focusInfo = informations[date]
                                            informations[date] = []
                                            informations[date]?.append((0))
                                            //print("calendar update")
                                            //print(focusDate?.day)
                                            //willMoveToNextScreen = true   
                                         }
                                       }
 
                                  }
                              }
                          }
                         
                          .onAppear(){
                             let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
                             //print("periodData")
                             //print(periodData)
                             //let periodData1 = "4-7-2022+29+6_3-8-2022+29+6"
                             //let periodData = periodData1.components(separatedBy: "_")
                             
                             if((periodData?.isEmpty) != nil) {
                                for k in 0..<1{ //periodData!.count
                                   let currentData = periodData![k]
                                   let arrCurrentData = currentData.components(separatedBy: "+")
                                   print("currentData")
                                   print(arrCurrentData[0])
                                   let arrDate = arrCurrentData[0].components(separatedBy: "-")
                                   
                                   let dateFormatter = DateFormatter()
                                   dateFormatter.dateFormat = "dd-MM-yyyy"
                                   //let result:Date = dateFormatter.date(from: arrCurrentData[0]) ?? Date()
                                   print("calendar period")
                                   //print(result)

                                   var date = YearMonthDay.current
                                   
                                   let soNgayDenThang = Int(arrCurrentData[2])!
                                   print(soNgayDenThang)
                                   if soNgayDenThang > 0 {
                                      for i in 0..<soNgayDenThang {
                                         date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                                         date = date.addDay(value: i)
                                         informations[date] = []
                                         informations[date]?.append((0))
                                      }
                                   }
                                   
                                   
                                   
                                   
                                   //print("calendar info")
                                   //print(informations)
                                } //ForEach(periodData, id: \.self) { currentData in
                             } //if(periodData != "") {
//                             print("count info")
//                             print(informations)
                          }
                      })
//                               if let infos = focusInfo {
//                                   List(infos.indices, id: \.self) { index in
//                                       let info = infos[index]
//                                       HStack(alignment: .center, spacing: 0) {
//                                           Circle()
//                                               .fill(info.1.opacity(0.75))
//                                               .frame(width: 12, height: 12)
//                                           Text(info.0)
//                                               .padding(.leading, 8)
//                                       }
//                                   }
//                                   .frame(width: reader.size.width, height: 160, alignment: .center)
//                               }
                  }
                  .frame(width: reader.size.width, height: reader.size.width * 1.25, alignment: .center)
                  
               }
               
               HStack{
                    Button(action: {
                       
                       if(variable.updateChuKy(ob: informations)) {
                          willMoveToNextScreen = true
                       }else{
                          presentingToast = true
                       }
                       
                        }) {
                            Text("update")
                                .frame(minWidth: 0, maxWidth: 180)
                                .font(.custom("comfortaa.ttf", size: 22))
                                .padding(variable.getRatioScreen() > 1.8 ? 15 : 9)
                                
                                .foregroundColor(.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white, lineWidth: 2)
                            )
                        }
                        .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                             ContentView(mydata: 0, mucDich: 0)
                         })
                        .background(variable.textColorPink) // If you have this
                        .cornerRadius(20)  // You also need the cornerRadius herel
                    
                    Button(action: {
                       self.presentationMode.wrappedValue.dismiss()
                       
                        }) {
                            Text("cancel")
                                .frame(minWidth: 0, maxWidth: 180)
                                .font(.custom("comfortaa.ttf", size: 22))
                                .padding(variable.getRatioScreen() > 1.8 ? 15 : 9)
                                .foregroundColor(variable.textColorPinkBorder)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white, lineWidth: 2)
                            )
                        }
                        .background(variable.textColorPink.opacity(0.15))
                        .cornerRadius(20)
                    
               }
               .padding()
               .padding(.leading, 5)
               .padding(.trailing, 5)
               .padding(.bottom, variable.getRatioScreen() > 1.8 ? 50 : 0)
               .toast(isPresented: $presentingToast, dismissAfter: 5) {
                     ToastView {
                       VStack {
                         Text("capnhatchukythatbai")
                           .padding(.bottom)
                           .multilineTextAlignment(.center)

                       }
                     }
                   }
               //Spacer().padding(.bottom, 0)
            }
            
            //.navigate(to: ManHinhKhaiBao(mydata:0), when: $willMoveToNextScreen)
            .environment(\.colorScheme, .light).preferredColorScheme(.light)
            .edgesIgnoringSafeArea(.all)
            
        }.edgesIgnoringSafeArea(.all)
          .tabItem{
            Image(systemName: "calendar").font(.system(size: 26))
           
        }
    }
}

struct ManHinhUpdateCalendar_Previews: PreviewProvider {
    static var previews: some View {
        ManHinhUpdateCalendar()
    }
}
