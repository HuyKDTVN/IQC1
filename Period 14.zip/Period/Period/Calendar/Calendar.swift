import SwiftUI
import SwiftUICalendar
extension YearMonthDay: Hashable {
    public func hash(into hasher: inout Hasher) {
        hasher.combine(self.year)
        hasher.combine(self.month)
        hasher.combine(self.day)
    }
}
struct CalendarViewH: View {
    
    var fullScreenAd: Interstitial?
   @Environment(\.scenePhase) var scenePhase
   
   // Start & End date should be configured based on your needs.
   let variable = Variable()
   @ObservedObject var controller = CalendarController(orientation: .vertical)
       var informations = [YearMonthDay: [(Int)]]()
       @State var focusDate: YearMonthDay? = nil
       @State var focusInfo: [(String, Color)]? = nil
    @State var focusDayType: Int = 0
   
   @State private var willMoveToNextScreen = false
   @State private var hasMoodOrSymptom = false
    @State private var hasSymptoms: Bool = false 
       init() {
           fullScreenAd = Interstitial()
           fullScreenAd?.loadInterstitial()
          let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
          //let periodData1 = "4-7-2022+29+6_3-8-2022+29+6"
          //let periodData = periodData1.components(separatedBy: "_")
          print("ADD")
          //print(variable.getGapDate(startYMD: "2-11-2022", endYMD: "24-1-2023"))
          //print(periodData)
          if((periodData?.isEmpty) != nil) {
             for k in 0..<periodData!.count{
                let currentData = periodData![k]
                let arrCurrentData = currentData.components(separatedBy: "+")
//                print("currentData")
//                print(arrCurrentData[0])
                let arrDate = arrCurrentData[0].components(separatedBy: "-")
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd-MM-yyyy"
                let result:Date = dateFormatter.date(from: arrCurrentData[0]) ?? Date()
//                print("calendar period")
//                print(result)

                var date = YearMonthDay.current
                let soNgayDenThang = Int(arrCurrentData[2])!
//                print("soNgayDenThang")
//                print(soNgayDenThang)
                let soNgayanToan1 = variable.tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!)
                print("so ngay an toan")
                print(soNgayanToan1)
                let soNgayThuThai = variable.tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!)
                for i in soNgayanToan1..<soNgayThuThai {
                   date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                   date = date.addDay(value: i)
                   informations[date] = []
                   informations[date]?.append((2))
                }
                
                if(soNgayDenThang > 0) {
                   for i in 0..<soNgayDenThang {
                      date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                      date = date.addDay(value: i)
                      informations[date] = []
                      informations[date]?.append((0))
                   }
                }
                if(soNgayanToan1 > soNgayDenThang) {
                   for i in soNgayDenThang..<soNgayanToan1{
                      date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                      date = date.addDay(value: i)
                      informations[date] = []
                      informations[date]?.append((1))
                   }
                }
                 
                for i in soNgayThuThai..<Int(arrCurrentData[1])! {
                   date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                   date = date.addDay(value: i)
                   informations[date] = []
                   informations[date]?.append((1))
                }
                
                date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                date = date.addDay(value: variable.tinhNgayRungTrungTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!))
                informations[date] = []
                informations[date]?.append((3))
             } //ForEach(periodData, id: \.self) { currentData in
          } //if(periodData != "") {
       }
   
    var body: some View {
        ZStack{
            VStack {
               
//               VStack {
//                   HStack {
//                       Spacer()
//                       Image("bg-top").resizable().scaledToFit()
//                           .frame(width: 130, height: 100, alignment: .top)
//                           .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? 0: -40)
//                   }
//               }.edgesIgnoringSafeArea(.all)
                HStack {
                    Text(NSLocalizedString("calendar", comment: "")).padding(.leading, 0)
                      .font(Font.custom("NunitoSans-Bold", size: 37))
                      .foregroundColor(variable.textColorPink)
                      //.multilineTextAlignment(.center)
                    //Spacer()
                }
//                .padding(.bottom, -20) //padding(.bottom, variable.getRatioScreen() > 1.8 ? -20 : -40))
                .padding(.top, 10)

               GeometryReader { reader in
                  VStack (alignment: .leading){
                     Text("\(controller.yearMonth.monthShortString.capitalizingFirstLetter()) \(String(controller.yearMonth.year))")
                        .multilineTextAlignment(.center)
                        .font(Font.custom("comfortaa", size: 22))
                        .textCase(.uppercase)
                        .padding(EdgeInsets(top: variable.getRatioScreen() > 1.8 ? -40 : -30, leading: 10, bottom: 0, trailing: 0))
                     
                      CalendarView(controller, header: { week in
                         
                          GeometryReader { geometry in
                              Text(week.shortString)
                                .font(Font.custom("comfortaa", size: 16))
                                .textCase(.uppercase)
                                  .frame(width: geometry.size.width, height: geometry.size.height, alignment: .center)
                          }
                      }, component: { date in
                          GeometryReader { geometry in
                              VStack(alignment: .center, spacing: 2) {
                                  if date.isToday {
                                      
                                      Text("\(date.day)")
                                          .font(Font.custom("comfortaa", size: 17))
                                          .padding(4)
                                          .padding(.bottom, 3)
                                          .padding(.top, 25)
                                          .foregroundColor(.black)
                                          //.background(Color.red.opacity(0.75))
                                          .cornerRadius(14)
                                          .frame(maxWidth: .infinity, alignment: .center)
                                          
                                     Circle()
                                         .strokeBorder(Color.blue,lineWidth: 0)
                                         .background(Circle())
                                         .foregroundColor(variable.textColorPink)
                                            .frame(width: 38, height: 38)
                                            .opacity(0.4)
                                            .offset(x: 0, y: -38)
                                     
                                  } else {
                                      Text("\(date.day)")
                                          //.font(.system(size: 18, weight: .semibold, design: .default))
                                          .font(Font.custom("comfortaa", size: 17))
                                          .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                          .foregroundColor(.black.opacity(0.7))
                                          .frame(maxWidth: .infinity, alignment: .center)
                                          .padding(4)
                                          .padding(.bottom, 3)
                                          .padding(.top, 25)
                                  }
                                  if let infos = informations[date] {
                                      ForEach(infos.indices) { index in
                                          let info = infos[index]
                                          Circle()
                                              .strokeBorder(Color.blue,lineWidth: 0)
                                              .background(Circle()
                                                 .foregroundColor(variable.getColorCalendar(i: (info))))
                                                 .frame(width: 6, height: 6)
                                                 .offset(x: 0, y: date.isToday ? -38 : 0)
                                          var mood = variable.moodForDay(currentYear: date.year, currentMonth: date.month, currentDay: date.day)
                                          if let entry = variable.entryForDay(currentYear: date.year, currentMonth: date.month, currentDay: date.day) {
//                                              if !entry.symptoms.isEmpty {
//                                                  var numDauDau = variable.getNumberSymptomDau(symptom: entry.symptoms.joined(separator: ", "))
//                                                  var numDauBody = variable.getNumberSymptomBody(symptom: entry.symptoms.joined(separator: ", "))
//                                                  var numDauBuomBuom = variable.getNumberSymptomBuomBuom(symptom: entry.symptoms.joined(separator: ", "))
//                                              }
                                              if (mood > 0 || !entry.symptoms.isEmpty) {
                                                  Image("flower")
                                                      .resizable()
                                                      .scaledToFit()
                                                      .frame(width: 18, height: 18)
                                                      .offset(x: 0, y: date.isToday ? -102 : -54)
                                              }
                                          }
                                      }
                                  }
                              }
                              .frame(width: geometry.size.width, alignment: .center)//height: geometry.size.height,
                              //.border(.green.opacity(0.8), width: (focusDate == date ? 1 : 0))
                              
                              .cornerRadius(2)
                              .contentShape(Rectangle())
                              .onTapGesture {
                                  withAnimation {
                                      if focusDate == date {
                                          focusDate = nil
                                          focusInfo = nil
                                          focusDayType = 0
                                      } else {
                                          focusDate = date
                                          //focusDayType = informations[date]
                                          if let array = informations[date], let first = array.first {
                                              focusDayType = first + 1
                                              //print(first) // 👉 In ra: 1
                                          }
                                      }
                                  }
                              }
                          }
                      })
                      .padding(EdgeInsets(top: variable.getRatioScreen() > 1.8 ? -20 : -10, leading: 0, bottom: 0, trailing: 0))
//                      Spacer()
//                               if let infos = focusInfo {
//                                   List(infos.indices, id: \.self) { index in
//                                       let info = infos[index]
//                                       HStack(alignment: .center, spacing: 0) {
//                                           Circle()
//                                               .fill(info.1.opacity(0.75))
//                                               .frame(width: 12, height: 12)
//                                           Text(info.0)
//                                               .padding(.leading, 8)
//                                       }
//                                   }
//                                   .frame(width: reader.size.width, height: 160, alignment: .center)
//                               }
                  }
                  .frame(width: reader.size.width, height: reader.size.width * (variable.getRatioScreen() > 1.8 ? 1.1 : 0.89), alignment: .top)
                  //.background(Color.black)
                   //Spacer()
                   VStack {
                       if focusDayType > 0 {
                           let arrCacGiaiDoanCKColor: [Color] = [variable.colorCircleDo, variable.colorCircleXam, variable.colorCircleXanh, variable.colorCircleTimBorder]
                           HStack{
                               RoundedRectangle(cornerRadius: 25)
                                   .frame(width: 25, height: 10)
                                   .foregroundColor(arrCacGiaiDoanCKColor[focusDayType - 1])
                               Text(NSLocalizedString(variable.arrCacGiaiDoanCK[focusDayType - 1], comment: "")).padding(0).padding(.top, 0)
                                   .font(.custom("NunitoSans-Bold", size: 14))
                                   .opacity(0.7)
                           }
                           .frame(maxWidth: .infinity, alignment: .leading)
                           .padding(.leading, 20)
                       }
                       if focusDate != nil {
                           
                           var mood = variable.moodForDay(currentYear: focusDate!.year, currentMonth: focusDate!.month, currentDay: focusDate!.day)
                           if mood > 0 {
                               HStack{
                                   Image(variable.arrTamTrangImg[mood - 1])
                                       .resizable()
                                       .scaledToFit()
                                       .frame(width: 25, height: 25)
                                   Text(NSLocalizedString(variable.arrTamTrang[mood - 1], comment: ""))
                                       .padding(0)
                                       .padding(.top, 0)
                                       .font(.custom("NunitoSans-Bold", size: 14))
                                       .opacity(0.7)
                               }
                               .frame(maxWidth: .infinity, alignment: .leading)
                               .padding(.leading, 20)
                           }
                           
                           if let entry = variable.entryForDay(currentYear: focusDate!.year, currentMonth: focusDate!.month, currentDay: focusDate!.day) {
                               if !entry.symptoms.isEmpty {
                                   var symptomDau: String = variable.getSymptomDau(symptom: entry.symptoms.joined(separator: ", "))
                                   var symptomBody = variable.getSymptomBody(symptom: entry.symptoms.joined(separator: ", "))
                                   var symptomBuomBuom = variable.getSymptomBuomBuom(symptom: entry.symptoms.joined(separator: ", "))
                                   
                                   if symptomDau != "" {
                                       HStack{
                                           Image("head")
                                               .resizable()
                                               .scaledToFit()
                                               .frame(width: 25, height: 25)
                                               .clipped()
                                                   .scaleEffect(1.3)
                                                   .mask(
                                                       Circle()
                                                           .frame(width: 25, height: 25)
                                                   )
                                           Text(variable.catText(symptomDau))
                                               .padding(0)
                                               .padding(.top, 0)
                                               .font(.custom("NunitoSans-Bold", size: 14))
                                               .opacity(0.7)
                                       }
                                       .frame(maxWidth: .infinity, alignment: .leading)
                                       .padding(.leading, 20)
                                   }
                                   if symptomBody != "" {
                                       HStack{
                                           Image("body")
                                               .resizable()
                                               .scaledToFit()
                                               .frame(width: 25, height: 25)
                                               .clipped()
                                                   .scaleEffect(1.3)
                                                   .mask(
                                                       Circle()
                                                           .frame(width: 25, height: 25)
                                                   )
                                           Text(variable.catText(symptomBody))
                                               .padding(0)
                                               .padding(.top, 0)
                                               .font(.custom("NunitoSans-Bold", size: 14))
                                               .opacity(0.7)
                                       }
                                       .frame(maxWidth: .infinity, alignment: .leading)
                                       .padding(.leading, 20)
                                   }
                                   if symptomBuomBuom != "" {
                                       HStack{
                                           Image("buom-buom")
                                               .resizable()
                                               .scaledToFit()
                                               .frame(width: 25, height: 25)
                                               .clipped()
                                                   .scaleEffect(1.3)
                                                   .mask(
                                                       Circle()
                                                           .frame(width: 25, height: 25)
                                                   )
                                           Text(variable.catText(symptomBuomBuom))
                                               .padding(0)
                                               .padding(.top, 0)
                                               .font(.custom("NunitoSans-Bold", size: 14))
                                               .opacity(0.7)
                                       }
                                       .frame(maxWidth: .infinity, alignment: .leading)
                                       .padding(.leading, 20)
                                   }
                               }
                           }
                       }
                           
                   }
                   //.background(Color.blue)
                   .padding(.top, 15 + reader.size.width * (variable.getRatioScreen() > 1.8 ? 1.1 : 0.89))
                   .frame(maxHeight: .infinity, alignment: .top)
               }
                
                Spacer()
            }
            
            .navigate(to: ManHinhKhaiBao(mydata:0), when: $willMoveToNextScreen)
            .environment(\.colorScheme, .light).preferredColorScheme(.light)
            .edgesIgnoringSafeArea(.all)
            
            Spacer()
        }.edgesIgnoringSafeArea(.all)
          .onChange(of: scenePhase) { newPhase in
                 if newPhase == .inactive {
                     print("Inactive")
                 } else if newPhase == .active {
                     print("Active")
                 } else if newPhase == .background {
                     print("Background")
                 }
            }
          .tabItem{
            Image(systemName: "calendar").font(.system(size: 26))
          }
          .tag(2)
          .onAppear(){
              self.fullScreenAd?.showAd()
              let today = YearMonthDay.current
                  self.focusDate = today
                  if let array = informations[today], let first = array.first {
                      self.focusDayType = first + 1
                  } else {
                      self.focusDayType = 0
                  }
          }
        
    }
}

struct Calendar_Previews: PreviewProvider {
    static var previews: some View {
        CalendarViewH()
    }
}
extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).capitalized + dropFirst()
    }

    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}
extension View {
    /// Navigate to a new view.
    /// - Parameters:
    ///   - view: View to navigate to.
    ///   - binding: Only navigates when this condition is `true`.
    func navigate<NewView: View>(to view: NewView, when binding: Binding<Bool>) -> some View {
        NavigationView {
            ZStack {
                self
                    .navigationBarTitle("")
                    .navigationBarHidden(true)

                NavigationLink(
                    destination: view
                        .navigationBarTitle("")
                        .navigationBarHidden(true),
                    isActive: binding
                ) {
                    EmptyView()
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
