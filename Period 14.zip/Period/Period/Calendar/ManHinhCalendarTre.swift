//
//  ManHinhCalendarTre.swift
//  Period - BMI
//
//  Created by Huy Le on 30/08/2022.
//

import SwiftUI
import SwiftUICalendar
import ToastUI

struct ManHinhCalendarTre: View {
   @State var informations = [YearMonthDay: [(Int)]]()
   @Environment(\.presentationMode) var presentationMode
   
   @State private var presentingToast: Bool = false
   @State var lastDateString: String = ""
   let dateFormatter2 = DateFormatter()
   let defaults = UserDefaults.standard
   
   // Start & End date should be configured based on your needs.
   let variable = Variable()
   @ObservedObject var controller = CalendarController(orientation: .vertical)
       
    @State var focusDate: YearMonthDay? = nil
    @State var focusInfo: [(String, Color)]? = nil
   
   @State private var willMoveToNextScreen = false
   
   @State private var ngayBatDau: String = ""
   @State private var ngayBatDau1: String = "AA"
   @State private var ck: Int = 0
   
    init() {
          
    }
    var body: some View {
        ZStack{
            VStack{
               
               VStack {
                   HStack {
                       Spacer()
                       Image("bg-top").resizable().scaledToFit()
                           .frame(width: 130, height: 100, alignment: .top)
                   }
               }.edgesIgnoringSafeArea(.all)
               HStack {
                   Text("update").padding(.leading, 10)
                       .font(.custom("NunitoSans-Bold", size: variable.getRatioScreen() > 1.8 ? 25 : 23))
                       .foregroundColor(variable.textColor)
                   
                   Spacer()
               }
               .padding(.bottom, 1)
               .padding(.top, variable.getRatioScreen() > 1.8 ? -60 : -70)

               HStack {
                   Text("ngaytoithang").padding(.leading, 10)
                       .font(.custom("NunitoSans-Bold", size: variable.getRatioScreen() > 1.8 ? 37 : 25))
                       .foregroundColor(variable.textColorPink)
                   Spacer()
               }
               .padding(.top, variable.getRatioScreen() > 1.8 ? -35 : -45)
               .padding(.bottom, variable.getRatioScreen() > 1.8 ? 25 : -5)
               GeometryReader { reader in
                  VStack (alignment: .leading){
                     
                   
                     Text("\(controller.yearMonth.monthShortString.capitalizingFirstLetter()) \(String(controller.yearMonth.year))")
                        .multilineTextAlignment(.center)
                        .font(Font.custom("comfortaa", size: 22))
                        .textCase(.uppercase)
                        .padding(EdgeInsets(top: 8, leading: 10, bottom: 8, trailing: 0))
                     
                      CalendarView(controller, header: { week in
                         
                          GeometryReader { geometry in
                              Text(week.shortString)
                                .font(Font.custom("comfortaa", size: 16))
                                .textCase(.uppercase)
                                  .frame(width: geometry.size.width, height: geometry.size.height, alignment: .center)
                          }
                      }, component: { date in
                          GeometryReader { geometry in
                              VStack(alignment: .center, spacing: 2) {
                                  
                                  if let infos = informations[date] {
                                      ForEach(infos.indices) { index in
                                          let info = infos[index]
                                          //if focusInfo != nil {
//                                             Rectangle()
//                                                 .fill(info.1.opacity(0.75))
//                                                 .frame(width: geometry.size.width, height: 4, alignment: .center)
//                                                 .cornerRadius(20)
//                                                 .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                          //} else {
//                                              Text(info.0 + "s")
//                                                  .lineLimit(1)
//                                                  .foregroundColor(.white)
//                                                  .font(.system(size: 14, weight: .bold, design: .default))
//                                                  .padding(EdgeInsets(top: 2, leading: 4, bottom: 2, trailing: 4))
//                                                  .frame(width: geometry.size.width, alignment: .center)
//                                                  .background(info.1.opacity(0.75))
//                                                  .cornerRadius(4)
//                                                  .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                          //}
                                         if date.isToday {
                                            Text("\(date.day)")
                                                //.font(.system(size: 18, weight: .semibold, design: .default))
                                                .font(Font.custom("comfortaa", size: 17))
                                                .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                                .foregroundColor(.black.opacity(0.7))
                                                .frame(maxWidth: .infinity, alignment: .center)
                                                .padding(4)
                                                .padding(.bottom, 2)
                                                .padding(.top, 18)
                                            Circle()
                                                .strokeBorder(Color.blue,lineWidth: 0)
                                                .background(Circle())
                                                .foregroundColor(variable.textColorPink)
                                                   .frame(width: 38, height: 38)
                                                   .opacity(0.4)
                                                   .offset(x: 0, y: -38)
                                            Circle()
                                               .strokeBorder(variable.textColorPinkBorder,lineWidth: 0)
                                                .background(Circle()
                                                   .foregroundColor(variable.getColorCalendar(i: (info))))
                                                   .frame(width: 6, height: 6)
                                                   .padding(.bottom, 25)
                                                   .offset(x: 0, y: -38)
                                         }else{
                                            
                                               Text("\(date.day)")
                                               //.font(.system(size: 18, weight: .semibold, design: .default))
                                                  .font(Font.custom("comfortaa", size: 17))
                                                  .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                                  .foregroundColor(.black.opacity(0.7))
                                                  .frame(maxWidth: .infinity, alignment: .center)
                                                  .padding(4)
                                                  .padding(.bottom, 2)
                                                  .padding(.top, 18)
                                               Circle()
                                                  .strokeBorder(variable.textColorPinkBorder,lineWidth: 0)
                                                  .background(Circle()
                                                   .foregroundColor(variable.getColorCalendar(i: (info)))
                                                  )
                                                  .frame(width: 6, height: 6
                                                  )
                                                  .padding(.bottom, 25)
                                            
                                         }
                                      }
                                  }else{
                                        if date.isToday {
                                           Text("\(date.day)")
                                               //.font(.system(size: 18, weight: .semibold, design: .default))
                                               .font(Font.custom("comfortaa", size: 17))
                                               .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                               .foregroundColor(.black.opacity(0.7))
                                               .frame(maxWidth: .infinity, alignment: .center)
                                               .padding(4)
                                               .padding(.bottom, 2)
                                               .padding(.top, 18)
                                           Circle()
                                               .strokeBorder(Color.blue,lineWidth: 0)
                                               .background(Circle())
                                               .foregroundColor(variable.textColorPink)
                                                  .frame(width: 38, height: 38)
                                                  .opacity(0.4)
                                                  .offset(x: 0, y: -38)
                                           if(dateFormatter2.date(from: String(date.year) + "-" + String(date.month) + "-" + String(date.day)) ?? Date() > dateFormatter2.date(from: lastDateString) ?? Date()){
                                              Circle()
                                                 .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                                  .background(Circle()
                                                   .foregroundColor(focusDate == date ? variable.textColorPink: .white))
                                                     .frame(width: 15, height: 15)
                                                     .padding(.bottom, 25)
                                                     .offset(x: 0, y: -38)
                                           }
                                        } else {
                                           
                                              Text("\(date.day)")
                                              //.font(.system(size: 18, weight: .semibold, design: .default))
                                                 .font(Font.custom("comfortaa", size: 17))
                                                 .opacity(date.isFocusYearMonth == true ? 1 : 0.4)
                                              //.foregroundColor(.black.opacity(0.7))
                                                 .frame(maxWidth: .infinity, alignment: .center)
                                                 .padding(4)
                                                 .padding(.bottom, 2)
                                                 .padding(.top, 18)
                                              if(dateFormatter2.date(from: String(date.year) + "-" + String(date.month) + "-" + String(date.day)) ?? Date() <= Date()){
                                                 if(dateFormatter2.date(from: String(date.year) + "-" + String(date.month) + "-" + String(date.day)) ?? Date() > dateFormatter2.date(from: lastDateString) ?? Date()){
                                                    Circle()
                                                       .strokeBorder(variable.textColorPinkBorder,lineWidth: 2)
                                                       .background(Circle()
                                                         .foregroundColor(focusDate == date ? variable.textColorPink: .white))
                                                       .frame(width: 15, height: 15)
                                                       .padding(.bottom, 25)
                                                 }
                                              }
                                           
                                        }
                                     
                                     
                                  }
                              }
                              .frame(width: geometry.size.width, alignment: .center)//height: geometry.size.height,
                              //.border(.green.opacity(0.8), width: (focusDate == date ? 1 : 0))
                              .cornerRadius(2)
                              .contentShape(Rectangle())
                              .onTapGesture {
                                  withAnimation {
                                     if focusDate == date {
                                         //focusDate = nil
                                         //focusInfo = nil
                                      
                                     } else {

                                         focusDate = date
                                        print("focus date")
                                        print(focusDate)
                                        //focusInfo = informations[date]
                                        //informations[date] = []
                                        //informations[date]?.append((0))
                                        //print("calendar update")
                                        //print(focusDate?.day)
                                        //willMoveToNextScreen = true
                                        
                                     }
                                  }
                              }
                          }
                          .onAppear(){
                             dateFormatter2.dateFormat = "yyyy-MM-dd"
                             let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
                             //print("periodData")
                             //print(periodData)
                             //let periodData1 = "4-7-2022+29+6_3-8-2022+29+6"
                             //let periodData = periodData1.components(separatedBy: "_")
                             
                             if((periodData?.isEmpty) != nil) {
                                for k in 0..<periodData!.count{
                                   let currentData = periodData![k]
                                   let arrCurrentData = currentData.components(separatedBy: "+")
                                   print("currentData")
                                   print(arrCurrentData[0])
                                   let arrDate = arrCurrentData[0].components(separatedBy: "-")
                                   
                                   let dateFormatter = DateFormatter()
                                   dateFormatter.dateFormat = "dd-MM-yyyy"
                                   //let result:Date = dateFormatter.date(from: arrCurrentData[0]) ?? Date()
                                   //print("calendar period")
                                   //print(result)

                                   var date = YearMonthDay.current
                                   
                                   let soNgayDenThang = Int(arrCurrentData[2])!
                                   let soNgayanToan1 = variable.tinhNgayBatDauThuThaiTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!)
                                   let soNgayThuThai = variable.tinhNgayKetThucThuThaiTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!)
                                   for i in 0..<soNgayDenThang {
                                      date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                                      date = date.addDay(value: i)
                                      informations[date] = []
                                      informations[date]?.append((0))
                                   }
                                   
//                                   for i in soNgayDenThang..<soNgayanToan1{
//                                      date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
//                                      date = date.addDay(value: i)
//                                      informations[date] = []
//                                      informations[date]?.append((1))
//                                   }
//
//                                   for i in soNgayanToan1..<soNgayThuThai {
//                                      date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
//                                      date = date.addDay(value: i)
//                                      informations[date] = []
//                                      informations[date]?.append((2))
//                                   }
//
//                                   for i in soNgayThuThai..<Int(arrCurrentData[1])! {
//                                      date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
//                                      date = date.addDay(value: i)
//                                      informations[date] = []
//                                      informations[date]?.append((1))
//                                   }
//
//                                   date = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
//                                   date = date.addDay(value: variable.tinhNgayRungTrungTuDoDaiChuKy(chuKy: Int(arrCurrentData[1])!))
//                                   informations[date] = []
//                                   informations[date]?.append((3))
//
                                   var lastDate = YearMonthDay.init(year: Int(arrDate[2])!, month: Int(arrDate[1])!, day: Int(arrDate[0])!)
                                   lastDate = lastDate.addDay(value: Int(arrCurrentData[2])! - 1 )
                                   lastDateString = String(lastDate.year) + "-" + String(lastDate.month) + "-" + String(lastDate.day)
                                   
                                   ngayBatDau = String(arrDate[0]) + "-" + String(arrDate[1]) + "-" + String(arrDate[2])
                                   if(ngayBatDau1 == "AA") {
                                      ngayBatDau1 = ngayBatDau
                                   }
                                   
                                   ck = variable.getDoDaiCaChuKy()
                                   
                                   //print("count info")
                                   ///print(dateFormatter2.date(from: lastDateString))
                                   
                                } //ForEach(periodData, id: \.self) { currentData in
                             } //if(periodData != "") {
                             
                             
                          }
                      })
//                               if let infos = focusInfo {
//                                   List(infos.indices, id: \.self) { index in
//                                       let info = infos[index]
//                                       HStack(alignment: .center, spacing: 0) {
//                                           Circle()
//                                               .fill(info.1.opacity(0.75))
//                                               .frame(width: 12, height: 12)
//                                           Text(info.0)
//                                               .padding(.leading, 8)
//                                       }
//                                   }
//                                   .frame(width: reader.size.width, height: 160, alignment: .center)
//                               }
                  }
                  .frame(width: reader.size.width, height: reader.size.width * 1.25, alignment: .center)
                  
               }
               
               HStack{
                    Button(action: {
                       print("focus DateHUY")
                       if(focusDate?.day != nil){
                          let focusDateString = String(focusDate!.day) + "-" + String(focusDate!.month) + "-" + String(focusDate!.year)
                          print(focusDateString)
                          //print(ngayBatDau)
                          //print(ck)
                          let ckNew = variable.getGapDate(startYMD: ngayBatDau1, endYMD: focusDateString)
                          print(ckNew)
                          
                          var periodString: String = ""
                          var periodNew: String = ""
                          var doDai1ThangNew: Int = 0
                          var doDaiCKNew: Int = 0
                          let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
                          if(ckNew - ck != 0) {
                             //update thang cu
                             let currentPerior = periodData?[0]
                             let arrCurrentPerior = currentPerior?.components(separatedBy: "+")
                             let soNgayCK = arrCurrentPerior![1]
                             //print(currentPerior)
                             let currentPeriorNew:String = arrCurrentPerior![0] + "+" + String(ckNew) + "+" + arrCurrentPerior![2]
                             print(currentPeriorNew)
                             var i:Int = 0
                             if(periodData!.count > 1) {
                                for val in periodData!{
                                   if(i == 0) {
                                      periodString = currentPeriorNew
                                   }else{
                                      periodString = periodString + "_" + val
                                   }
                                   
                                   i += 1
                                   
                                }
                             }else{
                                periodString = currentPeriorNew
                             }
                          }else{
                             periodString = UserDefaults.standard.string(forKey: "period")!
                          }
                          //update thang moi
                          var ckTrungBinh: Int = 0
                          var soNgayToiThangTrungBinh: Int = 0
                          
                          if(periodData!.count > 1) {
                             for val in periodData!{
                                let arr = val.components(separatedBy: "+")
                                if(ckTrungBinh == 0) {
                                   ckTrungBinh = ckNew
                                }else{
                                    ckTrungBinh = (ckNew + ckTrungBinh) / 2
                                }
                                
                                if(soNgayToiThangTrungBinh == 0) {
                                   soNgayToiThangTrungBinh = Int(arr[2])!
                                }else{
                                   soNgayToiThangTrungBinh = (Int(arr[2])! + soNgayToiThangTrungBinh) / 2
                                }
                                
                                periodNew = focusDateString
                                doDai1ThangNew = ckTrungBinh
                                doDaiCKNew = soNgayToiThangTrungBinh
                             }
                          }else{
                             let currentPerior = periodData?[0]
                             let arrCurrentPerior = currentPerior?.components(separatedBy: "+")

                             periodNew = focusDateString
                             print("truong hop moi co 1 thang")
                             doDai1ThangNew = Int(ckNew)
                             doDaiCKNew = Int(arrCurrentPerior![2])!
                          }
                          print("test tre")
                          print(periodNew)
                          print(doDai1ThangNew)
                          print(doDaiCKNew)
                          
                          periodString = periodNew + "+" + String(doDai1ThangNew) + "+" + String(doDaiCKNew) + "_" + periodString
                          print(periodString)
                          
                          UserDefaults.standard.set(periodString, forKey: "period")
                          variable.clearNotiPeriod()
                          variable.setNotiAllPeriod(selectDoDai1Thang: doDai1ThangNew, selectDoDaiChuky: doDaiCKNew, ngayDauDMY: periodNew)
                          
                          
                       } //if(focusDate?.day != nil){
                       willMoveToNextScreen = true
                       
//                       if(variable.updateChuKy(ob: informations)) {
//                          willMoveToNextScreen = true
//                       }else{
//                          presentingToast = true
//                       }
                       
                        }) {
                            Text("update")
                                .frame(minWidth: 0, maxWidth: 200)
                                .font(.custom("comfortaa.ttf", size: 22))
                                .padding(variable.getRatioScreen() > 1.8 ? 15 : 10)
                                
                                .foregroundColor(.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white, lineWidth: 2)
                            )
                        }
                        .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                              
                             ContentView(mydata: 0, mucDich: 0)
                         })
                        .background(variable.textColorPink) // If you have this
                        .cornerRadius(20)         // You also need the cornerRadius here
                    
                    Button(action: {
                       self.presentationMode.wrappedValue.dismiss()
                       
                        }) {
                            Text("cancel")
                                .frame(minWidth: 0, maxWidth: 200)
                                .font(.custom("comfortaa.ttf", size: 22))
                                .padding(variable.getRatioScreen() > 1.8 ? 15 : 10)
                                .foregroundColor(variable.textColorPinkBorder)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white, lineWidth: 2)
                            )
                        }
                        .background(variable.textColorPink.opacity(0.15))
                        .cornerRadius(20)
                    
               }
               .padding()
               .padding(.leading, 5)
               .padding(.trailing, 5)
               .padding(.bottom, variable.getRatioScreen() > 1.8 ? 50 : -5)
               .toast(isPresented: $presentingToast, dismissAfter: 5) {
                     ToastView {
                       VStack {
                         Text("capnhatchukythatbai")
                           .padding(.bottom)
                           .multilineTextAlignment(.center)

                       }
                     }
                   }
               //Spacer().padding(.bottom, 0)
            }
            
            //.navigate(to: ContentView(mydata: 0, mucDich: 0), when: $willMoveToNextScreen)
            .environment(\.colorScheme, .light).preferredColorScheme(.light)
            .edgesIgnoringSafeArea(.all)
            
        }.edgesIgnoringSafeArea(.all)
          .tabItem{
            Image(systemName: "calendar").font(.system(size: 26))
           
        }
    }
}

struct ManHinhCalendarTre_Previews: PreviewProvider {
    static var previews: some View {
        ManHinhCalendarTre()
    }
}
