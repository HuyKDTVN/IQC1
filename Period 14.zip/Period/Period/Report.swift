//
//  Report.swift
//  Period - BMI
//
//  Created by Huy Le on 21/05/2022.
//

import SwiftUI
import SwiftUICharts
import StoreKit
import GoogleMobileAds
struct Report: View {
    var fullScreenAd: Interstitial?
    var variable:Variable = Variable()
    //let chartStyle = ChartStyle(backgroundColor: Color.black, accentColor: Colors.OrangeStart, secondGradientColor: Colors.OrangeEnd, chartFormSize: ChartForm.medium, textColor: Color.white, legendTextColor: Color.white )
     
   @State var selected = -1
   var colors = [Color("bgRed"), Color("red")]
   var columns = Array(repeating: GridItem(.flexible(), spacing: 20), count: 2)
    
   @State var chuKyDataArr: [chuKyData] = []
   @State var stats_Data: [Stats] = []
    
   init(){
       fullScreenAd = Interstitial()
       fullScreenAd?.loadInterstitial()
   }
   var body: some View {
        ZStack{
//            VStack {
//                HStack {
//                    Spacer()
//                    Image("bg-top").resizable().scaledToFit()
//                        .frame(width: 130, height: 130, alignment: .top)
//                        .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? 0: -40)
//                }
//                Spacer()
//                
//            }.edgesIgnoringSafeArea(.all)
            
            VStack{
               Spacer()
                HStack {
                   Spacer()
                    Text(NSLocalizedString("report", comment: ""))//.padding(.leading, 30)
                      .font(.custom("NunitoSans-Bold", size: 37))
                      .foregroundColor(variable.textColorPink)
                    
                    Spacer()
                }.padding(.bottom, 1)
                  .padding(.top, variable.getRatioScreen() > 1.8 ? 0 : 15)
                
               
               
               ScrollView(.vertical, showsIndicators: false) {
                    
                    VStack(alignment: .leading){
//                        Spacer()
//                            .frame(height: 20)
                     
                       Text("uongnuoc")
                          .font(.custom("NunitoSans-Bold", size: 30))
                          .foregroundColor(variable.textColorPink)
                          .padding(.bottom, 20)
                          .padding(.top, -20)
                       
                       LazyVGrid(columns: columns, spacing: 30){
                           ForEach(stats_Data){stat in
                               VStack(spacing: 32){
                                   HStack{
                                      Spacer(minLength: 0)
                                       Text(stat.title)
                                         .font(.custom("NunitoSans-Bold", size: 22))
                                           .foregroundColor(.black.opacity(0.6))
                                       Spacer(minLength: 0)
                                   }
                                  
                                  let widthCircle = (UIScreen.main.bounds.width - stat.w)/2
                                  
                                   ZStack{
                                       Circle()
                                           .trim(from: 0, to: 1)
                                           .stroke(stat.color.opacity(0.10), lineWidth: 10)
                                           .frame(width: widthCircle, height: widthCircle)
                                      
                                       Circle()
                                           .trim(from: 0, to: stat.currentData / stat.goal)
                                           .stroke(stat.color, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                                           .frame(width: widthCircle, height: widthCircle)
                                           .rotationEffect(.init(degrees: -90))
                                       Text(getPercent(current: stat.currentData, goal:stat.goal) + " %")
                                           .font(.system(size: 22))
                                           .fontWeight(.bold)
                                           .foregroundColor(stat.color)
                                       
                                   }
                                  //print("\(stat.w)")
                                   Text(getDec(val: stat.currentData) + " " + gettype(val: stat.title))
                                       .font(.system(size: 22))
                                       .fontWeight(.bold)
                               }
                               .padding()
                               //.background(Color("bgBlue1").opacity(0.22))
                               .cornerRadius(15)
                               .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 0)
                           }
                       }
                       .padding()
                       .frame(height: 250)
                        
                        Spacer()
                            .frame(height: 20)

                       let chartStyle = ChartStyle(backgroundColor: Color("bgRed").opacity(0), accentColor: variable.textColorPinkBorder, secondGradientColor: Color("bgRed3"), textColor: variable.textColorPink, legendTextColor: variable.textColorPinkBorder, dropShadowColor: Color("bgRed") )

                       MultiLineChartView(data: [([18.5,18.5,18.5,18.5,18.5,18.5, 18.5], GradientColors.green), ([24.9,24.9,24.9,24.9,24.9,24.9,24.9], GradientColors.green), (variable.getBMIarr(), GradientColors.prplNeon)], title: "BMI", legend: NSLocalizedString(variable.getBMITitle(), comment: ""), style: chartStyle, form: ChartForm.extraLarge, rateValue: variable.getBMIPercent())
                        Spacer()
                            .frame(height: 30)
                        Spacer()
                       
                       Text("chuky")
                          .font(.custom("NunitoSans-Bold", size: 30))
                          .foregroundColor(variable.textColorPink)
                          .padding(.bottom, 20)
                       VStack(spacing: 30){
                          ForEach(chuKyDataArr){ck in
                          
                             let wChuKy = variable.getWidthMaxScreen(myVal: CGFloat(ck.soNgayChuKy), myMax: CGFloat(330))
                             let wDenThang = variable.getWidthMaxScreen(myVal: CGFloat(ck.soNgayDenThang), myMax: CGFloat(330))
                             
                             VStack(alignment: .leading){
                                Text("\(ck.startDate) - \(ck.endDate)")
                                   .font(.custom("comfortaa", size: 18))
                                   .foregroundColor(variable.textColorPinkBorder)
                                   .padding(.bottom, -2)
                                ZStack(alignment: .topLeading){
                                   Rectangle()
                                      .frame(width: CGFloat(wChuKy), height: 30)
                                      .cornerRadius(15)
                                      .foregroundColor(Color.black.opacity(0.9))
                                   Rectangle()
                                      .frame(width: CGFloat(wDenThang), height: 30)
                                      .cornerRadius(15)
                                      .foregroundColor(variable.textColorPink)
                                   Text("\(ck.soNgayDenThang)")
                                      .font(.custom("comfortaa", size: 18))
                                      .foregroundColor(.white)
                                      .frame(maxWidth: .infinity, alignment: .leading)
                                      .padding(.leading, 15)
                                      .padding(.top, 5)
                                   Text("\(ck.soNgayChuKy)")
                                      .font(.custom("comfortaa", size: 18))
                                      .foregroundColor(.white)
                                      .frame(width: CGFloat(wChuKy), alignment: .trailing)
                                      .padding(.leading, -15)
                                      .padding(.top, 5)
                                }
                             }
                          }
                          
                       }

                    }.padding(25)
                }
                .frame( alignment: .topLeading)
            }
            
        }
        
        .onAppear(){
         
           self.fullScreenAd?.showAd()
           
         stats_Data = [
              Stats(id: 1, title: NSLocalizedString("homqua", comment: ""), currentData: 2, goal: 2.5, color: Color("green"), w: 150),
              Stats(id: 2, title: NSLocalizedString("homnay", comment: ""), currentData: CGFloat(variable.getSoNuoc()) * 0.25, goal: 2.5, color: Color("blue"), w: 150)
           ]
           let periodData = UserDefaults.standard.string(forKey: "period")?.components(separatedBy: "_")
           
           var arr: [String] = []
           chuKyDataArr.removeAll()
           
           if periodData?.isEmpty == false {
              for i in 0..<periodData!.count {
                 arr = periodData![i].components(separatedBy: "+")
                 let startDate = (variable.stringToDate(data: arr[0], congThem: 0)).replacingOccurrences(of: "-", with: "/")
                 let endDate = (variable.stringToDate(data: arr[0], congThem: Int(arr[1])! - 1 )).replacingOccurrences(of: "-", with: "/")
                 chuKyDataArr.append(chuKyData(id: i + 1, startDate: startDate, endDate: endDate, soNgayDenThang: Int(arr[2]) ?? 0, soNgayChuKy: Int(arr[1]) ?? 0 ))
              }
           }
           
           
           
           
           let randomInt = Int.random(in: 1..<10)
           
           if randomInt == 3 {
               if #available(iOS 10.3, *) {
                  SKStoreReviewController.requestReview()
               } else {
                   // Fallback on earlier versions
               }
           }
           
//           print("periodData")
//           print(periodData)
        }
        .tabItem{
            Image(systemName: "chart.bar.xaxis").font(.system(size: 26))
               
        }
        .tag(3)
    }
    func getHeight(value: CGFloat) ->CGFloat{
        let hrs = CGFloat(value / 1440) * 200
        return hrs
    }
    
    func getHrs(value: CGFloat) -> String {
        let hrs = value / 60
        
        return String(format: "%0.1f", hrs)
    }
    
    func getPercent(current: CGFloat, goal: CGFloat) -> String{
        let per = current / goal * 100
        return String(format: "%.1f", per)
    }
    
    func gettype(val: String) ->String{
        switch val {
        case "Water": return "L"
        case "Running": return "Km"
        case "sleep": return "h"
        default:return "L"
            
        }
    }
    
    func getDec(val: CGFloat) -> String {
        let format = NumberFormatter()
        format.numberStyle = .decimal
        
        return format.string(from: NSNumber.init(value: Float(val)))!
    }
    
}
struct RoundedShape: Shape {
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 10, height: 10))
        
        return Path(path.cgPath)
    }
}

struct Report_Previews: PreviewProvider {
    static var previews: some View {
        Report()
    }
}
struct Daily: Identifiable {
    var id: Int
    var day: String
    var workout_In_Min: CGFloat
}

var workout_Data = [
    Daily(id: 0, day: "Thang 1", workout_In_Min: 480),
    Daily(id: 1, day: "Thang 2", workout_In_Min: 880),
    Daily(id: 3, day: "Thang 3", workout_In_Min: 280),
    Daily(id: 4, day: "Thang 4", workout_In_Min: 180),
    Daily(id: 5, day: "Thang 5", workout_In_Min: 480),
    Daily(id: 6, day: "Thang 6", workout_In_Min: 580),
    Daily(id: 7, day: "Thang 7", workout_In_Min: 680)
]


struct Stats : Identifiable{
    var id: Int
    var title: String
    var currentData: CGFloat
    var goal: CGFloat
    var color: Color
   var w: CGFloat
    
}
var variable:Variable = Variable()

struct chuKyData : Identifiable{
   var id: Int
   var startDate: String
   var endDate: String
   var soNgayDenThang: Int
   var soNgayChuKy: Int
}

