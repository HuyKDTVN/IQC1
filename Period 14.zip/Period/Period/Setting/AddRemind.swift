//
//  AddRemind.swift
//  Period - BMI
//
//  Created by Huy Le on 21/07/2022.
//

import SwiftUI

struct AddRemind: View {

   let variable = Variable()
   @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
   
   @State private var tieuDe = NSLocalizedString("title", comment: "")
   
   var arrSoLanUongThuoc = [1, 2, 3, 4]
   @State private var soLanUongThuoc = 1
   
   let calendar = Calendar.current
   
   
   @State private var currentDate1 = Date()
   @State private var currentDate2 = Date()
   @State private var currentDate3 = Date()
   @State private var currentDate4 = Date()
   
   
    var body: some View {
       ZStack{
          VStack {
              HStack {
                  Spacer()
                  Image("bg-top").resizable().scaledToFit()
                      .frame(width: 130, height: 130, alignment: .top)
                      
              }
              Spacer()

              HStack {
                  
                  Image("bg-bottom").resizable().scaledToFill()
                      .frame(width: 100, height: 100)
                  Spacer()
              }
          }.edgesIgnoringSafeArea(.all)
          VStack{
             ScrollView{
                VStack{
                   HStack {
                       Text(NSLocalizedString("add", comment: "")).padding(.leading, 30)
                           .font(.custom("comfortaa.ttf", size: 30))
                           .foregroundColor(variable.textColor)
                       
                       Spacer()
                   }.padding(.bottom, 1)
                    HStack {
                        Text(NSLocalizedString("remind2", comment: "")).padding(.leading, 30)
                            .font(.custom("comfortaa.ttf", size: 50))
                            .foregroundColor(variable.textColorPink)
                        
                        Spacer()
                    }.padding(.top, -5)
                    
                }
                
              
               VStack{
                  VStack(alignment: .leading) {
                     HStack {
                         Text(NSLocalizedString("tinNhan", comment: ""))
                             .font(.custom("comfortaa.ttf", size: 18))
                             .foregroundColor(variable.textColor)
                         
                         Spacer()
                     }.padding(.top, 25)
                      HStack {
                         TextField(NSLocalizedString("remind", comment: ""), text: $tieuDe)
                         Spacer()
                         Image("message").resizable()
                             .frame(width: 30, height: 30, alignment: .center)
                             .offset(x: 0, y: 2)
                      }.modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
                  }
                     .padding(.leading, 30)
                     .padding(.trailing, 30)

               }
                
                VStack{
                   VStack(alignment: .leading) {
                      HStack {
                          Text(NSLocalizedString("notemore", comment: ""))
                              .font(.custom("comfortaa.ttf", size: 18))
                              .foregroundColor(variable.textColor)
                          
                          Spacer()
                      }.padding(.top, 25)
                       HStack {
                          TextField(NSLocalizedString("notemore", comment: ""), text: $tieuDe)
                          Spacer()
                          Image("message").resizable()
                              .frame(width: 30, height: 30, alignment: .center)
                              .offset(x: 0, y: 2)
                       }.modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)

                }
                
                
                
                VStack{
                   VStack(alignment: .leading) {
                      HStack {
                         DatePicker(" " + NSLocalizedString("time", comment: ""), selection: $currentDate1, displayedComponents: .hourAndMinute)
                                     //.labelsHidden()
                            .datePickerStyle(GraphicalDatePickerStyle())
                            //.accentColor(variable.textColorPinkBorder)
                                        .background(Color(UIColor.systemBackground))
                              
                         
                      }.padding(.top, 0)
                      
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)
                      
                   
                   
                   

                }
                
                
                Spacer()
               VStack{
                  Button(action: {
                     
                     
                     withAnimation(.easeOut(duration:0.5)){
                        //save data to Usersdefault
                        
                        //back
                        presentationMode.wrappedValue.dismiss()
                     }
                     
                      }) {
                          Text(NSLocalizedString("done", comment: ""))
                              .frame(minWidth: 0, maxWidth: 250)
                              .font(.custom("comfortaa.ttf", size: 24))
                              .padding()
                              .foregroundColor(.white)
                              .overlay(
                                  RoundedRectangle(cornerRadius: 20)
                                      .stroke(Color.white, lineWidth: 2)
                          )
                      }
                      .background(variable.textColorPink) // If you have this
                      .cornerRadius(20)         // You also need the cornerRadius here
               }
                
             }
             
             
             
          }
       }//.navigate(to: ContentView(mydata: 0, mucDich: 0), when: $willMoveToNextScreen)
          .environment(\.colorScheme, .light).preferredColorScheme(.light)
          .onAppear(){
             let dateFormatter = DateFormatter()
             dateFormatter.dateFormat = "HH:mm"
             
             
          }
    }
}

struct AddRemind_Previews: PreviewProvider {
    static var previews: some View {
        AddRemind()
    }
}
