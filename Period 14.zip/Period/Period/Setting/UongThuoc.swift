//
//  UongThuoc.swift
//  Period - BMI
//
//  Created by Huy Le on 20/07/2022.
//

import SwiftUI

struct UongThuoc: View {
   @State private var willMoveToNextScreen = false
   
   let variable = Variable()
   @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
   @State private var tinNhanUongThuoc = NSLocalizedString("tinNhanUongThuoc", comment: "")
   
   var arrSoLanUongThuoc = [1, 2, 3, 4]
   @State private var soLanUongThuoc = 1
   
   let calendar = Calendar.current
   
   @State private var currentDate1 = Date()
   @State private var currentDate2 = Date()
   @State private var currentDate3 = Date()
   @State private var currentDate4 = Date()
   
   init() {
      
   }
   
    var body: some View {
       ZStack{
          VStack {
              HStack {
                  Spacer()
                  Image("bg-top").resizable().scaledToFit()
                      .frame(width: 130, height: 130, alignment: .top)
                      .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? 0: -40)
              }
              Spacer()

//              HStack {
//
//                  Image("bg-bottom").resizable().scaledToFill()
//                      .frame(width: 100, height: 100)
//                  Spacer()
//              }
          }.edgesIgnoringSafeArea(.all)
          VStack{
             ScrollView(showsIndicators: false){
                VStack{
                   HStack {
                       Text(NSLocalizedString("take", comment: "")).padding(.leading, 30)
                           .font(.custom("NunitoSans-Bold", size: 25))
                           .foregroundColor(variable.textColor)
                       
                       Spacer()
                   }.padding(.bottom, 1)
                    HStack {
                        Text(NSLocalizedString("medicine", comment: "")).padding(.leading, 30)
                          .font(.custom("NunitoSans-Bold", size: variable.getRatioScreen() > 1.8 ? 37 : 27))
                            .foregroundColor(variable.textColorPink)
                        
                        Spacer()
                    }.padding(.top, -5)
                      .padding(.bottom, -5)
                    
                }

               VStack{
                  VStack(alignment: .leading) {
                     HStack {
                         Text(NSLocalizedString("tinNhan", comment: ""))
                             .font(.custom("comfortaa.ttf", size: 18))
                             .foregroundColor(variable.textColor)
                         
                         Spacer()
                     }.padding(.top, 25)
                      HStack {
                         TextField(NSLocalizedString("tinNhanUongThuoc", comment: ""), text: $tinNhanUongThuoc)
                         Spacer()
                         Image("thuoc").resizable()
                             .frame(width: 30, height: 25, alignment: .center)
                             .offset(x: 0, y: 2)
                      }.modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
                  }
                     .padding(.leading, 30)
                     .padding(.trailing, 30)

               }
                
                VStack{
                   VStack(alignment: .leading) {
                      HStack {
                          Text(NSLocalizedString("solanuongthuoc", comment: ""))
                              .font(.custom("comfortaa.ttf", size: 18))
                              .foregroundColor(variable.textColor)
                          
                          Spacer()
                      }.padding(.top, 25)
                      Menu {
                          Picker(NSLocalizedString("dodaiChuKy", comment: ""), selection: $soLanUongThuoc) {
                              ForEach(arrSoLanUongThuoc, id: \.self) {
                                  Text("\($0)")
                              }
                          }
                             
                      }label: {
                         customLabelSoLanUongThuoc
                      }.padding(.top, 5)
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)

                }
                
                VStack{
                   VStack(alignment: .leading) {
                      HStack {
                          Text(NSLocalizedString("thoigianuongthuoc", comment: ""))
                              .font(.custom("comfortaa.ttf", size: 18))
                              .foregroundColor(variable.textColor)
                          
                          Spacer()
                         
                         
                         
                      }.padding(.top, 25)
                       HStack {
                          
                       }
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)

                }
                
                VStack{
                   VStack(alignment: .leading) {
                      HStack {
                         DatePicker(" " + NSLocalizedString("times", comment: "") + " " + "1", selection: $currentDate1, displayedComponents: .hourAndMinute)
                                     //.labelsHidden()
                            .datePickerStyle(GraphicalDatePickerStyle())
                            //.accentColor(variable.textColorPinkBorder)
                                        .background(Color(UIColor.systemBackground))
                              
                         
                      }.padding(.top, 0)
                      
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)
                      
                   
                   VStack(alignment: .leading) {
                      HStack {
                         DatePicker(" " + NSLocalizedString("times", comment: "") + " " + "2", selection: $currentDate2, displayedComponents: .hourAndMinute)
                                     //.labelsHidden()
                            .datePickerStyle(GraphicalDatePickerStyle())
                            //.accentColor(variable.textColorPinkBorder)
                                        .background(Color(UIColor.systemBackground))
                              
                         
                      }.padding(.top, 0)
                      
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)
                      .opacity(soLanUongThuoc < 2 ? 0 : 1)
                      .animation(.easeIn)
                   
                   VStack(alignment: .leading) {
                      HStack {
                         DatePicker(" " + NSLocalizedString("times", comment: "") + " " + "3", selection: $currentDate3, displayedComponents: .hourAndMinute)
                                     //.labelsHidden()
                            .datePickerStyle(GraphicalDatePickerStyle())
                            //.accentColor(variable.textColorPinkBorder)
                                        .background(Color(UIColor.systemBackground))
                              
                         
                      }.padding(.top, 0)
                      
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)
                      .opacity(soLanUongThuoc < 3 ? 0 : 1)
                      .animation(.easeIn)
                   
                   VStack(alignment: .leading) {
                      HStack {
                         DatePicker(" " + NSLocalizedString("times", comment: "") + " " + "4", selection: $currentDate4, displayedComponents: .hourAndMinute)
                                     //.labelsHidden()
                            .datePickerStyle(GraphicalDatePickerStyle())
                            //.accentColor(variable.textColorPinkBorder)
                                        .background(Color(UIColor.systemBackground))
                                        
                              
                         
                      }.padding(.top, 0)
                     
                   }
                      .padding(.leading, 30)
                      .padding(.trailing, 30)
                      .opacity(soLanUongThuoc < 4 ? 0 : 1)
                      .animation(.easeIn)

                }
                
                
                Spacer()
               VStack{
                  HStack{
                     Button(action: {
                        
                        
                        withAnimation(.easeOut(duration:0.5)){
                           //save data to Usersdefault
                           print(tinNhanUongThuoc)
                           UserDefaults.standard.set(tinNhanUongThuoc, forKey: "tinNhanUongThuoc")
                           print("soLanUongThuoc")
                           print("\(soLanUongThuoc)")
                           UserDefaults.standard.set(soLanUongThuoc, forKey: "soLanUongThuoc")

                           let t1 = String(calendar.component(.hour, from: currentDate1)) + ":" + String(calendar.component(.minute, from: currentDate1))
                           UserDefaults.standard.set(t1, forKey: "thoiGianUongThuocLan1")
                           
                           let t2 = String(calendar.component(.hour, from: currentDate2)) + ":" + String(calendar.component(.minute, from: currentDate2))
                           UserDefaults.standard.set(t2, forKey: "thoiGianUongThuocLan2")
                           
                           let t3 = String(calendar.component(.hour, from: currentDate3)) + ":" + String(calendar.component(.minute, from: currentDate3))
                           UserDefaults.standard.set(t3, forKey: "thoiGianUongThuocLan3")
                           
                           let t4 = String(calendar.component(.hour, from: currentDate4)) + ":" + String(calendar.component(.minute, from: currentDate4))
                           UserDefaults.standard.set(t4, forKey: "thoiGianUongThuocLan4")
                           
                           for i in 1...soLanUongThuoc{
                              if i == 1{
                                 variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate1), phut: calendar.component(.minute, from: currentDate1), myName: "uongthuoc\(i)")
                              }
                              
                              if i == 2{
                                 variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate2), phut: calendar.component(.minute, from: currentDate2), myName: "uongthuoc\(i)")
                              }
                              
                              if i == 3{
                                 variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate3), phut: calendar.component(.minute, from: currentDate3), myName: "uongthuoc\(i)")
                              }
                              
                              if i == 4{
                                 variable.setNotiDaily(mtitle: tinNhanUongThuoc, mcontent: "", gio: calendar.component(.hour, from: currentDate4), phut: calendar.component(.minute, from: currentDate4), myName: "uongthuoc\(i)")
                              }
                              
                           }
                           
                           //back
                           //presentationMode.wrappedValue.dismiss()
                           willMoveToNextScreen = true
                        }
                        
                         }) {
                             Text(NSLocalizedString("done", comment: ""))
                                 .frame(minWidth: 0, maxWidth: 250)
                                 .font(.custom("comfortaa.ttf", size: 22))
                                 .padding()
                                 .foregroundColor(.white)
                                 .overlay(
                                     RoundedRectangle(cornerRadius: 20)
                                         .stroke(Color.white, lineWidth: 2)
                             )
                         }
                     
                     
                         .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                            ContentView(mydata: 0, mucDich: 0, tabSelection: 4)
                             })
                         .background(variable.textColorPink) // If you have this
                         .cornerRadius(20)         // You also need the cornerRadius here
                     
                     Button(action: {
                        self.presentationMode.wrappedValue.dismiss()
                        
                         }) {
                             Text(NSLocalizedString("cancel", comment: ""))
                                 .frame(minWidth: 0, maxWidth: 180)
                                 .font(.custom("comfortaa.ttf", size: 22))
                                 .padding()
                                 .foregroundColor(variable.textColorPinkBorder)
                                 .overlay(
                                     RoundedRectangle(cornerRadius: 20)
                                         .stroke(Color.white, lineWidth: 2)
                             )
                         }
                         .background(variable.textColorPink.opacity(0.15))
                         .cornerRadius(20)
                  }.padding(30)
                     .padding(.top, -15)
                     .padding(.bottom, 0)
               }
             }
          }
       }//.navigate(to: ContentView(mydata: 0, mucDich: 0), when: $willMoveToNextScreen)
          .environment(\.colorScheme, .light).preferredColorScheme(.light)
          .onAppear(){
             let dateFormatter1 = DateFormatter()
             dateFormatter1.timeZone = TimeZone.ReferenceType.local
             dateFormatter1.dateFormat = "yyyy_MM_dd"
             let currentDate = dateFormatter1.string(from: Date())
             
             dateFormatter1.dateFormat = "yyyy_MM_dd HH:mm:ss"
             dateFormatter1.locale = .current
             
             if(UserDefaults.standard.string(forKey: "tinNhanUongThuoc") != "") {
                tinNhanUongThuoc = UserDefaults.standard.string(forKey: "tinNhanUongThuoc") ?? NSLocalizedString("tinNhanUongThuoc", comment: "")
             }
             
             if(UserDefaults.standard.integer(forKey: "soLanUongThuoc") != 0) {
                soLanUongThuoc = UserDefaults.standard.integer(forKey: "soLanUongThuoc")
             }
             
             if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan1") != "") {
                //print(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan1"))
               
                let a1:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan1") ?? "07:30")  + ":00"
                
                currentDate1 = dateFormatter1.date(from: a1)!
                print(currentDate1)
                
             }else{
                currentDate1 = dateFormatter1.date(from: currentDate + " " + "07:30:00")!
             }
             
             if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan2") != "") {
                let a2:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan2") ?? "11:30")  + ":00"
                
                currentDate2 = dateFormatter1.date(from: a2)!
               
             }else{
                currentDate2 = dateFormatter1.date(from: currentDate + " " + "11:30:00")!
             }
             
             if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan3") != "") {
                let a3:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan3") ?? "18:30")  + ":00"
                
                currentDate3 = dateFormatter1.date(from: a3)!
             }else{
                currentDate3 = dateFormatter1.date(from: currentDate + " " + "18:30:00")!
             }
             
             if(UserDefaults.standard.string(forKey: "thoiGianUongThuocLan4") != "") {
                let a4:String = currentDate + " " + (UserDefaults.standard.string(forKey: "thoiGianUongThuocLan4") ?? "21:30")  + ":00"
                
                currentDate4 = dateFormatter1.date(from: a4)!
                
             }else{
                currentDate4 = dateFormatter1.date(from: currentDate + " " + "21:30:00")!
             }
          }
    }
   
   var customLabelSoLanUongThuoc: some View {
      ZStack {
         variable.textW.ignoresSafeArea().cornerRadius(20) // 1
         HStack {
            
            Text(String(soLanUongThuoc)).padding(0)
                .font(.custom("comfortaa.ttf", size: 21))
            Spacer()
            Image("checklist").resizable()
                .frame(width: 30, height: 30, alignment: .center)
                .offset(x: 0, y: 2)
         }
         .frame(width: UIScreen.main.bounds.size.width - 90, alignment: .leading)
         .padding()
         //.background(.white)
         .cornerRadius(20)
  //       .overlay(
  //               RoundedRectangle(cornerRadius: 20)
  //                  .stroke(.gray.opacity(0.7), lineWidth: 1)
  //           )
         
         
         .foregroundColor(.black.opacity(0.8))
      }
      .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 2)
   }
}

struct UongThuoc_Previews: PreviewProvider {
    static var previews: some View {
        UongThuoc()
    }
}
