//
//  HomeFitness.swift
//  Period - BMI
//
//  Created by Huy Le on 18/4/25.
//

import SwiftUI
import Foundation

struct HomeFitness: View {
   @Environment(\.scenePhase) private var scenePhase
    var variable:Variable = Variable()
   let defaults = UserDefaults.standard
   init(){
       
   }
    var body: some View {
        ZStack (alignment: .top){
            ZStack{
                ZStack (alignment: .center){
                    Image("bg-symptom")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 130)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .opacity(0.8)
                            .padding(.leading, 160)
                            .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                    Image("bg-bai-tap")
                            .resizable()
                            .scaledToFill()
                            .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                    Text("AD")
                        .foregroundColor(.white)
                        .padding(.vertical, 2)
                        .padding(.horizontal, 4)
                        .background(Color("buttonFitness"))
                        .cornerRadius(6)
                        .font(.custom("NunitoSans-Bold", size: 11))
                        .padding(.horizontal, 20)
                        .padding(.vertical, 20)
                        .opacity(0.8)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                        
                    Button(action: {
                        if let url = URL(string: "https://apps.apple.com/vn/app/id1280373486") {
                                UIApplication.shared.open(url)
                            }

                    }) {
                        Text(NSLocalizedString("tapngay", comment: ""))
                            .font(.custom("NunitoSans-Bold", size: 15))
                            .foregroundColor(.white)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 15)
                            .background(Color("buttonFitness"))
                            .cornerRadius(18)
                    }
                    
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 20)
                    
                    VStack(alignment: .trailing) {
                        Text(NSLocalizedString("5ptapluyen", comment: ""))
                            .font(.custom("NunitoSans-Bold", size: 15))
                            .foregroundColor(Color("textFitness"))
                            .padding(.top, 20)
                            .padding(.trailing, 20)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                        Text(NSLocalizedString("nhenhang", comment: ""))
                            .font(.custom("NunitoSans", size: 15))
                            .foregroundColor(Color("textFitness2"))
                            .padding(.vertical, 3)
                            .padding(.trailing, 40)
                            .padding(.leading, 10)
                            .background(Color("bgFitness2"))
                            .cornerRadius(18)
                            .padding(.trailing, -20)
                            .padding(.top, variable.isLargeScreen ? -17 : -10)
                            
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                        Text(NSLocalizedString("caithienvocdang", comment: ""))
                            .font(.custom("NunitoSans", size: 15))
                            .foregroundColor(Color("textFitness"))
                            .padding(.top, variable.isLargeScreen ? -50 : -35)
                            .padding(.trailing, 20)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                        Spacer()
                    }
                }
            }
            .frame(
                  minWidth: 0,
                  maxWidth: .infinity,
                  minHeight: variable.isLargeScreen ? 170 : 140,
                  maxHeight: variable.isLargeScreen ? 170 : 140
                )
            .background(
                        Rectangle()
                            .foregroundColor(Color("bgFitness"))
                            .opacity(0.9)
            )
            .cornerRadius(30)
            //.shadow(color: Color("bgFit").opacity(1), radius: 17, x: 0, y: 5)
        }
        .padding(15)
        .padding(.top, -10)
        .zIndex(1)
    }
}
struct HomeFitness_Previews: PreviewProvider {
    static var previews: some View {
        HomeFitness()
    }
}
