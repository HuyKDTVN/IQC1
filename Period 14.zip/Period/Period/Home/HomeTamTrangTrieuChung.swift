//
//  HomeTamTrangTrieuChung.swift
//  Period - BMI
//
//  Created by Huy Le on 17/4/25.
//

import SwiftUI
import Foundation
struct HomeTamTrangTrieuChung: View {
    @State private var hasSymptoms: Bool = false
    @Environment(\.scenePhase) private var scenePhase
    //var ads: Interstitial = Interstitial()
    let currentMonth = Calendar.current.component(.month, from: Date())
    let currentYear = Calendar.current.component(.year, from: Date())
    let currentDay = Calendar.current.component(.day, from: Date())
    var variable:Variable = Variable()
    let defaults = UserDefaults.standard
    @State private var willMoveToNextScreen = false
    @State private var willMoveToNextScreen2 = false
    @State private var numDauDau = 0
    @State private var numDauBody = 0
    @State private var numDauBuomBuom = 0
    @State private var symptom:[String] = []
    @State private var isAnimating = false
    
    @State private var thongBaoTrieuChung: String = "no"
    var body: some View {
          HStack(alignment: .top, spacing: 20) {
              ZStack (alignment: .top){
                  ZStack{
                      ZStack (alignment: .top){
                          ZStack(alignment: .center){
                              Circle()
                                  .strokeBorder(Color.blue,lineWidth: 0)
                                  //.background(Circle().foregroundColor(Color("bgTamTrang"))).frame(width: 250, height: 220)
                                  .offset(x: 120, y: 5)
                              Image("bg-mood0")
                                      .resizable()
                                      .scaledToFit()
                                      .frame(width: 130)
                                      .frame(maxWidth: .infinity, alignment: .center)
                                      .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                              Image("bg-mood")
                                      .resizable()
                                      .scaledToFit()
                                      .frame(width: 80)
                                      
                                      .frame(maxWidth: .infinity, alignment: .trailing)
                                      .padding(.top, -60)
                              VStack{
                                  
                                  var mood = variable.moodForDay(currentYear: currentYear, currentMonth: currentMonth, currentDay: currentDay)
                                  
                                  if mood > 0 {
                                      
                                      Text(NSLocalizedString(variable.arrTamTrang[mood - 1], comment: ""))
                                          .foregroundColor(Color("textTamTrang"))
                                          .font(.custom("NunitoSans-Bold", size: 17))
                                          .padding(.top, 20)
                                  } else {
                                      Text(NSLocalizedString("ratdechiu", comment: "") + "?")
                                          .foregroundColor(Color("textTamTrang"))
                                          .font(.custom("NunitoSans-Bold", size: 17))
                                          .padding(.top, 20)
                                  }
                                  
                                      //.offset(x: 0, y: 170)
                                  Button(action: {
                                     willMoveToNextScreen = true
                                  }) {
                                      Image(systemName: "plus.circle.fill")
                                          .font(.system(size: 50))
                                          .foregroundColor(Color("buttonTamTrang"))
                                          .shadow(color: Color("buttonTamTrang").opacity(0.7), radius: 8, x: 0, y: 5)
                                          .scaleEffect(isAnimating && mood == 0 ? 0.8 : 1)
                                          .animation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: isAnimating)
                                          //.offset(x: 0, y: 70)
                                          .padding(.top, 5)
                                          .padding(.leading, 70)
                                         
                                  }
                                  
                                  .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
                                      SelectTamTrang()
                                  })
                                  
                                  Spacer()
                                      .frame(height: 3)
                              }
                          }
                          .clipShape(RoundedRectangle(cornerRadius: 40))
                          .background(
                              Rectangle()
                                  .foregroundColor(Color("bgTamTrang"))
                          )
                          .frame(width: 250, height: 150)
                          .cornerRadius(40)
                      }
                  }
                  .frame(width: 250, height: 150)
                  .shadow(color: Color("bgTamTrang").opacity(0.6), radius: 12, x: 0, y: 3)
              }.padding(.top, 50).id(1)
              ZStack (alignment: .top){
                  ZStack{
                      ZStack (alignment: .top){
                          ZStack(alignment: .center){
                              Circle()
                                .strokeBorder(Color.blue,lineWidth: 0)
                                    //.background(Circle().foregroundColor(Color("bgTamTrang"))).frame(width: 250, height: 220)
                                    .offset(x: 120, y: 5)
                                Image("bg-symptom")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 130)
                                        .frame(maxWidth: .infinity, alignment: .center)
                                        .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                              VStack (alignment: .center){
                                  if hasSymptoms {
                                          HStack {
                                              if numDauDau > 0 {
                                                  ZStack {
                                                      Image("head")
                                                          .resizable()
                                                          .scaledToFit()
                                                          .frame(width: 45, height: 45)
                                                          .shadow(color: Color("buttonSymptom2").opacity(0.4), radius: 12, x: 0, y: 3)
                                                          .padding(.top, 45)
                                                          
                                                      Text(String(numDauDau))
                                                          .foregroundColor(.white)
                                                          .font(.custom("NunitoSans-Bold", size: 14))
                                                          .padding(5)
                                                          
                                                          .background(Circle().foregroundColor(Color("buttonSymptom2")))
                                                          .offset(x: -7)
                                                  }
                                              }
                                              if numDauBody > 0 {
                                                  ZStack {
                                                      Image("body")
                                                          .resizable()
                                                          .scaledToFit()
                                                          .frame(width: 45, height: 45)
                                                          .shadow(color: Color("buttonSymptom2").opacity(0.4), radius: 12, x: 0, y: 3)
                                                          .padding(.top, 45)
                                                          
                                                      Text(String(numDauBody))
                                                          .foregroundColor(.white)
                                                          .font(.custom("NunitoSans-Bold", size: 14))
                                                          .padding(5)
                                                          
                                                          .background(Circle().foregroundColor(Color("buttonSymptom2")))
                                                          .offset(x: -7)
                                                  }
                                              }
                                              if numDauBuomBuom > 0 {
                                                  ZStack {
                                                      Image("buom-buom")
                                                          .resizable()
                                                          .scaledToFit()
                                                          .frame(width: 45, height: 45)
                                                          .shadow(color: Color("buttonSymptom2").opacity(0.4), radius: 12, x: 0, y: 3)
                                                          .padding(.top, 45)
                                                          
                                                      Text(String(numDauBuomBuom))
                                                          .foregroundColor(.white)
                                                          .font(.custom("NunitoSans-Bold", size: 14))
                                                          .padding(5)
                                                          
                                                          .background(Circle().foregroundColor(Color("buttonSymptom2")))
                                                          .offset(x: -7)
                                                  }
                                              }
                                      }
                                      .padding(.top, -45)
                                      
                                  }else {
                                      if thongBaoTrieuChung == "no" {
                                          Text(NSLocalizedString("khoe" +  String(Int.random(in: 1..<14)), comment: ""))
                                            .foregroundColor(Color("textTamTrang"))
                                            .font(.custom("NunitoSans-Bold", size: 17))
                                            .padding(.top, 15)
                                            //.offset(x: 0, y: 170)
                                      } else {
                                          Text(thongBaoTrieuChung)
                                            .foregroundColor(Color("textTamTrang"))
                                            .font(.custom("NunitoSans-Bold", size: 17))
                                            .padding(.top, 15)
                                            //.offset(x: 0, y: 170)
                                      }
                                      
                                  }
                                  
                                  if(thongBaoTrieuChung == "no" || hasSymptoms) {
                                      HStack {
                                          Image("mention")
                                                  .resizable()
                                                  .scaledToFit()
                                                  .frame(width: 15, height: 15)
                                                  .padding(.leading, 15)
                                                  .ignoresSafeArea() // Cho ảnh phủ toàn màn hình
                                          Text(variable.getGoiY(symptom: symptom))
                                            .foregroundColor(Color.black)
                                            .opacity(0.9)
                                            .font(.custom("NunitoSans-Italic", size: 14))
                                            .padding(.leading, 0)
                                            .padding(.trailing, 7)
                                      }
                                      .padding(.top, 5)
                                      .frame(maxWidth: .infinity, alignment: .leading)
                                  }
                                  
                                Spacer()
                                    .frame(height: 3)

                            }
                          }
                          //.clipShape(RoundedRectangle(cornerRadius: 40))
                          .background(
                              Rectangle()
                                  .foregroundColor(Color("bgRed")).opacity(0.25)
                          )
                      
                          .frame(width: 250, height: 150)
                          .cornerRadius(40)
                         Image("icon-symptom").resizable()
                             .frame(width: 41, height: 44, alignment: .top)
                             .offset(x: 70, y: -24)
                          Button(action: {
                              
                             willMoveToNextScreen2 = true
                          }) {
                             
                              Image(systemName: "plus.circle.fill")
                                  .font(.system(size: 50))
                                  .foregroundColor(Color("redButton"))
                                  //.shadow(color: Color("redButton").opacity(0.7), radius: 8, x: 0, y: 5)
                                  //.offset(x: 0, y: 70)
                                  .padding(.top, 80)
                          }
                          .offset(x: 70, y: 40)
                          .zIndex(10)
                          .fullScreenCover(isPresented: $willMoveToNextScreen2, content: {
                              SelectSymptom()
                        
                          })
                      }
                  }
                  .frame(width: 250, height: 150)
                  .shadow(color: Color("bgSymptom").opacity(0.6), radius: 12, x: 0, y: 3)
              }.padding(.top, 50).id(2)
          }
          .environment(\.colorScheme, .light).preferredColorScheme(.light)
          .onChange(of: scenePhase) { phase in
             
          }
          .onAppear(){
              isAnimating = true
              thongBaoTrieuChung = UserDefaults.standard.string(forKey: "thongbaotrieuchung") ?? "no"
              if let entry = variable.entryForDay(currentYear: currentYear, currentMonth: currentMonth, currentDay: currentDay) {
                  if !entry.symptoms.isEmpty {
                      symptom = entry.symptoms
                      numDauDau = variable.getNumberSymptomDau(symptom: entry.symptoms.joined(separator: ", "))
                      numDauBody = variable.getNumberSymptomBody(symptom: entry.symptoms.joined(separator: ", "))
                      numDauBuomBuom = variable.getNumberSymptomBuomBuom(symptom: entry.symptoms.joined(separator: ", "))
                      hasSymptoms = true
                  }
              }
          }
          .padding(.bottom, -17)
          .padding(.top, -13)
       
       }
}
struct HomeTamTrangTrieuChung_Previews: PreviewProvider {
    static var previews: some View {
        HomeTamTrangTrieuChung()
    }
}

