//
//  HomeCell.swift
//  Period - BMI
//
//  Created by Huy Le on 19/05/2022.
//

import SwiftUI
import ToastUI
import Foundation


struct HomeCell: View {
   @Environment(\.scenePhase) private var scenePhase
   
    var ads: Interstitial = Interstitial()
    
    var variable:Variable = Variable()
   @State private var presentingToast: Bool = false
   let defaults = UserDefaults.standard
   @State var soNuoc: Int = 0
   
   @State private var willMoveToNextScreen = false
   
   @State private var willMoveToNextScreen2 = false
   
   @State private var BMIindex:Double = 0
   
   @State var shouldHideButtonUongNuoc = false
   
   @State private var soLanUongThuoc: Int = 0
   
   @State private var thoiGianUongThuoc: String = ""
   
   init(){
       ads.loadInterstitial()
   }
   
    var body: some View {
    
          HStack(alignment: .top, spacing: 20) {
//              ZStack (alignment: .top){
//                  ZStack{
//                      ZStack (alignment: .top){
//                          ZStack(alignment: .top){
//                              Circle()
//                                  .strokeBorder(Color.blue,lineWidth: 0)
//                                  .background(Circle().foregroundColor(Color("bgYellow2"))).frame(width: 220, height: 190)
//                                  .offset(x: -90, y: 0)
//                             if(soLanUongThuoc != 0) {
//                                
//                                if(thoiGianUongThuoc != ""){
//                                   
//                                   VStack{
//                                       Text(UserDefaults.standard.string(forKey: "tinNhanUongThuoc") ?? NSLocalizedString("tinNhanUongThuoc", comment: ""))
//                                           .foregroundColor(variable.textColorYellow)
//                                           .font(.custom("NunitoSans-Light", size: 20))
//
//                                           .padding(.top, 80)
//                                      Text(thoiGianUongThuoc)
//                                           .foregroundColor(variable.textColorYellow)
//                                           .font(.custom("comfortaa", size: 30))
//                                           .offset(x: 0, y: 10)
//                                   }
//                                }else{
//                                   Image("done-vang").resizable()
//                                      .frame(width: 60, height: 60, alignment: .center)
//                                      .shadow(color: Color("bgYellow3").opacity(0.6), radius: 8, x: 0, y: 5)
//                                       .offset(x: 0, y: 85)
//                                }
//                                
//                             }else{
//                                VStack{
//                                    Button(action: {
//                                       print("add loi nhac")
//
//                                       willMoveToNextScreen = true
//
//                                    }) {
//                                        Image(systemName: "plus.circle.fill")
//                                            .font(.system(size: 60))
//                                            .foregroundColor(Color("bgYellow3").opacity(0.8))
//                                            .shadow(color: Color("bgYellow3").opacity(0.6), radius: 8, x: 0, y: 5)
//                                            //.offset(x: 0, y: 70)
//                                            .padding(.top, 65)
//                                    }
//                                    .fullScreenCover(isPresented: $willMoveToNextScreen, content: {
//                                               UongThuocHome()
//                                           })
//
//                                   Text(NSLocalizedString("addRemind", comment: ""))
//                                      .foregroundColor(variable.textColorYellow)
//                                      .font(.custom("comfortaa.ttf", size: 20))
//                                      .offset(x: 0, y: 15)
//                                      .padding(.top, 0)
//                                }
//                             }
//                          }
//                          .clipShape(RoundedRectangle(cornerRadius: 40))
//                          .background(
//                              Rectangle()
//                                  .foregroundColor(Color("bgYellow"))
//                          )
//                      
//                          .frame(width: 180, height: 180)
//                          .cornerRadius(40)
//                          
//                          Image("thuoc4").resizable()
//                              .frame(width: 60, height: 60, alignment: .top)
//                              .offset(x: 0, y: -28)
//                         
//                      }
//                      
//                      
//                  }
//                  .frame(width: 180, height: 180)
//                  .shadow(color: Color("bgYellow2").opacity(0.6), radius: 12, x: 0, y: 3)
//
//              }.padding(.top, 50).id(1)
              
              ZStack (alignment: .top){
                  ZStack{
                      ZStack (alignment: .top){
                          ZStack(alignment: .top){
                              Circle()
                                  .strokeBorder(Color.blue,lineWidth: 0)
                                  .background(Circle().foregroundColor(Color("bgBlue2"))).frame(width: 220, height: 150)
                                  .offset(x: 70, y: 0)
                              
                              VStack{
                                  Button(action: {
                                     print("add nuoc")
                                      ads.showAd()
                                     soNuoc += 1
                                     if(soNuoc > 10){
                                        self.shouldHideButtonUongNuoc = true
                                     }
                                     if(soNuoc <= 10){
                                        variable.saveSoNuoc(i: soNuoc)
                                        print("soNuoc: \(soNuoc)")
                                        //presentingToast = true
                                         
                                         withAnimation(Animation.easeOut(duration: 0.5).delay(0)) {
                                                             self.presentingToast.toggle() // << transition requires explicit animation
                                                         }
                                         
                                         withAnimation(Animation.easeOut(duration: 0.5).delay(1)) {
                                                             self.presentingToast.toggle() // << transition requires explicit animation
                                                         }
                                     }
                                  }) {
                                     if(soNuoc < 10){
                                        Image(systemName: "plus.circle.fill")
                                            .font(.system(size: 50))
                                            .foregroundColor(Color("blue"))
                                            .shadow(color: Color("blue").opacity(0.7), radius: 8, x: 0, y: 5)
                                            //.offset(x: 0, y: 70)
                                            .padding(.top, 35)
                                            .opacity(shouldHideButtonUongNuoc ? 0 : 1)
                                     }else{
                                        Image("done-xanh").resizable()
                                           .frame(width: 60, height: 60, alignment: .center)
                                           .shadow(color: Color("blue").opacity(0.7), radius: 8, x: 0, y: 5)
                                           .padding(.top, 60)
                                           .padding(.bottom, 5)
                                     }
                                  }
                                  
//                                  if presentingToast == true  {
//                                      self.toast(isPresented: $presentingToast, dismissAfter: 0.5) {
//                                            ToastView {
//                                              VStack {
//                                                Text("💧+250ml")
//                                                  //.padding(.bottom)
//                                                  .multilineTextAlignment(.center)
//
//                                              }
//                                            }
//
//                                      }.toastDimmedBackground(true)
//                                  }
                                  HStack(spacing: 0){
                                     ForEach(1..<6) { i in
                                        if(i <= soNuoc){
                                           Image("cocnuocday").resizable()
                                                .frame(width: 15, height: 18.7, alignment: .topLeading)
                                        }else{
                                           Image("cocnuoc").resizable()
                                                .frame(width: 15, height: 18.7, alignment: .topLeading)
                                        }
                                     }
                                  }
                                  Spacer()
                                      .frame(height: 3)
                                  HStack(spacing: 0){
                                     ForEach(6..<11) { i in
                                        if(i <= soNuoc){
                                           Image("cocnuocday").resizable()
                                                .frame(width: 15, height: 18.7, alignment: .topLeading)
                                        }else{
                                           Image("cocnuoc").resizable()
                                                .frame(width: 15, height: 18.7, alignment: .topLeading)
                                        }
                                     }
                                  }
                              }
                              
                          }
                          .clipShape(RoundedRectangle(cornerRadius: 40))
                          .background(
                              Rectangle()
                                  .foregroundColor(Color("bgBlue1"))
                          )
                      
                          .frame(width: 180, height: 150)
                          .cornerRadius(40)
                          
                          Image("bg-uongnuoc").resizable()
                              .frame(width: 20, height: 40, alignment: .top)
                              .offset(x: 0, y: -10)
                          ZStack(alignment: .top){
                              Text("+250ml")
                                  .foregroundColor(.white)
                                   .font(.custom("NunitoSans-Bold", size: 16))
                          }
                          
                          .frame(width: 100, height: 50)
                          .clipShape(RoundedRectangle(cornerRadius: 40))
                          .background(
                              Rectangle()
                                  .foregroundColor(Color("blue"))
                          )
                          .cornerRadius(40)
                          .offset(x: 0, y: -20)
                          .opacity(presentingToast ? 1 : 0)
                          //.scaleEffect(presentingToast ? 1 : 0)
                          //.transition(AnyTransition.opacity.combined(with: .scale))
                          .transition(.opacity)
                      }
                  }
                  .frame(width: 180, height: 150)
                  .shadow(color: Color("bgBlue2").opacity(0.6), radius: 12, x: 0, y: 3)
                  
              }.padding(.top, 30).id(2)
              ZStack (alignment: .top){
                  ZStack{
                      ZStack (alignment: .top){
                          ZStack(alignment: .top){
                              Circle()
                                  .strokeBorder(Color.blue,lineWidth: 0)
                                  .background(Circle().foregroundColor(Color("bgRed2")))
                                  .opacity(0.12)
                                  .frame(width: 220, height: 150)
                                  .offset(x: -75, y: 50)
                              Button(action: {
                                 willMoveToNextScreen2 = true
                                 print("add BMI")
                                
                              }) {
                                 
                                  Image(systemName: "plus.circle.fill")
                                      .font(.system(size: 50))
                                      .foregroundColor(Color("redButton"))
                                      .shadow(color: Color("redButton").opacity(0.7), radius: 8, x: 0, y: 5)
                                      //.offset(x: 0, y: 70)
                                      .padding(.top, 85)
                                  
                              }
                              .fullScreenCover(isPresented: $willMoveToNextScreen2, content: {
                                  BMI()
                                
                                  })
                              
                                                          
                              Circle()
                                  .trim(from: 0.52, to: 0.71)
                                  .stroke(Color("redButton").opacity(0.4), style: StrokeStyle(lineWidth: 12))
                                  .frame(width: 250, height: 250)
                                  .offset(x: 0, y: 152)
                              Circle()
                                  .trim(from: 0.71, to: 1)
                                  .stroke(Color("bgRed3"), style: StrokeStyle(lineWidth: 12))
                                  .frame(width: 250, height: 250)
                                  .offset(x: 0, y: 152)
                              Circle()
                                  .trim(from: 0.79, to: 1)
                                  .stroke(Color("red"), style: StrokeStyle(lineWidth: 12))
                                  .frame(width: 250, height: 250)
                                  .offset(x: 0, y: 152)
                              
//                              Circle()
//                                  .strokeBorder(Color.blue,lineWidth: 0)
//                                  .background(Circle().foregroundColor(Color.white)).frame(width: 25, height: 25)
//                                  .offset(variable.getPositionBMICurrent(value: BMIindex, banKinh: 100))
                              
                              Text("\(String(format: "%0.1f",BMIindex))")
                                  .foregroundColor(Color("red"))
                                  .font(.custom("comfortaa", size: 25))
                                  .offset(x: 0, y: 165)
                          }
                          //.clipShape(RoundedRectangle(cornerRadius: 40))
                          .background(
                              Rectangle()
                                  .foregroundColor(Color("bgRed")).opacity(0.25)
                          )
                      
                          .frame(width: 180, height: 150)
                          .cornerRadius(40)
                          
//                          Text("BMI")
//                              .foregroundColor(Color("red"))
//                              .font(.custom("comfortaa", size: 30))
//
//                              .offset(x: 0, y: -13)
                         Image("bmi2").resizable()
                             .frame(width: 31, height: 33, alignment: .top)
                             .offset(x: 0, y: -12)
                         
                      }
                      
                      
                  }
                  .frame(width: 180, height: 150)
                  .shadow(color: Color("bgRed2").opacity(0.6), radius: 12, x: 0, y: 3)

              }.padding(.top, 30).id(3)
          }
          
          .environment(\.colorScheme, .light).preferredColorScheme(.light)
         
          .onChange(of: scenePhase) { phase in
             if phase == .active {
                soNuoc = variable.getSoNuoc()
                 print("so nuoc : \(soNuoc)")
                if(soNuoc >= 10){
                   shouldHideButtonUongNuoc = true
                }
                //print("sonuoc: \(soNuoc)")
                
                BMIindex = variable.getBMICurrent()
                soLanUongThuoc = UserDefaults.standard.integer(forKey: "soLanUongThuoc")
                thoiGianUongThuoc = variable.homePageGetThoiGianUongThuoc()
             }
          }
          .onAppear(){
             soNuoc = variable.getSoNuoc()
             if(soNuoc >= 10){
                shouldHideButtonUongNuoc = true
             }
             //print("sonuoc: \(soNuoc)")
             
             BMIindex = variable.getBMICurrent()
             soLanUongThuoc = UserDefaults.standard.integer(forKey: "soLanUongThuoc")
             thoiGianUongThuoc = variable.homePageGetThoiGianUongThuoc()
          }
          .padding(.bottom, -17)
          .padding(.top, -13)
       
       }
    private func delayText() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.presentingToast = false
        }
    }
}
struct HomeCell_Previews: PreviewProvider {
    static var previews: some View {
        HomeCell()
    }
}

extension View {
    /// Navigate to a new view.
    /// - Parameters:
    ///   - view: View to navigate to.
    ///   - binding: Only navigates when this condition is `true`.
    func navigate2<NewView: View>(to view: NewView, when binding: Binding<Bool>) -> some View {
        NavigationView {
            ZStack {
                self
                    .navigationBarTitle("")
                    .navigationBarHidden(true)

                NavigationLink(
                    destination: view
                        .navigationBarTitle("")
                        .navigationBarHidden(true),
                    isActive: binding
                ) {
                    EmptyView()
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
