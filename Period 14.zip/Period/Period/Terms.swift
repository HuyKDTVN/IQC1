//
//  Terms.swift
//  Period - BMI
//
//  Created by Huy Le on 22/05/2022.
//

import SwiftUI

struct Terms: View {
    var variable:Variable = Variable()
    
    var body: some View {
        VStack{
            WebView(url: variable.link_terms)
        }
    }
}

struct Terms_Previews: PreviewProvider {
    static var previews: some View {
        Terms()
    }
}
