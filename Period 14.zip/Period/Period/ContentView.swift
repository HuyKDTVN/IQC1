//
//  ContentView.swift
//  Period
//
//  Created by Huy Le on 08/05/2022.
//

import SwiftUI
import SwiftUICharts
import LocalAuthentication
import UserNotifications
import GoogleMobileAds

struct ContentView: View {
   var ads: Interstitial = Interstitial()
   @Environment(\.scenePhase) var scenePhase
   
   @State var ratioManhinh: Double = 1
   @State var willMoveToNextScreenHome = false
   @State var selectNgonNgu = "aa"
   @State var identifier = "en"
   
   @State var danhNgon: String = ""
   
   var variable:Variable = Variable()
   @State var banKinh:Int = 145
   @State var duongKinh: Int = 250
   @State var soNgay:Int = 28
   @State var selectedDate = Date()
   var doDai1Thang = [22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
   @State private var selectDoDai1Thang = 29
   
   var doDaiChuky = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
   @State private var selectDoDaiChuky = 6
   
   @State private var isUnlocked = false
   
   @Environment(\.presentationMode) var presentationModer
   var demoData: [Double] = [8, 2, 4, 6, 12, 9, 2]
   var mydata: Int = 0
   
   let defaults = UserDefaults.standard
   
   @State public var mucDich:Int
   @State public var tabSelection: Int = 1
    @State private var firstOpenApp = UserDefaults.standard.bool(forKey: "firstOpenApp")
   var body: some View {
       switch mucDich {
        case 1:
           if !firstOpenApp {
               OnBoardingView(firstOpen: $firstOpenApp)
           } else {
               NavigationView {
                   ZStack{
                       VStack {
                           HStack {
                               Spacer()
                               Image("bg-top").resizable().scaledToFit()
                                   .frame(width: 130, height: 130, alignment: .top)
                                   .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? 0: -40)
                           }
                           Spacer()
                           HStack {
                               Image("bg-bottom").resizable().scaledToFill()
                                   .frame(width: 100, height: 100)
                               Spacer()
                           }
                       }.edgesIgnoringSafeArea(.all)
                       
                       VStack {
                           //NavigationLink(destination: ManHinhKhaiBao(redirectToHomeView: false, mydata: selectType), isActive: $areYouGoingToSecondView) { EmptyView() }
                           HStack {
                               Text("select").padding(.leading, 30)
                                   .font(.custom("comfortaa.ttf", size: variable.getRatioScreen() > 1.8 ? 30 : 25))
                                   .foregroundColor(variable.textColor)
                               
                               Spacer()
                           }.padding(.bottom, 1)
                               .padding(.top, variable.getRatioScreen() > 1.8 ? 0 : 10)
                           
                           HStack {
                               Text("target").padding(.leading, 30)
                                   .font(.custom("comfortaa.ttf", size: variable.getRatioScreen() > 1.8 ? 50 : 35))
                                   .foregroundColor(variable.textColorPink)
                               
                               Spacer()
                           }.padding(.top, -7)
                           //.padding(.bottom, variable.getRatioScreen() > 1.8 ? 0 : -15)
                           
                           Button(action: {
                               withAnimation(.easeOut(duration:0.5)){
                                   
                                   defaults.set(1, forKey: "mucdich")
                                   defaults.set("mucdich1", forKey: "mdsetting")
                                   self.mucDich = 2
                               }
                               
                               
                           }) {
                               ZStack {
                                   Image("select1").resizable().scaledToFill().frame(width: UIScreen.main.bounds.size.width).clipped()
                                   HStack {
                                       Spacer()
                                       Text("selectTitle1").font(.custom("comfortaa.ttf", size: 26))
                                           .foregroundColor(variable.textColorSelect1).multilineTextAlignment(.leading).padding(.top, -20)
                                       Spacer()
                                       Spacer()
                                   }
                               }
                           }.padding(.top, -30)
                           Button(action: {
                               withAnimation(.easeOut(duration:0.5)){
                                   
                                   defaults.set(2, forKey: "mucdich")
                                   defaults.set("mucdich2", forKey: "mdsetting")
                                   self.mucDich = 2
                               }
                           }) {
                               ZStack {
                                   Image("select2").resizable().scaledToFill().frame(width: UIScreen.main.bounds.size.width).clipped()
                                   HStack {
                                       Spacer()
                                       Spacer()
                                       Text("selectTitle2").font(.custom("comfortaa.ttf", size: 26))
                                           .foregroundColor(variable.textColorSelect2).multilineTextAlignment(.leading).padding(.top, -10)
                                       Spacer()
                                   }
                               }
                           }.padding(.top, variable.getRatioScreen() > 1.8 ? -50 : -60)
                           Button(action: {
                               withAnimation(.easeOut(duration:0.5)){
                                   
                                   defaults.set(3, forKey: "mucdich")
                                   defaults.set("mucdich3", forKey: "mdsetting")
                                   self.mucDich = 2
                               }
                           }) {
                               ZStack {
                                   Image("select3").resizable().scaledToFill().frame(width: UIScreen.main.bounds.size.width).clipped()
                                   HStack {
                                       Spacer()
                                       Text("selectTitle3").font(.custom("comfortaa.ttf", size: 26))
                                           .foregroundColor(variable.textColorSelect3).multilineTextAlignment(.leading).padding(.top, -20)
                                       Spacer()
                                       Spacer()
                                   }
                               }
                           }.padding(.top, variable.getRatioScreen() > 1.8 ? -50 : -60)
                           
                           Spacer()
                       }.padding(.bottom, -35)
                       
                       Spacer()
                   }
                   
               }.environment(\.colorScheme, .light).preferredColorScheme(.light)
                   .environment(\.locale, .init(identifier: identifier))
           }
      
       case 5:
          
          ManHinhKhaiBaoCalendar()
     
       case 2:
          //ManHinhLanDau(areYouGoingToSecondView: false, selectType: 1)
          //ManHinhKhaiBao(mydata: 1)
          
          ZStack{
              
              VStack {
                  HStack {
                      Spacer()
                      Image("bg-top").resizable().scaledToFit()
                          .frame(width: 130, height: 130, alignment: .top)
                          .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? 0: -40)
                  }
                  Spacer()

                  HStack {
                      
                      Image("bg-bottom").resizable().scaledToFill()
                          .frame(width: 100, height: 100)
                      Spacer()
                  }
              }.edgesIgnoringSafeArea(.all)
              VStack {
                 //NavigationLink(destination: ContentView(mydata: 0, mucDich: 0), isActive: $redirectToHomeView) { EmptyView() }
                  VStack{
                      HStack {
                          Text(NSLocalizedString("sap", comment: "")).padding(.leading, 30)
                              .font(.custom("NunitoSans-Bold", size: variable.getRatioScreen() > 1.8 ? 25 : 23))
                              .foregroundColor(variable.textColor)
                          
                          Spacer()
                      }.padding(.bottom, 1)
                      
                      HStack {
                          Text(NSLocalizedString("batdau", comment: "")).padding(.leading, 30)
                            .font(.custom("NunitoSans-Bold", size: variable.getRatioScreen() > 1.8 ? 37 : 37))
                              .foregroundColor(variable.textColorPink)
                          
                          Spacer()
                      }.padding(.top, -5)
                        .padding(.bottom,  variable.getRatioScreen() > 1.8 ? 70 : 30)
                      
                  }

                 VStack{
                    HStack {
                        Text(NSLocalizedString("ngayBatdauKyKinhCuoi", comment: "")).padding(.leading, 30)
                            .font(.custom("comfortaa.ttf", size: 18))
                            .foregroundColor(variable.textColor)
                        
                        Spacer()
                    }.padding(.top, -5)
                    
                    Button(action: {
                       withAnimation(.easeOut(duration:0.5)){
                           
                          print("show picker date")
                          self.mucDich = 5
                       }
                    }) {
                       HStack {
                          
                          if(defaults.integer(forKey: "khaibao-ngay") == 0) {
                             
                             
                             Text(variable.getCurrentDate()).padding(0)
                                 .font(.custom("comfortaa.ttf", size: 21))
                          }else{
                             Text(String(defaults.integer(forKey: "khaibao-ngay")) + "-" + String(defaults.integer(forKey: "khaibao-thang")) + "-" + String(defaults.integer(forKey: "khaibao-nam"))).padding(0)
                                 .font(.custom("comfortaa.ttf", size: 21))
                          }
                          
                          Spacer()
                          Image("calendar").resizable()
                              .frame(width: 30, height: 30, alignment: .center)
                              .offset(x: 0, y: 2)
                       }
                       .modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
                       .frame(width: UIScreen.main.bounds.size.width - 50, alignment: .leading)
//                       .padding()
//                       .background(.white)
//                       .cornerRadius(20)
//                       .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 2)
                       .foregroundColor(.black.opacity(0.8))
                    }.padding(.top, 5)
                 }
                 VStack{
                    HStack {
                        Text(NSLocalizedString("dodaiChuKy", comment: "")).padding(.leading, 30)
                            .font(.custom("comfortaa.ttf", size: 18))
                            .foregroundColor(variable.textColor)
                        
                        Spacer()
                    }.padding(.top, 25)
                    
                   Menu {
                       Picker(NSLocalizedString("dodaiChuKy", comment: ""), selection: $selectDoDaiChuky) {
                           ForEach(doDaiChuky, id: \.self) {
                               Text("\($0)")
                           }
                       }
                          
                   }label: {
                      customLabelDoDaiChuKy
                   }.padding(.top, 5)
                 }
                 
                 VStack{
                    HStack {
                        Text(NSLocalizedString("daoDai1Thang", comment: "")).padding(.leading, 30)
                            .font(.custom("comfortaa.ttf", size: 18))
                            .foregroundColor(variable.textColor)
                        
                        Spacer()
                    }.padding(.top, 25)
                    
                   Menu {
                       Picker(NSLocalizedString("dodaiChuKy", comment: ""), selection: $selectDoDai1Thang) {
                           ForEach(doDai1Thang, id: \.self) {
                               Text("\($0)")

                           }
                       }
                          
                   }label: {
                      customLabelDoDai1Thang
                   }.padding(.top, 5)
                 }
                 Spacer().frame(height: 60)
                  
                 VStack{
                    Button(action: {
                        ads.showAd()
                        //requestAppTrackingPermission()
                       if(UserDefaults.standard.integer(forKey: "khaibao") != 1) {
                          defaults.set(1, forKey: "khaibao")
                          defaults.set(variable.getCurrentDay(), forKey: "khaibao-ngay")
                          defaults.set(variable.getCurrentMonth(), forKey: "khaibao-thang")
                          defaults.set(variable.getCurrentYear(), forKey: "khaibao-nam")
                       }
                       //print("\(selectDoDaiChuky)")
                       //print("\(selectDoDai1Thang)")
                       defaults.set(selectDoDaiChuky, forKey: "khaibao-dodaichuky")
                       defaults.set(selectDoDai1Thang, forKey: "khaibao-dodai1thang")
                       
                       let ngayDau = String(defaults.integer(forKey: "khaibao-ngay")) + "-" + String(defaults.integer(forKey: "khaibao-thang")) + "-" + String(defaults.integer(forKey: "khaibao-nam"))
                       
                       defaults.set(ngayDau + "+" + String(selectDoDai1Thang) + "+" + String(selectDoDaiChuky), forKey: "period")
                       
                       variable.setDefaultForNoti()
                       variable.clearNotiPeriod()
                       variable.setNotiAllPeriod(selectDoDai1Thang: selectDoDai1Thang, selectDoDaiChuky: selectDoDaiChuky, ngayDauDMY: ngayDau)
                       
                       
                       withAnimation(.easeOut(duration:0.5)){
                          self.mucDich = 0
                       }

                       
                        }) {
                            Text(NSLocalizedString("batDau", comment: ""))
                                .frame(minWidth: 0, maxWidth: 200)
                                .font(.custom("comfortaa.ttf", size: 24))
                                .padding()
                                .foregroundColor(.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white, lineWidth: 2)
                            )
                        }
                        .background(variable.textColorPink) // If you have this
                        .cornerRadius(20)         // You also need the cornerRadius here
                 }
                 
              }
          }.environment(\.colorScheme, .light).preferredColorScheme(.light)
             .environment(\.locale, .init(identifier: identifier))
       case 0:
         
          TabView (selection: $tabSelection) {
              
              ZStack{
                  
//                  VStack {
//                      HStack {
//                          Spacer()
//                         Image("bg-top").resizable().scaledToFit()
//                              .frame(width: 70, height: 70, alignment: .top)
//                              .offset(x: variable.getRatioScreen() > 1.8 ? 0: 30, y: variable.getRatioScreen() > 1.8 ? 0: -40)
//                      }
//                      Spacer()
//                      
//                  }.edgesIgnoringSafeArea(.all)
                  ScrollView(.vertical, showsIndicators: false) {
                     
                         VStack{
                             Spacer()
                               .frame(height: 25)
                             ZStack {
                                 Circle()
                                     .fill(
                                        RadialGradient(gradient: variable.getGradian(i: variable.ngayHomNay(chuKy: variable.getDoDaiCaChuKy() )), center: .center, startRadius: 0, endRadius: CGFloat(duongKinh))
                                         )
                                     .frame(width: CGFloat(duongKinh), height: CGFloat(duongKinh))
                                if(soNgay > 1){
                                   ForEach((0...(soNgay - 1)), id: \.self) {
                                       Circle()
                                           .strokeBorder(variable.getBorderColor(i: Int($0)),lineWidth: variable.getBorderWidth(i: Int($0)))
                                           .background(Circle().foregroundColor(variable.getColor(i: Int($0)))).frame(width: variable.getCricleSize(i: Int($0)), height: variable.getCricleSize(i: Int($0)))
                                           .offset(x: CGFloat(banKinh) * sin(CGFloat(Int($0)) * .pi/(CGFloat(soNgay) / 2)), y:  (-CGFloat(banKinh)) * cos(CGFloat(Int($0)) * .pi/(CGFloat(soNgay) / 2)))
                                   }
                                }
                                 VStack(alignment: .center){
                                    HomeThongBao()
                                    Button(action: {
                                       print("chinh sua chu ky")

                                       willMoveToNextScreenHome.toggle()

                                    }) {
                                        Image(systemName: "pencil.circle.fill")
                                            .font(.system(size: 50))
                                            .foregroundColor(Color.white.opacity(0.5))
                                            .shadow(color: Color.white.opacity(0.3), radius: 8, x: 0, y: 2)
                                            .padding(.top, 6)
                                    }
                                    .fullScreenCover(isPresented: $willMoveToNextScreenHome, content: {
                                       
                                       if(variable.ngayKetThucThuThai() > 0) {//if(variable.ngayBatDauThuThai() > 0) {
                                          ManHinhCalendarTre()
                                       }else{
                                          ManHinhUpdateCalendar()
                                         
                                       }
                                       
                                     })
                                 }
                             }
                             .padding(.top, 7)
       //                     if isUnlocked {
       //                             Text("Unlocked")
       //                         } else {
       //                             Text("Locked")
       //                         }
                               
                             Spacer()
                                 .frame(height: 15)
                             ScrollView(.horizontal, showsIndicators: false) {
                                 ScrollViewReader{value in
                                     HomeTamTrangTrieuChung()
                                     .onAppear {
                                        value.scrollTo(2, anchor: .center)
                                     }.padding(.leading, 6)
                                         .padding(.bottom, 30)
     //                                .onChange(of: scenePhase) { phase in
     //                                   if phase == .active {
     //
     //                                   }
     //                                }
                                    
                                 }.padding(.bottom, 15)//40
                             }.zIndex(11)
                            HomeFitness()

                                     
                                     HomeCell()
                                     .onAppear {
                                        //value.scrollTo(2, anchor: .center)
                                     }//.padding(.leading, 6)
     //                                .onChange(of: scenePhase) { phase in
     //                                   if phase == .active {
     //
     //                                   }
     //                                }
                                    
                                 //}.padding(.bottom, 40)//40
                                     
                                 
                             //}.zIndex(11)
                             
                         }
                      
                  }.padding(.top, 1)
                 
              }.tabItem{
                  Image(systemName: "heart.circle.fill")
                      .font(.system(size: 30, weight: .bold))
               }
              
              .tag(1)
              CalendarViewH()
              
             Report()
              
              Setting()
          }
          
          .navigationBarTitle("", displayMode: .automatic)
          
          .navigationBarBackButtonHidden(true)
          .environment(\.locale, .init(identifier: identifier))
          
          .environment(\.colorScheme, .light).preferredColorScheme(.light)
          
          .accentColor(variable.textColorPink)
          
          .onChange(of: scenePhase) { newPhase in
                   if newPhase == .active {
                      UIApplication.shared.applicationIconBadgeNumber = 0
                      
                       print("Onchange Home")
                      willMoveToNextScreenHome = false
                      
          
                      danhNgon = variable.getDanhNgon()
                      print("muc dich-start:")
                      let screenSize: CGRect = UIScreen.main.bounds
                      let w = screenSize.width
                       print("chieu rong man hinh")
                      print(w)
                      ratioManhinh = screenSize.height / w
                       
//                       banKinh = Int(0.32 * w)
//                       duongKinh = Int(0.56 * w)
                      
                      //print(ratioManhinh)
                      //print(UserDefaults.standard.string(forKey: "mdsetting"))
                      selectNgonNgu = UserDefaults.standard.string(forKey: "language") ?? "aa"
                      if(selectNgonNgu == "aa") {
                         identifier = NSLocale.current.languageCode!
                      } else{
                         identifier = selectNgonNgu
                      }
                      //print ("data Period: " + UserDefaults.standard.string(forKey: "period")!)
                      
                      self.soNgay = variable.getDoDaiCaChuKy()
                      //defaults.set(25, forKey: "mucDich")
                      if(defaults.integer(forKey: "mucdich") == 0){
                         withAnimation(.easeOut(duration:0.5)){
                            self.mucDich = 1
                         }
                      }else{
                         if(defaults.integer(forKey: "khaibao-dodaichuky") == 0){
                            withAnimation(.easeOut(duration:0.5)){
                               self.mucDich = 2
                            }
                         }
                      }
                      
                      //print("Ngon ngu: \(NSLocale.current.languageCode)")
                      
                      print(variable.ngayHomNay(chuKy: soNgay))
                      let selectMucDich = UserDefaults.standard.string(forKey: "mdsetting") ?? ""
                      print("Muc dich: \(selectMucDich)")
                      
                       
                       //requestAppTrackingPermission()
                      
                       
                   }
                  
              }
          
            .onAppear(){
                
                
                                    
                
               //UIApplication.shared.applicationIconBadgeNumber = 0
               
               print("onApear Home")
               danhNgon = variable.getDanhNgon()
               print("muc dich-start:")
               let screenSize: CGRect = UIScreen.main.bounds
               let w = screenSize.width
               //print(ratioManhinh)
               //print(UserDefaults.standard.string(forKey: "mdsetting"))
               selectNgonNgu = UserDefaults.standard.string(forKey: "language") ?? "aa"
               if(selectNgonNgu == "aa") {
                  identifier = NSLocale.current.languageCode!
               } else{
                  identifier = selectNgonNgu
               }
               //print ("data Period: " + UserDefaults.standard.string(forKey: "period")!)
               
               self.soNgay = variable.getDoDaiCaChuKy()
               //defaults.set(25, forKey: "mucDich")
               if(defaults.integer(forKey: "mucdich") == 0){
                  withAnimation(.easeOut(duration:0.5)){
                     self.mucDich = 1
                  }
               }else{
                  if(defaults.integer(forKey: "khaibao-dodaichuky") == 0){
                     withAnimation(.easeOut(duration:0.5)){
                        self.mucDich = 2
                     }
                  }
               }
               //print("Ngon ngu: \(NSLocale.current.languageCode)")
               
               print(variable.ngayHomNay(chuKy: soNgay))
               let selectMucDich = UserDefaults.standard.string(forKey: "mdsetting") ?? ""
               print("Muc dich: \(selectMucDich)")

                
               
                //requestAppTrackingPermission()
            }
       default:
          Text("Period").onAppear(){
             self.mucDich = 0
             //print(self.mucDich)
          }
          .onAppear(perform: authenticate)
       }
          
    }
    
   func authenticate() {
       let context = LAContext()
       var error: NSError?

       // check whether biometric authentication is possible
       if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
           // it's possible, so go ahead and use it
           let reason = "We need to unlock your data."

           context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, authenticationError in
               // authentication has now completed
               if success {
                   // authenticated successfully
               } else {
                   // there was a problem
               }
           }
       } else {
           // no biometrics
       }
   }
   
   
   var customLabelDoDaiChuKy: some View {
       HStack {
          
          Text(String(selectDoDaiChuky)).padding(0)
              .font(.custom("comfortaa.ttf", size: 21))
          Spacer()
          Image("chuky").resizable()
              .frame(width: 30, height: 30, alignment: .center)
              .offset(x: 0, y: 2)
       }
       .modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
       .frame(width: UIScreen.main.bounds.size.width - 50, alignment: .leading)
       //.padding()
       //.background(.white)
       //.cornerRadius(20)
       //.shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 2)
       .foregroundColor(.black.opacity(0.8))
   }
   
   
   var customLabelDoDai1Thang: some View {
       HStack {
          Text(String(selectDoDai1Thang)).padding(0)
              .font(.custom("comfortaa.ttf", size: 21))
          Spacer()
          Image("calendar2").resizable()
              .frame(width: 30, height: 30, alignment: .center)
              .offset(x: 0, y: 2)
       }
       .modifier(customViewModifier(roundedCornes: 20, startColor: .white, endColor: .white, textColor: .black))
       .frame(width: UIScreen.main.bounds.size.width - 50, alignment: .leading)
       //.padding()
       //.background(.white)
       //.cornerRadius(20)
       //.shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 2)
       .foregroundColor(.black.opacity(0.8))
   }
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//       ContentView(mydata: 0, mucDich: 0)
//            .previewDevice(PreviewDevice(rawValue: "iPhone 11"))
//            .previewDisplayName("iPhone 11")
//    }
//}
