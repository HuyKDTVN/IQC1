//
//  ModelTamTrangTrieuChung.swift
//  Period - BMI
//
//  Created by Huy Le on 19/4/25.
//

import SwiftUI

struct MoodEntry: Identifiable, Codable {
    let id = UUID()
    var date: Date
    var mood: Int
    var symptoms: [String]
}

class MoodViewModel: ObservableObject {
    @Published var moods: [MoodEntry] = []
    private let saveKeys = "SaveMoods"
    init() {
        loadMoods()
    }
    
    private func saveMoods() {
        if let data = try? JSONEncoder().encode(moods) {
            UserDefaults.standard.set(data, forKey: saveKeys)
        }
    }
    
    func addMoods(_ mood: Int) {
        let today = Calendar.current.startOfDay(for: Date())

            if let index = moods.firstIndex(where: {
                Calendar.current.isDate($0.date, inSameDayAs: today)
            }) {
                moods[index].mood = mood
                moods[index].date = Date()
            } else {
                let entry = MoodEntry(date: Date(), mood: mood, symptoms: [])
                moods.append(entry)
            }
            
            saveMoods()
    }
    func addSymptoms(_ symptoms: [String]) {
        let today = Calendar.current.startOfDay(for: Date())

        if let index = moods.firstIndex(where: {
            Calendar.current.isDate($0.date, inSameDayAs: today)
        }) {
            moods[index].symptoms = symptoms
            moods[index].date = Date()
        } else {
            let entry = MoodEntry(date: Date(), mood: 0, symptoms: symptoms)
            moods.append(entry)
        }
        
        saveMoods()
    }
    
    func loadMoods() {
        if let data = UserDefaults.standard.data(forKey: saveKeys) ,
            let saveMoods = try?  JSONDecoder().decode([MoodEntry].self, from: data) {
                moods = saveMoods
        }
    }
}
