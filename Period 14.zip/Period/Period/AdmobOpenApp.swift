import GoogleMobileAds
import SwiftUI

class AppOpenAdManager: NSObject, FullScreenContentDelegate, ObservableObject {
    static let shared = AppOpenAdManager()

    private var appOpenAd: AppOpenAd?
    private var isLoadingAd = false
    private var isShowingAd = false
    private var lastLoadTime: Date?

    private var adUnitID = Variable().adUnitOpenIDTest
    // Tải quảng cáo
    func loadAd() {
        if isLoadingAd { return }
        if UserDefaults.standard.integer(forKey: "mucdich") == 0 {
            return
        }
        isLoadingAd = true
        
        if Variable().production {
            adUnitID = Variable().adUnitOpenIDReal
        }
        print("🔄 Đang tải quảng cáo mở ứng dụng...")

        // Tải quảng cáo
        AppOpenAd.load(
            with: adUnitID,
            request: Request(),
            completionHandler: { [weak self] ad, error in
                self?.isLoadingAd = false
                if let error = error {
                    print("❌ Lỗi khi tải quảng cáo: \(error.localizedDescription)")
                    return
                }
                self?.appOpenAd = ad
                self?.lastLoadTime = Date() // Cập nhật thời gian tải
                self?.appOpenAd?.fullScreenContentDelegate = self
                print("✅ Quảng cáo đã được tải thành công.")
            }
        )
    }

    // Hiển thị quảng cáo nếu có sẵn
    func showAdIfAvailable(from viewController: UIViewController) {
//        // Kiểm tra nếu quảng cáo chưa tải hoặc đã quá cũ
//        if isShowingAd || appOpenAd == nil || !wasLoadTimeLessThanNHoursAgo(threshold: 4) {
//            print("🚫 Không thể hiển thị quảng cáo (chưa tải hoặc đã quá cũ).")
//            loadAd() // Tải lại quảng cáo nếu cần
//            return
//        }
//
//        // Hiển thị quảng cáo nếu có sẵn
//        isShowingAd = true
//        appOpenAd?.present(from: viewController)
//        print("✅ Đang hiển thị quảng cáo.")
    }

    // Kiểm tra thời gian tải quảng cáo
    func wasLoadTimeLessThanNHoursAgo(threshold: Int) -> Bool {
        guard let lastLoadTime = lastLoadTime else { return false }
        return Date().timeIntervalSince(lastLoadTime) < Double(threshold * 3600)
    }

    // Delegate Methods khi quảng cáo được đóng
    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        print("✅ Quảng cáo đóng, tải quảng cáo mới.")
        appOpenAd = nil
        isShowingAd = false
        loadAd() // Tải lại quảng cáo mới
    }

    func ad(_ ad: FullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        print("❌ Lỗi hiển thị quảng cáo: \(error.localizedDescription)")
        appOpenAd = nil
        isShowingAd = false
    }
}
