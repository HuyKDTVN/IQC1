//
//  InterstitialView.swift
//  Google AdMob Tutorial
//
//  Created by Francesco Dal Savio on 14/03/21.
//

import GoogleMobileAds
import SwiftUI
import UIKit

final class Interstitial:NSObject, FullScreenContentDelegate {
    var interstitial:InterstitialAd?

  private var adUnitID = Variable().adUnitXenKeDTest
  override init() {
    super.init()
    self.loadInterstitial()
  }

    func loadInterstitial(){
        if Variable().production {//
            adUnitID = Variable().adUnitXenKeDReal
        }
        
        let request = Request()
        InterstitialAd.load(with: adUnitID,
                               request: request,
                               completionHandler: { [self] ad, error in
                                if let error = error {
                                    print("Failed to load interstitial ad with error: \(error.localizedDescription)")
                                    return
                                }
                                interstitial = ad
                                interstitial?.fullScreenContentDelegate = self
                               })
    }

    func showAd(){
        if self.interstitial != nil {
            let root = UIApplication.shared.windows.first?.rootViewController
            self.interstitial?.present(from: root!)
        }
        else{
            print("Not Ready")
        }
    }
    
    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        print("Ad did dismiss full screen content.")
        self.loadInterstitial()
    }
    
}
