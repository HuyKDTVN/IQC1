//
//  Privacy.swift
//  Period - BMI
//
//  Created by Huy Le on 22/05/2022.
//

import SwiftUI

struct Privacy: View {
    
    var variable:Variable = Variable()
    
    var body: some View {
        VStack{
            WebView(url: variable.link_privacy)
        }
    }
}

struct Privacy_Previews: PreviewProvider {
    static var previews: some View {
        Privacy()
    }
}
