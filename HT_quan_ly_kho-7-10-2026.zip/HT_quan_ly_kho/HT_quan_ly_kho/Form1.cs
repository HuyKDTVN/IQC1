﻿using System.Security.Cryptography;

namespace HT_quan_ly_kho
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        public string path = Variable.pathThanhVien;
        private void Form1_Load(object sender, EventArgs e)
        {
            //check da vuot qua so ngay dung thu chua
            if(Huy_functions.checkTry(Variable.ngayBatDauDungThu, Variable.tryTime))
            {
                MessageBox.Show("Bạn đã kết thời hạn dùng thử phần mềm.");
                Environment.Exit(1);
            }
            //check ket noi server hay chua
            if (!Directory.Exists(Variable.pathThanhVien)) {
                MessageBox.Show("Phần mềm chưa được kết nối với cơ sở dữ liệu", "Vui lòng kiểm tra lại", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            this.myPass.KeyDown += new System.Windows.Forms.KeyEventHandler(this.inputPass_KeyDown);
        }
        private void inputPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                submit();
            }
        }
        private void submit()
        {
            //validate
            if (tenDangNhap.Text.Trim() == "" || myPass.Text.Trim() == "")
            {
                MessageBox.Show("Hãy điền tên đăng nhập và mật khẩu");
            }
            else
            {
                if (File.Exists(path + tenDangNhap.Text.Trim() + ".cnm"))
                {
                    // Open the text file using a stream reader.
                    using StreamReader reader = new(path + tenDangNhap.Text.Trim() + ".cnm");

                    // Read the stream as a string.
                    string text = reader.ReadToEnd();
                    string[] infor = text.Split("##");
                    if (infor[0] == myPass.Text)
                    {
                        home f = new home(tenDangNhap.Text.Trim(), infor[2], Int32.Parse(infor[1]));
                        f.FormClosed += (s, args) => this.Close();
                        f.Show();       // Hiển thị Form2
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Mật khẩu không đúng");
                    }

                }
                else
                {
                    MessageBox.Show("Hệ thống không tồn tại tên đăng nhập: " + tenDangNhap.Text);
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            submit();

        }

        private void tenDangNhap_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
