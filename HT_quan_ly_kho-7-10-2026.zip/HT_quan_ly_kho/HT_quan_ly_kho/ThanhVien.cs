﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{

    public partial class ThanhVien : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVatLieu;

        public string maLK;

        public string thanhVienCanChinhSua;
        public ThanhVien(string maCodeNV, string tenNV, int phanQuyen, string maVL)
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVatLieu = maVL;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {
            // Ví dụ: cho một button nằm ở giữa form
            //button1.Left = (this.ClientSize.Width - button1.Width) / 2;
            //button1.Top = (this.ClientSize.Height - button1.Height) / 2;

            dataGridView1.Width = this.ClientSize.Width - 60;
        }



        private void ThanhVien_Load(object sender, EventArgs e)
        {
            helloText.Text = "Xin chào " + hoTen;

            DataTable table = new DataTable();

            // Tạo cột
            table.Columns.Add("Tên đăng nhập", typeof(string));
            table.Columns.Add("Họ tên", typeof(string));
            table.Columns.Add("Phân quyền", typeof(string));
            dataGridView1.DataSource = table;
            dataGridView1.ReadOnly = true;                    // Không cho sửa nội dung
            dataGridView1.AllowUserToAddRows = false;         // Không cho thêm dòng mới
            dataGridView1.Visible = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            string[] filePaths = Directory.GetFiles(Variable.pathThanhVien, "*.cnm",
                                         SearchOption.TopDirectoryOnly);
            int i = 0;
            foreach (string filePath in filePaths)
            {
                // Open the text file using a stream reader.
                using StreamReader reader = new(filePath);

                // Read the stream as a string.
                string text = reader.ReadToEnd();
                string[] infor = text.Split("##");

                string phanQuyen = "Chỉ xem";
                if (infor[1] == "2")
                {
                    phanQuyen = "Nhập xuất kho";
                }
                if (infor[1] == "3")
                {
                    phanQuyen = "Toàn quyền";
                }
                string username = Path.GetFileNameWithoutExtension(filePath);
                if (i == 0)
                {
                    thanhVienCanChinhSua = username;
                }
                table.Rows.Add(username, infor[2], phanQuyen);
                i = i + 1;
            }

            dataGridView1.CellClick += dataGridView1_CellClick;

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                thanhVienCanChinhSua = row.Cells["Tên đăng nhập"].Value?.ToString();

            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (maNV == thanhVienCanChinhSua)
            {
                MessageBox.Show("Bạn không thể xóa tài khoản của chính mình", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string p = Variable.pathThanhVien + thanhVienCanChinhSua + ".cnm";
                if (File.Exists(p))
                {
                    File.Delete(p);
                }
                //dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                ThanhVien f = new ThanhVien(maNV, hoTen, phanQuyenInt, "");
                f.FormClosed += (s, args) => this.Close();
                f.Show();
                this.Hide();
                MessageBox.Show("Đã xóa tài khoản: " + thanhVienCanChinhSua, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
            }

        }


        private void btnSuaTonKho_Click_1(object sender, EventArgs e)
        {

            ThemThanhVien f = new ThemThanhVien(maNV, hoTen, phanQuyenInt, "", thanhVienCanChinhSua);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void btnSuaVatLieu_Click(object sender, EventArgs e)
        {
            ThemThanhVien f = new ThemThanhVien(maNV, hoTen, phanQuyenInt, "", "");
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
    }
}
