﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class nhatKy : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVatLieu;

        public string maLK;
        public nhatKy(string maCodeNV, string tenNV, int phanQuyen, string maVL)
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVatLieu = maVL;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {
            // Ví dụ: cho một button nằm ở giữa form
            //button1.Left = (this.ClientSize.Width - button1.Width) / 2;
            //button1.Top = (this.ClientSize.Height - button1.Height) / 2;

            dataGridView1.Width = this.ClientSize.Width - 60;
        }

        private void nhatKy_Load(object sender, EventArgs e)
        {
            helloText.Text = "Xin chào " + hoTen;

            DataTable table = new DataTable();

            // Tạo cột
            table.Columns.Add("Mã vật liệu", typeof(string));
            table.Columns.Add("Mã hàng", typeof(string));
            table.Columns.Add("Tên vật liệu", typeof(string));
            table.Columns.Add("Đơn vị", typeof(string));
            table.Columns.Add("Phân loại", typeof(string));
            table.Columns.Add("Ký tự", typeof(string));
            table.Columns.Add("Số lượng tối thiểu", typeof(string));
            table.Columns.Add("Đơn giá (VND)", typeof(string));
            table.Columns.Add("Code người thao tác", typeof(string));
            table.Columns.Add("Ngày cập nhật", typeof(string));
            table.Columns.Add("Ghi chú", typeof(string));

            // Thêm dòng
            //table.Rows.Add("NVL001", "Ván MDF 18mm", 120, "Tấm", 20, "350000 VND", "Vật liệu chính", "Gỗ công nghiệp", "Kho Gỗ A", "Cty Minh Phát", DateTime.Now, "Thanh", "Dùng cho dòng tủ cao cấp");

            // Gán dữ liệu vào DataGridView
            dataGridView1.DataSource = table;
            dataGridView1.ReadOnly = true;                    // Không cho sửa nội dung
            dataGridView1.AllowUserToAddRows = false;         // Không cho thêm dòng mới
            dataGridView1.Visible = true;


            string[] filePaths = Directory.GetFiles(Variable.pathBangLK, "*.cnm",
                                         SearchOption.TopDirectoryOnly);
            string pathFileTaiBangLK;
            foreach (string filePath in filePaths)
            {
                // Open the text file using a stream reader.
                using StreamReader reader = new(filePath);

                // Read the stream as a string.
                string text = reader.ReadToEnd();
                string[] infor = text.Split("##");

                string nhomVL = "Chính";
                if (infor[2] == "P")
                {
                    nhomVL = "Phụ";
                }
                if (infor[2] == "TB")
                {
                    nhomVL = "Thiết bị";
                }
                string maVL = Path.GetFileNameWithoutExtension(filePath);
                table.Rows.Add(maVL, infor[7], infor[0], infor[1], infor[2], infor[8], infor[3], infor[9], infor[4], infor[5], infor[6]);
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void dangXuat_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
    }
}
