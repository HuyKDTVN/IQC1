﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing;
using ZXing.Common;
using ZXing.QrCode.Internal;
using ZXing.Rendering;
using ZXing.Windows.Compatibility;


//using static System.Runtime.InteropServices.JavaScript.JSType;

namespace HT_quan_ly_kho
{
    public partial class themVL : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVL;
        public bool isEditVL;
        string p = "";
        int s = 1;

        public string tenVLCu;
        public string maHangCu;
        public string donViCu;
        public string tonKhoToiThieuCu;
        public string ghiChuCu;
        public string donGiaCu;
        public themVL(string maCodeNV, string tenNV, int phanQuyen, string maVatLieu, bool editVL)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVL = maVatLieu;
            isEditVL = editVL;
        }
        private void setComboboxValue()
        {
            //lay thong tincac vi tri gia
            string pathThongTinDonVi = Variable.pathOther + "don-vi.cnm";
            string contentFileThongtindonVi = "";

            if (File.Exists(pathThongTinDonVi))
            {
                contentFileThongtindonVi = Huy_functions.readFile(pathThongTinDonVi);
                if (contentFileThongtindonVi.Contains("##"))
                {
                    string[] arrDonvi = contentFileThongtindonVi.Split("##");
                    foreach (string donVi in arrDonvi)
                    {
                        inputDonVi.Items.Add(donVi);
                    }
                }
            }
        }

        private void themVL_Load(object sender, EventArgs e)
        {
            lblTonDuoiMucToiThieu.Location = new Point(
                lblTonDuoiMucToiThieu.Location.X,
                this.ClientSize.Height - lblTonDuoiMucToiThieu.Height - 15
            );
            lblMsg.Visible = false;
            helloText.Text = "Xin chào " + hoTen;            
             
            
            inputMaLK.ReadOnly = true;
            btnIn.Visible = false;
            imgQR.Visible = false;
            //MessageBox.Show(phanQuyenInt + "");
            setComboboxValue();
            if (isEditVL)
            {
                this.Text = "Sửa thông tin vật liệu";
                myTitle.Text = "Sửa thông tin vật liệu";
                btn.Text = "Sửa thông tin vật liệu";
                inputNhomVL.Enabled = false;
                inputKyTu.ReadOnly = true;

                this.ActiveControl = inputTenVL;
                string path = Variable.pathBangLK + maVL + ".cnm";

                lblLyDo.Visible = true;
                inputLyDo.Visible = true;

                if (File.Exists(path))
                {
                    using StreamReader reader = new(path);
                    // Read the stream as a string.
                    string text = reader.ReadToEnd();
                    string[] infor = text.Split("##");
                    tenVLCu = infor[0];
                    inputTenVL.Text = tenVLCu;
                    inputNhomVL.SelectedItem = infor[2];
                    donViCu = infor[1];

                    int index = inputDonVi.FindStringExact(donViCu);
                    if (index < 0)
                    {
                        inputDonVi.Items.Add(donViCu);
                    }
                    inputDonVi.SelectedItem = donViCu;

                    tonKhoToiThieuCu = infor[3];
                    inputTonKhoToiThieu.Text = tonKhoToiThieuCu;

                    donGiaCu = infor[9];
                    inputDonGia.Text = donGiaCu;

                    ghiChuCu = infor[6];
                    inputGhiChu.Text = ghiChuCu;

                    maHangCu = infor[7];
                    inputMaHang.Text = maHangCu;
                    inputKyTu.Text = infor[8];

                    btnIn.Visible = true;
                    imgQR.Visible = true;
                    qrMa.Visible = true;
                    qrName.Visible = true;
                    panel1.Visible = true;
                    panel2.Visible = true;
                    Bitmap qr = GenerateQRCode(maVL + "##" + maHangCu);
                    imgQR.Image = qr;


                    //kiem tra con ton kho hay khong
                    string pathTonKho1 = Variable.pathTonKho + maVL + ".cnm";
                    if (File.Exists(pathTonKho1))
                    {
                        inputDonVi.Enabled = false;
                        lblmsgDonVi.Visible = true;
                    }

                }
            }
            if (maVL != "")
            {

                if (isEditVL)
                {

                    inputMaLK.Text = maVL;
                    Bitmap qr = GenerateQRCode(inputMaLK.Text + "##" + inputMaHang.Text.Trim());
                    imgQR.Image = qr;
                    qrMa.Text = inputMaLK.Text;

                    string tenRutGon = inputTenVL.Text.Trim().ToUpper();
                    if (tenRutGon.Length > 9)
                    {
                        tenRutGon = tenRutGon.Substring(0, 9);
                    }
                    //MessageBox.Show(tenRutGon);
                    qrName.Text = tenRutGon;
                    qrName.Visible = true;
                }
                else
                {
                    if (maVL.Contains("-"))
                    {

                        string[] arrMa = maVL.Split("-");
                        if (arrMa[0] == "P" || arrMa[0] == "C" || arrMa[0] == "TB")
                        {
                            inputNhomVL.SelectedItem = arrMa[0];
                        }

                        if (arrMa.Length >= 2)
                        {
                            inputKyTu.Text = arrMa[1];
                        }
                    }
                    panel1.Visible = false;
                    panel2.Visible = false;
                    imgQR.Visible = false;
                    qrMa.Visible = false;
                    qrName.Visible = false;
                    btnIn.Visible = false;
                }


            }

            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);
        }

        private Bitmap printImage;
        public Bitmap CaptureControl(Control control)
        {
            Bitmap bitmap = new Bitmap(control.Width, control.Height);
            control.DrawToBitmap(bitmap, new Rectangle(0, 0, control.Width, control.Height));
            return bitmap;
        }
        private void PrintControl(Control control)
        {
            printImage = CaptureControl(control);

            PrintDocument pd = new PrintDocument();
            pd.PrintPage += Pd_PrintPage;

            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = pd;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                pd.Print();
            }
        }

        private void Pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            // In ảnh chụp với kích thước gốc
            e.Graphics.DrawImage(printImage, new Point(0, 0));
            e.HasMorePages = false;
        }

        public static Bitmap GenerateQRCode(string text, int width = 95, int height = 95)
        {
            var writer = new BarcodeWriter
            {
                Format = BarcodeFormat.QR_CODE,
                Options = new EncodingOptions
                {
                    Width = width,
                    Height = height,
                    Margin = 1
                }
            };

            return writer.Write(text);

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            bool isError = false;
            bool hasSharp = false;

            lblMaLK.ForeColor = Color.Black;
            lblTenVL.ForeColor = Color.Black;
            lblNhomVL.ForeColor = Color.Black;
            lblDonVi.ForeColor = Color.Black;
            lblMaHang.ForeColor = Color.Black;
            lblKyTu.ForeColor = Color.Black;
            lblLyDo.ForeColor = Color.Black;

            string maLK = inputMaLK.Text;
            string tenLK = inputTenVL.Text.Trim();
            string nhomVL = inputNhomVL.Text.Trim();
            string donVi = inputDonVi.Text.Trim();
            string tonKhoToiThieu = inputTonKhoToiThieu.Text.Trim();
            string ghiChu = inputGhiChu.Text.Trim();
            string maHang = inputMaHang.Text.Trim();
            string kyTu = inputKyTu.Text.Trim();
            string lyDo = inputLyDo.Text.Trim();
            string donGia = inputDonGia.Text.Trim();

            //validate
            if (Huy_functions.hasSharpChar(tenLK))
            {
                lblTenVL.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(maHang))
            {
                lblMaHang.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(kyTu))
            {
                lblKyTu.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(donVi))
            {
                lblDonVi.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(ghiChu))
            {
                lblGhiChu.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(lyDo))
            {
                lblLyDo.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (hasSharp)
            {
                MessageBox.Show("Dữ liệu nhập vào không được chứa ký tự ##");
            }

            //check empty
            if (maLK == "" || !Huy_functions.IsValidAlphaNum(maLK))
            {
                lblMaLK.ForeColor = Color.Red;
                isError = true;
            }
            if (tenLK == "")
            {
                lblTenVL.ForeColor = Color.Red;
                isError = true;
            }
            if (nhomVL == "")
            {
                lblNhomVL.ForeColor = Color.Red;
                isError = true;
            }
            if (donGia == "")
            {
                lblDongia.ForeColor = Color.Red;
                isError = true;
            }
            if (donVi == "")
            {
                lblDonVi.ForeColor = Color.Red;
                isError = true;
            }

            if (maHang == "")
            {
                lblMaHang.ForeColor = Color.Red;
                isError = true;
            }
            if (kyTu == "")
            {
                lblKyTu.ForeColor = Color.Red;
                isError = true;
            }
            if (lyDo == "" && isEditVL)
            {
                lblLyDo.ForeColor = Color.Red;
                isError = true;
            }
            if (!isError)
            {
                //câp nhật vào bảng giao dịch
                Huy_functions.createFile(Variable.pathBangLK + maLK + ".cnm", tenLK + "##" + donVi + "##" + nhomVL + "##" + tonKhoToiThieu + "##" + maNV + "##" + DateTime.Now.ToString() + "##" + ghiChu + "##" + maHang + "##" + kyTu + "##" + donGia);

                if (isEditVL)
                {
                    //cập nhật vào bảng nhật ký
                    string tenFileNhatKy = DateTime.Now.ToString("yyyyMMdd_HHmmss") + "##" + maNV + "##" + 1 + "##" + maVL;
                    string pathNhatKy = tenFileNhatKy;
                    string contentNhatKy = lyDo + "##" + Dns.GetHostName();

                    if (tenVLCu != tenLK)
                    {
                        //MessageBox.Show(pathNhatKy + "##tenVL.cnm");
                        //MessageBox.Show(tenVLCu + "##" + tenLK + "##" + contentNhatKy);
                        Huy_functions.insertToBangNhatKy(pathNhatKy + "##tenVL.cnm", tenVLCu + "##" + tenLK + "##" + contentNhatKy);
                    }
                    if (maHangCu != maHang)
                    {
                        //MessageBox.Show(pathNhatKy + "##mahang.cnm");
                        //MessageBox.Show(maHangCu + "##" + maHang + "##" + contentNhatKy);
                        Huy_functions.insertToBangNhatKy(pathNhatKy + "##mahang.cnm", maHangCu + "##" + maHang + "##" + contentNhatKy);
                    }
                    if (donViCu != donVi)
                    {
                        //MessageBox.Show(pathNhatKy + "##donvi.cnm");
                        //MessageBox.Show(donViCu + "##" + donVi + "##" + contentNhatKy);
                        Huy_functions.insertToBangNhatKy(pathNhatKy + "##donvi.cnm", donViCu + "##" + donVi + "##" + contentNhatKy);
                    }
                    if (tonKhoToiThieuCu != tonKhoToiThieu)
                    {

                        Huy_functions.insertToBangNhatKy(pathNhatKy + "##tonkhotoithieu.cnm", tonKhoToiThieuCu + "##" + tonKhoToiThieu + "##" + contentNhatKy);
                        //sua thong tin so luong ton kho toi thieu can cap nhat lai thu muc ton kho toi thieu
                        //tim duoc so luong dang co de so sach voi voi luong ton kho toi thieu

                        string fileTonKho = Variable.pathTonKho + maVL + ".cnm";
                        if (File.Exists(fileTonKho))
                        {
                            string contentFileTonKho = Huy_functions.readFile(fileTonKho);
                            string[] arrContent = contentFileTonKho.Split("##");
                            double soLuongHienTai = Convert.ToDouble(arrContent[0]);
                            if (soLuongHienTai < Convert.ToDouble(tonKhoToiThieu))
                            {
                                Huy_functions.insertFileInBangTonKhoToiThieu(maLK);
                            }
                            else
                            {
                                Huy_functions.deleteFileInBangTonKhoToiThieu(maLK);
                            }
                        }
                        else
                        {
                            if (Int32.Parse(tonKhoToiThieu) > 0)
                            {
                                Huy_functions.insertFileInBangTonKhoToiThieu(maLK);
                            }
                            else
                            {
                                Huy_functions.deleteFileInBangTonKhoToiThieu(maLK);
                            }
                        }
                    }
                    if (Int32.Parse(donGiaCu) != Int32.Parse(donGia))
                    {
                        Huy_functions.insertToBangNhatKy(pathNhatKy + "##dongia.cnm", donGiaCu + "##" + inputDonGia.Text + "##" + contentNhatKy);
                    }
                    if (ghiChuCu != ghiChu)
                    {
                        //MessageBox.Show(pathNhatKy + "##ghichu.cnm");
                        //MessageBox.Show(ghiChuCu + "##" + ghiChu + "##" + contentNhatKy);
                        Huy_functions.insertToBangNhatKy(pathNhatKy + "##ghichu.cnm", ghiChuCu + "##" + ghiChu + "##" + contentNhatKy);
                    }

                    lblMsg.Visible = false;
                    MessageBox.Show("Đã sửa thành công cho mã vật liệu: " + maLK);
                    TraCuu f = new TraCuu(maNV, hoTen, phanQuyenInt, maLK);
                    f.FormClosed += (s, args) => this.Close();
                    f.Show();
                    this.Hide();
                }
                else
                {
                    if (inputTonKhoToiThieu.Text != "" && inputTonKhoToiThieu.Text != "0")
                    {
                        Huy_functions.insertFileInBangTonKhoToiThieu(maLK);
                    }
                    lblMsg.Visible = true;
                    lblMsg.Text = "Đã thêm thành công cho mã vật liệu: " + maLK;
                    Huy_functions.createFile(p, s + "");
                }

                string tmpQR = inputMaLK.Text.Trim().ToUpper() + "##" + inputMaHang.Text.Trim();

                
                inputTenVL.Focus();
                inputTenVL.Text = "";
                inputTonKhoToiThieu.Text = "";
                inputGhiChu.Text = "";
                inputNhomVL.SelectedItem = null;
                inputDonVi.SelectedItem = null;
                inputMaHang.Text = "";
                inputKyTu.Text = "";
                inputDonGia.Text = "";
                inputMaLK.Text = "";
                lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);

                Bitmap qr = GenerateQRCode(tmpQR);
                imgQR.Image = qr;
                imgQR.Visible = true;
                btnIn.Visible = true;
                qrMa.Visible = true;
                qrName.Visible = true;
                panel1.Visible = true;
                panel2.Visible = true;
            }
        }

        private void inputMaLK_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void inputTonKhoToiThieu_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblTonDuoiMucToiThieu_Click(object sender, EventArgs e)
        {
            TKToiThieu f = new TKToiThieu(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void inputKyTu_TextChanged(object sender, EventArgs e)
        {
            if (inputKyTu.Text.Length == 0)
            {
                imgQR.Visible = false;
                btnIn.Visible = false;
                qrMa.Visible = false;
                qrName.Visible = false;
                panel1.Visible = false;
                panel2.Visible = false;
            }
            else
            {
                if (!isEditVL)
                {
                    if (inputKyTu.Text.Length == 3)
                    {
                        if (!Huy_functions.IsValidAlpha(inputKyTu.Text))
                        {
                            MessageBox.Show("Hãy nhập 3 ký tự từ a-Z");
                            inputKyTu.Text = "";
                            inputMaLK.Text = "";
                        }
                        genMaVL();
                    }
                    else
                    {
                        inputMaLK.Text = "";
                        btnIn.Visible = false;
                        imgQR.Visible = false;
                        qrMa.Visible = false;
                        qrName.Visible = false;
                        panel1.Visible = false;
                        panel2.Visible = false;
                        if (inputKyTu.Text.Length > 3)
                        {
                            MessageBox.Show("Hãy nhập 3 ký tự");
                            inputKyTu.Text = inputKyTu.Text.Substring(0, 3);
                            genMaVL();
                        }

                    }
                }
            }
        }

        private void genMaVL()
        {
            string ten = "";

            //kiem tra xem co file P-BAA chưa
            //  + nếu chưa có thì thêm duôi 001 và thêm file P-BAA
            //  + nếu có rồi thì lấy giá trị đang có rồi cộng thêm 1 vào file, đông thời update file P-BAA
            string prefixMaVL = inputNhomVL.SelectedItem + "-" + inputKyTu.Text.ToUpper();
            p = Variable.pathDatTen + prefixMaVL + ".cnm";
            s = 1;
            if (File.Exists(p))
            {
                string c = Huy_functions.readFile(p);
                if (c.Length > 0)
                {
                    s = Int32.Parse(c) + 1;
                    ten = prefixMaVL + "-" + Huy_functions.lay3ChuSo(s + "");
                    if (s > 999)
                    {
                        MessageBox.Show("Số thứ tự của mã vật liệu này đã vượt qua 999");
                    }
                }
                else
                {
                    ten = prefixMaVL + "-" + "001";
                }
            }
            else
            {
                ten = prefixMaVL + "-" + "001";
            }

            //Nếu tên được gen ra mà vẫn bị trùng thì +1 và cạp nhật vào bảng tên
            if (File.Exists(Variable.pathBangLK + ten + ".cnm"))
            {
                s = s + 1;
                ten = prefixMaVL + "-" + Huy_functions.lay3ChuSo(s + "");
                if (File.Exists(Variable.pathBangLK + ten + ".cnm"))
                {
                    s = s + 1;
                    ten = prefixMaVL + "-" + Huy_functions.lay3ChuSo(s + "");
                    if (File.Exists(Variable.pathBangLK + ten + ".cnm"))
                    {
                        s = s + 1;
                        ten = prefixMaVL + "-" + Huy_functions.lay3ChuSo(s + "");
                        if (File.Exists(Variable.pathBangLK + ten + ".cnm"))
                        {
                            s = s + 1;
                            ten = prefixMaVL + "-" + Huy_functions.lay3ChuSo(s + "");
                            if (File.Exists(Variable.pathBangLK + ten + ".cnm"))
                            {
                                s = s + 1;
                                ten = prefixMaVL + "-" + Huy_functions.lay3ChuSo(s + "");
                                if (File.Exists(Variable.pathBangLK + ten + ".cnm"))
                                {
                                    s = s + 1;
                                    ten = prefixMaVL + "-" + Huy_functions.lay3ChuSo(s + "");
                                }
                            }
                        }
                    }
                }

            }
            inputMaLK.Text = ten;
            Bitmap qr = GenerateQRCode(ten + "##" + inputMaHang.Text.Trim());
            imgQR.Image = qr;
            qrMa.Text = ten;

            string tenRutGon = inputTenVL.Text.Trim().ToUpper();
            if(tenRutGon.Length > 9)
            {
                tenRutGon = tenRutGon.Substring(0, 9);
            }
            qrName.Text = tenRutGon;
            imgQR.Visible = true;
            btnIn.Visible = true;
            qrMa.Visible = true;
            qrName.Visible = true;
            panel1.Visible = true;
            panel2.Visible = true;
        }
        private void inputNhomVL_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (inputKyTu.Text.Length == 3)
            {
                genMaVL();
            }

        }

        private void inputTenVL_TextChanged(object sender, EventArgs e)
        {
            //if (inputTenVL.Text.Length > 0)
            //{
            //    if (inputMaLK.Text.Length > 0)
            //    {
            //        genMaVL();
            //    }
            //    else
            //    {
            //        imgQR.Visible = false;
            //        btnIn.Visible = false;

            //    }

            //}
            if (inputTenVL.Text.Length > 0)
            {
                if (inputMaLK.Text.Length > 0)
                {
                    string tenRutGon = inputTenVL.Text.Trim().ToUpper();
                    if (tenRutGon.Length > 9)
                    {
                        tenRutGon = tenRutGon.Substring(0, 9);
                    }
                    qrName.Text = tenRutGon;
                }
                else
                {
                    imgQR.Visible = false;
                    btnIn.Visible = false;

                }

            }
        }

        private void myTitle_Click(object sender, EventArgs e)
        {

        }

        private void inputMaHang_TextChanged(object sender, EventArgs e)
        {
            Bitmap qr = GenerateQRCode(inputMaLK.Text.Trim() + "##" + inputMaHang.Text.Trim());
            imgQR.Image = qr;
        }

        private void btnIn_Click(object sender, EventArgs e)
        {

        }

        private void btnIn_Click_1(object sender, EventArgs e)
        {
            PrintControl(panel1);

        }

        private void inputDonVi_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
