﻿namespace HT_quan_ly_kho
{
    partial class ThemThanhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThemThanhVien));
            pictureBox1 = new PictureBox();
            button2 = new Button();
            helloText = new Label();
            lblTitle = new Label();
            inputPass = new TextBox();
            lblPass = new Label();
            lblMsg = new Label();
            inputPhanQuyen = new ComboBox();
            btnNhap = new Button();
            inputHoTen = new TextBox();
            lblHoTen = new Label();
            lblPhanQuyen = new Label();
            inputTenDN = new TextBox();
            lblTenDN = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(12, 25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 69;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(1163, 35);
            button2.Name = "button2";
            button2.Size = new Size(162, 49);
            button2.TabIndex = 66;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(91, 43);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 68;
            helloText.Text = "Xin chào Đức";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.FromArgb(64, 64, 64);
            lblTitle.Location = new Point(504, 43);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(377, 43);
            lblTitle.TabIndex = 67;
            lblTitle.Text = "Chỉnh sửa thành viên";
            // 
            // inputPass
            // 
            inputPass.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputPass.Location = new Point(682, 287);
            inputPass.Name = "inputPass";
            inputPass.Size = new Size(224, 37);
            inputPass.TabIndex = 3;
            // 
            // lblPass
            // 
            lblPass.AutoSize = true;
            lblPass.Font = new Font("Segoe UI", 11F);
            lblPass.Location = new Point(482, 289);
            lblPass.Name = "lblPass";
            lblPass.Size = new Size(123, 30);
            lblPass.TabIndex = 173;
            lblPass.Text = "Mật khẩu *:";
            // 
            // lblMsg
            // 
            lblMsg.AutoSize = true;
            lblMsg.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMsg.ForeColor = Color.CadetBlue;
            lblMsg.Location = new Point(654, 713);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(549, 38);
            lblMsg.TabIndex = 171;
            lblMsg.Text = "Đã nhập kho thành công cho mã vật liệu: ";
            lblMsg.Visible = false;
            // 
            // inputPhanQuyen
            // 
            inputPhanQuyen.DropDownStyle = ComboBoxStyle.DropDownList;
            inputPhanQuyen.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputPhanQuyen.FormattingEnabled = true;
            inputPhanQuyen.Location = new Point(682, 360);
            inputPhanQuyen.Name = "inputPhanQuyen";
            inputPhanQuyen.Size = new Size(221, 38);
            inputPhanQuyen.TabIndex = 4;
            // 
            // btnNhap
            // 
            btnNhap.BackColor = Color.CornflowerBlue;
            btnNhap.Cursor = Cursors.Hand;
            btnNhap.FlatStyle = FlatStyle.Flat;
            btnNhap.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNhap.Location = new Point(591, 445);
            btnNhap.Name = "btnNhap";
            btnNhap.Size = new Size(211, 68);
            btnNhap.TabIndex = 5;
            btnNhap.Text = "Cập nhật";
            btnNhap.UseVisualStyleBackColor = false;
            btnNhap.Click += btnNhap_Click;
            // 
            // inputHoTen
            // 
            inputHoTen.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputHoTen.Location = new Point(685, 210);
            inputHoTen.Name = "inputHoTen";
            inputHoTen.Size = new Size(221, 37);
            inputHoTen.TabIndex = 2;
            // 
            // lblHoTen
            // 
            lblHoTen.AutoSize = true;
            lblHoTen.Font = new Font("Segoe UI", 11F);
            lblHoTen.Location = new Point(482, 212);
            lblHoTen.Name = "lblHoTen";
            lblHoTen.Size = new Size(99, 30);
            lblHoTen.TabIndex = 170;
            lblHoTen.Text = "Họ tên *:";
            // 
            // lblPhanQuyen
            // 
            lblPhanQuyen.AutoSize = true;
            lblPhanQuyen.Font = new Font("Segoe UI", 11F);
            lblPhanQuyen.Location = new Point(479, 361);
            lblPhanQuyen.Name = "lblPhanQuyen";
            lblPhanQuyen.Size = new Size(146, 30);
            lblPhanQuyen.TabIndex = 169;
            lblPhanQuyen.Text = "Phân quyền *:";
            // 
            // inputTenDN
            // 
            inputTenDN.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputTenDN.Location = new Point(682, 140);
            inputTenDN.Name = "inputTenDN";
            inputTenDN.Size = new Size(221, 37);
            inputTenDN.TabIndex = 1;
            // 
            // lblTenDN
            // 
            lblTenDN.AutoSize = true;
            lblTenDN.Font = new Font("Segoe UI", 11F);
            lblTenDN.Location = new Point(479, 142);
            lblTenDN.Name = "lblTenDN";
            lblTenDN.Size = new Size(176, 30);
            lblTenDN.TabIndex = 168;
            lblTenDN.Text = "Tên đăng nhập *:";
            // 
            // ThemThanhVien
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1344, 712);
            Controls.Add(inputPass);
            Controls.Add(lblPass);
            Controls.Add(lblMsg);
            Controls.Add(inputPhanQuyen);
            Controls.Add(btnNhap);
            Controls.Add(inputHoTen);
            Controls.Add(lblHoTen);
            Controls.Add(lblPhanQuyen);
            Controls.Add(inputTenDN);
            Controls.Add(lblTenDN);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(helloText);
            Controls.Add(lblTitle);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "ThemThanhVien";
            Text = "ThemThanhVien";
            Load += ThemThanhVien_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button2;
        private Label helloText;
        private Label lblTitle;
        private TextBox inputPass;
        private Label lblPass;
        private Label lblMsg;
        private ComboBox inputPhanQuyen;
        private Button btnNhap;
        private TextBox inputHoTen;
        private Label lblHoTen;
        private Label lblPhanQuyen;
        private TextBox inputTenDN;
        private Label lblTenDN;
    }
}