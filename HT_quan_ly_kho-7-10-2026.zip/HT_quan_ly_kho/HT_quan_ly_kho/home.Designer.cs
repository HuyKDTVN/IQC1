﻿namespace HT_quan_ly_kho
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            traCuuTonKho = new Button();
            helloText = new Label();
            mytitle = new Label();
            btnDangXuat = new Button();
            nhapKho = new Button();
            xuatKho = new Button();
            taiNhap = new Button();
            huyVatLieu = new Button();
            lblTonDuoiMucToiThieu = new Label();
            themVL = new Button();
            img1 = new PictureBox();
            pictureBox2 = new PictureBox();
            lblMesUpdate = new Label();
            link = new Label();
            bangTonKho = new Button();
            bangvatlieu = new Button();
            phieuNhapKho = new Button();
            phieuXuatKho = new Button();
            capNhatThanhVien = new Button();
            bangNhatKy = new Button();
            bangGiaoDich = new Button();
            capNhatViTriDonVi = new Button();
            tinhTrangTonKho = new Button();
            ((System.ComponentModel.ISupportInitialize)img1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // traCuuTonKho
            // 
            traCuuTonKho.BackColor = SystemColors.Info;
            traCuuTonKho.Cursor = Cursors.Hand;
            traCuuTonKho.FlatStyle = FlatStyle.Flat;
            traCuuTonKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            traCuuTonKho.ForeColor = Color.Black;
            traCuuTonKho.Location = new Point(27, 238);
            traCuuTonKho.Name = "traCuuTonKho";
            traCuuTonKho.Size = new Size(224, 92);
            traCuuTonKho.TabIndex = 8;
            traCuuTonKho.Text = "Tra cứu thông tin vật liệu";
            traCuuTonKho.UseVisualStyleBackColor = false;
            traCuuTonKho.Click += button1_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(21, 28);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 7;
            helloText.Text = "Xin chào Đức";
            // 
            // mytitle
            // 
            mytitle.AutoSize = true;
            mytitle.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            mytitle.ForeColor = Color.FromArgb(64, 64, 64);
            mytitle.Location = new Point(373, 163);
            mytitle.Name = "mytitle";
            mytitle.Size = new Size(467, 43);
            mytitle.TabIndex = 6;
            mytitle.Text = "Hệ thống quản lý kho LMC";
            mytitle.Click += mytitle_Click;
            // 
            // btnDangXuat
            // 
            btnDangXuat.BackColor = Color.Transparent;
            btnDangXuat.Cursor = Cursors.Hand;
            btnDangXuat.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDangXuat.ForeColor = Color.Brown;
            btnDangXuat.Location = new Point(1097, 18);
            btnDangXuat.Name = "btnDangXuat";
            btnDangXuat.Size = new Size(161, 48);
            btnDangXuat.TabIndex = 9;
            btnDangXuat.Text = "Đăng xuất";
            btnDangXuat.UseVisualStyleBackColor = false;
            btnDangXuat.Click += button2_Click;
            // 
            // nhapKho
            // 
            nhapKho.BackColor = Color.DeepSkyBlue;
            nhapKho.Cursor = Cursors.Hand;
            nhapKho.FlatStyle = FlatStyle.Flat;
            nhapKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            nhapKho.ForeColor = Color.Black;
            nhapKho.Location = new Point(779, 362);
            nhapKho.Name = "nhapKho";
            nhapKho.Size = new Size(211, 92);
            nhapKho.TabIndex = 11;
            nhapKho.Text = "Nhập kho";
            nhapKho.UseVisualStyleBackColor = false;
            nhapKho.Click += button4_Click;
            // 
            // xuatKho
            // 
            xuatKho.BackColor = Color.LawnGreen;
            xuatKho.Cursor = Cursors.Hand;
            xuatKho.FlatStyle = FlatStyle.Flat;
            xuatKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            xuatKho.ForeColor = Color.Black;
            xuatKho.Location = new Point(27, 483);
            xuatKho.Name = "xuatKho";
            xuatKho.Size = new Size(220, 92);
            xuatKho.TabIndex = 12;
            xuatKho.Text = "Xuất kho";
            xuatKho.UseVisualStyleBackColor = false;
            xuatKho.Click += button5_Click;
            // 
            // taiNhap
            // 
            taiNhap.BackColor = SystemColors.MenuHighlight;
            taiNhap.Cursor = Cursors.Hand;
            taiNhap.FlatStyle = FlatStyle.Flat;
            taiNhap.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            taiNhap.ForeColor = Color.Black;
            taiNhap.Location = new Point(1026, 362);
            taiNhap.Name = "taiNhap";
            taiNhap.Size = new Size(220, 92);
            taiNhap.TabIndex = 13;
            taiNhap.Text = "Tái nhập";
            taiNhap.UseVisualStyleBackColor = false;
            taiNhap.Click += button6_Click;
            // 
            // huyVatLieu
            // 
            huyVatLieu.BackColor = Color.Orchid;
            huyVatLieu.Cursor = Cursors.Hand;
            huyVatLieu.FlatStyle = FlatStyle.Flat;
            huyVatLieu.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            huyVatLieu.ForeColor = Color.Black;
            huyVatLieu.Location = new Point(1026, 483);
            huyVatLieu.Name = "huyVatLieu";
            huyVatLieu.Size = new Size(220, 93);
            huyVatLieu.TabIndex = 14;
            huyVatLieu.Text = "Hủy vật liệu";
            huyVatLieu.UseVisualStyleBackColor = false;
            huyVatLieu.Click += button7_Click;
            // 
            // lblTonDuoiMucToiThieu
            // 
            lblTonDuoiMucToiThieu.AutoSize = true;
            lblTonDuoiMucToiThieu.BackColor = Color.FromArgb(0, 192, 192);
            lblTonDuoiMucToiThieu.Cursor = Cursors.Hand;
            lblTonDuoiMucToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTonDuoiMucToiThieu.ForeColor = Color.White;
            lblTonDuoiMucToiThieu.Location = new Point(799, 782);
            lblTonDuoiMucToiThieu.Name = "lblTonDuoiMucToiThieu";
            lblTonDuoiMucToiThieu.Size = new Size(434, 30);
            lblTonDuoiMucToiThieu.TabIndex = 16;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: 10";
            lblTonDuoiMucToiThieu.Click += lblTonDuoiMucToiThieu_Click;
            // 
            // themVL
            // 
            themVL.BackColor = Color.PeachPuff;
            themVL.Cursor = Cursors.Hand;
            themVL.FlatStyle = FlatStyle.Flat;
            themVL.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            themVL.ForeColor = Color.Black;
            themVL.Location = new Point(27, 363);
            themVL.Name = "themVL";
            themVL.Size = new Size(220, 92);
            themVL.TabIndex = 17;
            themVL.Text = "Thêm vật liệu";
            themVL.UseVisualStyleBackColor = false;
            themVL.Click += themVL_Click;
            // 
            // img1
            // 
            img1.Image = (Image)resources.GetObject("img1.Image");
            img1.Location = new Point(-17, -405);
            img1.Name = "img1";
            img1.Size = new Size(1333, 1233);
            img1.SizeMode = PictureBoxSizeMode.StretchImage;
            img1.TabIndex = 18;
            img1.TabStop = false;
            img1.Click += img1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(541, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(213, 142);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // lblMesUpdate
            // 
            lblMesUpdate.AutoSize = true;
            lblMesUpdate.Font = new Font("Arial", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMesUpdate.ForeColor = Color.FromArgb(64, 64, 64);
            lblMesUpdate.Location = new Point(210, 247);
            lblMesUpdate.Name = "lblMesUpdate";
            lblMesUpdate.Size = new Size(464, 33);
            lblMesUpdate.TabIndex = 20;
            lblMesUpdate.Text = "Hệ thống quản lý kho HOMETIME";
            lblMesUpdate.Visible = false;
            // 
            // link
            // 
            link.AutoSize = true;
            link.Cursor = Cursors.Hand;
            link.Font = new Font("Arial", 20F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            link.ForeColor = Color.FromArgb(0, 192, 192);
            link.Location = new Point(550, 348);
            link.Name = "link";
            link.Size = new Size(100, 46);
            link.TabIndex = 21;
            link.Text = "Link";
            link.Visible = false;
            link.Click += link_Click;
            // 
            // bangTonKho
            // 
            bangTonKho.BackColor = Color.Turquoise;
            bangTonKho.Cursor = Cursors.Hand;
            bangTonKho.FlatStyle = FlatStyle.Flat;
            bangTonKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            bangTonKho.ForeColor = Color.Black;
            bangTonKho.Image = (Image)resources.GetObject("bangTonKho.Image");
            bangTonKho.Location = new Point(281, 237);
            bangTonKho.Name = "bangTonKho";
            bangTonKho.Size = new Size(220, 93);
            bangTonKho.TabIndex = 22;
            bangTonKho.Text = "Bảng tồn kho";
            bangTonKho.UseVisualStyleBackColor = false;
            bangTonKho.Click += bangTonKho_Click;
            // 
            // bangvatlieu
            // 
            bangvatlieu.BackColor = Color.Turquoise;
            bangvatlieu.Cursor = Cursors.Hand;
            bangvatlieu.FlatStyle = FlatStyle.Flat;
            bangvatlieu.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            bangvatlieu.ForeColor = Color.Black;
            bangvatlieu.Location = new Point(534, 237);
            bangvatlieu.Name = "bangvatlieu";
            bangvatlieu.Size = new Size(213, 93);
            bangvatlieu.TabIndex = 23;
            bangvatlieu.Text = "Bảng vật liệu";
            bangvatlieu.UseVisualStyleBackColor = false;
            bangvatlieu.Click += bangvatlieu_Click;
            // 
            // phieuNhapKho
            // 
            phieuNhapKho.BackColor = Color.DeepSkyBlue;
            phieuNhapKho.Cursor = Cursors.Hand;
            phieuNhapKho.FlatStyle = FlatStyle.Flat;
            phieuNhapKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            phieuNhapKho.ForeColor = Color.Black;
            phieuNhapKho.Location = new Point(281, 362);
            phieuNhapKho.Name = "phieuNhapKho";
            phieuNhapKho.Size = new Size(220, 92);
            phieuNhapKho.TabIndex = 26;
            phieuNhapKho.Text = "Phiếu yêu cầu nhập kho";
            phieuNhapKho.UseVisualStyleBackColor = false;
            phieuNhapKho.Click += phieuNhapKho_Click;
            // 
            // phieuXuatKho
            // 
            phieuXuatKho.BackColor = Color.LawnGreen;
            phieuXuatKho.Cursor = Cursors.Hand;
            phieuXuatKho.FlatStyle = FlatStyle.Flat;
            phieuXuatKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            phieuXuatKho.ForeColor = Color.Black;
            phieuXuatKho.Location = new Point(534, 362);
            phieuXuatKho.Name = "phieuXuatKho";
            phieuXuatKho.Size = new Size(213, 92);
            phieuXuatKho.TabIndex = 27;
            phieuXuatKho.Text = "Phiếu yêu cầu xuất kho";
            phieuXuatKho.UseVisualStyleBackColor = false;
            phieuXuatKho.Click += phieuXuatKho_Click;
            // 
            // capNhatThanhVien
            // 
            capNhatThanhVien.BackColor = Color.PeachPuff;
            capNhatThanhVien.Cursor = Cursors.Hand;
            capNhatThanhVien.FlatStyle = FlatStyle.Flat;
            capNhatThanhVien.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            capNhatThanhVien.ForeColor = Color.Black;
            capNhatThanhVien.Location = new Point(281, 483);
            capNhatThanhVien.Name = "capNhatThanhVien";
            capNhatThanhVien.Size = new Size(220, 92);
            capNhatThanhVien.TabIndex = 28;
            capNhatThanhVien.Text = "Cập nhật thành viên";
            capNhatThanhVien.UseVisualStyleBackColor = false;
            capNhatThanhVien.Click += capNhatThanhVien_Click;
            // 
            // bangNhatKy
            // 
            bangNhatKy.BackColor = Color.Turquoise;
            bangNhatKy.Cursor = Cursors.Hand;
            bangNhatKy.FlatStyle = FlatStyle.Flat;
            bangNhatKy.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            bangNhatKy.ForeColor = Color.Black;
            bangNhatKy.Location = new Point(534, 483);
            bangNhatKy.Name = "bangNhatKy";
            bangNhatKy.Size = new Size(213, 93);
            bangNhatKy.TabIndex = 30;
            bangNhatKy.Text = "Bảng nhật ký";
            bangNhatKy.UseVisualStyleBackColor = false;
            bangNhatKy.Click += button7_Click_2;
            // 
            // bangGiaoDich
            // 
            bangGiaoDich.BackColor = Color.Turquoise;
            bangGiaoDich.Cursor = Cursors.Hand;
            bangGiaoDich.FlatStyle = FlatStyle.Flat;
            bangGiaoDich.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            bangGiaoDich.ForeColor = Color.Black;
            bangGiaoDich.Location = new Point(781, 483);
            bangGiaoDich.Name = "bangGiaoDich";
            bangGiaoDich.Size = new Size(209, 93);
            bangGiaoDich.TabIndex = 29;
            bangGiaoDich.Text = "Bảng giao dịch";
            bangGiaoDich.UseVisualStyleBackColor = false;
            bangGiaoDich.Click += button8_Click_2;
            // 
            // capNhatViTriDonVi
            // 
            capNhatViTriDonVi.BackColor = Color.Turquoise;
            capNhatViTriDonVi.Cursor = Cursors.Hand;
            capNhatViTriDonVi.FlatStyle = FlatStyle.Flat;
            capNhatViTriDonVi.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            capNhatViTriDonVi.ForeColor = Color.Black;
            capNhatViTriDonVi.Location = new Point(779, 237);
            capNhatViTriDonVi.Name = "capNhatViTriDonVi";
            capNhatViTriDonVi.Size = new Size(211, 93);
            capNhatViTriDonVi.TabIndex = 32;
            capNhatViTriDonVi.Text = "Cập nhật vị trí\r\nĐơn vị-NCC";
            capNhatViTriDonVi.UseVisualStyleBackColor = false;
            capNhatViTriDonVi.Click += capNhatViTriDonVi_Click;
            // 
            // tinhTrangTonKho
            // 
            tinhTrangTonKho.BackColor = Color.MediumSpringGreen;
            tinhTrangTonKho.Cursor = Cursors.Hand;
            tinhTrangTonKho.FlatStyle = FlatStyle.Flat;
            tinhTrangTonKho.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            tinhTrangTonKho.ForeColor = Color.Black;
            tinhTrangTonKho.Location = new Point(1026, 237);
            tinhTrangTonKho.Name = "tinhTrangTonKho";
            tinhTrangTonKho.Size = new Size(220, 93);
            tinhTrangTonKho.TabIndex = 33;
            tinhTrangTonKho.Text = "Tình trạng tồn kho";
            tinhTrangTonKho.UseVisualStyleBackColor = false;
            tinhTrangTonKho.Click += button1_Click_1;
            // 
            // home
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1284, 718);
            Controls.Add(tinhTrangTonKho);
            Controls.Add(capNhatViTriDonVi);
            Controls.Add(bangNhatKy);
            Controls.Add(bangGiaoDich);
            Controls.Add(capNhatThanhVien);
            Controls.Add(phieuXuatKho);
            Controls.Add(phieuNhapKho);
            Controls.Add(bangvatlieu);
            Controls.Add(bangTonKho);
            Controls.Add(link);
            Controls.Add(lblMesUpdate);
            Controls.Add(pictureBox2);
            Controls.Add(themVL);
            Controls.Add(lblTonDuoiMucToiThieu);
            Controls.Add(huyVatLieu);
            Controls.Add(taiNhap);
            Controls.Add(xuatKho);
            Controls.Add(nhapKho);
            Controls.Add(btnDangXuat);
            Controls.Add(traCuuTonKho);
            Controls.Add(helloText);
            Controls.Add(mytitle);
            Controls.Add(img1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "home";
            Text = "HomeTime - phần mềm quản lý kho";
            Load += home_Load;
            ((System.ComponentModel.ISupportInitialize)img1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button traCuuTonKho;
        private Label helloText;
        private Label mytitle;
        private Button btnDangXuat;
        private Button nhapKho;
        private Button xuatKho;
        private Button taiNhap;
        private Button huyVatLieu;
        private Label lblTonDuoiMucToiThieu;
        private Button themVL;
        private PictureBox img1;
        private PictureBox pictureBox2;
        private Label lblMesUpdate;
        private Label link;
        private Button bangTonKho;
        private Button bangvatlieu;
        private Button phieuNhapKho;
        private Button phieuXuatKho;
        private Button capNhatThanhVien;
        private Button bangNhatKy;
        private Button bangGiaoDich;
        private Button capNhatViTriDonVi;
        private Button tinhTrangTonKho;
    }
}