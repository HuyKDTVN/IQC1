﻿namespace HT_quan_ly_kho
{
    partial class bangVatLieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(bangVatLieu));
            lblTonDuoiMucToiThieu = new Label();
            dataGridView1 = new DataGridView();
            button2 = new Button();
            helloText = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            btnThemVL = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblTonDuoiMucToiThieu
            // 
            lblTonDuoiMucToiThieu.AutoSize = true;
            lblTonDuoiMucToiThieu.Cursor = Cursors.Hand;
            lblTonDuoiMucToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTonDuoiMucToiThieu.ForeColor = Color.Brown;
            lblTonDuoiMucToiThieu.Location = new Point(875, 672);
            lblTonDuoiMucToiThieu.Name = "lblTonDuoiMucToiThieu";
            lblTonDuoiMucToiThieu.Size = new Size(434, 30);
            lblTonDuoiMucToiThieu.TabIndex = 73;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: 10";
            lblTonDuoiMucToiThieu.Click += lblTonDuoiMucToiThieu_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 94);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1320, 508);
            dataGridView1.TabIndex = 72;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(1163, 21);
            button2.Name = "button2";
            button2.Size = new Size(162, 49);
            button2.TabIndex = 68;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(91, 29);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 70;
            helloText.Text = "Xin chào Đức";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(534, 27);
            label1.Name = "label1";
            label1.Size = new Size(240, 43);
            label1.TabIndex = 69;
            label1.Text = "Bảng vật liệu";
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 74;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btnThemVL
            // 
            btnThemVL.BackColor = Color.DeepSkyBlue;
            btnThemVL.Cursor = Cursors.Hand;
            btnThemVL.FlatStyle = FlatStyle.Flat;
            btnThemVL.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnThemVL.Location = new Point(12, 633);
            btnThemVL.Name = "btnThemVL";
            btnThemVL.Size = new Size(332, 67);
            btnThemVL.TabIndex = 75;
            btnThemVL.Text = "Thêm vật liệu mới";
            btnThemVL.UseVisualStyleBackColor = false;
            btnThemVL.Visible = false;
            btnThemVL.Click += btnThemVL_Click;
            // 
            // bangVatLieu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1344, 712);
            Controls.Add(btnThemVL);
            Controls.Add(pictureBox1);
            Controls.Add(lblTonDuoiMucToiThieu);
            Controls.Add(dataGridView1);
            Controls.Add(button2);
            Controls.Add(helloText);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "bangVatLieu";
            Text = "Bảng vật liệu";
            Load += bangVatLieu_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTonDuoiMucToiThieu;
        private DataGridView dataGridView1;
        private Button button2;
        private Label helloText;
        private Label label1;
        private PictureBox pictureBox1;
        private Button btnThemVL;
    }
}