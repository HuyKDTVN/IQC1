﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class ton_kho : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVatLieu;

        public string maLK;
        public ton_kho(string maCodeNV, string tenNV, int phanQuyen, string maVL)
        {
            InitializeComponent();
            lblTonDuoiMucToiThieu.Location = new Point(
                lblTonDuoiMucToiThieu.Location.X,
                this.ClientSize.Height - lblTonDuoiMucToiThieu.Height - 15
            );
            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVatLieu = maVL;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {
            // Ví dụ: cho một button nằm ở giữa form
            //button1.Left = (this.ClientSize.Width - button1.Width) / 2;
            //button1.Top = (this.ClientSize.Height - button1.Height) / 2;

            dataGridView1.Width = this.ClientSize.Width - 60;
        }

        private void ton_kho_Load(object sender, EventArgs e)
        {
            helloText.Text = "Xin chào " + hoTen;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);
            
            DataTable table = new DataTable();

            // Tạo cột
            table.Columns.Add("Mã vật liệu", typeof(string));
            table.Columns.Add("Tên vật liệu", typeof(string));
            table.Columns.Add("Số Lượng", typeof(string));
            table.Columns.Add("Đơn vị", typeof(string));
            table.Columns.Add("Tồn kho tối thiểu", typeof(string));
            table.Columns.Add("Đơn giá", typeof(string));
            table.Columns.Add("Vị trí", typeof(string));
            table.Columns.Add("Nhóm vật liệu", typeof(string));
            
            table.Columns.Add("Mã hàng", typeof(string));
            table.Columns.Add("Ký tự", typeof(string));
            table.Columns.Add("Nhà cung cấp", typeof(string));
            table.Columns.Add("Ngày Nhập", typeof(string));
            table.Columns.Add("Người nhập", typeof(string));
            table.Columns.Add("Ghi chú", typeof(string));

            // Thêm dòng
            //table.Rows.Add("NVL001", "Ván MDF 18mm", 120, "Tấm", 20, "350000 VND", "Vật liệu chính", "Gỗ công nghiệp", "Kho Gỗ A", "Cty Minh Phát", DateTime.Now, "Thanh", "Dùng cho dòng tủ cao cấp");

            // Gán dữ liệu vào DataGridView
            dataGridView1.DataSource = table;
            dataGridView1.ReadOnly = true;                    // Không cho sửa nội dung
            dataGridView1.AllowUserToAddRows = false;         // Không cho thêm dòng mới
            dataGridView1.Visible = true;


            string[] filePaths = Directory.GetFiles(Variable.pathTonKho, "*.cnm",
                                         SearchOption.TopDirectoryOnly);
            string pathFileTaiBangLK;
            foreach (string filePath in filePaths) { 
                pathFileTaiBangLK = Variable.pathBangLK + Path.GetFileName(filePath);
                if (File.Exists(pathFileTaiBangLK))
                {
                    // Open the text file using a stream reader.
                    using StreamReader reader = new(pathFileTaiBangLK);

                    // Read the stream as a string.
                    string text = reader.ReadToEnd();
                    string[] infor = text.Split("##");
                    
                    string nhomVL = "Chính";
                    if (infor[2] == "P")
                    {
                        nhomVL = "Phụ";
                    }
                    if (infor[2] == "TB")
                    {
                        nhomVL = "Thiết bị";
                    }


                    //kiem tra con ton kho hay khong
                    string pathTonKho1 = Variable.pathTonKho + Path.GetFileName(filePath);
                    string maVL = Path.GetFileNameWithoutExtension(filePath);
                    if (File.Exists(pathTonKho1))
                    {
                        using (StreamReader reader1 = new StreamReader(pathTonKho1))
                        {
                            string text1 = reader1.ReadToEnd();
                            string[] infor1 = text1.Split("##");

                            table.Rows.Add(maVL, infor[0], infor1[0], infor[1], infor[3], infor1[1], infor1[2], infor[2], infor[7], infor[8], infor1[3], infor1[5], infor1[4], infor1[6]);


                        } // <-- tại đây StreamReader sẽ được đóng
                    }
                    else
                    {
                        table.Rows.Add(maVL, infor[0], 0, infor[1], infor[3], "", "", infor[2], infor[7], infor[8], "", "", "", "");
                    }

                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void lblTonDuoiMucToiThieu_Click(object sender, EventArgs e)
        {
            TKToiThieu f = new TKToiThieu(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
    }
}
