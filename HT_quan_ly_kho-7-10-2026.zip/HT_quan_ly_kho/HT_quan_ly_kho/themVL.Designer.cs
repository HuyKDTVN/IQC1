﻿namespace HT_quan_ly_kho
{
    partial class themVL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(themVL));
            lblTonDuoiMucToiThieu = new Label();
            helloText = new Label();
            inputDonVi = new ComboBox();
            btn = new Button();
            label19 = new Label();
            lblDonVi = new Label();
            inputGhiChu = new TextBox();
            lblGhiChu = new Label();
            lblNhomVL = new Label();
            lblMaHang = new Label();
            label5 = new Label();
            inputMaHang = new TextBox();
            inputMaLK = new TextBox();
            lblMaLK = new Label();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            myTitle = new Label();
            inputNhomVL = new ComboBox();
            inputTonKhoToiThieu = new NumericUpDown();
            lblKyTu = new Label();
            inputKyTu = new TextBox();
            lblTenVL = new Label();
            inputTenVL = new TextBox();
            lblMsg = new Label();
            lblmsgDonVi = new Label();
            inputLyDo = new TextBox();
            lblLyDo = new Label();
            inputDonGia = new NumericUpDown();
            lblDongia = new Label();
            imgQR = new PictureBox();
            btnIn = new Button();
            panel1 = new Panel();
            panel2 = new Panel();
            qrName = new Label();
            qrMa = new Label();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)inputTonKhoToiThieu).BeginInit();
            ((System.ComponentModel.ISupportInitialize)inputDonGia).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgQR).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblTonDuoiMucToiThieu
            // 
            lblTonDuoiMucToiThieu.AutoSize = true;
            lblTonDuoiMucToiThieu.Cursor = Cursors.Hand;
            lblTonDuoiMucToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTonDuoiMucToiThieu.ForeColor = Color.Brown;
            lblTonDuoiMucToiThieu.Location = new Point(451, 600);
            lblTonDuoiMucToiThieu.Margin = new Padding(2, 0, 2, 0);
            lblTonDuoiMucToiThieu.Name = "lblTonDuoiMucToiThieu";
            lblTonDuoiMucToiThieu.Size = new Size(302, 20);
            lblTonDuoiMucToiThieu.TabIndex = 148;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: 10";
            lblTonDuoiMucToiThieu.Click += lblTonDuoiMucToiThieu_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(65, 31);
            helloText.Margin = new Padding(2, 0, 2, 0);
            helloText.Name = "helloText";
            helloText.Size = new Size(97, 20);
            helloText.TabIndex = 147;
            helloText.Text = "Xin chào Đức";
            // 
            // inputDonVi
            // 
            inputDonVi.DropDownStyle = ComboBoxStyle.DropDownList;
            inputDonVi.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputDonVi.FormattingEnabled = true;
            inputDonVi.Location = new Point(334, 270);
            inputDonVi.Margin = new Padding(2);
            inputDonVi.Name = "inputDonVi";
            inputDonVi.Size = new Size(156, 28);
            inputDonVi.TabIndex = 6;
            inputDonVi.SelectedIndexChanged += inputDonVi_SelectedIndexChanged;
            // 
            // btn
            // 
            btn.BackColor = Color.CornflowerBlue;
            btn.Cursor = Cursors.Hand;
            btn.FlatStyle = FlatStyle.Flat;
            btn.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn.Location = new Point(234, 473);
            btn.Margin = new Padding(2);
            btn.Name = "btn";
            btn.Size = new Size(235, 41);
            btn.TabIndex = 11;
            btn.Text = "Thêm vật liệu mới";
            btn.UseVisualStyleBackColor = false;
            btn.Click += button4_Click;
            // 
            // label19
            // 
            label19.Location = new Point(0, 0);
            label19.Margin = new Padding(2, 0, 2, 0);
            label19.Name = "label19";
            label19.Size = new Size(70, 14);
            label19.TabIndex = 151;
            // 
            // lblDonVi
            // 
            lblDonVi.AutoSize = true;
            lblDonVi.Font = new Font("Segoe UI", 11F);
            lblDonVi.Location = new Point(192, 270);
            lblDonVi.Margin = new Padding(2, 0, 2, 0);
            lblDonVi.Name = "lblDonVi";
            lblDonVi.Size = new Size(65, 20);
            lblDonVi.TabIndex = 139;
            lblDonVi.Text = "Đơn vị *:";
            // 
            // inputGhiChu
            // 
            inputGhiChu.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputGhiChu.Location = new Point(334, 387);
            inputGhiChu.Margin = new Padding(2);
            inputGhiChu.Name = "inputGhiChu";
            inputGhiChu.Size = new Size(158, 27);
            inputGhiChu.TabIndex = 9;
            // 
            // lblGhiChu
            // 
            lblGhiChu.AutoSize = true;
            lblGhiChu.Font = new Font("Segoe UI", 11F);
            lblGhiChu.Location = new Point(195, 388);
            lblGhiChu.Margin = new Padding(2, 0, 2, 0);
            lblGhiChu.Name = "lblGhiChu";
            lblGhiChu.Size = new Size(61, 20);
            lblGhiChu.TabIndex = 138;
            lblGhiChu.Text = "Ghi chú:";
            // 
            // lblNhomVL
            // 
            lblNhomVL.AutoSize = true;
            lblNhomVL.Font = new Font("Segoe UI", 11F);
            lblNhomVL.Location = new Point(197, 132);
            lblNhomVL.Margin = new Padding(2, 0, 2, 0);
            lblNhomVL.Name = "lblNhomVL";
            lblNhomVL.Size = new Size(115, 20);
            lblNhomVL.TabIndex = 131;
            lblNhomVL.Text = "Nhóm vật liệu *:";
            lblNhomVL.Click += label13_Click;
            // 
            // lblMaHang
            // 
            lblMaHang.AutoSize = true;
            lblMaHang.Font = new Font("Segoe UI", 11F);
            lblMaHang.Location = new Point(195, 166);
            lblMaHang.Margin = new Padding(2, 0, 2, 0);
            lblMaHang.Name = "lblMaHang";
            lblMaHang.Size = new Size(80, 20);
            lblMaHang.TabIndex = 127;
            lblMaHang.Text = "Mã hàng *:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(195, 347);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(124, 20);
            label5.TabIndex = 126;
            label5.Text = "Tồn kho tối thiểu:";
            // 
            // inputMaHang
            // 
            inputMaHang.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputMaHang.Location = new Point(336, 161);
            inputMaHang.Margin = new Padding(2);
            inputMaHang.Name = "inputMaHang";
            inputMaHang.Size = new Size(156, 27);
            inputMaHang.TabIndex = 4;
            inputMaHang.TextChanged += inputMaHang_TextChanged;
            // 
            // inputMaLK
            // 
            inputMaLK.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputMaLK.Location = new Point(334, 234);
            inputMaLK.Margin = new Padding(2);
            inputMaLK.Name = "inputMaLK";
            inputMaLK.Size = new Size(156, 27);
            inputMaLK.TabIndex = 100;
            inputMaLK.TextChanged += inputMaLK_TextChanged;
            // 
            // lblMaLK
            // 
            lblMaLK.AutoSize = true;
            lblMaLK.Font = new Font("Segoe UI", 11F);
            lblMaLK.Location = new Point(192, 235);
            lblMaLK.Margin = new Padding(2, 0, 2, 0);
            lblMaLK.Name = "lblMaLK";
            lblMaLK.Size = new Size(95, 20);
            lblMaLK.TabIndex = 124;
            lblMaLK.Text = "Mã vật liệu *:";
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(8, 20);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(45, 35);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 123;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(658, 20);
            button2.Margin = new Padding(2);
            button2.Name = "button2";
            button2.Size = new Size(113, 29);
            button2.TabIndex = 134;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // myTitle
            // 
            myTitle.AutoSize = true;
            myTitle.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            myTitle.ForeColor = Color.FromArgb(64, 64, 64);
            myTitle.Location = new Point(242, 46);
            myTitle.Margin = new Padding(2, 0, 2, 0);
            myTitle.Name = "myTitle";
            myTitle.Size = new Size(219, 29);
            myTitle.TabIndex = 122;
            myTitle.Text = "Thêm vật liệu mới";
            myTitle.Click += myTitle_Click;
            // 
            // inputNhomVL
            // 
            inputNhomVL.DropDownStyle = ComboBoxStyle.DropDownList;
            inputNhomVL.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputNhomVL.FormattingEnabled = true;
            inputNhomVL.Items.AddRange(new object[] { "C", "P", "TB" });
            inputNhomVL.Location = new Point(336, 130);
            inputNhomVL.Margin = new Padding(2);
            inputNhomVL.Name = "inputNhomVL";
            inputNhomVL.Size = new Size(156, 28);
            inputNhomVL.TabIndex = 3;
            inputNhomVL.SelectedIndexChanged += inputNhomVL_SelectedIndexChanged;
            // 
            // inputTonKhoToiThieu
            // 
            inputTonKhoToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputTonKhoToiThieu.Location = new Point(334, 347);
            inputTonKhoToiThieu.Margin = new Padding(2);
            inputTonKhoToiThieu.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            inputTonKhoToiThieu.Name = "inputTonKhoToiThieu";
            inputTonKhoToiThieu.Size = new Size(157, 27);
            inputTonKhoToiThieu.TabIndex = 8;
            // 
            // lblKyTu
            // 
            lblKyTu.AutoSize = true;
            lblKyTu.Font = new Font("Segoe UI", 11F);
            lblKyTu.Location = new Point(195, 203);
            lblKyTu.Margin = new Padding(2, 0, 2, 0);
            lblKyTu.Name = "lblKyTu";
            lblKyTu.Size = new Size(124, 20);
            lblKyTu.TabIndex = 156;
            lblKyTu.Text = "Ký tự (3 chữ số) *:";
            // 
            // inputKyTu
            // 
            inputKyTu.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputKyTu.Location = new Point(336, 199);
            inputKyTu.Margin = new Padding(2);
            inputKyTu.Name = "inputKyTu";
            inputKyTu.Size = new Size(156, 27);
            inputKyTu.TabIndex = 5;
            inputKyTu.TextChanged += inputKyTu_TextChanged;
            // 
            // lblTenVL
            // 
            lblTenVL.AutoSize = true;
            lblTenVL.Font = new Font("Segoe UI", 11F);
            lblTenVL.Location = new Point(195, 101);
            lblTenVL.Margin = new Padding(2, 0, 2, 0);
            lblTenVL.Name = "lblTenVL";
            lblTenVL.Size = new Size(97, 20);
            lblTenVL.TabIndex = 158;
            lblTenVL.Text = "Tên vật liệu *:";
            // 
            // inputTenVL
            // 
            inputTenVL.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputTenVL.Location = new Point(336, 97);
            inputTenVL.Margin = new Padding(2);
            inputTenVL.Name = "inputTenVL";
            inputTenVL.Size = new Size(156, 27);
            inputTenVL.TabIndex = 2;
            inputTenVL.TextChanged += inputTenVL_TextChanged;
            // 
            // lblMsg
            // 
            lblMsg.AutoSize = true;
            lblMsg.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMsg.ForeColor = Color.CadetBlue;
            lblMsg.Location = new Point(153, 538);
            lblMsg.Margin = new Padding(2, 0, 2, 0);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(334, 25);
            lblMsg.TabIndex = 154;
            lblMsg.Text = "Đã thêm thành công cho mã vật liệu: ";
            lblMsg.Click += label2_Click;
            // 
            // lblmsgDonVi
            // 
            lblmsgDonVi.AutoSize = true;
            lblmsgDonVi.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblmsgDonVi.ForeColor = Color.Firebrick;
            lblmsgDonVi.Location = new Point(493, 263);
            lblmsgDonVi.Margin = new Padding(2, 0, 2, 0);
            lblmsgDonVi.Name = "lblmsgDonVi";
            lblmsgDonVi.Size = new Size(172, 38);
            lblmsgDonVi.TabIndex = 159;
            lblmsgDonVi.Text = "Không thể chỉnh sửa được\r\nđơn vị khi có tồn kho";
            lblmsgDonVi.Visible = false;
            // 
            // inputLyDo
            // 
            inputLyDo.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputLyDo.Location = new Point(336, 425);
            inputLyDo.Margin = new Padding(2);
            inputLyDo.Name = "inputLyDo";
            inputLyDo.Size = new Size(158, 27);
            inputLyDo.TabIndex = 10;
            inputLyDo.Visible = false;
            // 
            // lblLyDo
            // 
            lblLyDo.AutoSize = true;
            lblLyDo.Font = new Font("Segoe UI", 11F);
            lblLyDo.Location = new Point(197, 426);
            lblLyDo.Margin = new Padding(2, 0, 2, 0);
            lblLyDo.Name = "lblLyDo";
            lblLyDo.Size = new Size(127, 20);
            lblLyDo.TabIndex = 161;
            lblLyDo.Text = "Lý do  chỉnh sửa *:";
            lblLyDo.Visible = false;
            // 
            // inputDonGia
            // 
            inputDonGia.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputDonGia.Location = new Point(334, 309);
            inputDonGia.Margin = new Padding(2);
            inputDonGia.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            inputDonGia.Name = "inputDonGia";
            inputDonGia.Size = new Size(157, 27);
            inputDonGia.TabIndex = 7;
            // 
            // lblDongia
            // 
            lblDongia.AutoSize = true;
            lblDongia.Font = new Font("Segoe UI", 11F);
            lblDongia.Location = new Point(192, 309);
            lblDongia.Margin = new Padding(2, 0, 2, 0);
            lblDongia.Name = "lblDongia";
            lblDongia.Size = new Size(75, 20);
            lblDongia.TabIndex = 163;
            lblDongia.Text = "Đơn giá *:";
            // 
            // imgQR
            // 
            imgQR.Location = new Point(127, 2);
            imgQR.Margin = new Padding(2);
            imgQR.Name = "imgQR";
            imgQR.Size = new Size(63, 54);
            imgQR.TabIndex = 164;
            imgQR.TabStop = false;
            // 
            // btnIn
            // 
            btnIn.BackColor = Color.Turquoise;
            btnIn.Cursor = Cursors.Hand;
            btnIn.FlatStyle = FlatStyle.Flat;
            btnIn.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnIn.Location = new Point(638, 209);
            btnIn.Margin = new Padding(2);
            btnIn.Name = "btnIn";
            btnIn.Size = new Size(70, 27);
            btnIn.TabIndex = 165;
            btnIn.Text = "In";
            btnIn.UseVisualStyleBackColor = false;
            btnIn.Click += btnIn_Click_1;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(qrName);
            panel1.Controls.Add(qrMa);
            panel1.Controls.Add(imgQR);
            panel1.Location = new Point(576, 98);
            panel1.Margin = new Padding(2);
            panel1.Name = "panel1";
            panel1.Size = new Size(196, 109);
            panel1.TabIndex = 166;
            panel1.Visible = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(64, 64, 64);
            panel2.Location = new Point(8, 55);
            panel2.Margin = new Padding(2);
            panel2.Name = "panel2";
            panel2.Size = new Size(112, 1);
            panel2.TabIndex = 167;
            panel2.Visible = false;
            // 
            // qrName
            // 
            qrName.AutoSize = true;
            qrName.Font = new Font("Arial Narrow", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            qrName.Location = new Point(6, 70);
            qrName.Margin = new Padding(2, 0, 2, 0);
            qrName.Name = "qrName";
            qrName.Size = new Size(94, 26);
            qrName.TabIndex = 166;
            qrName.Text = "P-VIT-031";
            qrName.Visible = false;
            // 
            // qrMa
            // 
            qrMa.AutoSize = true;
            qrMa.Font = new Font("Arial Narrow", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            qrMa.Location = new Point(6, 16);
            qrMa.Margin = new Padding(2, 0, 2, 0);
            qrMa.Name = "qrMa";
            qrMa.Size = new Size(94, 26);
            qrMa.TabIndex = 165;
            qrMa.Text = "P-VIT-031";
            qrMa.Visible = false;
            // 
            // themVL
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(786, 641);
            Controls.Add(panel1);
            Controls.Add(btnIn);
            Controls.Add(inputDonGia);
            Controls.Add(lblDongia);
            Controls.Add(inputLyDo);
            Controls.Add(lblLyDo);
            Controls.Add(lblmsgDonVi);
            Controls.Add(lblTenVL);
            Controls.Add(inputTenVL);
            Controls.Add(lblKyTu);
            Controls.Add(inputKyTu);
            Controls.Add(lblMsg);
            Controls.Add(inputTonKhoToiThieu);
            Controls.Add(inputNhomVL);
            Controls.Add(lblTonDuoiMucToiThieu);
            Controls.Add(helloText);
            Controls.Add(inputDonVi);
            Controls.Add(btn);
            Controls.Add(label19);
            Controls.Add(lblDonVi);
            Controls.Add(inputGhiChu);
            Controls.Add(lblGhiChu);
            Controls.Add(lblNhomVL);
            Controls.Add(lblMaHang);
            Controls.Add(label5);
            Controls.Add(inputMaHang);
            Controls.Add(inputMaLK);
            Controls.Add(lblMaLK);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(myTitle);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(2);
            MaximizeBox = false;
            Name = "themVL";
            Text = "Thêm vật liệu";
            Load += themVL_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)inputTonKhoToiThieu).EndInit();
            ((System.ComponentModel.ISupportInitialize)inputDonGia).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgQR).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTonDuoiMucToiThieu;
        private Label helloText;
        private ComboBox inputDonVi;
        private Button btn;
        private Label label19;
        private Label lblDonVi;
        private TextBox inputGhiChu;
        private Label lblGhiChu;
        private Label lblNhomVL;
        private Label lblMaHang;
        private Label label5;
        private TextBox inputMaHang;
        private TextBox inputMaLK;
        private Label lblMaLK;
        private PictureBox pictureBox1;
        private Button button2;
        private Label myTitle;
        private ComboBox inputNhomVL;
        private NumericUpDown inputTonKhoToiThieu;
        private Label lblKyTu;
        private TextBox inputKyTu;
        private Label lblTenVL;
        private TextBox inputTenVL;
        private Label lblMsg;
        private Label lblmsgDonVi;
        private TextBox inputLyDo;
        private Label lblLyDo;
        private NumericUpDown inputDonGia;
        private Label lblDongia;
        private PictureBox imgQR;
        private Button btnIn;
        private Panel panel1;
        private Label qrMa;
        private Label qrName;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Panel panel2;
    }
}