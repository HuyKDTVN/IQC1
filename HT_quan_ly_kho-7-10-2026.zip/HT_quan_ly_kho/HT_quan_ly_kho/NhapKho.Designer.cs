﻿namespace HT_quan_ly_kho
{
    partial class NhapKho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NhapKho));
            button2 = new Button();
            titleNhap = new Label();
            pictureBox1 = new PictureBox();
            soLuongDangCo = new Label();
            nhomVatLieuValue = new Label();
            label13 = new Label();
            ngayNhapkho = new Label();
            label11 = new Label();
            tenLKValue = new Label();
            label6 = new Label();
            lblDongia = new Label();
            lblSoLuong = new Label();
            inputMaLK = new TextBox();
            lblMaVL = new Label();
            lblKho = new Label();
            lblSoLuongToiThieu = new Label();
            ghiChu = new TextBox();
            lblGhiChu = new Label();
            lblNCC = new Label();
            nguoiNhapKhoValue = new Label();
            label21 = new Label();
            btnNhap = new Button();
            inputKhoLuuTru = new ComboBox();
            inputNhaCungCap = new ComboBox();
            lblTonDuoiMucToiThieu = new Label();
            helloText = new Label();
            btnThemVL = new Button();
            soLuongToiThieuValue = new Label();
            inputSoLuong = new NumericUpDown();
            inputDonGia = new NumericUpDown();
            lblMsg = new Label();
            maHangValue = new Label();
            lblMaHang = new Label();
            kyTuValue = new Label();
            lblKyTu = new Label();
            inputLyDo = new TextBox();
            lblLyDo = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)inputSoLuong).BeginInit();
            ((System.ComponentModel.ISupportInitialize)inputDonGia).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(678, 12);
            button2.Margin = new Padding(2, 2, 2, 2);
            button2.Name = "button2";
            button2.Size = new Size(113, 29);
            button2.TabIndex = 100;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // titleNhap
            // 
            titleNhap.AutoSize = true;
            titleNhap.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleNhap.ForeColor = Color.FromArgb(64, 64, 64);
            titleNhap.Location = new Point(304, 28);
            titleNhap.Margin = new Padding(2, 0, 2, 0);
            titleNhap.Name = "titleNhap";
            titleNhap.Size = new Size(123, 29);
            titleNhap.TabIndex = 10;
            titleNhap.Text = "Nhập kho";
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(6, 6);
            pictureBox1.Margin = new Padding(2, 2, 2, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(45, 35);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 30;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // soLuongDangCo
            // 
            soLuongDangCo.AutoSize = true;
            soLuongDangCo.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            soLuongDangCo.Location = new Point(314, 121);
            soLuongDangCo.Margin = new Padding(2, 0, 2, 0);
            soLuongDangCo.Name = "soLuongDangCo";
            soLuongDangCo.Size = new Size(83, 20);
            soLuongDangCo.TabIndex = 64;
            soLuongDangCo.Text = "/ 1000 pcs";
            // 
            // nhomVatLieuValue
            // 
            nhomVatLieuValue.AutoSize = true;
            nhomVatLieuValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            nhomVatLieuValue.Location = new Point(574, 163);
            nhomVatLieuValue.Margin = new Padding(2, 0, 2, 0);
            nhomVatLieuValue.Name = "nhomVatLieuValue";
            nhomVatLieuValue.Size = new Size(104, 20);
            nhomVatLieuValue.TabIndex = 63;
            nhomVatLieuValue.Text = "Vật liệu chính";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 11F);
            label13.Location = new Point(452, 163);
            label13.Margin = new Padding(2, 0, 2, 0);
            label13.Name = "label13";
            label13.Size = new Size(105, 20);
            label13.TabIndex = 62;
            label13.Text = "Nhóm vật liệu:";
            // 
            // ngayNhapkho
            // 
            ngayNhapkho.AutoSize = true;
            ngayNhapkho.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            ngayNhapkho.Location = new Point(580, 324);
            ngayNhapkho.Margin = new Padding(2, 0, 2, 0);
            ngayNhapkho.Name = "ngayNhapkho";
            ngayNhapkho.Size = new Size(86, 20);
            ngayNhapkho.TabIndex = 61;
            ngayNhapkho.Text = "12/7/2025";
            ngayNhapkho.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11F);
            label11.Location = new Point(458, 324);
            label11.Margin = new Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new Size(112, 20);
            label11.TabIndex = 60;
            label11.Text = "Ngày nhập kho:";
            label11.Visible = false;
            // 
            // tenLKValue
            // 
            tenLKValue.AutoSize = true;
            tenLKValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            tenLKValue.Location = new Point(574, 83);
            tenLKValue.Margin = new Padding(2, 0, 2, 0);
            tenLKValue.Name = "tenLKValue";
            tenLKValue.Size = new Size(39, 20);
            tenLKValue.TabIndex = 59;
            tenLKValue.Text = "ABC";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(452, 83);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(87, 20);
            label6.TabIndex = 58;
            label6.Text = "Tên vật liệu:";
            // 
            // lblDongia
            // 
            lblDongia.AutoSize = true;
            lblDongia.Font = new Font("Segoe UI", 11F);
            lblDongia.Location = new Point(8, 161);
            lblDongia.Margin = new Padding(2, 0, 2, 0);
            lblDongia.Name = "lblDongia";
            lblDongia.Size = new Size(75, 20);
            lblDongia.TabIndex = 56;
            lblDongia.Text = "Đơn giá *:";
            // 
            // lblSoLuong
            // 
            lblSoLuong.AutoSize = true;
            lblSoLuong.Font = new Font("Segoe UI", 11F);
            lblSoLuong.Location = new Point(8, 121);
            lblSoLuong.Margin = new Padding(2, 0, 2, 0);
            lblSoLuong.Name = "lblSoLuong";
            lblSoLuong.Size = new Size(82, 20);
            lblSoLuong.TabIndex = 54;
            lblSoLuong.Text = "Số lượng *:";
            // 
            // inputMaLK
            // 
            inputMaLK.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputMaLK.Location = new Point(150, 81);
            inputMaLK.Margin = new Padding(2, 2, 2, 2);
            inputMaLK.Name = "inputMaLK";
            inputMaLK.Size = new Size(156, 27);
            inputMaLK.TabIndex = 1;
            inputMaLK.TextChanged += textBox1_TextChanged;
            // 
            // lblMaVL
            // 
            lblMaVL.AutoSize = true;
            lblMaVL.Font = new Font("Segoe UI", 11F);
            lblMaVL.Location = new Point(8, 82);
            lblMaVL.Margin = new Padding(2, 0, 2, 0);
            lblMaVL.Name = "lblMaVL";
            lblMaVL.Size = new Size(95, 20);
            lblMaVL.TabIndex = 52;
            lblMaVL.Text = "Mã vật liệu *:";
            // 
            // lblKho
            // 
            lblKho.AutoSize = true;
            lblKho.Font = new Font("Segoe UI", 11F);
            lblKho.Location = new Point(8, 203);
            lblKho.Margin = new Padding(2, 0, 2, 0);
            lblKho.Name = "lblKho";
            lblKho.Size = new Size(101, 20);
            lblKho.TabIndex = 102;
            lblKho.Text = "Vị trí lưu trữ *:";
            // 
            // lblSoLuongToiThieu
            // 
            lblSoLuongToiThieu.AutoSize = true;
            lblSoLuongToiThieu.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSoLuongToiThieu.Location = new Point(452, 126);
            lblSoLuongToiThieu.Margin = new Padding(2, 0, 2, 0);
            lblSoLuongToiThieu.Name = "lblSoLuongToiThieu";
            lblSoLuongToiThieu.Size = new Size(117, 19);
            lblSoLuongToiThieu.TabIndex = 104;
            lblSoLuongToiThieu.Text = "Tồn kho tối thiểu:";
            // 
            // ghiChu
            // 
            ghiChu.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            ghiChu.Location = new Point(152, 279);
            ghiChu.Margin = new Padding(2, 2, 2, 2);
            ghiChu.Name = "ghiChu";
            ghiChu.Size = new Size(156, 27);
            ghiChu.TabIndex = 6;
            // 
            // lblGhiChu
            // 
            lblGhiChu.AutoSize = true;
            lblGhiChu.Font = new Font("Segoe UI", 11F);
            lblGhiChu.Location = new Point(10, 280);
            lblGhiChu.Margin = new Padding(2, 0, 2, 0);
            lblGhiChu.Name = "lblGhiChu";
            lblGhiChu.Size = new Size(71, 20);
            lblGhiChu.TabIndex = 106;
            lblGhiChu.Text = "Ghi chú *:";
            // 
            // lblNCC
            // 
            lblNCC.AutoSize = true;
            lblNCC.Font = new Font("Segoe UI", 11F);
            lblNCC.Location = new Point(8, 240);
            lblNCC.Margin = new Padding(2, 0, 2, 0);
            lblNCC.Name = "lblNCC";
            lblNCC.Size = new Size(113, 20);
            lblNCC.TabIndex = 108;
            lblNCC.Text = "Nhà cung cấp *:";
            // 
            // nguoiNhapKhoValue
            // 
            nguoiNhapKhoValue.AutoSize = true;
            nguoiNhapKhoValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            nguoiNhapKhoValue.Location = new Point(580, 289);
            nguoiNhapKhoValue.Margin = new Padding(2, 0, 2, 0);
            nguoiNhapKhoValue.Name = "nguoiNhapKhoValue";
            nguoiNhapKhoValue.Size = new Size(37, 20);
            nguoiNhapKhoValue.TabIndex = 113;
            nguoiNhapKhoValue.Text = "Đức";
            nguoiNhapKhoValue.Visible = false;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 11F);
            label21.Location = new Point(458, 289);
            label21.Margin = new Padding(2, 0, 2, 0);
            label21.Name = "label21";
            label21.Size = new Size(119, 20);
            label21.TabIndex = 112;
            label21.Text = "Người nhập kho:";
            label21.Visible = false;
            // 
            // btnNhap
            // 
            btnNhap.BackColor = Color.CornflowerBlue;
            btnNhap.Cursor = Cursors.Hand;
            btnNhap.FlatStyle = FlatStyle.Flat;
            btnNhap.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNhap.Location = new Point(304, 367);
            btnNhap.Margin = new Padding(2, 2, 2, 2);
            btnNhap.Name = "btnNhap";
            btnNhap.Size = new Size(148, 41);
            btnNhap.TabIndex = 7;
            btnNhap.Text = "Nhập kho";
            btnNhap.UseVisualStyleBackColor = false;
            btnNhap.Click += button4_Click;
            // 
            // inputKhoLuuTru
            // 
            inputKhoLuuTru.DropDownStyle = ComboBoxStyle.DropDownList;
            inputKhoLuuTru.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputKhoLuuTru.FormattingEnabled = true;
            inputKhoLuuTru.Location = new Point(150, 202);
            inputKhoLuuTru.Margin = new Padding(2, 2, 2, 2);
            inputKhoLuuTru.Name = "inputKhoLuuTru";
            inputKhoLuuTru.Size = new Size(156, 28);
            inputKhoLuuTru.TabIndex = 4;
            // 
            // inputNhaCungCap
            // 
            inputNhaCungCap.DropDownStyle = ComboBoxStyle.DropDownList;
            inputNhaCungCap.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputNhaCungCap.FormattingEnabled = true;
            inputNhaCungCap.Location = new Point(150, 240);
            inputNhaCungCap.Margin = new Padding(2, 2, 2, 2);
            inputNhaCungCap.Name = "inputNhaCungCap";
            inputNhaCungCap.Size = new Size(156, 28);
            inputNhaCungCap.TabIndex = 5;
            // 
            // lblTonDuoiMucToiThieu
            // 
            lblTonDuoiMucToiThieu.AutoSize = true;
            lblTonDuoiMucToiThieu.Cursor = Cursors.Hand;
            lblTonDuoiMucToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTonDuoiMucToiThieu.ForeColor = Color.Brown;
            lblTonDuoiMucToiThieu.Location = new Point(496, 490);
            lblTonDuoiMucToiThieu.Margin = new Padding(2, 0, 2, 0);
            lblTonDuoiMucToiThieu.Name = "lblTonDuoiMucToiThieu";
            lblTonDuoiMucToiThieu.Size = new Size(302, 20);
            lblTonDuoiMucToiThieu.TabIndex = 118;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: 10";
            lblTonDuoiMucToiThieu.Click += lblTonDuoiMucToiThieu_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(62, 17);
            helloText.Margin = new Padding(2, 0, 2, 0);
            helloText.Name = "helloText";
            helloText.Size = new Size(97, 20);
            helloText.TabIndex = 117;
            helloText.Text = "Xin chào Đức";
            // 
            // btnThemVL
            // 
            btnThemVL.BackColor = Color.LightSteelBlue;
            btnThemVL.Cursor = Cursors.Hand;
            btnThemVL.FlatStyle = FlatStyle.Flat;
            btnThemVL.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThemVL.Location = new Point(314, 79);
            btnThemVL.Margin = new Padding(2, 2, 2, 2);
            btnThemVL.Name = "btnThemVL";
            btnThemVL.Size = new Size(134, 27);
            btnThemVL.TabIndex = 119;
            btnThemVL.Text = "Thêm vật liệu mới";
            btnThemVL.UseVisualStyleBackColor = false;
            btnThemVL.Click += btnThemVL_Click;
            // 
            // soLuongToiThieuValue
            // 
            soLuongToiThieuValue.AutoSize = true;
            soLuongToiThieuValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            soLuongToiThieuValue.Location = new Point(574, 126);
            soLuongToiThieuValue.Margin = new Padding(2, 0, 2, 0);
            soLuongToiThieuValue.Name = "soLuongToiThieuValue";
            soLuongToiThieuValue.Size = new Size(39, 20);
            soLuongToiThieuValue.TabIndex = 120;
            soLuongToiThieuValue.Text = "ABC";
            // 
            // inputSoLuong
            // 
            inputSoLuong.DecimalPlaces = 1;
            inputSoLuong.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputSoLuong.Location = new Point(148, 120);
            inputSoLuong.Margin = new Padding(2, 2, 2, 2);
            inputSoLuong.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            inputSoLuong.Name = "inputSoLuong";
            inputSoLuong.Size = new Size(157, 27);
            inputSoLuong.TabIndex = 2;
            // 
            // inputDonGia
            // 
            inputDonGia.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputDonGia.Location = new Point(150, 161);
            inputDonGia.Margin = new Padding(2, 2, 2, 2);
            inputDonGia.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            inputDonGia.Name = "inputDonGia";
            inputDonGia.Size = new Size(157, 27);
            inputDonGia.TabIndex = 3;
            // 
            // lblMsg
            // 
            lblMsg.AutoSize = true;
            lblMsg.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMsg.ForeColor = Color.CadetBlue;
            lblMsg.Location = new Point(130, 425);
            lblMsg.Margin = new Padding(2, 0, 2, 0);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(369, 25);
            lblMsg.TabIndex = 155;
            lblMsg.Text = "Đã nhập kho thành công cho mã vật liệu: ";
            lblMsg.Visible = false;
            // 
            // maHangValue
            // 
            maHangValue.AutoSize = true;
            maHangValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            maHangValue.Location = new Point(574, 202);
            maHangValue.Margin = new Padding(2, 0, 2, 0);
            maHangValue.Name = "maHangValue";
            maHangValue.Size = new Size(104, 20);
            maHangValue.TabIndex = 157;
            maHangValue.Text = "Vật liệu chính";
            // 
            // lblMaHang
            // 
            lblMaHang.AutoSize = true;
            lblMaHang.Font = new Font("Segoe UI", 11F);
            lblMaHang.Location = new Point(452, 202);
            lblMaHang.Margin = new Padding(2, 0, 2, 0);
            lblMaHang.Name = "lblMaHang";
            lblMaHang.Size = new Size(70, 20);
            lblMaHang.TabIndex = 156;
            lblMaHang.Text = "Mã hàng:";
            // 
            // kyTuValue
            // 
            kyTuValue.AutoSize = true;
            kyTuValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            kyTuValue.Location = new Point(574, 242);
            kyTuValue.Margin = new Padding(2, 0, 2, 0);
            kyTuValue.Name = "kyTuValue";
            kyTuValue.Size = new Size(104, 20);
            kyTuValue.TabIndex = 159;
            kyTuValue.Text = "Vật liệu chính";
            // 
            // lblKyTu
            // 
            lblKyTu.AutoSize = true;
            lblKyTu.Font = new Font("Segoe UI", 11F);
            lblKyTu.Location = new Point(452, 242);
            lblKyTu.Margin = new Padding(2, 0, 2, 0);
            lblKyTu.Name = "lblKyTu";
            lblKyTu.Size = new Size(45, 20);
            lblKyTu.TabIndex = 158;
            lblKyTu.Text = "Ký tự:";
            // 
            // inputLyDo
            // 
            inputLyDo.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputLyDo.Location = new Point(150, 317);
            inputLyDo.Margin = new Padding(2, 2, 2, 2);
            inputLyDo.Name = "inputLyDo";
            inputLyDo.Size = new Size(158, 27);
            inputLyDo.TabIndex = 162;
            inputLyDo.Visible = false;
            // 
            // lblLyDo
            // 
            lblLyDo.AutoSize = true;
            lblLyDo.Font = new Font("Segoe UI", 11F);
            lblLyDo.Location = new Point(10, 318);
            lblLyDo.Margin = new Padding(2, 0, 2, 0);
            lblLyDo.Name = "lblLyDo";
            lblLyDo.Size = new Size(123, 20);
            lblLyDo.TabIndex = 163;
            lblLyDo.Text = "Lý do chỉnh sửa *:";
            lblLyDo.Visible = false;
            // 
            // NhapKho
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(820, 561);
            Controls.Add(inputLyDo);
            Controls.Add(lblLyDo);
            Controls.Add(kyTuValue);
            Controls.Add(lblKyTu);
            Controls.Add(maHangValue);
            Controls.Add(lblMaHang);
            Controls.Add(lblMsg);
            Controls.Add(inputDonGia);
            Controls.Add(inputSoLuong);
            Controls.Add(soLuongToiThieuValue);
            Controls.Add(btnThemVL);
            Controls.Add(lblTonDuoiMucToiThieu);
            Controls.Add(helloText);
            Controls.Add(inputNhaCungCap);
            Controls.Add(inputKhoLuuTru);
            Controls.Add(btnNhap);
            Controls.Add(nguoiNhapKhoValue);
            Controls.Add(label21);
            Controls.Add(lblNCC);
            Controls.Add(ghiChu);
            Controls.Add(lblGhiChu);
            Controls.Add(lblSoLuongToiThieu);
            Controls.Add(lblKho);
            Controls.Add(soLuongDangCo);
            Controls.Add(nhomVatLieuValue);
            Controls.Add(label13);
            Controls.Add(ngayNhapkho);
            Controls.Add(label11);
            Controls.Add(tenLKValue);
            Controls.Add(label6);
            Controls.Add(lblDongia);
            Controls.Add(lblSoLuong);
            Controls.Add(inputMaLK);
            Controls.Add(lblMaVL);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(titleNhap);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(2, 2, 2, 2);
            MaximizeBox = false;
            Name = "NhapKho";
            Text = "Nhập kho";
            Load += NhapKho_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)inputSoLuong).EndInit();
            ((System.ComponentModel.ISupportInitialize)inputDonGia).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Label titleNhap;
        private PictureBox pictureBox1;
        private Label soLuongDangCo;
        private Label nhomVatLieuValue;
        private Label label13;
        private Label ngayNhapkho;
        private Label label11;
        private Label tenLKValue;
        private Label label6;
        private Label lblDongia;
        private Label lblSoLuong;
        private TextBox inputMaLK;
        private Label lblMaVL;
        private Label lblKho;
        private Label lblSoLuongToiThieu;
        private TextBox ghiChu;
        private Label lblGhiChu;
        private Label lblNCC;
        private Label nguoiNhapKhoValue;
        private Label label21;
        private Button btnNhap;
        private ComboBox inputKhoLuuTru;
        private ComboBox inputNhaCungCap;
        private Label lblTonDuoiMucToiThieu;
        private Label helloText;
        private Button btnThemVL;
        private Label soLuongToiThieuValue;
        private NumericUpDown inputSoLuong;
        private NumericUpDown inputDonGia;
        private Label lblMsg;
        private Label maHangValue;
        private Label lblMaHang;
        private Label kyTuValue;
        private Label lblKyTu;
        private TextBox inputLyDo;
        private Label lblLyDo;
    }
}