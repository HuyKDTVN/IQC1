﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class XuatKho : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public bool xuatHayHuy;

        public double soLuongCu = 0;
        public double soLuongToiThieu = 0;
        public int typeTonKhoToiThieu = 2;
        public string maLK;
        public XuatKho(string maCodeNV, string tenNV, int phanQuyen, bool xuatHuy)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            xuatHayHuy = xuatHuy;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
        private void XuatKho_Load(object sender, EventArgs e)
        {
            lblTonDuoiMucToiThieu.Location = new Point(
                lblTonDuoiMucToiThieu.Location.X,
                this.ClientSize.Height - lblTonDuoiMucToiThieu.Height - 15
            );

            inputmaVL.AutoCompleteMode = AutoCompleteMode.Suggest;
            inputmaVL.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection source = new AutoCompleteStringCollection();
            source.AddRange(Huy_functions.getAllFilesfolder(Variable.pathTonKho));
            inputmaVL.AutoCompleteCustomSource = source;

            if (xuatHayHuy)
            {
                titleXuatKho.Text = "Xuất kho";
                btnXuatKho.Text = "Xuất kho";
                this.Text = "Xuất kho";
            }
            else
            {
                titleXuatKho.Text = "Hủy vật liệu";
                btnXuatKho.Text = "Hủy vật liệu";
                this.Text = "Hủy vật liệu";
                typeTonKhoToiThieu = 4;
            }
            helloText.Text = "Xin chào " + hoTen;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);
            clearScreen();
        }

        private void clearScreen()
        {
            soLuongCuValue.Text = "";
            donGiaValue.Text = "";
            khoLuuTruValue.Text = "";
            nccValue.Text = "";
            tenVLValue.Text = "";
            soLuongToiThieuValue.Text = "";
            nhomVLValue.Text = "";
            maHangValue.Text = "";
            kyTuValue.Text = "";
            inputSoLuong.Text = "";
            inputGhiChu.Text = "";
        }

        private void inputmaVL_TextChanged(object sender, EventArgs e)
        {
            if (inputmaVL.Text.Length > 0)
            {
                clearScreen();
                lblMsg.Visible = false;
            }

            //soLuongCuValue.Visible = true;
            maLK = inputmaVL.Text.ToUpper();

            if (maLK.Contains("##"))
            {
                string[] arrBarCode = maLK.Split("##");
                maLK = arrBarCode[0];
                if (arrBarCode.Length > 2)
                {
                    inputSoLuong.Text = arrBarCode[1];
                    inputGhiChu.Text = arrBarCode[2];
                }
            }

            //lay thong tin tu bang LK
            string path = Variable.pathBangLK + maLK + ".cnm";
            //MessageBox.Show(path);
            if (File.Exists(path))
            {
                // Open the text file using a stream reader.
                using StreamReader reader = new(path);

                // Read the stream as a string.
                string text = reader.ReadToEnd();
                string[] infor = text.Split("##");
                tenVLValue.Text = infor[0];

                //string nhomVL = "Chính";
                //if (infor[2] == "P")
                //{
                //    nhomVL = "Phụ";
                //}
                //if (infor[2] == "TB")
                //{
                //    nhomVL = "Thiết bị";
                //}
                nhomVLValue.Text = infor[2];
                string donVi = infor[1];
                soLuongToiThieu = 0;
                if(infor[3].Length > 0  )
                {
                    soLuongToiThieu = Convert.ToDouble(infor[3]);
                }
                
                soLuongToiThieuValue.Text = soLuongToiThieu + " " + donVi;
                maHangValue.Text = infor[7];
                kyTuValue.Text = infor[8];

                //kiem tra con ton kho hay khong
                string pathTonKho1 = Variable.pathTonKho + maLK + ".cnm";
                if (File.Exists(pathTonKho1))
                {

                    using (StreamReader reader1 = new StreamReader(pathTonKho1))
                    {
                        string text1 = reader1.ReadToEnd();
                        string[] infor1 = text1.Split("##");

                        soLuongCu = Convert.ToDouble(infor1[0]);
                        //MessageBox.Show(soLuongCu + "");
                        soLuongCuValue.Text = "/" + soLuongCu + " " + donVi;

                        donGiaValue.Text = infor1[1];
                        khoLuuTruValue.Text = infor1[2];
                       // MessageBox.Show(infor1[2]);
                        nccValue.Text = infor1[3];
                    } // <-- tại đây StreamReader sẽ được đóng
                }
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            
            //MessageBox.Show(DateTime.Now.ToString());
            lblMaVL.ForeColor = Color.Black;
            lblSoLuong.ForeColor = Color.Black;
            lblGhiChu.ForeColor = Color.Black;
            bool isError = false;
            bool hasSharp = false;
            //validate
            if (Huy_functions.hasSharpChar(maLK))
            {
                lblMaVL.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(inputGhiChu.Text))
            {
                lblGhiChu.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            

            if (hasSharp)
            {
                MessageBox.Show("Dữ liệu nhập vào không được chứa ký tự ##");
            }

            //check empty
            if (inputmaVL.Text == "")
            {
                isError = true;
                lblMaVL.ForeColor = Color.Red;
            }
            if (inputSoLuong.Text.Length > 0)
            {
                if (Convert.ToDouble(inputSoLuong.Text) <= 0)
                {
                    isError = true;
                    lblSoLuong.ForeColor = Color.Red;
                }
            }
            else
            {
                isError = true;
                lblSoLuong.ForeColor = Color.Red;
            }
            if (inputGhiChu.Text.Trim() == "")
            {
                isError = true;
                lblGhiChu.ForeColor = Color.Red;
            }
            if (inputGhiChu.Text == "")
            {
                isError = true;
                lblGhiChu.ForeColor = Color.Red;
            }
            if (!isError)
            {
                if (tenVLValue.Text == "")
                {
                    //kiem tra xem da duoc them linh kien truoc do hay chua
                    MessageBox.Show("Không tồn tại vật liệu " + inputmaVL.Text);

                }
                else
                {
                    //insert to bang nhap kho

                    if (soLuongCu > 0)
                    {
                        lblSoLuong.ForeColor = Color.Black;
                        double sl = 0;

                        if (inputSoLuong.Text.Length > 0)
                        {
                            sl = Convert.ToDouble(inputSoLuong.Text);
                        }
                        if (sl > soLuongCu)
                        {
                            lblSoLuong.ForeColor = Color.Red;
                            MessageBox.Show("Không thể xuất quá số lượng tồn kho");
                        }
                        else
                        {
                            //co the xuat kho
                            string pathTonKho1 = Variable.pathTonKho + maLK + ".cnm";
                            //// Open the text file using a stream reader.
                            //using StreamReader reader = new(pathTonKho1);
                            //// Read the stream as a string.
                            //string text = reader.ReadToEnd();
                            //string[] infor = text.Split("##");
                            double soLuongConLai = soLuongCu - sl;
                            
                            // Mở FileStream với quyền ghi và cho phép chia sẻ
                            using (FileStream fs = new FileStream(pathTonKho1,
                                                                  FileMode.Open,
                                                                  FileAccess.Write,
                                                                  FileShare.ReadWrite))
                            using (StreamWriter writer = new StreamWriter(fs, Encoding.UTF8))
                            {
                                writer.WriteLine(soLuongConLai + "##" + donGiaValue.Text + "##" + khoLuuTruValue.Text + "##" + nccValue.Text + "##" + maNV + "##" + DateTime.Now.ToString() + "##" + inputGhiChu.Text);

                                if (soLuongConLai < soLuongToiThieu)
                                {
                                    //them vao bang ton kho toi thieu
                                    Huy_functions.insertFileInBangTonKhoToiThieu(maLK);
                                }

                                string fileName = "##" + maLK + "##" + inputSoLuong.Text + "##" + typeTonKhoToiThieu + "##" + maNV + ".cnm";
                                Huy_functions.insertToBangGiaoDich(fileName, inputGhiChu.Text);
                                lblMsg.Visible = true;
                                lblMsg.Text = "Đã xuất kho thành công cho mã vật liệu " + maLK;
                                clearScreen();
                                inputSoLuong.Text = "";
                                inputGhiChu.Text = "";

                                lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);
                            }
                            
                            
                            if (soLuongConLai == 0)
                            {
                                //delete khoi bang ton kho
                                Huy_functions.deleteFileInBangTonKho(maLK);
                            }
                            inputmaVL.Text = "";
                            
                            inputmaVL.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Mã vật liệu " + maLK + " không còn tồn kho");
                    }
                }
            }
        }

        private void inputSoLuong_ValueChanged(object sender, EventArgs e)
        {
            lblSoLuong.ForeColor = Color.Black;

            double sl = 0;
            if (inputSoLuong.Text.Length > 0)
            {
                sl = Convert.ToDouble(inputSoLuong.Text);
            }

            if (sl > soLuongCu)
            {
                lblSoLuong.ForeColor = Color.Red;
                MessageBox.Show("Không thể xuất quá số lượng tồn kho");
            }
            else
            {

            }
        }

        private void lblTonDuoiMucToiThieu_Click(object sender, EventArgs e)
        {
            TKToiThieu f = new TKToiThieu(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
    }
}
