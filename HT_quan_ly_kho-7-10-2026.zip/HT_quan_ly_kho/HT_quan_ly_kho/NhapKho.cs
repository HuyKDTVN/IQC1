﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HT_quan_ly_kho
{
    public partial class NhapKho : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public int soLuongTonKhoToiThieu;
        public string loai;
        public string maVL;

        public int typeNhapMoiInData = 1;

        public string soLuongCu;
        public string donGiaCu;
        public string khoLuutruCu;
        public string nccCu;
        public string ghiChuCu;
        public string maLK;
        public NhapKho(string maCodeNV, string tenNV, int phanQuyen, string loaiGiaoDich, string maVatLieu)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            loai = loaiGiaoDich;
            maVL = maVatLieu;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void clearScreen()
        {
            soLuongDangCo.Text = "";
            soLuongToiThieuValue.Text = "";
            tenLKValue.Text = "";
            ngayNhapkho.Text = "";
            nhomVatLieuValue.Text = "";
            nguoiNhapKhoValue.Text = "";
            maHangValue.Text = "";
            kyTuValue.Text = "";
            inputSoLuong.Text = "";
            ghiChu.Text = "";
        }
        private void setComboboxValue()
        {
            //lay thong tin ncc
            string pathThongTinNCC = Variable.pathOther + "ncc.cnm";
            string contentFileThongtinNCC = "";

            if (File.Exists(pathThongTinNCC))
            {
                contentFileThongtinNCC = Huy_functions.readFile(pathThongTinNCC);
                if (contentFileThongtinNCC.Contains("##"))
                {
                    string[] arrNcc = contentFileThongtinNCC.Split("##");
                    foreach (string ncc in arrNcc)
                    {
                        inputNhaCungCap.Items.Add(ncc);
                    }
                }
            }

            //lay thong tincac vi tri gia
            string pathThongTinviTriGia = Variable.pathOther + "vi-tri-gia.cnm";
            string contentFileThongtinViTri = "";

            if (File.Exists(pathThongTinviTriGia))
            {
                contentFileThongtinViTri = Huy_functions.readFile(pathThongTinviTriGia);
                if (contentFileThongtinViTri.Contains("##"))
                {
                    string[] arrVitri = contentFileThongtinViTri.Split("##");
                    foreach (string viTri in arrVitri)
                    {
                        inputKhoLuuTru.Items.Add(viTri);
                    }
                }
            }
        }
        private void NhapKho_Load(object sender, EventArgs e)
        {
            lblTonDuoiMucToiThieu.Location = new Point(
                lblTonDuoiMucToiThieu.Location.X,
                this.ClientSize.Height - lblTonDuoiMucToiThieu.Height - 15
            );
            clearScreen();
            setComboboxValue();
            inputMaLK.AutoCompleteMode = AutoCompleteMode.Suggest;
            inputMaLK.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection source = new AutoCompleteStringCollection();
            source.AddRange(Huy_functions.getAllFilesfolder(Variable.pathBangLK));
            inputMaLK.AutoCompleteCustomSource = source;

            if (loai == "nhap")
            {
                titleNhap.Text = "Nhập kho";
                btnNhap.Text = "Nhập kho";
                typeNhapMoiInData = 1;
            } 
            if(loai == "tainhap"){
                titleNhap.Text = "Tái nhập";
                btnNhap.Text = "Tái nhập";
                this.Text = "Tái nhập";
                typeNhapMoiInData = 3;
                inputDonGia.Enabled = false;
                inputKhoLuuTru.Enabled = false;
                inputNhaCungCap.Enabled = false;
            }
            if(loai == "sua")
            {
                this.Text = "Chỉnh sửa thông tin tồn kho";
                titleNhap.Text = "Chỉnh sửa";
                btnNhap.Text = "Chỉnh sửa";
                //typeNhapMoiInData = 3;
                inputMaLK.Text = maVL;
                inputMaLK.ReadOnly = true;
                this.ActiveControl = inputSoLuong;
                //submitInputMaVL();
                
                donGiaCu = inputDonGia.Text;
                khoLuutruCu = inputKhoLuuTru.SelectedItem + "";
                nccCu = inputNhaCungCap.SelectedItem + "";
                ghiChuCu = ghiChu.Text.Trim();
                inputLyDo.Visible = true;
                lblLyDo.Visible = true;
            }
            
            btnThemVL.Visible = false;
            helloText.Text = "Xin chào " + hoTen;
            //MessageBox.Show(phanQuyenInt + "");
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);   
        }
        private void submitInputMaVL()
        {
            lblMsg.Visible = false;
            soLuongDangCo.Visible = true;
            maLK = inputMaLK.Text.ToUpper();
            if (maLK.Contains("##"))
            {
                string[] arrBarCode = maLK.Split("##");
                maLK = arrBarCode[0];
                if (arrBarCode.Length > 2)
                {
                    inputSoLuong.Text = arrBarCode[1];
                    ghiChu.Text = arrBarCode[2];
                }
            }
            if (maLK.Length >= 9)
            {
                //lay thong tin tu bang LK
                string path = Variable.pathBangLK + maLK + ".cnm";
                if (File.Exists(path))
                {
                    btnThemVL.Visible = false;
                    // Open the text file using a stream reader.
                    using StreamReader reader = new(path);

                    // Read the stream as a string.
                    string text = reader.ReadToEnd();
                    string[] infor = text.Split("##");
                    tenLKValue.Text = infor[0];

                    //string nhomVL = "Chính";
                    //if (infor[2] == "P")
                    //{
                    //    nhomVL = "Phụ";
                    //}
                    //if (infor[2] == "TB")
                    //{
                    //    nhomVL = "Thiết bị";
                    //}
                    nhomVatLieuValue.Text = infor[2];
                    string donVi = infor[1];

                    string soLuongToiThieuString = infor[3];
                    if(soLuongToiThieuString.Length > 0)
                    {
                        soLuongTonKhoToiThieu = Int32.Parse(soLuongToiThieuString);
                    }
                    else
                    {
                        soLuongTonKhoToiThieu = 0;
                    }                       
                    soLuongToiThieuValue.Text = soLuongTonKhoToiThieu + " " + donVi;
                    maHangValue.Text = infor[7];
                    kyTuValue.Text = infor[8];

                    //kiem tra con ton kho hay khong
                    string pathTonKho1 = Variable.pathTonKho + maLK + ".cnm";
                    if (File.Exists(pathTonKho1))
                    {
                        // Open the text file using a stream reader.
                        using StreamReader reader1 = new(pathTonKho1);

                        // Read the stream as a string.
                        string text1 = reader1.ReadToEnd();
                        string[] infor1 = text1.Split("##");
                        soLuongCu = infor1[0];
                        soLuongDangCo.Text = "/" + soLuongCu + " " + donVi;
                        if(loai == "sua" || loai == "tainhap")
                        {
                            
                            inputDonGia.Text = infor1[1];
                            int index = inputKhoLuuTru.FindStringExact(infor1[2]);
                            if (index < 0)
                            {
                                inputKhoLuuTru.Items.Add(infor1[2]);
                            }
                            inputKhoLuuTru.SelectedItem = infor1[2];

                            int index2 = inputNhaCungCap.FindStringExact(infor1[3]);
                            if (index2 < 0)
                            {
                                inputNhaCungCap.Items.Add(infor1[3]);
                            }
                            inputNhaCungCap.SelectedItem = infor1[3];
                        }

                        if (loai == "sua")
                        {
                            inputSoLuong.Text = soLuongCu;
                           
                        }


                    }
                }
                else
                {
                    btnThemVL.Visible = true;
                    tenLKValue.Text = "";
                    nhomVatLieuValue.Text = "";
                    soLuongDangCo.Text = "";
                    maHangValue.Text = "";
                    kyTuValue.Text = "";
                    inputKhoLuuTru.SelectedItem = null;
                    inputNhaCungCap.SelectedItem = null;
                    soLuongToiThieuValue.Text = "";
                    inputDonGia.Text = "";
                   
                }
            }
        }
       
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (inputMaLK.Text.Length > 0)
            {
                clearScreen();
          
            }
            submitInputMaVL();
        }

        private void lblTonDuoiMucToiThieu_Click(object sender, EventArgs e)
        {
            TKToiThieu f = new TKToiThieu(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(DateTime.Now.ToString());
            lblMaVL.ForeColor = Color.Black;
            lblSoLuong.ForeColor = Color.Black;
            lblDongia.ForeColor = Color.Black;
            lblKho.ForeColor = Color.Black;
            lblNCC.ForeColor = Color.Black;
            lblLyDo.ForeColor = Color.Black;

            bool isError = false;
            bool hasSharp = false;
            //validate
            if (Huy_functions.hasSharpChar(maLK))
            {
                lblMaVL.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(ghiChu.Text))
            {
                lblGhiChu.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(inputLyDo.Text))
            {
                lblLyDo.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            
            if (hasSharp)
            {
                MessageBox.Show("Dữ liệu nhập vào không được chứa ký tự ##");
            }

            //check empty
            if (inputMaLK.Text == "")
            {
                isError = true;
                lblMaVL.ForeColor = Color.Red;
            }

            if(inputSoLuong.Text.Length > 0)
            {
                if (Convert.ToDouble(inputSoLuong.Text) <= 0)
                {
                    isError = true;
                    lblSoLuong.ForeColor = Color.Red;
                }
            }
            else
            {
                isError = true;
                lblSoLuong.ForeColor = Color.Red;
            }
            
            if (inputDonGia.Text == "0" || inputDonGia.Text == "")
            {
                isError = true;
                lblDongia.ForeColor = Color.Red;
            }
            if (inputKhoLuuTru.Text == "")
            {
                isError = true;
                lblKho.ForeColor = Color.Red;
            }
            if (inputNhaCungCap.Text == "")
            {
                isError = true;
                lblNCC.ForeColor = Color.Red;
            }
            if (ghiChu.Text.Trim() == "")
            {
                isError = true;
                lblGhiChu.ForeColor = Color.Red;
            }
            if (inputLyDo.Text == "" && loai == "sua")
            {
                isError = true;
                lblLyDo.ForeColor = Color.Red;
            }

            if (!isError)
            {
                if (tenLKValue.Text == "")
                {
                    //kiem tra xem da duoc them linh kien truoc do hay chua
                    MessageBox.Show("Hãy thêm linh kiện mới trước khi nhập kho");
                }
                else
                {
                    //insert to bang nhap kho
                    //tim xem bang ton kho co ma nay chua neu chua co thi them moi neu co roi thì cộng số lượng
                    string pathTonKho1 = Variable.pathTonKho + maLK + ".cnm";
                    double soLuong = Convert.ToDouble(inputSoLuong.Text);

                    if (File.Exists(pathTonKho1))
                    {
                        // Open the text file using a stream reader.
                        using StreamReader reader = new(pathTonKho1);

                        // Read the stream as a string.
                        string text = reader.ReadToEnd();
                        string[] infor = text.Split("##");
                        soLuong = Convert.ToDouble(infor[0]) + Convert.ToDouble(inputSoLuong.Text);

                    }

                    if(loai == "sua")
                    {
                        string lyDo = inputLyDo.Text.Trim();
                        //cập nhật vào bảng nhật ký
                        string tenFileNhatKy = DateTime.Now.ToString("yyyyMMdd_HHmmss") + "##" + maNV + "##" + 2 + "##" + maVL;
                        string pathNhatKy = tenFileNhatKy;
                        string contentNhatKy = lyDo + "##" + Dns.GetHostName();

                        if (soLuongCu != inputSoLuong.Text)
                        {
                            //MessageBox.Show(pathNhatKy + "##tenVL.cnm");
                            //MessageBox.Show(tenVLCu + "##" + tenLK + "##" + contentNhatKy);
                            Huy_functions.insertToBangNhatKy(pathNhatKy + "##soluong.cnm", soLuongCu + "##" + inputSoLuong.Text + "##" + contentNhatKy);
                        }
                        if (donGiaCu != inputDonGia.Text)
                        {
                            //MessageBox.Show(pathNhatKy + "##mahang.cnm");
                            //MessageBox.Show(maHangCu + "##" + maHang + "##" + contentNhatKy);
                            Huy_functions.insertToBangNhatKy(pathNhatKy + "##dongia.cnm", donGiaCu + "##" + inputDonGia.Text + "##" + contentNhatKy);
                        }
                        if (khoLuutruCu != inputKhoLuuTru.SelectedItem)
                        {
                            //MessageBox.Show(pathNhatKy + "##donvi.cnm");
                            //MessageBox.Show(donViCu + "##" + donVi + "##" + contentNhatKy);
                            Huy_functions.insertToBangNhatKy(pathNhatKy + "##kholuutru.cnm", khoLuutruCu + "##" + inputKhoLuuTru.SelectedItem + "##" + contentNhatKy);
                        }
                        if (nccCu != inputNhaCungCap.SelectedItem)
                        {
                            //MessageBox.Show(pathNhatKy + "##tonkhotoithieu.cnm");
                            //MessageBox.Show(tonKhoToiThieuCu + "##" + tonKhoToiThieu + "##" + contentNhatKy);
                            Huy_functions.insertToBangNhatKy(pathNhatKy + "##ncc.cnm", nccCu + "##" + inputNhaCungCap.SelectedItem + "##" + contentNhatKy);
                        }
                        if (ghiChuCu != ghiChu.Text.Trim())
                        {
                            //MessageBox.Show(pathNhatKy + "##ghichu.cnm");
                            //MessageBox.Show(ghiChuCu + "##" + ghiChu + "##" + contentNhatKy);
                            Huy_functions.insertToBangNhatKy(pathNhatKy + "##ghichu.cnm", ghiChuCu + "##" + ghiChu.Text.Trim() + "##" + contentNhatKy);
                        }

                        Huy_functions.createFile(pathTonKho1, inputSoLuong.Text + "##" + inputDonGia.Text + "##" + inputKhoLuuTru.Text + "##" + inputNhaCungCap.Text + "##" + maNV + "##" + DateTime.Now.ToString() + "##" + ghiChu.Text);

                        //MessageBox.Show(inputSoLuong.Text);
                        //MessageBox.Show(soLuongTonKhoToiThieu + ""); 
                        if (Convert.ToDouble(inputSoLuong.Text) < Convert.ToDouble(soLuongTonKhoToiThieu))
                        {
                            Huy_functions.insertFileInBangTonKhoToiThieu(maLK);
                        }
                        else
                        {
                            Huy_functions.deleteFileInBangTonKhoToiThieu(maLK);
                        }
                        
                        lblMsg.Visible = false;
                        MessageBox.Show("Đã sửa thông tin tồn kho thành công cho mã vật liệu: " + maVL);
                        TraCuu f = new TraCuu(maNV, hoTen, phanQuyenInt, maVL);
                        f.FormClosed += (s, args) => this.Close();
                        f.Show();
                        this.Hide();
                    }
                    else
                    {
                        //nhap kho hoac tai nhap
                        Huy_functions.createFile(pathTonKho1, soLuong + "##" + inputDonGia.Text + "##" + inputKhoLuuTru.Text + "##" + inputNhaCungCap.Text + "##" + maNV + "##" + DateTime.Now.ToString() + "##" + ghiChu.Text);

                        
                        string fileName = "##" + maLK + "##" + inputSoLuong.Text + "##" + typeNhapMoiInData + "##" + maNV + ".cnm";
                        Huy_functions.insertToBangGiaoDich(fileName, ghiChu.Text);
                        if (soLuong >= soLuongTonKhoToiThieu)
                        {
                            //check if co thi delete trong ton kho toi thieu
                            Huy_functions.deleteFileInBangTonKhoToiThieu(maLK);
                        }
                        lblMsg.Text = "Đã nhập kho thành công cho mã vật liệu " + maLK;

                    }
                    inputMaLK.Text = "";
                    inputSoLuong.Text = "0";
                    inputDonGia.Text = "0";
                    inputKhoLuuTru.SelectedItem = null;
                    inputNhaCungCap.SelectedItem = null;
                    ghiChu.Text = "";

                    tenLKValue.Text = "";
                    soLuongToiThieuValue.Text = "";
                    nhomVatLieuValue.Text = "";
                    kyTuValue.Text = "";
                    maHangValue.Text = "";
                    lblMsg.Visible = true;
                    btnThemVL.Visible = false;
                    soLuongDangCo.Visible = false;
                    inputMaLK.Focus();
                    lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);
                }
            }
        }

        private void btnThemVL_Click(object sender, EventArgs e)
        {
            themVL f = new themVL(maNV, hoTen, phanQuyenInt, maLK, false);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
    }
}
