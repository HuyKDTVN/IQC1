﻿namespace HT_quan_ly_kho
{
    partial class XuatKho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(XuatKho));
            pictureBox1 = new PictureBox();
            button2 = new Button();
            helloText = new Label();
            titleXuatKho = new Label();
            btnXuatKho = new Button();
            label20 = new Label();
            label21 = new Label();
            inputGhiChu = new TextBox();
            soLuongCuValue = new Label();
            nhomVLValue = new Label();
            label13 = new Label();
            label10 = new Label();
            label11 = new Label();
            tenVLValue = new Label();
            label6 = new Label();
            inputmaVL = new TextBox();
            donGiaValue = new Label();
            khoLuuTruValue = new Label();
            nccValue = new Label();
            lblTonDuoiMucToiThieu = new Label();
            soLuongToiThieuValue = new Label();
            lblSoLuongToiThieu = new Label();
            inputSoLuong = new NumericUpDown();
            lblNCC = new Label();
            lblGhiChu = new Label();
            lblKho = new Label();
            lblDongia = new Label();
            lblSoLuong = new Label();
            lblMaVL = new Label();
            label19 = new Label();
            label18 = new Label();
            lblMsg = new Label();
            kyTuValue = new Label();
            lblKyTu = new Label();
            maHangValue = new Label();
            lblMaHang = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)inputSoLuong).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(8, 7);
            pictureBox1.Margin = new Padding(2, 2, 2, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(45, 35);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 49;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(709, 18);
            button2.Margin = new Padding(2, 2, 2, 2);
            button2.Name = "button2";
            button2.Size = new Size(113, 29);
            button2.TabIndex = 4;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(64, 18);
            helloText.Margin = new Padding(2, 0, 2, 0);
            helloText.Name = "helloText";
            helloText.Size = new Size(97, 20);
            helloText.TabIndex = 32;
            helloText.Text = "Xin chào Đức";
            // 
            // titleXuatKho
            // 
            titleXuatKho.AutoSize = true;
            titleXuatKho.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleXuatKho.ForeColor = Color.FromArgb(64, 64, 64);
            titleXuatKho.Location = new Point(328, 28);
            titleXuatKho.Margin = new Padding(2, 0, 2, 0);
            titleXuatKho.Name = "titleXuatKho";
            titleXuatKho.Size = new Size(115, 29);
            titleXuatKho.TabIndex = 31;
            titleXuatKho.Text = "Xuất kho";
            // 
            // btnXuatKho
            // 
            btnXuatKho.BackColor = Color.Gold;
            btnXuatKho.Cursor = Cursors.Hand;
            btnXuatKho.FlatStyle = FlatStyle.Flat;
            btnXuatKho.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXuatKho.Location = new Point(301, 315);
            btnXuatKho.Margin = new Padding(2, 2, 2, 2);
            btnXuatKho.Name = "btnXuatKho";
            btnXuatKho.Size = new Size(148, 41);
            btnXuatKho.TabIndex = 3;
            btnXuatKho.Text = "Xuất kho";
            btnXuatKho.UseVisualStyleBackColor = false;
            btnXuatKho.Click += button5_Click;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            label20.Location = new Point(709, 362);
            label20.Margin = new Padding(2, 0, 2, 0);
            label20.Name = "label20";
            label20.Size = new Size(37, 20);
            label20.TabIndex = 138;
            label20.Text = "Đức";
            label20.Visible = false;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 11F);
            label21.Location = new Point(587, 362);
            label21.Margin = new Padding(2, 0, 2, 0);
            label21.Name = "label21";
            label21.Size = new Size(114, 20);
            label21.TabIndex = 137;
            label21.Text = "Người xuất kho:";
            label21.Visible = false;
            // 
            // inputGhiChu
            // 
            inputGhiChu.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputGhiChu.Location = new Point(155, 188);
            inputGhiChu.Margin = new Padding(2, 2, 2, 2);
            inputGhiChu.Name = "inputGhiChu";
            inputGhiChu.Size = new Size(156, 27);
            inputGhiChu.TabIndex = 3;
            // 
            // soLuongCuValue
            // 
            soLuongCuValue.AutoSize = true;
            soLuongCuValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            soLuongCuValue.Location = new Point(318, 116);
            soLuongCuValue.Margin = new Padding(2, 0, 2, 0);
            soLuongCuValue.Name = "soLuongCuValue";
            soLuongCuValue.Size = new Size(83, 20);
            soLuongCuValue.TabIndex = 126;
            soLuongCuValue.Text = "/ 1000 pcs";
            // 
            // nhomVLValue
            // 
            nhomVLValue.AutoSize = true;
            nhomVLValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            nhomVLValue.Location = new Point(579, 155);
            nhomVLValue.Margin = new Padding(2, 0, 2, 0);
            nhomVLValue.Name = "nhomVLValue";
            nhomVLValue.Size = new Size(104, 20);
            nhomVLValue.TabIndex = 125;
            nhomVLValue.Text = "Vật liệu chính";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 11F);
            label13.Location = new Point(457, 155);
            label13.Margin = new Padding(2, 0, 2, 0);
            label13.Name = "label13";
            label13.Size = new Size(105, 20);
            label13.TabIndex = 124;
            label13.Text = "Nhóm vật liệu:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            label10.Location = new Point(709, 335);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(86, 20);
            label10.TabIndex = 123;
            label10.Text = "12/7/2025";
            label10.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11F);
            label11.Location = new Point(587, 335);
            label11.Margin = new Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new Size(107, 20);
            label11.TabIndex = 122;
            label11.Text = "Ngày xuất kho:";
            label11.Visible = false;
            // 
            // tenVLValue
            // 
            tenVLValue.AutoSize = true;
            tenVLValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            tenVLValue.Location = new Point(579, 77);
            tenVLValue.Margin = new Padding(2, 0, 2, 0);
            tenVLValue.Name = "tenVLValue";
            tenVLValue.Size = new Size(39, 20);
            tenVLValue.TabIndex = 121;
            tenVLValue.Text = "ABC";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(457, 77);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(87, 20);
            label6.TabIndex = 120;
            label6.Text = "Tên vật liệu:";
            // 
            // inputmaVL
            // 
            inputmaVL.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputmaVL.Location = new Point(155, 76);
            inputmaVL.Margin = new Padding(2, 2, 2, 2);
            inputmaVL.Name = "inputmaVL";
            inputmaVL.Size = new Size(156, 27);
            inputmaVL.TabIndex = 1;
            inputmaVL.TextChanged += inputmaVL_TextChanged;
            // 
            // donGiaValue
            // 
            donGiaValue.AutoSize = true;
            donGiaValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            donGiaValue.Location = new Point(157, 156);
            donGiaValue.Margin = new Padding(2, 0, 2, 0);
            donGiaValue.Name = "donGiaValue";
            donGiaValue.Size = new Size(104, 20);
            donGiaValue.TabIndex = 139;
            donGiaValue.Text = "350.000 VND";
            // 
            // khoLuuTruValue
            // 
            khoLuuTruValue.AutoSize = true;
            khoLuuTruValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            khoLuuTruValue.Location = new Point(587, 190);
            khoLuuTruValue.Margin = new Padding(2, 0, 2, 0);
            khoLuuTruValue.Name = "khoLuuTruValue";
            khoLuuTruValue.Size = new Size(74, 20);
            khoLuuTruValue.TabIndex = 140;
            khoLuuTruValue.Text = "Kho gỗ A";
            // 
            // nccValue
            // 
            nccValue.AutoSize = true;
            nccValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            nccValue.Location = new Point(155, 229);
            nccValue.Margin = new Padding(2, 0, 2, 0);
            nccValue.Name = "nccValue";
            nccValue.Size = new Size(108, 20);
            nccValue.TabIndex = 141;
            nccValue.Text = "Cty Minh Phát";
            // 
            // lblTonDuoiMucToiThieu
            // 
            lblTonDuoiMucToiThieu.AutoSize = true;
            lblTonDuoiMucToiThieu.Cursor = Cursors.Hand;
            lblTonDuoiMucToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTonDuoiMucToiThieu.ForeColor = Color.Brown;
            lblTonDuoiMucToiThieu.Location = new Point(505, 447);
            lblTonDuoiMucToiThieu.Margin = new Padding(2, 0, 2, 0);
            lblTonDuoiMucToiThieu.Name = "lblTonDuoiMucToiThieu";
            lblTonDuoiMucToiThieu.Size = new Size(302, 20);
            lblTonDuoiMucToiThieu.TabIndex = 142;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: 10";
            lblTonDuoiMucToiThieu.Click += lblTonDuoiMucToiThieu_Click;
            // 
            // soLuongToiThieuValue
            // 
            soLuongToiThieuValue.AutoSize = true;
            soLuongToiThieuValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            soLuongToiThieuValue.Location = new Point(579, 117);
            soLuongToiThieuValue.Margin = new Padding(2, 0, 2, 0);
            soLuongToiThieuValue.Name = "soLuongToiThieuValue";
            soLuongToiThieuValue.Size = new Size(39, 20);
            soLuongToiThieuValue.TabIndex = 144;
            soLuongToiThieuValue.Text = "ABC";
            // 
            // lblSoLuongToiThieu
            // 
            lblSoLuongToiThieu.AutoSize = true;
            lblSoLuongToiThieu.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSoLuongToiThieu.Location = new Point(457, 117);
            lblSoLuongToiThieu.Margin = new Padding(2, 0, 2, 0);
            lblSoLuongToiThieu.Name = "lblSoLuongToiThieu";
            lblSoLuongToiThieu.Size = new Size(117, 19);
            lblSoLuongToiThieu.TabIndex = 143;
            lblSoLuongToiThieu.Text = "Tồn kho tối thiểu:";
            // 
            // inputSoLuong
            // 
            inputSoLuong.DecimalPlaces = 1;
            inputSoLuong.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inputSoLuong.Location = new Point(155, 115);
            inputSoLuong.Margin = new Padding(2, 2, 2, 2);
            inputSoLuong.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            inputSoLuong.Name = "inputSoLuong";
            inputSoLuong.Size = new Size(157, 27);
            inputSoLuong.TabIndex = 2;
            inputSoLuong.ValueChanged += inputSoLuong_ValueChanged;
            // 
            // lblNCC
            // 
            lblNCC.AutoSize = true;
            lblNCC.Font = new Font("Segoe UI", 11F);
            lblNCC.Location = new Point(23, 229);
            lblNCC.Margin = new Padding(2, 0, 2, 0);
            lblNCC.Name = "lblNCC";
            lblNCC.Size = new Size(103, 20);
            lblNCC.TabIndex = 151;
            lblNCC.Text = "Nhà cung cấp:";
            // 
            // lblGhiChu
            // 
            lblGhiChu.AutoSize = true;
            lblGhiChu.Font = new Font("Segoe UI", 11F);
            lblGhiChu.Location = new Point(23, 193);
            lblGhiChu.Margin = new Padding(2, 0, 2, 0);
            lblGhiChu.Name = "lblGhiChu";
            lblGhiChu.Size = new Size(71, 20);
            lblGhiChu.TabIndex = 150;
            lblGhiChu.Text = "Ghi chú *:";
            // 
            // lblKho
            // 
            lblKho.AutoSize = true;
            lblKho.Font = new Font("Segoe UI", 11F);
            lblKho.Location = new Point(455, 190);
            lblKho.Margin = new Padding(2, 0, 2, 0);
            lblKho.Name = "lblKho";
            lblKho.Size = new Size(86, 20);
            lblKho.TabIndex = 149;
            lblKho.Text = "Kho lưu trữ:";
            // 
            // lblDongia
            // 
            lblDongia.AutoSize = true;
            lblDongia.Font = new Font("Segoe UI", 11F);
            lblDongia.Location = new Point(23, 160);
            lblDongia.Margin = new Padding(2, 0, 2, 0);
            lblDongia.Name = "lblDongia";
            lblDongia.Size = new Size(65, 20);
            lblDongia.TabIndex = 148;
            lblDongia.Text = "Đơn giá:";
            // 
            // lblSoLuong
            // 
            lblSoLuong.AutoSize = true;
            lblSoLuong.Font = new Font("Segoe UI", 11F);
            lblSoLuong.Location = new Point(23, 119);
            lblSoLuong.Margin = new Padding(2, 0, 2, 0);
            lblSoLuong.Name = "lblSoLuong";
            lblSoLuong.Size = new Size(82, 20);
            lblSoLuong.TabIndex = 147;
            lblSoLuong.Text = "Số lượng *:";
            // 
            // lblMaVL
            // 
            lblMaVL.AutoSize = true;
            lblMaVL.Font = new Font("Segoe UI", 11F);
            lblMaVL.Location = new Point(23, 80);
            lblMaVL.Margin = new Padding(2, 0, 2, 0);
            lblMaVL.Name = "lblMaVL";
            lblMaVL.Size = new Size(95, 20);
            lblMaVL.TabIndex = 146;
            lblMaVL.Text = "Mã vật liệu *:";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 11F);
            label19.Location = new Point(587, 305);
            label19.Margin = new Padding(2, 0, 2, 0);
            label19.Name = "label19";
            label19.Size = new Size(92, 20);
            label19.TabIndex = 135;
            label19.Text = "Loại vật liệu:";
            label19.Visible = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            label18.Location = new Point(709, 305);
            label18.Margin = new Padding(2, 0, 2, 0);
            label18.Name = "label18";
            label18.Size = new Size(119, 20);
            label18.TabIndex = 136;
            label18.Text = "Gỗ công nghiệp";
            label18.Visible = false;
            // 
            // lblMsg
            // 
            lblMsg.AutoSize = true;
            lblMsg.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMsg.ForeColor = Color.CadetBlue;
            lblMsg.Location = new Point(130, 377);
            lblMsg.Margin = new Padding(2, 0, 2, 0);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(412, 25);
            lblMsg.TabIndex = 156;
            lblMsg.Text = "Đã nhập xuất kho thành công cho mã vật liệu: ";
            lblMsg.Visible = false;
            // 
            // kyTuValue
            // 
            kyTuValue.AutoSize = true;
            kyTuValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            kyTuValue.Location = new Point(578, 265);
            kyTuValue.Margin = new Padding(2, 0, 2, 0);
            kyTuValue.Name = "kyTuValue";
            kyTuValue.Size = new Size(104, 20);
            kyTuValue.TabIndex = 163;
            kyTuValue.Text = "Vật liệu chính";
            // 
            // lblKyTu
            // 
            lblKyTu.AutoSize = true;
            lblKyTu.Font = new Font("Segoe UI", 11F);
            lblKyTu.Location = new Point(456, 265);
            lblKyTu.Margin = new Padding(2, 0, 2, 0);
            lblKyTu.Name = "lblKyTu";
            lblKyTu.Size = new Size(45, 20);
            lblKyTu.TabIndex = 162;
            lblKyTu.Text = "Ký tự:";
            // 
            // maHangValue
            // 
            maHangValue.AutoSize = true;
            maHangValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            maHangValue.Location = new Point(578, 230);
            maHangValue.Margin = new Padding(2, 0, 2, 0);
            maHangValue.Name = "maHangValue";
            maHangValue.Size = new Size(104, 20);
            maHangValue.TabIndex = 161;
            maHangValue.Text = "Vật liệu chính";
            // 
            // lblMaHang
            // 
            lblMaHang.AutoSize = true;
            lblMaHang.Font = new Font("Segoe UI", 11F);
            lblMaHang.Location = new Point(456, 230);
            lblMaHang.Margin = new Padding(2, 0, 2, 0);
            lblMaHang.Name = "lblMaHang";
            lblMaHang.Size = new Size(70, 20);
            lblMaHang.TabIndex = 160;
            lblMaHang.Text = "Mã hàng:";
            // 
            // XuatKho
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(832, 561);
            Controls.Add(kyTuValue);
            Controls.Add(lblKyTu);
            Controls.Add(maHangValue);
            Controls.Add(lblMaHang);
            Controls.Add(lblMsg);
            Controls.Add(lblNCC);
            Controls.Add(lblGhiChu);
            Controls.Add(lblKho);
            Controls.Add(lblDongia);
            Controls.Add(lblSoLuong);
            Controls.Add(lblMaVL);
            Controls.Add(inputSoLuong);
            Controls.Add(soLuongToiThieuValue);
            Controls.Add(lblSoLuongToiThieu);
            Controls.Add(lblTonDuoiMucToiThieu);
            Controls.Add(nccValue);
            Controls.Add(khoLuuTruValue);
            Controls.Add(donGiaValue);
            Controls.Add(label20);
            Controls.Add(label21);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(inputGhiChu);
            Controls.Add(soLuongCuValue);
            Controls.Add(nhomVLValue);
            Controls.Add(label13);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(tenVLValue);
            Controls.Add(label6);
            Controls.Add(inputmaVL);
            Controls.Add(btnXuatKho);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(helloText);
            Controls.Add(titleXuatKho);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(2, 2, 2, 2);
            MaximizeBox = false;
            Name = "XuatKho";
            Text = "Xuất kho";
            Load += XuatKho_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)inputSoLuong).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button2;
        private Label helloText;
        private Label titleXuatKho;
        private Button btnXuatKho;
        private Label label20;
        private Label label21;
        private TextBox inputGhiChu;
        private Label soLuongCuValue;
        private Label nhomVLValue;
        private Label label13;
        private Label label10;
        private Label label11;
        private Label tenVLValue;
        private Label label6;
        private TextBox inputmaVL;
        private Label donGiaValue;
        private Label khoLuuTruValue;
        private Label nccValue;
        private Label lblTonDuoiMucToiThieu;
        private Label soLuongToiThieuValue;
        private Label lblSoLuongToiThieu;
        private NumericUpDown inputSoLuong;
        private Label lblNCC;
        private Label lblGhiChu;
        private Label lblKho;
        private Label lblDongia;
        private Label lblSoLuong;
        private Label lblMaVL;
        private Label label19;
        private Label label18;
        private Label lblMsg;
        private Label kyTuValue;
        private Label lblKyTu;
        private Label maHangValue;
        private Label lblMaHang;
    }
}