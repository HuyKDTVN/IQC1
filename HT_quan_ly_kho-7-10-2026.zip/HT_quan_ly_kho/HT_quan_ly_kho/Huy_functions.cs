﻿using Microsoft.VisualBasic;
using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HT_quan_ly_kho
{
    internal class Huy_functions
    {
        public static bool checkTry(DateTime ngayBatDau, int soNgayDungThu)
        {
            bool result = false;
            if(Variable.isTry)
            {
                DateTime today = DateTime.Today;
                TimeSpan difference = today - ngayBatDau;
                int daysDifference = difference.Days;
                if (daysDifference > soNgayDungThu)
                {
                    result = true;
                }
                
            }
            return result;
        }
        public static string checkNewVersion()
        {
            string result = "";

            if (File.Exists(Variable.fileVersion))
            {
                string content = readFile(Variable.fileVersion);


                if (content != Variable.version)
                {
                    result = content;
                }
            }
            return result;
        }
        public static string[] getAllFilesfolder(string path)
        {
            string[] filePaths = Directory.GetFiles(path, "*.cnm",
                                         SearchOption.TopDirectoryOnly);
            string[] files = new string[filePaths.Length];
            for (int i = 0; i < filePaths.Length; i++)
            {
                string fileName = Path.GetFileName(filePaths[i]).Replace(".cnm", "");
                files[i] = fileName;
            }
            return files;
        }
        public static bool hasSharpChar(string input)
        {
            bool result = false;
            //MessageBox.Show(input);
            if(input.Contains("##")) {
                //MessageBox.Show("co ##");
                result = true;
            }
            return result;
        }
        public static string lay3ChuSo(string s)
        {
            if(s.Length == 1)
            {
                s = "00" + s;
            }

            if(s.Length == 2)
            {
                s = "0" + s;
            }
            return s;
        }
        public static string readFile(string path)
        {
            string result = "";
            if (File.Exists(path))
            {
                
                using StreamReader reader = new(path);
                result = reader.ReadToEnd(); 
            }
            return result;
        }
        public static void createFile(string path, string content)
        {
            using (StreamWriter sw = File.CreateText(path))
            {
                sw.WriteLine(content);
            }
        }
        public static Int32 getFileInFolder(string path)
        {
            return Directory.GetFiles(path, "*.cnm").Length;
        }
       public static bool IsValidAlphaNum(string input)
        {
            // Regex ^[0-9a-zA-Z]+$ nghĩa là:
            // từ đầu đến cuối chuỗi chỉ chứa các ký tự 0-9, a-z, A-Z
            return Regex.IsMatch(input, @"^[0-9\-a-zA-Z]+$");
        }
        public static bool IsValidAlpha(string input)
        {
            // ^[a-zA-Z]+$ nghĩa là:
            // Từ đầu đến cuối chuỗi chỉ chứa chữ cái (viết thường hoặc in hoa)
            return Regex.IsMatch(input, @"^[a-zA-Z]+$");
        }
        public static bool IsValidNum(string input)
        {
            // Regex ^[0-9a-zA-Z]+$ nghĩa là:
            // từ đầu đến cuối chuỗi chỉ chứa các ký tự 0-9, a-z, A-Z
            return Regex.IsMatch(input, @"^[0-9]+$");
        }

        public static void deleteFileInBangTonKhoToiThieu(string fileName)
        {
            string path = Variable.pathTonKhoToiThieu + fileName + ".cnm";
            if(File.Exists(path))
            {
                File.Delete(path);
            }
            
        }
        public static void deleteFileInBangTonKho(string fileName)
        {
            string path = Variable.pathTonKho + fileName + ".cnm";
            if (File.Exists(path))
            {
                File.Delete(path);
            }

        }
        public static void insertFileInBangTonKhoToiThieu(string fileName)
        {
            string path = Variable.pathTonKhoToiThieu + fileName + ".cnm";
            using (StreamWriter sw = File.CreateText(path))
            {
                sw.WriteLine("");
            }

        }

        public static void insertToBangGiaoDich(string fileName, string ghiChu)
        {
            
            string path = Variable.pathGiaDich + DateTime.Now.Year;
            if(!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string myMonth = DateTime.Now.Month + "";
            if (myMonth.Length == 1)
            {
                myMonth = "0" + myMonth;
            }
            path = path + "\\" + myMonth;

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string myDay = DateTime.Now.Day + "";
            if (myDay.Length == 1)
            {
                myDay = "0" + myDay;
            }
            path = path + "\\" + myDay;
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string maGiaoDich = DateTime.Now.Year + myMonth + myDay + ( Directory.GetFiles(path, "*.cnm").Length + 1);

            using (StreamWriter sw = File.CreateText(path + "\\" + maGiaoDich + fileName))
            {
                sw.WriteLine(ghiChu);
            }
        }

        public static void insertToBangNhatKy(string fileName, string ghiChu)
        {

            string path = Variable.pathNhatKy + DateTime.Now.Year;
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string myMonth = DateTime.Now.Month + "";
            if (myMonth.Length == 1)
            {
                myMonth = "0" + myMonth;
            }
            path = path + "\\" + myMonth;

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string myDay = DateTime.Now.Day + "";
            if (myDay.Length == 1)
            {
                myDay = "0" + myDay;
            }
            path = path + "\\" + myDay;
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
           
            using (StreamWriter sw = File.CreateText(path + "\\" + fileName))
            {
                sw.WriteLine(ghiChu);
            }
        }
    }
}
