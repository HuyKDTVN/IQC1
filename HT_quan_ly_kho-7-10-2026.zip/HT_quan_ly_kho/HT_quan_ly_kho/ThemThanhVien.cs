﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace HT_quan_ly_kho
{
    public partial class ThemThanhVien : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVatLieu;
        public string thanhVienCanChinhSua;
        public string maLK;
        public ThemThanhVien(string maCodeNV, string tenNV, int phanQuyen, string maVL, string thanhVienCanChinhSua)
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVatLieu = maVL;
            this.Resize += TraCuu_Resize;
            this.thanhVienCanChinhSua = thanhVienCanChinhSua;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {

        }

        private void ThemThanhVien_Load(object sender, EventArgs e)
        {
            if(thanhVienCanChinhSua == "")
            {
                lblTitle.Text = "Thêm thành viên";
            }
            inputPhanQuyen.Items.Add("Chỉ xem");
            inputPhanQuyen.Items.Add("Nhập xuất kho");
            inputPhanQuyen.Items.Add("Toàn quyền");
            if(thanhVienCanChinhSua != "")
            {
                string p = Variable.pathThanhVien + thanhVienCanChinhSua + ".cnm";
                // Open the text file using a stream reader.
                using StreamReader reader = new(p);

                // Read the stream as a string.
                string text = reader.ReadToEnd();
                string[] infor = text.Split("##");
                inputTenDN.Text = thanhVienCanChinhSua;
                inputHoTen.Text = infor[2];
                inputPass.Text = infor[0];
                inputPhanQuyen.SelectedIndex = int.Parse(infor[1]) - 1;
            }
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            ThanhVien f = new ThanhVien(maNV, hoTen, phanQuyenInt, "");
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void btnNhap_Click(object sender, EventArgs e)
        {
            //validate 
            lblTenDN.ForeColor = Color.Black;
            lblHoTen.ForeColor = Color.Black;
            lblPass.ForeColor = Color.Black;
            lblPhanQuyen.ForeColor = Color.Black;
            
            string tenDN = inputTenDN.Text;
            string hoTen = inputHoTen.Text;
            string pass = inputPass.Text;
            double phanQuyen = inputPhanQuyen.SelectedIndex;

            bool isError = false;
            bool hasSharp = false;
            if (Huy_functions.hasSharpChar(tenDN))
            {
                lblTenDN.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if(tenDN.Contains(" "))
            {
                isError = true;
                MessageBox.Show("Tên đăng nhập không được chứa khoảng trắng", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (Huy_functions.hasSharpChar(hoTen))
            {
                lblHoTen.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }
            if (Huy_functions.hasSharpChar(pass))
            {
                lblPass.ForeColor = Color.Red;
                isError = true;
                hasSharp = true;
            }

            if (hasSharp)
            {
                MessageBox.Show("Dữ liệu nhập vào không được chứa ký tự ##", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (tenDN == "")
            {
                lblTenDN.ForeColor = Color.Red;
                isError = true;
            }
            if (hoTen == "")
            {
                lblHoTen.ForeColor = Color.Red;
                isError = true;
            }
            if (pass == "")
            {
                lblPass.ForeColor = Color.Red;
                isError = true;
            }
            if (phanQuyen == -1)
            {
                lblPhanQuyen.ForeColor = Color.Red;
                isError = true;
            }

            if (!isError) {
                Huy_functions.createFile(Variable.pathThanhVien + tenDN + ".cnm", pass + "##" + phanQuyen + "##" + hoTen);
                if(thanhVienCanChinhSua != "")
                {
                    MessageBox.Show("Đã chỉnh sửa tài khoản: " + tenDN, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Đã thêm tài khoản: " + tenDN, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                    
            }

        }
    }
}
