﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace HT_quan_ly_kho
{
    internal class Variable
    {
        //can cai dat khi thay doi cac thu muc luu tru
        public static bool isProduction = false;

        public static bool isTry = true;
        public static int tryTime = 365; //15
        public static DateTime ngayBatDauDungThu = new DateTime(2026, 10, 04);//1/8/2025

        public static string path = getPath(isProduction);
        public static string folderNewVersion = getPathVersion(isProduction);

        public static string pathTonKhoToiThieu = path + @"bangtonkho-duoi-tieu-chuan\";
        public static string pathBangLK = path +  @"banglk\";
        public static string pathTonKho = path + @"bangtonkho\";
        public static string pathGiaDich = path + @"banggiaodich\";
        public static string pathNhatKy = path + @"bangnhatky\";
        public static string pathDatTen = path + @"bangdatten\";
        public static string pathThanhVien = path + @"thanhvien\";
        public static string pathOther = path + @"other\";
        public static string version = "v1.3.1";
        public static string fileVersion = folderNewVersion + @"version.txt";
        
        public static string getRootPath(bool prod)
        {
            if (prod)
            {
                return @"\\192.168.1.33\hometime-share\hometime-data\";
            }
            else
            {
                if (isTry)
                {
                    return @"C:\LMC\quan-ly-kho\";
                }
                else
                {
                    //return @"C:\demo-share\";
                    //return @"D:\LMC\quan-ly-kho\";
                    return @"\\huy\demo-share\";
                }

            }
        }
        public static string getPath(bool prod)
        {
            if(isTry)
            {
                return getRootPath(prod) + @"lmc-data\";
            }
            else
            {
                return getRootPath(prod) + @"ht-data\";
            }
                
            
        }
        public static string getPathVersion(bool prod)
        {
           
            if (isTry)
            {
                return getRootPath(prod) + @"lmc-phan-mem\";
            }
            else
            {
                return getRootPath(prod) + @"ht-phan-mem\";
            }
        }

        public static string getTenCongTy(bool myTry)
        {
            if (myTry)
            {
                return @"LMC";
            }
            else
            {
                return @"HOMETIME";
            }
        }
    }
}
