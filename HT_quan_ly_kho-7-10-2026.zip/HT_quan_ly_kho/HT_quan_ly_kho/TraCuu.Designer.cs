﻿namespace HT_quan_ly_kho
{
    partial class TraCuu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TraCuu));
            pictureBox1 = new PictureBox();
            inputMaLK = new TextBox();
            label3 = new Label();
            button2 = new Button();
            helloText = new Label();
            label1 = new Label();
            button1 = new Button();
            btnSuaVatLieu = new Button();
            btnSuaTonKho = new Button();
            dataGridView1 = new DataGridView();
            lblTonDuoiMucToiThieu = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 57;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // inputMaLK
            // 
            inputMaLK.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            inputMaLK.Location = new Point(527, 122);
            inputMaLK.Name = "inputMaLK";
            inputMaLK.Size = new Size(270, 37);
            inputMaLK.TabIndex = 50;
            inputMaLK.TextChanged += inputMaLK_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(376, 127);
            label3.Name = "label3";
            label3.Size = new Size(124, 30);
            label3.TabIndex = 54;
            label3.Text = "Mã vật liệu:";
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(1163, 22);
            button2.Name = "button2";
            button2.Size = new Size(162, 49);
            button2.TabIndex = 51;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(91, 30);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 53;
            helloText.Text = "Xin chào Đức";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(411, 23);
            label1.Name = "label1";
            label1.Size = new Size(506, 43);
            label1.TabIndex = 52;
            label1.Text = "Tra cứu thông tin mã vật liệu";
            // 
            // button1
            // 
            button1.BackColor = Color.Turquoise;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(815, 114);
            button1.Name = "button1";
            button1.Size = new Size(168, 54);
            button1.TabIndex = 58;
            button1.Text = "Tìm kiếm";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // btnSuaVatLieu
            // 
            btnSuaVatLieu.BackColor = Color.DeepSkyBlue;
            btnSuaVatLieu.Cursor = Cursors.Hand;
            btnSuaVatLieu.FlatStyle = FlatStyle.Flat;
            btnSuaVatLieu.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnSuaVatLieu.Location = new Point(352, 456);
            btnSuaVatLieu.Name = "btnSuaVatLieu";
            btnSuaVatLieu.Size = new Size(332, 67);
            btnSuaVatLieu.TabIndex = 60;
            btnSuaVatLieu.Text = "Sửa thông tin vật liệu";
            btnSuaVatLieu.UseVisualStyleBackColor = false;
            btnSuaVatLieu.Visible = false;
            btnSuaVatLieu.Click += button6_Click;
            // 
            // btnSuaTonKho
            // 
            btnSuaTonKho.BackColor = Color.Gold;
            btnSuaTonKho.Cursor = Cursors.Hand;
            btnSuaTonKho.FlatStyle = FlatStyle.Flat;
            btnSuaTonKho.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnSuaTonKho.Location = new Point(700, 456);
            btnSuaTonKho.Name = "btnSuaTonKho";
            btnSuaTonKho.Size = new Size(323, 67);
            btnSuaTonKho.TabIndex = 59;
            btnSuaTonKho.Text = "Sửa thông tin tồn kho";
            btnSuaTonKho.UseVisualStyleBackColor = false;
            btnSuaTonKho.Visible = false;
            btnSuaTonKho.Click += btnSuaTonKho_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 212);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1320, 199);
            dataGridView1.TabIndex = 61;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // lblTonDuoiMucToiThieu
            // 
            lblTonDuoiMucToiThieu.AutoSize = true;
            lblTonDuoiMucToiThieu.Cursor = Cursors.Hand;
            lblTonDuoiMucToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTonDuoiMucToiThieu.ForeColor = Color.Brown;
            lblTonDuoiMucToiThieu.Location = new Point(832, 662);
            lblTonDuoiMucToiThieu.Name = "lblTonDuoiMucToiThieu";
            lblTonDuoiMucToiThieu.Size = new Size(434, 30);
            lblTonDuoiMucToiThieu.TabIndex = 62;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: 10";
            lblTonDuoiMucToiThieu.Click += lblTonDuoiMucToiThieu_Click;
            // 
            // TraCuu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1344, 712);
            Controls.Add(lblTonDuoiMucToiThieu);
            Controls.Add(dataGridView1);
            Controls.Add(btnSuaVatLieu);
            Controls.Add(btnSuaTonKho);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(inputMaLK);
            Controls.Add(label3);
            Controls.Add(button2);
            Controls.Add(helloText);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TraCuu";
            Text = "Tra cứu tồn kho";
            Load += TraCuu_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox inputMaLK;
        private Label label3;
        private Button button2;
        private Label helloText;
        private Label label1;
        private Button button1;
        private Button btnSuaVatLieu;
        private Button btnSuaTonKho;
        private DataGridView dataGridView1;
        private Label lblTonDuoiMucToiThieu;
    }
}