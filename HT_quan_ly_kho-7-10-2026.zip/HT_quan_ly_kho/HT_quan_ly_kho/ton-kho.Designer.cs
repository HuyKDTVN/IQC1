﻿namespace HT_quan_ly_kho
{
    partial class ton_kho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ton_kho));
            dataGridView1 = new DataGridView();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            helloText = new Label();
            label1 = new Label();
            lblTonDuoiMucToiThieu = new Label();
            btnSuaVatLieu = new Button();
            btnSuaTonKho = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 95);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1320, 508);
            dataGridView1.TabIndex = 66;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 65;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(1163, 22);
            button2.Name = "button2";
            button2.Size = new Size(162, 49);
            button2.TabIndex = 62;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(91, 30);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 64;
            helloText.Text = "Xin chào Đức";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(534, 28);
            label1.Name = "label1";
            label1.Size = new Size(318, 43);
            label1.TabIndex = 63;
            label1.Text = "Thông tin tồn kho";
            // 
            // lblTonDuoiMucToiThieu
            // 
            lblTonDuoiMucToiThieu.AutoSize = true;
            lblTonDuoiMucToiThieu.Cursor = Cursors.Hand;
            lblTonDuoiMucToiThieu.Font = new Font("Segoe UI", 11F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTonDuoiMucToiThieu.ForeColor = Color.Brown;
            lblTonDuoiMucToiThieu.Location = new Point(875, 673);
            lblTonDuoiMucToiThieu.Name = "lblTonDuoiMucToiThieu";
            lblTonDuoiMucToiThieu.Size = new Size(434, 30);
            lblTonDuoiMucToiThieu.TabIndex = 67;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: 10";
            lblTonDuoiMucToiThieu.Click += lblTonDuoiMucToiThieu_Click;
            // 
            // btnSuaVatLieu
            // 
            btnSuaVatLieu.BackColor = Color.DeepSkyBlue;
            btnSuaVatLieu.Cursor = Cursors.Hand;
            btnSuaVatLieu.FlatStyle = FlatStyle.Flat;
            btnSuaVatLieu.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnSuaVatLieu.Location = new Point(12, 636);
            btnSuaVatLieu.Name = "btnSuaVatLieu";
            btnSuaVatLieu.Size = new Size(332, 67);
            btnSuaVatLieu.TabIndex = 69;
            btnSuaVatLieu.Text = "Sửa thông tin vật liệu";
            btnSuaVatLieu.UseVisualStyleBackColor = false;
            btnSuaVatLieu.Visible = false;
            // 
            // btnSuaTonKho
            // 
            btnSuaTonKho.BackColor = Color.Gold;
            btnSuaTonKho.Cursor = Cursors.Hand;
            btnSuaTonKho.FlatStyle = FlatStyle.Flat;
            btnSuaTonKho.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnSuaTonKho.Location = new Point(389, 636);
            btnSuaTonKho.Name = "btnSuaTonKho";
            btnSuaTonKho.Size = new Size(323, 67);
            btnSuaTonKho.TabIndex = 68;
            btnSuaTonKho.Text = "Sửa thông tin tồn kho";
            btnSuaTonKho.UseVisualStyleBackColor = false;
            btnSuaTonKho.Visible = false;
            // 
            // ton_kho
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1344, 712);
            Controls.Add(btnSuaVatLieu);
            Controls.Add(btnSuaTonKho);
            Controls.Add(lblTonDuoiMucToiThieu);
            Controls.Add(dataGridView1);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(helloText);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "ton_kho";
            Text = "Bảng tồn kho";
            Load += ton_kho_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private PictureBox pictureBox1;
        private Button button2;
        private Label helloText;
        private Label label1;
        private Label lblTonDuoiMucToiThieu;
        private Button btnSuaVatLieu;
        private Button btnSuaTonKho;
    }
}