﻿namespace HT_quan_ly_kho
{
    partial class LichSuGiaoDich
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LichSuGiaoDich));
            dataGridView1 = new DataGridView();
            back = new PictureBox();
            dangXuat = new Button();
            helloText = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)back).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(22, 230);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1300, 454);
            dataGridView1.TabIndex = 77;
            // 
            // back
            // 
            back.Cursor = Cursors.Hand;
            back.Image = (Image)resources.GetObject("back.Image");
            back.InitialImage = (Image)resources.GetObject("back.InitialImage");
            back.Location = new Point(22, 29);
            back.Name = "back";
            back.Size = new Size(64, 59);
            back.SizeMode = PictureBoxSizeMode.Zoom;
            back.TabIndex = 76;
            back.TabStop = false;
            back.Click += back_Click;
            // 
            // dangXuat
            // 
            dangXuat.BackColor = Color.Transparent;
            dangXuat.Cursor = Cursors.Hand;
            dangXuat.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dangXuat.ForeColor = Color.Brown;
            dangXuat.Location = new Point(1161, 39);
            dangXuat.Name = "dangXuat";
            dangXuat.Size = new Size(162, 49);
            dangXuat.TabIndex = 73;
            dangXuat.Text = "Đăng xuất";
            dangXuat.UseVisualStyleBackColor = false;
            dangXuat.Click += dangXuat_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(101, 47);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 75;
            helloText.Text = "Xin chào Đức";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(539, 40);
            label1.Name = "label1";
            label1.RightToLeft = RightToLeft.Yes;
            label1.Size = new Size(294, 48);
            label1.TabIndex = 74;
            label1.Text = "Lịch sử giao dịch";
            // 
            // LichSuGiaoDich
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1344, 712);
            Controls.Add(dataGridView1);
            Controls.Add(back);
            Controls.Add(dangXuat);
            Controls.Add(helloText);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "LichSuGiaoDich";
            Text = "Lịch sử giao dịch";
            Load += LichSuGiaoDich_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)back).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private PictureBox back;
        private Button dangXuat;
        private Label helloText;
        private Label label1;
    }
}