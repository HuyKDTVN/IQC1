﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class capNhatVL : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public capNhatVL(string maCodeNV, string tenNV, int phanQuyen)
        {
            InitializeComponent();
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
        }

        private void capNhatVL_Load(object sender, EventArgs e)
        {

        }
    }
}
