﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class TraCuu : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;
        public string maVatLieu;

        public string maLK;

        public TraCuu(string maCodeNV, string tenNV, int phanQuyen, string maVL)
        {
            InitializeComponent();
            lblTonDuoiMucToiThieu.Location = new Point(
                lblTonDuoiMucToiThieu.Location.X,
                this.ClientSize.Height - lblTonDuoiMucToiThieu.Height - 15
            );
            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
            maVatLieu = maVL;
            this.Resize += TraCuu_Resize;
        }
        private void TraCuu_Resize(object sender, EventArgs e)
        {
            // Ví dụ: cho một button nằm ở giữa form
            //button1.Left = (this.ClientSize.Width - button1.Width) / 2;
            //button1.Top = (this.ClientSize.Height - button1.Height) / 2;

            dataGridView1.Width = this.ClientSize.Width - 60;
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {
            home f = new home(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
        private void inputPass_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                if (inputMaLK.Text.Length >= 9)
                {
                    submit();
                }
            }  
        }
        private void TraCuu_Load(object sender, EventArgs e)
        {
            inputMaLK.AutoCompleteMode = AutoCompleteMode.Suggest;
            inputMaLK.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection source = new AutoCompleteStringCollection();
            source.AddRange(Huy_functions.getAllFilesfolder(Variable.pathBangLK));
            inputMaLK.AutoCompleteCustomSource = source;

            this.inputMaLK.KeyDown += new System.Windows.Forms.KeyEventHandler(this.inputPass_KeyDown);
            helloText.Text = "Xin chào " + hoTen;
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);
            if (maVatLieu.Length > 0)
            {
                inputMaLK.Text = maVatLieu;
                submit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            submit();
        }
        private void submit()
        {
            maLK = inputMaLK.Text.Trim().ToUpper();
            if(maLK.Contains("##"))
            {
                string[] arrBarCode = maLK.Split("##");
                maLK = arrBarCode[0];
            }
            bool hasMaVL = false;
            bool hasTonKho = false;
            if (maLK.Length >= 8)
            {
                DataTable table = new DataTable();
                string path = Variable.pathBangLK + maLK + ".cnm";
                if (File.Exists(path))
                {
                    // Tạo cột
                    table.Columns.Add("Mã vật liệu", typeof(string));
                    table.Columns.Add("Tên vật liệu", typeof(string));
                    table.Columns.Add("Số Lượng", typeof(string));
                    table.Columns.Add("Đơn vị", typeof(string));
                    table.Columns.Add("Tồn kho tối thiểu", typeof(string));
                    table.Columns.Add("Đơn giá", typeof(string));
                    table.Columns.Add("Vị trí", typeof(string));
                    table.Columns.Add("Nhóm vật liệu", typeof(string));
                    table.Columns.Add("Mã hàng", typeof(string));
                    table.Columns.Add("Ký tự", typeof(string));
                    table.Columns.Add("Nhà cung cấp", typeof(string));
                    table.Columns.Add("Ngày Nhập", typeof(string));
                    table.Columns.Add("Người nhập", typeof(string));
                    table.Columns.Add("Ghi chú", typeof(string));

                    // Thêm dòng
                    //table.Rows.Add("NVL001", "Ván MDF 18mm", 120, "Tấm", 20, "350000 VND", "Vật liệu chính", "Gỗ công nghiệp", "Kho Gỗ A", "Cty Minh Phát", DateTime.Now, "Thanh", "Dùng cho dòng tủ cao cấp");

                    // Gán dữ liệu vào DataGridView
                    dataGridView1.DataSource = table;
                    dataGridView1.ReadOnly = true;                    // Không cho sửa nội dung
                    dataGridView1.AllowUserToAddRows = false;         // Không cho thêm dòng mới
                    dataGridView1.Visible = true;

                    // Open the text file using a stream reader.
                    using StreamReader reader = new(path);

                    // Read the stream as a string.
                    string text = reader.ReadToEnd();
                    string[] infor = text.Split("##");

                    //string nhomVL = "Chính";
                    //if (infor[2] == "P")
                    //{
                    //    nhomVL = "Phụ";
                    //}
                    //if (infor[2] == "TB")
                    //{
                    //    nhomVL = "Thiết bị";
                    //}
                    string nhomVL = infor[2];
                    hasMaVL = true;
                    //kiem tra con ton kho hay khong
                    string pathTonKho1 = Variable.pathTonKho + maLK + ".cnm";
                    if (File.Exists(pathTonKho1))
                    {
                        using (StreamReader reader1 = new StreamReader(pathTonKho1))
                        {
                            string text1 = reader1.ReadToEnd();
                            string[] infor1 = text1.Split("##");

                            table.Rows.Add(maLK, infor[0], infor1[0], infor[1], infor[3], infor1[1], infor1[2], infor[2], infor[7], infor[8], infor1[3], infor1[5], infor1[4], infor1[6]);
                            if(infor1[0] != "")
                            {
                                hasTonKho = true;
                            }
                        } // <-- tại đây StreamReader sẽ được đóng
                    }
                    else
                    {
                        table.Rows.Add(maLK, infor[0], 0, infor[1], infor[3], infor[9], "", infor[2], infor[7], infor[8], "", "", "", "");
                    }

                    if (phanQuyenInt == 3)
                    {
                        if (hasMaVL)
                        {
                            btnSuaVatLieu.Visible = true;
                            
                        }
                        if(hasTonKho)
                        {
                            btnSuaTonKho.Visible = true;
                        } 
                    }
                }
                else
                {
                    dataGridView1.Visible = false;
                    btnSuaVatLieu.Visible = false;
                    btnSuaTonKho.Visible = false;
                    MessageBox.Show("Không tìm thấy mã vật liệu " + maLK);
                    
                }
            }
        }

        private void inputMaLK_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            themVL f = new themVL(maNV, hoTen, phanQuyenInt, maLK, true);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSuaTonKho_Click(object sender, EventArgs e)
        {
           
            NhapKho f = new NhapKho(maNV, hoTen, phanQuyenInt, "sua", maLK);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void lblTonDuoiMucToiThieu_Click(object sender, EventArgs e)
        {
            TKToiThieu f = new TKToiThieu(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }
    }
}
