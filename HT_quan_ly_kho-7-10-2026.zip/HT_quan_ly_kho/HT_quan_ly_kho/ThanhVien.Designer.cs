﻿namespace HT_quan_ly_kho
{
    partial class ThanhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThanhVien));
            dataGridView1 = new DataGridView();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            helloText = new Label();
            label1 = new Label();
            btnSuaVatLieu = new Button();
            btnSuaTonKho = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(298, 120);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(778, 408);
            dataGridView1.TabIndex = 66;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(12, 23);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 65;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(1163, 33);
            button2.Name = "button2";
            button2.Size = new Size(162, 49);
            button2.TabIndex = 62;
            button2.Text = "Đăng xuất";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // helloText
            // 
            helloText.AutoSize = true;
            helloText.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            helloText.Location = new Point(91, 41);
            helloText.Name = "helloText";
            helloText.Size = new Size(139, 30);
            helloText.TabIndex = 64;
            helloText.Text = "Xin chào Đức";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(504, 41);
            label1.Name = "label1";
            label1.Size = new Size(333, 43);
            label1.TabIndex = 63;
            label1.Text = "Quản lý thành viên";
            // 
            // btnSuaVatLieu
            // 
            btnSuaVatLieu.BackColor = Color.DeepSkyBlue;
            btnSuaVatLieu.Cursor = Cursors.Hand;
            btnSuaVatLieu.FlatStyle = FlatStyle.Flat;
            btnSuaVatLieu.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnSuaVatLieu.Location = new Point(298, 572);
            btnSuaVatLieu.Name = "btnSuaVatLieu";
            btnSuaVatLieu.Size = new Size(232, 67);
            btnSuaVatLieu.TabIndex = 71;
            btnSuaVatLieu.Text = "Thêm tài khoản";
            btnSuaVatLieu.UseVisualStyleBackColor = false;
            btnSuaVatLieu.Click += btnSuaVatLieu_Click;
            // 
            // btnSuaTonKho
            // 
            btnSuaTonKho.BackColor = Color.Gold;
            btnSuaTonKho.Cursor = Cursors.Hand;
            btnSuaTonKho.FlatStyle = FlatStyle.Flat;
            btnSuaTonKho.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            btnSuaTonKho.Location = new Point(547, 572);
            btnSuaTonKho.Name = "btnSuaTonKho";
            btnSuaTonKho.Size = new Size(283, 67);
            btnSuaTonKho.TabIndex = 70;
            btnSuaTonKho.Text = "Chỉnh sửa tài khoản";
            btnSuaTonKho.UseVisualStyleBackColor = false;
            btnSuaTonKho.Click += btnSuaTonKho_Click_1;
            // 
            // button1
            // 
            button1.BackColor = Color.HotPink;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            button1.Location = new Point(848, 572);
            button1.Name = "button1";
            button1.Size = new Size(228, 67);
            button1.TabIndex = 72;
            button1.Text = "Xóa tài khoản";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // ThanhVien
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1344, 712);
            Controls.Add(button1);
            Controls.Add(btnSuaVatLieu);
            Controls.Add(btnSuaTonKho);
            Controls.Add(dataGridView1);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(helloText);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "ThanhVien";
            Text = "Quản lý thành viên";
            Load += ThanhVien_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private PictureBox pictureBox1;
        private Button button2;
        private Label helloText;
        private Label label1;
        private Button btnSuaVatLieu;
        private Button btnSuaTonKho;
        private Button button1;
    }
}