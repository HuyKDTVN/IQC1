//
//  Onboarding2.swift
//  kegel-exercise
//
//  Created by Huy Le on 5/5/26.
//

import SwiftUI

struct UpdateTinhTrangTri: View {
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    @State private var hasRedirect = false
    //let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        NavigationView {
            VStack{
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("kegellagi", comment: ""))
                        .font(.system(size: 20).bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                ScrollView{
                    VStack(spacing: 0) {
                        Text(NSLocalizedString("Nội dung đang cập nhật", comment: ""))
                            .padding(.leading, 10)
                            .font(.system(size: 18).bold())
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Spacer()
                    }
                    .padding()
                }
                Spacer()
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    UpdateTinhTrangTri().preferredColorScheme(.dark)
}
