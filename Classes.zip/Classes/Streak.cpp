//
//  Streak.cpp
//  mentalmath
//
//  Created by Huy Le on 6/9/26.
//

#include "Streak.hpp"
#include "setting.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "FirebaseAnalyticsHelper.h"
#include "HelloWorldScene.h"
#include "finish.h"
#include "finishDual.h"

USING_NS_CC;

int currentScoreStreak;
int cTypeStreak;
int cLevelStreak;
int cTypePlayBeforeStreak;
bool fromChallengeFinishStreak;
bool finishedStreak;
int soCauStreak;
bool dualPlayStreak;
int scoreDupStreak;
Scene* Streak::createScene(int soCau, int score, int type, int level, int typePlayBefore, bool fromChallenge, bool finished10, bool dualPlay, int scoreDup)

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    currentScoreStreak = score;
    cTypeStreak = type;
    cLevelStreak = level;
    cTypePlayBeforeStreak = typePlayBefore;
    fromChallengeFinishStreak = fromChallenge;
    finishedStreak = finished10;
    soCauStreak = soCau;
    dualPlayStreak = dualPlay;
    scoreDupStreak = scoreDup;
    
    // 'layer' is an autorelease object
    auto layer = Streak::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Streak::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;

    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    //back(wScene, hScene);
    createTemplate(wScene, hScene);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(6);
    }
    //this->setKeypadEnabled(true);
    
    log("click_streak");
    FirebaseAnalyticsHelper::logEvent("click_streak");
    return true;
}
void Streak::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg01.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void Streak::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void Streak::createTemplate(float w, float h){
    auto buttonStreakIcon = ui::Button::create("streak.png", "streak.png"); // tao button
    float ratiobuttonStreakIcon = 2.7;
    if (ratioScreen <= 1.53)
    {
        ratiobuttonStreakIcon = 8;
    }
    float scalebuttonStreakIcon = wScene / ratiobuttonStreakIcon / buttonStreakIcon->getContentSize().width;
    buttonStreakIcon->setScale(scalebuttonStreakIcon);
    float ybuttonStreakIcon = hScene * 0.9 - buttonStreakIcon->getContentSize().height * scalebuttonStreakIcon / 2;
    float xbuttonStreakIcon = wScene / 2;
    if (ratioScreen > 1.53 and ratioScreen < 1.8)
    {
        ybuttonStreakIcon = hScene * 0.95 - buttonStreakIcon->getContentSize().height * scalebuttonStreakIcon / 2;
    }
    buttonStreakIcon->setPosition(Vec2(xbuttonStreakIcon, ybuttonStreakIcon));
    addChild(buttonStreakIcon);//add button vao scene
    
    float fontSize = 0.06 * wScene;
    int fixFontSize = 5;
    if (hScene/ wScene <= 1.53)
    {
        fixFontSize = 3;
        fontSize = 0.03 * wScene;
    }
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    int soNgayChoiInt = HuyFunctions().getChuoiNgay();
    auto soNgayChoiString = cocos2d::__String::createWithFormat("%i", soNgayChoiInt);
    auto streakNumber = Label::createWithTTF(soNgayChoiString->getCString(), fontStyle, fontSize * fixFontSize);
   
    streakNumber->setColor(Color3B().YELLOW);
    // position the label on the center of the screen
    float xValueScore = wScene / 2;
    float yValueScore = buttonStreakIcon->getPositionY() -  buttonStreakIcon->getContentSize().height * scalebuttonStreakIcon / 2 - streakNumber->getContentSize().height / 3;
    streakNumber->setPosition(Vec2(xValueScore, yValueScore));
    streakNumber->setAnchorPoint({0.5, 0.5});
    streakNumber->setHorizontalAlignment(TextHAlignment::LEFT);
    addChild(streakNumber);
    
    auto visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();
    float margin = 20.0f;
    float radius = 25.0f;
    float barWidth = visibleSize.width - margin * 2;
    
    float fixWidthIpad = 1;
    if (hScene/ wScene <= 1.53)
    {
        fixWidthIpad = 2 / 1.5;
        barWidth = visibleSize.width * 0.6;
        radius = radius / fixWidthIpad;
    }
    Size rectSize(
        barWidth,
        80.0f / fixWidthIpad
    );

    Vec2 pos(
        origin.x + visibleSize.width / 2,
        streakNumber->getPosition().y - streakNumber->getContentSize().height / 2 - 40
    );
    auto drawNode = DrawNode::create();
    Color4F color = Color4F(28.0f / 255.0f,
                            5.0f / 255.0f,
                            70.0f / 255.0f,
                            1.0f);
    // Thân dọc
    drawNode->drawSolidRect(
        Vec2(-rectSize.width / 2 + radius, -rectSize.height / 2),
        Vec2( rectSize.width / 2 - radius,  rectSize.height / 2),
                            color
    );

    // Thân ngang
    drawNode->drawSolidRect(
        Vec2(-rectSize.width / 2, -rectSize.height / 2 + radius),
        Vec2( rectSize.width / 2,  rectSize.height / 2 - radius),
                            color
    );

    // 4 góc
    const int segments = 20 / fixWidthIpad;

    drawNode->drawSolidCircle(
        Vec2(-rectSize.width / 2 + radius, -rectSize.height / 2 + radius),
        radius, 0, segments, color
    );

    drawNode->drawSolidCircle(
        Vec2(rectSize.width / 2 - radius, -rectSize.height / 2 + radius),
        radius, 0, segments, color
    );

    drawNode->drawSolidCircle(
        Vec2(-rectSize.width / 2 + radius, rectSize.height / 2 - radius),
        radius, 0, segments, color
    );

    drawNode->drawSolidCircle(
        Vec2(rectSize.width / 2 - radius, rectSize.height / 2 - radius),
        radius, 0, segments, color
    );

    drawNode->setPosition(pos);
    this->addChild(drawNode);
    
    // =========================
    // 7 phần tử
    // =========================

    const int itemCount = 7;

    float circleDiameter = 27.0f / fixWidthIpad;
    float circleRadius = circleDiameter / 2.0f;

    Color3B circleColor(33, 31, 100); // #211F64

    // Khoảng cách giữa các item
    float itemSpacing = barWidth / itemCount;

    int dayOfW = HuyFunctions().getDayOfWeek();
    std::vector<int> itemsChuoi = HuyFunctions().getArrChuoiNgayInWeek();
    for (int i = 0; i < itemCount; i++)
    {
        // -------------------------
        // Vị trí item
        // -------------------------
        float x =
            -barWidth / 2.0f
            + itemSpacing * (i + 0.5f);

        float circleY = 10.0f;

        // -------------------------
        // Hình tròn
        // -------------------------
        auto circle = DrawNode::create();
        
        if (i + 2 == dayOfW || (i == 6 && dayOfW == 1)) {
            circle->drawSolidCircle(
                Vec2::ZERO,
                circleRadius,
                0,
                28,
                Color4F::GREEN
                
            );
        }else{
            circle->drawSolidCircle(
                Vec2::ZERO,
                circleRadius,
                0,
                28,
                Color4F(
                    circleColor.r / 255.0f,
                    circleColor.g / 255.0f,
                    circleColor.b / 255.0f,
                    1.0f
                )
            );
        }
        circle->setPosition(
            drawNode->getPosition() + Vec2(x, circleY)
        );

        this->addChild(circle);

        // -------------------------
        // Ảnh streak
        // -------------------------
        auto streak = Sprite::create("streak.png");

        if (streak)
        {
            streak->setPosition(
                circle->getPosition()
            );

            // Nếu ảnh streak không đúng kích thước,
            // có thể scale lại.
            float maxSize = 22.0f;

            float scaleX = maxSize / streak->getContentSize().width / fixWidthIpad;
            float scaleY = maxSize / streak->getContentSize().height / fixWidthIpad;

            float scale = std::min(scaleX, scaleY);

            streak->setScale(scale);
            if (itemsChuoi[i] != 1) {
                streak->setOpacity(0);
            }
            this->addChild(streak);
        }

        // -------------------------
        // Text T2
        // -------------------------
        auto label = Label::createWithTTF(
            LanguageManager::getInstance()->getStringForKey(cocos2d::__String::createWithFormat("T%i", (i + 2) )->getCString()).c_str(),
            "fonts/ArialUnicodeMS.ttf",
            fontSize * 0.65
        );

        if (label)
        {
            float textGap = 3.0f;

            float textY =
                circleY
                - circleRadius
                - textGap
                - label->getContentSize().height / 2.0f;

            label->setPosition(
                drawNode->getPosition() + Vec2(x, textY)
            );

            label->setTextColor(Color4B::WHITE);
            if (i + 2 == dayOfW || (i == 6 && dayOfW == 1)) {
                label->setTextColor(Color4B::GREEN);
            }

            this->addChild(label);
        }
    }
    
    fontStyle = "fonts/ArialUnicodeMS.ttf";
    
    auto streakMsg = Label::createWithTTF(
        LanguageManager::getInstance()->getStringForKey("streakmsg").c_str(),
        fontStyle,
        fontSize * 0.8,
        Size(wScene - 80, 0),
        TextHAlignment::CENTER,
        TextVAlignment::CENTER
    );

    streakMsg->setColor(Color3B::WHITE);

    float xStreakMsg = wScene / 2;
    float yStreakMeg = drawNode->getPositionY()
        - 40
        - streakMsg->getContentSize().height / 2
        - 30;

    streakMsg->setAnchorPoint(Vec2(0.5f, 0.5f));
    streakMsg->setPosition(Vec2(xStreakMsg, yStreakMeg));

    addChild(streakMsg);
    
    //create claim button
    auto okButton = ui::Button::create("button-claim.png", "button-claim.png"); // tao button
    float ratioButtonClaim = 4.5;
    if (h / w <= 1.53)
    {
        ratioButtonClaim = 9;
    }
    //auto okButtonHeight = okButton->getContentSize().height;
    auto okButtonWidth = okButton->getContentSize().width;
    float scaleokButton = w / ratioButtonClaim / okButtonWidth;
    okButton->setScale(scaleokButton);
    okButton->setPosition(Vec2(w/2, h / 20 + okButton->getContentSize().height * scaleokButton / 2));
    okButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                if (cTypePlayBeforeStreak > 0) {
                    if (dualPlayStreak) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, FinishDual::createScene(currentScoreStreak, scoreDupStreak, cTypeStreak, cLevelStreak), Color3B().WHITE));
                    } else {
                        if (soCauStreak > 9) {
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(currentScoreStreak, cTypeStreak, cLevelStreak, cTypePlayBeforeStreak, fromChallengeFinishStreak, true), Color3B().WHITE));
                        }else{
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(currentScoreStreak, cTypeStreak, cLevelStreak, cTypePlayBeforeStreak, fromChallengeFinishStreak), Color3B().WHITE));
                        }
                    }
                    
                    
                } else {
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                    });
                }
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(okButton);//add button vao scene
}
void Streak::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
//                HuyFunctions().animationClickedButton(button, [](){
//                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
//                });
                
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}


