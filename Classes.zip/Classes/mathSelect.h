#ifndef __MATHSELECT_H__
#define __MATHSELECT_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class MathSelect : public cocos2d::Layer
{
public:
    cocos2d::ui::Button* handButton;
    cocos2d::ui::Button* buttonPlay1;
    cocos2d::ui::Button* buttonPlay2;
    cocos2d::ui::Button* buttonPlay3;
    cocos2d::ui::Button* buttonPlay4;
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int mode, int typePhepTinh);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void createBg(float w, float h);
	void back(float w, float h);
	void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
	void createButtonKey();
	void createValueKey();
	void createTite(float w, float h);
    void createTiteEachType(float w, float h);

    void requestAds();
    void showAds();

	// a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
	CREATE_FUNC(MathSelect);
};

#endif // __MATHSELECT_H__
