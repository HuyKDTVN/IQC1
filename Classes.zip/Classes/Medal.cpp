//
//  Medal.cpp
//  mentalmath
//
//  Created by Huy Le on 13/12/25.
//
#include "Medal.hpp"
#include "HelloWorldScene.h"
#include "setting.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"

USING_NS_CC;

Scene* Medal::createScene()

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = Medal::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Medal::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;

    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    back(wScene, hScene);
    createTemplate(wScene, hScene);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(6);
    }
    //this->setKeypadEnabled(true);
    return true;
}
void Medal::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-blurr.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void Medal::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void Medal::createTemplate(float w, float h){
    auto fontStyle = "fonts/NunitoSans-Bold.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
    }
    
    auto fontTitle = 0.06 * w;
    auto fixIpad = 1;
    if (h / w <= 1.53)
    {
        fontTitle = 0.025 * w;
      
        fixIpad = 0.5;
    }
    
    labelTitle = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("THANHTICHCUABAN").c_str(), fontStyle, fontTitle);
    labelTitle->setHorizontalAlignment(TextHAlignment::CENTER);
    labelTitle->setPosition(Vec2(w/2, h * 0.9));
    this->addChild(labelTitle, 13);
   
    fixIpad = 1;
    if (ratioScreen <= 1.53)
    {
        fixIpad = 2;
    }
    auto scrollHeight = 1200 / fixIpad;
    cocos2d::ui::ScrollView *Item_Scroll = cocos2d::ui::ScrollView::create();
    Item_Scroll->setDirection(ui::ListView::Direction::VERTICAL);
    Item_Scroll->setAnchorPoint(Point::ANCHOR_TOP_LEFT);
    Item_Scroll->getInnerContainer()->setAnchorPoint(Point::ANCHOR_TOP_LEFT);
    Item_Scroll->setContentSize(Size(wScene,hScene));
    Item_Scroll->setBackGroundColorType(ui::Layout::BackGroundColorType::NONE);
    Item_Scroll->setInnerContainerSize(Size(wScene,scrollHeight));
    Item_Scroll->setBounceEnabled(true);
    Item_Scroll->setTouchEnabled(true);
    Item_Scroll->setScrollBarEnabled(false);
    Item_Scroll->setPosition(Vec2(wScene/2 - Item_Scroll->getContentSize().width / 2,labelTitle->getPositionY() - labelTitle->getContentSize().height - 20/ fixIpad));
    this->addChild(Item_Scroll);
    
    
    for (int m = 0; m < 5; m++) {
        auto soDiemMedalString = cocos2d::__String::createWithFormat("medal%i", m + 1);
        int soDiemMedal = UserDefault::getInstance()->getIntegerForKey(soDiemMedalString->getCString(), 0);
        
        Size bgSize(wScene * 0.9 / fixIpad, 170 / fixIpad);
        
        auto bg = DrawNode::create();
        HuyFunctions().drawSolidRoundedRect(bg, Vec2::ZERO, bgSize, 30 / fixIpad, Color4F(0.0902f, 0.0353f, 0.1412f, 1.0f));
        auto node = Node::create();
        node->addChild(bg);
        Item_Scroll->addChild(node, 5);
        float yNode = scrollHeight - bgSize.height - (bgSize.height + 30 / fixIpad) * m;
        node->setPosition(wScene /2 - bgSize.width / 2 , yNode);
        
        Size bgSizeTitle(wScene * 0.9 / fixIpad, 60 / fixIpad);
        auto bgTitle = DrawNode::create();
        HuyFunctions().drawSolidRoundedRect(bgTitle, Vec2::ZERO, bgSizeTitle, 30 / fixIpad, Color4F(0.1294f, 0.0353f, 0.2118f, 1.0f));
        auto nodeBgTitle = Node::create();
        nodeBgTitle->addChild(bgTitle);
        node->addChild(nodeBgTitle);
        nodeBgTitle->setPosition(Vec2(0, bgSize.height - bgSizeTitle.height));
        
        auto titleMedalString = cocos2d::__String::createWithFormat("MEDAL_TITLE%i", m + 1);
        auto descMedalString = cocos2d::__String::createWithFormat("MEDAL_DESC%i", m + 1);
        
        auto titleMedal = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey(titleMedalString->getCString()).c_str(), fontStyle, fontTitle);
        titleMedal->setHorizontalAlignment(TextHAlignment::CENTER);
        titleMedal->setPosition(Vec2( bgSizeTitle.width / 2, bgSizeTitle.height - titleMedal->getContentSize().height / 2 - 5));
        nodeBgTitle->addChild(titleMedal);
        auto descMedal = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey(descMedalString->getCString()).c_str(), fontStyle, fontTitle * 0.6);
        descMedal->setHorizontalAlignment(TextHAlignment::CENTER);
        descMedal->setColor(Color3B().YELLOW);
        descMedal->setPosition(Vec2( bgSizeTitle.width / 2, bgSizeTitle.height - titleMedal->getContentSize().height - 7 - descMedal->getContentSize().height / 2));
        nodeBgTitle->addChild(descMedal);
        
        if (soDiemMedal == 0) {
            descMedal->setColor(Color3B().GRAY);
            titleMedal->setColor(Color3B().GRAY);
        }
        
        auto iconMedalString = cocos2d::__String::createWithFormat("medal%i.png", m + 1);
        
        for (int i = 0; i < 10; i++) {
            if (i+1 <= soDiemMedal) {
                iconMedalString = cocos2d::__String::createWithFormat("medal%i.png", m + 1);
            }else {
                iconMedalString = cocos2d::__String::createWithFormat("medal-hide%i.png", m + 1);
            }
            auto iconMedal = Sprite::create(iconMedalString->getCString());
            float ratioMedal = 10 * wScene / bgSize.width / 0.75;
            
            float scaleiconMedal = wScene / ratioMedal / iconMedal->getContentSize().width;
            iconMedal->setScale(scaleiconMedal);
            float xIconMedal = (wScene / fixIpad - bgSize.width) / 2 + 0 + iconMedal->getContentSize().width * scaleiconMedal / 2 + (iconMedal->getContentSize().width * scaleiconMedal / 0.82) * i;
            float yIconMedal = bgSize.height - iconMedal->getContentSize().height * scaleiconMedal / 2 - bgSizeTitle.height - 20 / fixIpad;
            iconMedal->setPosition(Vec2( xIconMedal, yIconMedal));
            node->addChild(iconMedal);
        }
        
        for (int i = 10; i < 20; i++) {
            if (i+1 <= soDiemMedal) {
                iconMedalString = cocos2d::__String::createWithFormat("medal%i.png", m + 1);
            }else {
                iconMedalString = cocos2d::__String::createWithFormat("medal-hide%i.png", m + 1);
            }
            auto iconMedal = Sprite::create(iconMedalString->getCString());
            float ratioMedal = 10 * wScene / bgSize.width / 0.75;
            
            float scaleiconMedal = wScene / ratioMedal / iconMedal->getContentSize().width;
            iconMedal->setScale(scaleiconMedal);
            float xIconMedal = (wScene / fixIpad - bgSize.width) / 2 + 0 + iconMedal->getContentSize().width * scaleiconMedal / 2 + (iconMedal->getContentSize().width * scaleiconMedal / 0.82) * (i-10);
            float yIconMedal = bgSize.height - iconMedal->getContentSize().height * scaleiconMedal  * 1.5 - 10 / fixIpad - bgSizeTitle.height - 20 / fixIpad;
            iconMedal->setPosition(Vec2( xIconMedal, yIconMedal));
            node->addChild(iconMedal);
        }
    }
}
void Medal::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
