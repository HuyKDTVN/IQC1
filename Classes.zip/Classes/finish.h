#ifndef __FINISH_H__
#define __FINISH_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class Finish : public cocos2d::Layer
{
public:
    
    int soLanChayHam;
    int soLanChayHamAddGold;
    bool hasHideRetryButton;
    cocos2d::__String *labelScoreAdd200;
    cocos2d::ui::Button* buttonHome;
    cocos2d::ui::Button* buttonNext;
    cocos2d::ui::Button* buttonAddKey;
    bool done;
    
    float wScene;
    float hScene;
    
    cocos2d::Sprite* bgNenTet;
    cocos2d::ui::Button* bgNamMoi;
    cocos2d::ui::Button* lixi;
    cocos2d::ui::Button* lePhucSinhTho;
    //cocos2d::ui::Button* phaoHoa;
    //cocos2d::ui::Button* gold;
    cocos2d::Vector<cocos2d::ui::Button*> listGold;
    cocos2d::Vector<cocos2d::ui::Button*> listPhaoHoa;
    int randThemVang;
    
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int score, int type, int level, int typePlayBefore, bool fromChallenge = false);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
	void createScore(float w, float h);
	void createButtonKey(float w, float h);
    void createBg(float w, float h);
    void createBgTet(float w, float h);
    void createTrungLixi(float w, float h);
    void createPhaoHoa(float w, float h);
    int createPhaoHoaElement(float w, float h, int x, int y);
    void createLiXi(float w, float h);
	void createValueKey(float w, float h);
    void showGiftTet(float w, float h);
	void createButtonNextAndAddKey(float w, float h);
    void addGold();
    void showButtonAdd200();
  
    void updateEverySecondToLoadAds(float dt);
    
    void buttonNoThanksClick(cocos2d::ui::Button* me);
    
	void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void createTemplateChallenge();
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);

    
    // implement the "static create()" method manually
	CREATE_FUNC(Finish);
};

#endif // __FINISH_H__
