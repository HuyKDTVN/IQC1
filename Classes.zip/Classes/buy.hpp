//
//  buy.hpp
//  mentalmath-mobile
//
//  Created by Huy Le on 9/6/24.
//

#ifndef buy_hpp
#define buy_hpp
#include "cocos2d.h"
#include <ctime>
#include <iostream>
#include "ui/CocosGUI.h"
#include <stdio.h>

class Buy : public cocos2d::Scene
{
public:

    int tongDiem;
    int diemDiamond;
    int diemHeart;
    
    int soundHello;
    cocos2d::ui::Button* card1;
    cocos2d::ui::Button* card2;
    cocos2d::ui::Button* card3;
    cocos2d::ui::Button* card4;
    cocos2d::ui::Button* card5;
    
    cocos2d::ui::Button* button1;
    cocos2d::ui::Button* button2;
    cocos2d::ui::Button* button3;
    
    cocos2d::Sprite* phithuyenHienThi;
    cocos2d::ui::Button* buttonAdd200Gold2;
    
    cocos2d::Label* valueTongDiem;
    cocos2d::Label* valueHeightScore;
    cocos2d::Label* valueSoNgayChoi;
    
    int viTriPhiThuyen;
    int viTriNhanVat;
    int viTriTenLua;
    std::vector<std::string> arrSelected;
    
    
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int type);

    void createBg();
    void createInforDiemSo();
    void createButtonBack();
    void createPhiThuyen(float w, float h, int i);
    void createTenLua(float w, float h, int i);
    void createNhanVat(float w, float h, int i);
    void createCard(int ViTriActive);
    void createButton();
    void animationCardClicked(cocos2d::ui::Button* btn, int viTriClick);
    void clickBuy(cocos2d::ui::Button* btn, int type);
    void saveNhanVatSelected(std::string typeNameSelected, int viTri);
    virtual bool init();

    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);

    // implement the "static create()" method manually
    CREATE_FUNC(Buy);
};
#endif /* buy_hpp */
