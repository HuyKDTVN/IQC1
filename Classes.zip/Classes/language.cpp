#include "language.h"
#include "setting.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "Huy_functions/HuyFunctions.hpp"

USING_NS_CC;
ui::Button* titlelang;
float scaletitlelang;

Scene* Language::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = Language::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Language::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    //set bg
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));

    back(wScene, hScene);
    createTite(wScene, hScene);

    //this->setKeypadEnabled(true);
    return true;
}
void Language::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
}

void Language::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 11);//add button vao scene
}

void Language::createTite(float w, float h){
    //create bg color
    auto bgColor = ui::Button::create("bg-app.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    
    float fontSize = 0.12 * w;
    if (h / w <= 1.53)
    {
        fontSize = 0.06 * w;
    }
    titlelang = ui::Button::create("bg-title.png"); // tao button
    titlelang->setPressedActionEnabled(true);
    titlelang->setZoomScale(-0.1f);
    titlelang->setScale9Enabled(true);
    titlelang->setTitleText(LanguageManager::getInstance()->getStringForKey("LANG").c_str());

    if(appLang == "en" || appLang == "vi"){
        titlelang->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    

    titlelang->setTitleColor(Color3B().WHITE);
    titlelang->setTouchEnabled(false);
    float ratiotitlelang = 1;
    scaletitlelang = w / ratiotitlelang / titlelang->getContentSize().width;
    titlelang->setScale(scaletitlelang);
    titlelang->setTitleFontSize(fontSize / scaletitlelang);
    
    if (appLang == "ja")
    {
        titlelang->setTitleFontName("fonts/KosugiMaru.ttf");
        titlelang->setTitleFontSize(0.09 * w / scaletitlelang);
    }
    float ytitlelang = h - (titlelang->getContentSize().height / 2 * scaletitlelang);
    if (h / w <= 1.53)
    {
        ytitlelang = h * 1.1 - (titlelang->getContentSize().height / 2 * scaletitlelang);
        if (appLang == "ja")
        {
            
            titlelang->setTitleFontSize(0.05 * w / scaletitlelang);
        }
    }
    titlelang->setPosition(Vec2(w / 2, ytitlelang));
    titlelang->setEnabled(true);
    addChild(titlelang);

    auto langEng = HuyFunctions().creategGroupInfor(w, h, ytitlelang - h / 4, "language2.png", "", LanguageManager::getInstance()->getStringForKey("en").c_str(), "");
    langEng->setSwallowTouches(false);
    langEng->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                UserDefault::getInstance()->setStringForKey("LANGUAGE", "en");
                UserDefault::getInstance()->flush();
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(langEng);//add button vao scene
    // Giả sử button là một đối tượng Button đã được tạo
    auto children = langEng->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        UserDefault::getInstance()->setStringForKey("LANGUAGE", "en");
                        UserDefault::getInstance()->flush();
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }

    
    const char* yourLang = Application::getInstance()->getCurrentLanguageCode();
    std::string sYourLang = yourLang;
    CCLOG("yourLang %s", sYourLang.c_str());
    if (
        sYourLang != "en" &
        (sYourLang == "vi"
         || sYourLang == "ja"
         || sYourLang == "fr"
         || sYourLang == "de"
         || sYourLang == "ko"
         || sYourLang == "th"
         || sYourLang == "zh"
         || sYourLang == "ru"
         || sYourLang == "pt"
         || sYourLang == "it"
         || sYourLang == "id"
         || sYourLang == "tr"
         || sYourLang == "ca"
         || sYourLang == "cr"
         || sYourLang == "cz"
         || sYourLang == "da"
         || sYourLang == "du"
         || sYourLang == "fi"
         || sYourLang == "gr"
         || sYourLang == "hi"
         || sYourLang == "hu"
         || sYourLang == "ma"
         || sYourLang == "no"
         || sYourLang == "po"
         || sYourLang == "ro"
         || sYourLang == "sk"
         || sYourLang == "sp"
         || sYourLang == "sw"
         || sYourLang == "uk"
         )){
             auto langJapan = HuyFunctions().creategGroupInfor(w, h, langEng->getPositionY() - langEng->getContentSize().height * langEng->getScale() * 1.2, "language2.png", yourLang, LanguageManager::getInstance()->getStringForKey(yourLang).c_str(), "");
        langJapan->setName(sYourLang);
        langJapan->setSwallowTouches(false);
        langJapan->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    UserDefault::getInstance()->setStringForKey("LANGUAGE", ((ui::Button*) sender)->getName());
                    UserDefault::getInstance()->flush();
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //CCLOG("Button 1 clicked");
                    break;
                default:
                    break;
            }
        });
        addChild(langJapan);//add button vao scene
         // Giả sử button là một đối tượng Button đã được tạo
         auto children2 = langJapan->getChildren();
             for (auto& child : children2) {
                 auto childButton2 = dynamic_cast<ui::Button*>(child);
                 if (childButton2) {
                     // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
                     // Ví dụ: Thiết lập link cho button
                     childButton2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                         switch (type)
                         {
                             case cocos2d::ui::Widget::TouchEventType::BEGAN:
                                 UserDefault::getInstance()->setStringForKey("LANGUAGE", ((ui::Button*) sender)->getName());
                                 UserDefault::getInstance()->flush();
                                 Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
                                 break;
                             case cocos2d::ui::Widget::TouchEventType::ENDED:
                                 //CCLOG("Button 1 clicked");
                                 break;
                             default:
                                 break;
                         }
                     });
                 }
             }
        //change text color of current language
        if (appLang == "en")
        {
            langEng->setOpacity(150);
            langEng->setCascadeOpacityEnabled(true);
            //langEng->setEnabled(false);
        }
        else{
            langJapan->setOpacity(150);
            langJapan->setCascadeOpacityEnabled(true);
            //langJapan->setEnabled(false);
        }
        
    }
    else{
        langEng->setOpacity(150);
        langEng->setCascadeOpacityEnabled(true);
    }

}
