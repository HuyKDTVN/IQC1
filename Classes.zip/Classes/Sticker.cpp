//
//  Sticker.cpp
//  mentalmath
//
//  Created by Huy Le on 19/11/25.
//

#include "Sticker.hpp"
#include "HelloWorldScene.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"

USING_NS_CC;

Scene* Sticker::createScene()

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = Sticker::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Sticker::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;

    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    back(wScene, hScene);
    createTemplate(wScene, hScene);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(6);
    }
    //this->setKeypadEnabled(true);
    return true;
}
void Sticker::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-blurr.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void Sticker::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void Sticker::createTemplate(float w, float h){
    auto fontTitle = 0.08 * w;
    auto fixIpad = 1;
    Size sizeOfEditBox = Size(200,50);
    if (h / w <= 1.53)
    {
        fontTitle = 0.04 * w;
        sizeOfEditBox = Size(100,25);
        fixIpad = 0.5;
    }
    
    labelTitleNguoiChoi = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("sticker").c_str(), "fonts/NunitoSans-Bold.ttf", fontTitle);
    labelTitleNguoiChoi->setHorizontalAlignment(TextHAlignment::CENTER);
    labelTitleNguoiChoi->setPosition(Vec2(w/2, h * 0.75));
    this->addChild(labelTitleNguoiChoi, 13);
    
    auto bgSprite = ui::Scale9Sprite::create();
    bgSprite->setContentSize(sizeOfEditBox);
    bgSprite->setColor(Color3B::WHITE);  // nền trắng
    bgSprite->setOpacity(255);
    nameEditBox = ui::EditBox::create(sizeOfEditBox, bgSprite);
    //nameEditBox->setPosition(Vec2(w/ 2, h / 2));
    nameEditBox->setFontColor(Color3B::BLACK);
    nameEditBox->setMaxLength(20);
    nameEditBox->setFontSize(fontTitle);
    nameEditBox->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    nameEditBox->setInputMode(ui::EditBox::InputMode::SINGLE_LINE);
    nameEditBox->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    
    auto tenNguoiChoi = UserDefault::getInstance()->getStringForKey("ten-nguoi-choi");
    nameEditBox->setText(tenNguoiChoi.c_str());
    // Tự động focus:
    nameEditBox->openKeyboard();
    
    float paddingX = 30 * fixIpad, paddingY = 5 * fixIpad;
    Size bgSize(nameEditBox->getContentSize().width + paddingX,
                nameEditBox->getContentSize().height + paddingY);
    auto bg = DrawNode::create();
    HuyFunctions().drawSolidRoundedRect(bg, Vec2::ZERO, bgSize, bgSize.height / 2, Color4F(1, 1, 1, 1.0f));
    node = Node::create();
    node->addChild(bg);
    node->addChild(nameEditBox);
    nameEditBox->setPosition(Vec2(bgSize.width * 0.5f, bgSize.height * 0.5f));
    this->addChild(node, 12);
    node->setPosition(w/2 - bgSize.width / 2, labelTitleNguoiChoi->getPositionY() - h / 7);
    
    labelErr = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LOI_DIEN_TEN").c_str(), "fonts/NunitoSans-Bold.ttf", fontTitle * 0.7);
    labelErr->setHorizontalAlignment(TextHAlignment::CENTER);
    labelErr->setColor(Color3B::RED);
    labelErr->setPosition(Vec2(w/2, node->getPositionY() - labelErr->getContentSize().height));
    this->addChild(labelErr, 13);
    labelErr->setVisible(false);
    
    //create claim button
    okButton = ui::Button::create("button-claim.png", "button-claim.png"); // tao button
    float ratioButtonClaim = 4.5;
    if (h / w <= 1.53)
    {
        ratioButtonClaim = 9;
    }
    //auto okButtonHeight = okButton->getContentSize().height;
    auto okButtonWidth = okButton->getContentSize().width;

    float scaleokButton = w / ratioButtonClaim / okButtonWidth;
    okButton->setScale(scaleokButton);
    okButton->setPosition(Vec2(w/2, labelErr->getPositionY() - h / 10));
    okButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                inputTenHandle(w, h);

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(okButton, 12);//add button vao scene
    
    
}
void Sticker::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
void Sticker::inputTenHandle(float w, float h) {
    std::string name = HuyFunctions().trim(nameEditBox->getText());
    log("hien thi ten: %s", name.c_str());
    if (name == "") {
        labelErr->setVisible(true);
    }else{
        labelErr->setVisible(false);
        log("Tên cua ban: %s", name.c_str());
        UserDefault::getInstance()->setStringForKey("ten-nguoi-choi", name);
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
    }
    
    
}
