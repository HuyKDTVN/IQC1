#include "learnSelect.h"
#include "HelloWorldScene.h"
#include "learning.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "AdmobHelper.h"
#include <SimpleAudioEngine.h>
#include "Huy_functions/HuyFunctions.hpp"

USING_NS_CC;
float wSceneLearnSelect;
float hSceneLearnSelect;
int soundLearnSelect;
Scene* LearnSelect::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = LearnSelect::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool LearnSelect::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    wSceneLearnSelect = visibleSize.width;
    hSceneLearnSelect = visibleSize.height;

    soundLearnSelect = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
    //set bg
    createBg();
    createTite(wSceneLearnSelect, hSceneLearnSelect);
    createTwoButton();
    back();


    //this->setKeypadEnabled(true);
    return true;
}
void LearnSelect::createBg() {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    auto imageName = "bg-kid-top-3.png";
    if (hSceneLearnSelect / wSceneLearnSelect <= 1.53)
    {
        imageName = "bg-top-ipad.png";
        
    }
    auto bgTopKid = ui::Button::create(imageName); // tao button
    float ratioButtonkidTop = 1;
    float scaleButtonKidTop = wSceneLearnSelect / ratioButtonkidTop / bgTopKid->getContentSize().width;
    bgTopKid->setScale(scaleButtonKidTop);
    float yButtonKidTop = hSceneLearnSelect - bgTopKid->getContentSize().height / 2 * scaleButtonKidTop;
    float xButtonKidTop = bgTopKid->getContentSize().width / 2 * scaleButtonKidTop;
    bgTopKid->setPosition(Vec2(xButtonKidTop, yButtonKidTop));
    bgTopKid->setEnabled(false);
    this->addChild(bgTopKid);//add button vao scene
    
    auto imageNameBottom = "bg-kid.png";
    if (hSceneLearnSelect / wSceneLearnSelect <= 1.53)
    {
        imageNameBottom = "bg-bottom-ipad.png";
    }
    
    auto bgKid = ui::Button::create(imageNameBottom); // tao button
    float ratioButtonkid = 1;
    float scaleButtonKid = wSceneLearnSelect / ratioButtonkid / bgKid->getContentSize().width;
    bgKid->setScale(scaleButtonKid);
    float yButtonKid = 0 + bgKid->getContentSize().height / 2 * scaleButtonKid;
    float xButtonKid = 0 + bgKid->getContentSize().width / 2 * scaleButtonKid;
    bgKid->setPosition(Vec2(xButtonKid, yButtonKid));
    bgKid->setEnabled(false);
    this->addChild(bgKid);//add button vao scene
}
void LearnSelect::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}

void LearnSelect::back(){
    
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (hSceneLearnSelect / wSceneLearnSelect <= 1.53)
    {
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wSceneLearnSelect / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hSceneLearnSelect - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                //CCLOG("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
void LearnSelect::createTwoButton(){
    
    CCLOG(" soundLearnSelect %i", soundLearnSelect);
    auto buttonLearn = ui::Button::create("button-chia2.png", "button-chia2.png"); // tao button
    float ratioButtonLearn = 1.2;
    if (hSceneLearnSelect / wSceneLearnSelect <= 1.53)
    {
        ratioButtonLearn = 2.4;
    }

    float scaleButtonLearn = wSceneLearnSelect / ratioButtonLearn / buttonLearn->getContentSize().width;
    buttonLearn->setScale(scaleButtonLearn);
    float yButtonLearn = 50 + buttonLearn->getContentSize().height / 2 * scaleButtonLearn;
    buttonLearn->setPosition(Vec2(wSceneLearnSelect  / 2, yButtonLearn));
    buttonLearn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundLearnSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                //CCLOG("Button learn touch");
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                                AdmobHelper::showAds();
                                AdmobHelper::loadAds();
                #endif
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Learning::createScene(false, 2), Color3B().WHITE));
                });

                

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
       
    });
    addChild(buttonLearn);//add button vao scene


    //button Play
    auto buttonPlay = ui::Button::create("nhan-hoc.png", "nhan-hoc.png"); // tao button
    float ratioButtonPlay = 1.2;
    if (hSceneLearnSelect / wSceneLearnSelect <= 1.53)
    {
        ratioButtonPlay = 2.4;
    }

    float scaleButtonPlay = wSceneLearnSelect / ratioButtonPlay / buttonPlay->getContentSize().width;
    buttonPlay->setScale(scaleButtonPlay);
    float yButtonPlay = 0.1 * wSceneLearnSelect + yButtonLearn + buttonPlay->getContentSize().height * scaleButtonPlay;
    if (hSceneLearnSelect / wSceneLearnSelect <= 1.53)
    {
        yButtonPlay = 0.05 * wSceneLearnSelect + yButtonLearn + buttonPlay->getContentSize().height * scaleButtonPlay;
    }
    buttonPlay->setPosition(Vec2(wSceneLearnSelect / 2, yButtonPlay));
    buttonPlay->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundLearnSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //redirect to play
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    AdmobHelper::showAds();
                    AdmobHelper::loadAds();
                #endif
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Learning::createScene(true, 2), Color3B().WHITE));
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
        
       
        
    });
    addChild(buttonPlay);//add button vao scene
    
    
    //animation show buttonPlay
    float time = 0.2;
    buttonPlay->runAction(Spawn::create(FadeOut::create(0), nullptr));
    buttonPlay->runAction(Sequence::create(DelayTime::create(0.3), FadeIn::create(time), nullptr));
    
    buttonLearn->runAction(Spawn::create(FadeOut::create(0), nullptr));
    buttonLearn->runAction(Sequence::create(DelayTime::create(0.6), FadeIn::create(time), nullptr));
    
}
void LearnSelect::createTite(float w, float h){
    //create bg color
    auto bgColor = ui::Button::create("bg-app.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    float fontSize = 0.12 * w;
    auto title = ui::Button::create("bg-title.png"); // tao button
    title->setPressedActionEnabled(true);
    title->setZoomScale(-0.1f);
    title->setScale9Enabled(true);
    title->setTitleText(LanguageManager::getInstance()->getStringForKey("SELECTLEARN").c_str());
    if(appLang == "en" || appLang == "vi"){
        title->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }

    title->setTitleColor(Color3B().WHITE);
    title->setTouchEnabled(false);
    float ratiotitle = 1;
    if (h / w <= 1.53)
    {
        fontSize = 0.06 * w;
        
        
    }
    float scaletitle = w / ratiotitle / title->getContentSize().width;
    title->setScale(scaletitle);
    title->setTitleFontSize(fontSize / scaletitle);

    if (appLang == "ja")
    {
        title->setTitleFontName("fonts/KosugiMaru.ttf");
        title->setTitleFontSize(0.09 * w / scaletitle);
    }
    float ytitle = h - (title->getContentSize().height / 2 * scaletitle);
    if (h / w <= 1.53)
    {
        ytitle = h * 1.2 - (title->getContentSize().height / 2 * scaletitle);
        if (appLang == "ja")
        {
            
            title->setTitleFontSize(0.05 * w / scaletitle);
        }
    }

    title->setPosition(Vec2(w / 2, ytitle));
    title->setEnabled(true);
    addChild(title);
    
}
