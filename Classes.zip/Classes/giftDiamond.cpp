//
//  giftDiamond.cpp
//  mentalmath
//
//  Created by Huy Le on 30/12/24.
//

#include "giftDiamond.hpp"
#include "HelloWorldScene.h"
#include "ui/CocosGUI.h"
#include "Huy_functions/HuyFunctions.hpp"
#include <SimpleAudioEngine.h>
#include <iostream>
USING_NS_CC;



cocos2d::ui::Button* bgColorDiamond;
cocos2d::Label* valueTongDiemDiamond;
cocos2d::ui::Button* buttonAdd1Dimond;

Scene* GiftDiamond::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = GiftDiamond::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool GiftDiamond::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;

    
    
    //set bg
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    createBg(wScene, hScene);
    createTemplate(wScene, hScene);
    HuyFunctions().requestRewardedAdDiamond();
    createLabel(wScene, hScene);
    
    back(wScene, hScene);
    
    soLanChayHam = 0;
    soLanChayHamAddGold = 0;
    this->schedule(CC_SCHEDULE_SELECTOR(GiftDiamond::updateEverySecondToLoadAds), 1.0f);
    return true;
}

void GiftDiamond::updateEverySecondToLoadAds(float dt) {
    if (soLanChayHamAddGold == 0) {
        int didLoadAds = UserDefault::getInstance()->getIntegerForKey("loadadsgift", 0);
        if (didLoadAds == 1) {
            showButtonAdd200();
            soLanChayHam = 10;
            soLanChayHamAddGold = 1;
        }
        log("so lan chay ham update lien tuc %d, da load ads chua: %d", soLanChayHam, didLoadAds);
    }
    if (soLanChayHam >= 10) { // Điều kiện dừng, ví dụ a == 10
        if (soLanChayHamAddGold == 0) {
            // Hủy bỏ schedule
            this->unschedule(CC_SCHEDULE_SELECTOR(GiftDiamond::updateEverySecondToLoadAds));
            log("Stopped scheduling because cannot load Ads");
        } else {
            
            int didCloseAds = UserDefault::getInstance()->getIntegerForKey("addgoldadsgift", 0);
            if (didCloseAds == 1) {
                addGold();
                
                soLanChayHamAddGold = 1000;
            }
            log("so lan chay ham update lien tuc truoc khi close Ads by User %d, da load ads chua: %d", soLanChayHamAddGold, didCloseAds);
            if (soLanChayHamAddGold == 1000) {
                this->unschedule(CC_SCHEDULE_SELECTOR(GiftDiamond::updateEverySecondToLoadAds));
                log("Stopped scheduling because User close Ads Popup (Add gold)");
            }
            
            soLanChayHamAddGold++;
        }
        
    }

    // Tăng giá trị của a hoặc thực hiện công việc khác
    soLanChayHam++;
}

void GiftDiamond::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bg = ui::Button::create("bg-blurr.jpg"); // tao button
    bg->setTouchEnabled(false);
    float ratiobg = 1;
    float scalebg = hScene / ratiobg / bg->getContentSize().height;
    if(scalebg < wScene / ratiobg / bg->getContentSize().width) {
        scalebg = wScene / ratiobg / bg->getContentSize().width;
    }
    //log("ti le test: %f", scalebg);
    //log("ti le test theo w: %f", w / ratiobg / bg->getContentSize().width);
    bg->setScale(scalebg);
    bg->setAnchorPoint(Vec2(0, 0));
    bg->setPosition(Vec2(0, 0));
    bg->setEnabled(true);
    addChild(bg, 0);
    log("hien thi Gift screen");
}
void GiftDiamond::createLabel(float w, float h) {
    float fontSize = 0.1 * w;
    float fixIpad = 1;
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    int iHighScore = UserDefault::getInstance()->getIntegerForKey("diamond", 0);
    auto labelHightScore = cocos2d::__String::createWithFormat("%i", iHighScore);
    valueTongDiemDiamond = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize);
    valueTongDiemDiamond->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    auto xValueScore = w / 2;
    auto yValueScore = bgColorDiamond->getPositionY() + bgColorDiamond->getContentSize().height * bgColorDiamond->getScale() / 8;
    log("yValueScore: %f, %f", yValueScore, h);
    if (h/ w <= 1.53)
    {
        fontSize = 0.05 * w;
        fixIpad = 0.5;
    }
    valueTongDiemDiamond->setPosition(Vec2(xValueScore, yValueScore));
    valueTongDiemDiamond->setAnchorPoint({0.5, 0.5});
    addChild(valueTongDiemDiamond, 1);
    
    valueTongDiemDiamond->setOpacity(0);
    valueTongDiemDiamond->runAction(
        Sequence::create(
            DelayTime::create(1),
              Spawn::create(
                    FadeIn::create(0.2),
                    ScaleTo::create(0.2, 1.2 * fixIpad), nullptr),
              ScaleTo::create(0.05, 1 * fixIpad), nullptr)
    );
}
void GiftDiamond::createTemplate(float w, float h) {
    bgColorDiamond = ui::Button::create("cardDiamond.png"); // tao button
    bgColorDiamond->setTouchEnabled(false);
    float ratiobgColorDiamond = 1.3;
    if (h / w <= 1.53)
    {
        ratiobgColorDiamond = 2.6;
    }
    float scalebgColorDiamond = w / ratiobgColorDiamond / bgColorDiamond->getContentSize().width;
    
    //log("ti le test: %f", scalebgColorDiamond);
    //log("ti le test theo w: %f", w / ratiobgColorDiamond / bgColorDiamond->getContentSize().width);
    bgColorDiamond->setScale(scalebgColorDiamond);
    bgColorDiamond->setAnchorPoint(Vec2(0.5, 0.5));
    bgColorDiamond->setPosition(Vec2(w / 2, h / 2));
    bgColorDiamond->setEnabled(true);
    this->addChild(bgColorDiamond, 0);
    
    bgColorDiamond->setOpacity(0);
    bgColorDiamond->runAction(
        Sequence::create(
                         DelayTime::create(0.5),
              Spawn::create(
                    FadeIn::create(0.2),
                    ScaleTo::create(0.2, 1.1 * scalebgColorDiamond), nullptr),
              ScaleTo::create(0.05, 1 * scalebgColorDiamond), nullptr)
    );
}
void GiftDiamond::createButtonAdd200(float w, float h) {
    buttonAdd1Dimond = ui::Button::create("addDiamond.png"); // tao button
    buttonAdd1Dimond->setTouchEnabled(true);
    //auto tongDiem = HuyFunctions().getSoVang();
    
    //auto labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (tongDiem + 200 ));
    //buttonAdd1Dimond->setName(labelScoreAdd200->getCString());
    float ratiobuttonAdd1Dimond = 2;
    float fixHeightIphone = h / 23;
    if (h / w <= 1.8)
    {
        //ratiobuttonAdd1Dimond = 2;
        //fixHeightIphone = h / 40;
    }
    if (h / w <= 1.53)
    {
        ratiobuttonAdd1Dimond = 4;
        fixHeightIphone = h / 23;
    }
    float scalebuttonAdd1Dimond = w / ratiobuttonAdd1Dimond / buttonAdd1Dimond->getContentSize().width;
    buttonAdd1Dimond->setScale(scalebuttonAdd1Dimond);
    buttonAdd1Dimond->setAnchorPoint({0.5, 0});
    if (buttonAdd1Dimond) {
        buttonAdd1Dimond->setPosition(Vec2(w / 2,  bgColorDiamond->getPositionY() - bgColorDiamond->getContentSize().height * bgColorDiamond->getScale() / 2 + 30));
        
        //log("tong diem %d, vitri x: %f, y: %f, width: %f, height: %f", tongDiem, buttonAdd1Dimond->getPositionX(), buttonAdd1Dimond->getPositionY(), buttonAdd1Dimond->getContentSize().width * scalebuttonAdd1Dimond, buttonAdd1Dimond->getContentSize().height * scalebuttonAdd1Dimond);
        
        buttonAdd1Dimond->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    HuyFunctions().showRewardedAdDiamond();
                    buttonAdd1Dimond->setOpacity(0);
                    //buttonAdd1Dimond->setScale(0.8);
                    buttonAdd1Dimond->setEnabled(false);
                    //removeChild(buttonAdd1Dimond);
                    //valueTongDiemDiamond->setOpacity(0);
                    //removeChild(valueTongDiemDiamond);
                    
                    //addGold();
                    
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
            }
        });
        
        this->addChild(buttonAdd1Dimond, 100);//add button vao scene
        buttonAdd1Dimond->setOpacity(0);
        //buttonAdd1Dimond->runAction(Spawn::create(FadeOut::create(0), nullptr));
        float scale = buttonAdd1Dimond->getScale();
        log("do dai: %f", scale);
        buttonAdd1Dimond->runAction(
            Sequence::create(
                  Spawn::create(
                    FadeIn::create(0.3),
                    ScaleTo::create(0.3, 1.1 * scale), nullptr),
                  ScaleTo::create(0.1, 1 * scale), nullptr)
        );
        
        //buttonAdd1Dimond->runAction(Sequence::create(DelayTime::create(3), FadeIn::create(0.2), nullptr));
    }
}

void GiftDiamond::showButtonAdd200() {
    
    log("test do lon man hinh %f x %f", wScene, hScene);
    createButtonAdd200(wScene, hScene);
}
void GiftDiamond::addGold() {
     //Kiểm tra null pointerfloat fontSize = 0.1 * w;
//    float w = Director::getInstance()->getVisibleSize().width;
//    float fontSize = 0.1 * w;
//    auto fontStyle = "fonts/BraahOne-Regular.ttf";
//    auto tongDiem = HuyFunctions().getSoVang();
//    auto labelTongDiem = cocos2d::__String::createWithFormat("%i", tongDiem);
//    valueTongDiemDiamond = Label::createWithTTF(labelTongDiem->getCString(), fontStyle, fontSize);
//    addChild(valueTongDiemDiamond);
    if (valueTongDiemDiamond == nullptr) {
        //  OcreateLabel(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
        
        return;
    }
    if ( !buttonAdd1Dimond) {
        log("buttonAdd1Dimond is null");
        return;
    }

    //log("Starting the add gold effect");
    
    float delayAnimationDesc = 0.3;
    float timeAnimation = 0.3;
    
    int soVang = UserDefault::getInstance()->getIntegerForKey("diamond", 0);
    HuyFunctions().saveDiamondToDBAndGameCenterAchievement(0);
    std::string sdString = std::to_string(soVang);
    if (auto label = dynamic_cast<cocos2d::Label*>(valueTongDiemDiamond)) {
        // valueTongDiemDiamond là một đối tượng Label
        label->setString(sdString);
    } else {
        // valueTongDiemDiamond không phải là một đối tượng Label
        log("valueTongDiemDiamond is not a Label");
    }
    
   
    if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0) {
        valueTongDiemDiamond->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc + timeAnimation), CallFunc::create([&]() {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        })));
    }

    valueTongDiemDiamond->runAction(Sequence::create(
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 2),
              FadeOut::create(timeAnimation / 1.2), nullptr),
          nullptr)

    );
 
    valueTongDiemDiamond->runAction(Sequence::create(
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 2),
              FadeOut::create(timeAnimation / 1.2), nullptr),
                                              
          DelayTime::create(delayAnimationDesc),
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 0.8),
              FadeIn::create(timeAnimation / 1.2), nullptr),
          DelayTime::create(0.1),
          ScaleTo::create(timeAnimation / 1, 1),
          nullptr)
    );
   
    
}

void GiftDiamond::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
