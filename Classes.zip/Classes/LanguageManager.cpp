#include "LanguageManager.h"
#include "cocos2d.h"

using namespace cocos2d;

LanguageManager* LanguageManager::_instance = 0;


LanguageManager::LanguageManager()
{
	auto languageCurrent = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");

    CCLOG("ngon ngu in manager: %s", languageCurrent.c_str());
    
    _fileName = "en.json";
    
	if (languageCurrent == "en")
		_fileName = "en.json"; // english language
	else
	if (languageCurrent == "vi")
		_fileName = "vi.json"; // vietnamese language
	else
    if (languageCurrent == "de")
        _fileName = "de.json"; // vietnamese language
    else
    if (languageCurrent == "fr")
        _fileName = "fr.json"; // vietnamese language
    else
    if (languageCurrent == "id")
        _fileName = "id.json"; // vietnamese language
    else
    if (languageCurrent == "it")
        _fileName = "it.json"; // vietnamese language
    else
    if (languageCurrent == "ko")
        _fileName = "ko.json"; // vietnamese language
    else
    if (languageCurrent == "pt")
        _fileName = "pt.json"; // vietnamese language
    else
    if (languageCurrent == "ru")
        _fileName = "ru.json"; // vietnamese language
    else
    if (languageCurrent == "th")
        _fileName = "th.json"; // vietnamese language
    else
    if (languageCurrent == "tr")
        _fileName = "tr.json"; // vietnamese language
    else
    if (languageCurrent == "zh")
        _fileName = "zh.json"; // vietnamese language
    else
    if (languageCurrent == "ja")
        _fileName = "ja.json"; // Japan language
    else
    if (languageCurrent == "ca")
        _fileName = "ca.json"; // catalan language
    else
    if (languageCurrent == "cr")
        _fileName = "cr.json"; // catalan language
    else
    if (languageCurrent == "cz")
        _fileName = "cz.json"; // catalan language
    else
    if (languageCurrent == "da")
        _fileName = "da.json"; // catalan language
    else
    if (languageCurrent == "du")
        _fileName = "du.json"; // catalan language
    else
    if (languageCurrent == "fi")
        _fileName = "fi.json"; // catalan language
    else
    if (languageCurrent == "gr")
        _fileName = "gr.json"; // catalan language
    else
    if (languageCurrent == "hi")
        _fileName = "hi.json"; // catalan language
    else
    if (languageCurrent == "hu")
        _fileName = "hu.json"; // catalan language
    else
    if (languageCurrent == "ma")
        _fileName = "ma.json"; // catalan language
    else
    if (languageCurrent == "no")
        _fileName = "no.json"; // catalan language
    else
    if (languageCurrent == "po")
        _fileName = "po.json"; // catalan language
    else
    if (languageCurrent == "ro")
        _fileName = "ro.json"; // catalan language
    else
    if (languageCurrent == "sk")
        _fileName = "sk.json"; // catalan language
    else
    if (languageCurrent == "sw")
        _fileName = "sw.json"; // catalan language
    else
    if (languageCurrent == "sw")
        _fileName = "sw.json"; // catalan language
    else
    if (languageCurrent == "sp")
        _fileName = "sp.json"; // catalan language
    else
    if (languageCurrent == "uk")
        _fileName = "uk.json"; // catalan language
    else
		_fileName = "en.json"; // default languge
    
	ssize_t size;
	//const char* buf = (const char*)FileUtils::getInstance()->getFileData(_fileName.c_str(), "r", &size);
    auto buf = FileUtils::getInstance()->getStringFromFile(_fileName.c_str());
	string content(buf);
	string clearContent = content.substr(0, content.rfind('}') + 1);

	_document.Parse<0>(clearContent.c_str());
}

LanguageManager::~LanguageManager()
{
	
}

LanguageManager* LanguageManager::getInstance()
{
	if (!_instance)
		_instance = new LanguageManager();
	return _instance;
}
LanguageManager* LanguageManager::getInstanceRestart()
{
	//if (!_instance)
		_instance = new LanguageManager();
	return _instance;
}

string LanguageManager::getStringForKey(string key) const
{
   string result;
   result = key.c_str();
   if(_document.HasMember(key.c_str())) {
      result = _document[key.c_str()].GetString();
   }
   
   return result;
}
