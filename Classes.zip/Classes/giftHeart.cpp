//
//  giftHeart.cpp
//  mentalmath
//
//  Created by Huy Le on 30/12/24.
//

#include "giftHeart.hpp"
#include "HelloWorldScene.h"
#include "ui/CocosGUI.h"
#include "Huy_functions/HuyFunctions.hpp"
#include <SimpleAudioEngine.h>
#include <iostream>
USING_NS_CC;



cocos2d::ui::Button* bgColorHeart;
cocos2d::Label* valueTongDiemHeart;
cocos2d::ui::Button* buttonAddHeart;

Scene* GiftHeart::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = GiftHeart::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool GiftHeart::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;

    
    
    //set bg
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    createBg(wScene, hScene);
    createTemplate(wScene, hScene);
    HuyFunctions().requestRewardedAdHeart();
    createLabel(wScene, hScene);
    
    back(wScene, hScene);
    
    soLanChayHam = 0;
    soLanChayHamAddGold = 0;
    this->schedule(CC_SCHEDULE_SELECTOR(GiftHeart::updateEverySecondToLoadAds), 1.0f);
    return true;
}

void GiftHeart::updateEverySecondToLoadAds(float dt) {
    if (soLanChayHamAddGold == 0) {
        int didLoadAds = UserDefault::getInstance()->getIntegerForKey("loadadsgift", 0);
        if (didLoadAds == 1) {
            showButtonAdd200();
            soLanChayHam = 10;
            soLanChayHamAddGold = 1;
        }
        log("so lan chay ham update lien tuc %d, da load ads chua: %d", soLanChayHam, didLoadAds);
    }
    if (soLanChayHam >= 10) { // Điều kiện dừng, ví dụ a == 10
        if (soLanChayHamAddGold == 0) {
            // Hủy bỏ schedule
            this->unschedule(CC_SCHEDULE_SELECTOR(GiftHeart::updateEverySecondToLoadAds));
            log("Stopped scheduling because cannot load Ads");
        } else {
            
            int didCloseAds = UserDefault::getInstance()->getIntegerForKey("addgoldadsgift", 0);
            if (didCloseAds == 1) {
                addGold();
                
                soLanChayHamAddGold = 1000;
            }
            log("so lan chay ham update lien tuc truoc khi close Ads by User %d, da load ads chua: %d", soLanChayHamAddGold, didCloseAds);
            if (soLanChayHamAddGold == 1000) {
                this->unschedule(CC_SCHEDULE_SELECTOR(GiftHeart::updateEverySecondToLoadAds));
                log("Stopped scheduling because User close Ads Popup (Add gold)");
            }
            
            soLanChayHamAddGold++;
        }
        
    }

    // Tăng giá trị của a hoặc thực hiện công việc khác
    soLanChayHam++;
}

void GiftHeart::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bg = ui::Button::create("bg-blurr.jpg"); // tao button
    bg->setTouchEnabled(false);
    float ratiobg = 1;
    float scalebg = hScene / ratiobg / bg->getContentSize().height;
    if(scalebg < wScene / ratiobg / bg->getContentSize().width) {
        scalebg = wScene / ratiobg / bg->getContentSize().width;
    }
    //log("ti le test: %f", scalebg);
    //log("ti le test theo w: %f", w / ratiobg / bg->getContentSize().width);
    bg->setScale(scalebg);
    bg->setAnchorPoint(Vec2(0, 0));
    bg->setPosition(Vec2(0, 0));
    bg->setEnabled(true);
    addChild(bg, 0);
    log("hien thi Gift screen");
}
void GiftHeart::createLabel(float w, float h) {
    float fontSize = 0.1 * w;
    float fixIpad = 1;
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    int soNgayChoiInt = UserDefault::getInstance()->getIntegerForKey("songay", 0);
    auto soNgayChoi = cocos2d::__String::createWithFormat("%i", soNgayChoiInt);
    valueTongDiemHeart = Label::createWithTTF(soNgayChoi->getCString(), fontStyle, fontSize);
    valueTongDiemHeart->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    auto xValueScore = w * 0.51;
    auto yValueScore = bgColorHeart->getPositionY() + bgColorHeart->getContentSize().height * bgColorHeart->getScale() / 8;
    log("yValueScore: %f, %f", yValueScore, h);
    if (h/ w <= 1.53)
    {
        fontSize = 0.05 * w;
        fixIpad = 0.5;
    }
    valueTongDiemHeart->setPosition(Vec2(xValueScore, yValueScore));
    valueTongDiemHeart->setAnchorPoint({0.5, 0.5});
    addChild(valueTongDiemHeart, 1);
    
    valueTongDiemHeart->setOpacity(0);
    valueTongDiemHeart->runAction(
        Sequence::create(
            DelayTime::create(1),
              Spawn::create(
                    FadeIn::create(0.2),
                    ScaleTo::create(0.2, 1.2 * fixIpad), nullptr),
              ScaleTo::create(0.05, 1 * fixIpad), nullptr)
    );
}
void GiftHeart::createTemplate(float w, float h) {
    bgColorHeart = ui::Button::create("cardHeart.png"); // tao button
    bgColorHeart->setTouchEnabled(false);
    float ratiobgColorHeart = 1.3;
    if (h / w <= 1.53)
    {
        
        ratiobgColorHeart = 2.6;
    }
    float scalebgColorHeart = w / ratiobgColorHeart / bgColorHeart->getContentSize().width;
    
    //log("ti le test: %f", scalebgColorHeart);
    //log("ti le test theo w: %f", w / ratiobgColorHeart / bgColorHeart->getContentSize().width);
    bgColorHeart->setScale(scalebgColorHeart);
    bgColorHeart->setAnchorPoint(Vec2(0.5, 0.5));
    bgColorHeart->setPosition(Vec2(w / 2, h / 2));
    bgColorHeart->setEnabled(true);
    this->addChild(bgColorHeart, 0);
    
    bgColorHeart->setOpacity(0);
    bgColorHeart->runAction(
        Sequence::create(
                         DelayTime::create(0.5),
              Spawn::create(
                    FadeIn::create(0.2),
                    ScaleTo::create(0.2, 1.1 * scalebgColorHeart), nullptr),
              ScaleTo::create(0.05, 1 * scalebgColorHeart), nullptr)
    );
}
void GiftHeart::createButtonAdd200(float w, float h) {
    buttonAddHeart = ui::Button::create("addHeart.png"); // tao button
    buttonAddHeart->setTouchEnabled(true);
//    auto tongDiem = HuyFunctions().getSoVang();
//    
//    auto labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (tongDiem + 200 ));
//    buttonAddHeart->setName(labelScoreAdd200->getCString());
    float ratiobuttonAddHeart = 2;
    float fixHeightIphone = h / 23;
    if (h / w <= 1.8)
    {
        //ratiobuttonAddHeart = 2;
        //fixHeightIphone = h / 40;
    }
    if (h / w <= 1.53)
    {
        ratiobuttonAddHeart = 4;
        fixHeightIphone = h / 23;
    }
    float scalebuttonAddHeart = w / ratiobuttonAddHeart / buttonAddHeart->getContentSize().width;
    buttonAddHeart->setScale(scalebuttonAddHeart);
    buttonAddHeart->setAnchorPoint({0.5, 0});
    if (bgColorHeart) {
        buttonAddHeart->setPosition(Vec2(w / 2,  bgColorHeart->getPositionY() - bgColorHeart->getContentSize().height * bgColorHeart->getScale() / 2 + 30));
        //log("tong diem %d, vitri x: %f, y: %f, width: %f, height: %f", tongDiem, buttonAddHeart->getPositionX(), buttonAddHeart->getPositionY(), buttonAddHeart->getContentSize().width * scalebuttonAddHeart, buttonAddHeart->getContentSize().height * scalebuttonAddHeart);
        
        buttonAddHeart->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    HuyFunctions().showRewardedAdHeart();
                    buttonAddHeart->setOpacity(0);
                    //buttonAddHeart->setScale(0.8);
                    buttonAddHeart->setEnabled(false);
                    //removeChild(buttonAddHeart);
                    //valueTongDiemHeart->setOpacity(0);
                    //removeChild(valueTongDiemHeart);
                    
                    //addGold();
                    
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
            }
        });
        
        this->addChild(buttonAddHeart, 100);//add button vao scene
        buttonAddHeart->setOpacity(0);
        //buttonAddHeart->runAction(Spawn::create(FadeOut::create(0), nullptr));
        float scale = buttonAddHeart->getScale();
        log("do dai: %f", scale);
        buttonAddHeart->runAction(
            Sequence::create(
                  Spawn::create(
                    FadeIn::create(0.3),
                    ScaleTo::create(0.3, 1.1 * scale), nullptr),
                  ScaleTo::create(0.1, 1 * scale), nullptr)
        );
        
        //buttonAddHeart->runAction(Sequence::create(DelayTime::create(3), FadeIn::create(0.2), nullptr));
    }
    
    
    
}

void GiftHeart::showButtonAdd200() {
    
    log("test do lon man hinh %f x %f", wScene, hScene);
    createButtonAdd200(wScene, hScene);
}
void GiftHeart::addGold() {
     //Kiểm tra null pointerfloat fontSize = 0.1 * w;
//    float w = Director::getInstance()->getVisibleSize().width;
//    float fontSize = 0.1 * w;
//    auto fontStyle = "fonts/BraahOne-Regular.ttf";
//    auto tongDiem = HuyFunctions().getSoVang();
//    auto labelTongDiem = cocos2d::__String::createWithFormat("%i", tongDiem);
//    valueTongDiemHeart = Label::createWithTTF(labelTongDiem->getCString(), fontStyle, fontSize);
//    addChild(valueTongDiemHeart);
    if (valueTongDiemHeart == nullptr) {
        //  OcreateLabel(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
        
        return;
    }
    if ( !buttonAddHeart) {
        log("buttonAddHeart is null");
        return;
    }

    //log("Starting the add gold effect");
    
    float delayAnimationDesc = 0.3;
    float timeAnimation = 0.3;
    
    int soVang = UserDefault::getInstance()->getIntegerForKey("songay", 0);
    HuyFunctions().saveHeartToDBAndGameCenterAchievement(false);
    
    std::string sdString = std::to_string(soVang);
    if (auto label = dynamic_cast<cocos2d::Label*>(valueTongDiemHeart)) {
        // valueTongDiemHeart là một đối tượng Label
        label->setString(sdString);
    } else {
        // valueTongDiemHeart không phải là một đối tượng Label
        log("valueTongDiemHeart is not a Label");
    }
    
   
    if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0) {
        valueTongDiemHeart->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc + timeAnimation), CallFunc::create([&]() {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        })));
    }

    valueTongDiemHeart->runAction(Sequence::create(
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 2),
              FadeOut::create(timeAnimation / 1.2), nullptr),
          nullptr)

    );
 
    valueTongDiemHeart->runAction(Sequence::create(
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 2),
              FadeOut::create(timeAnimation / 1.2), nullptr),
                                              
          DelayTime::create(delayAnimationDesc),
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 0.8),
              FadeIn::create(timeAnimation / 1.2), nullptr),
          DelayTime::create(0.1),
          ScaleTo::create(timeAnimation / 1, 1),
          nullptr)
    );

}

void GiftHeart::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
