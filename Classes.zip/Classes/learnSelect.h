#ifndef __LEARNSELECT_H__
#define __LEARNSELECT_H__

#include "cocos2d.h"

class LearnSelect : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    void createBg();
    void createTwoButton();
	void back();
	void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
	void createTite(float w, float h);
    
    // implement the "static create()" method manually
	CREATE_FUNC(LearnSelect);
};

#endif // __LEARNSELECT_H__
