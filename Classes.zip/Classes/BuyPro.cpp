//
//  BuyPro.cpp
//  mentalmath
//
//  Created by Huy Le on 23/8/25.
//

#include "BuyPro.hpp"
#include "Onboarding5.hpp"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "HelloWorldScene.h"
#include "Huy_functions/HuyFunctions.hpp"
#include "Variable.hpp"
#include "mathSelect.h"
#include <string>
#include <SimpleAudioEngine.h>
#include <iostream>
#include <sstream>
#include "IAPManager.h"
#include "AllowNoti.hpp"
USING_NS_CC;

bool isOnboarding;
Scene* BuyPro::createScene(bool hasOnboarding)
{
    isOnboarding = hasOnboarding;
    auto scene = Scene::create();
    auto layer = BuyPro::create();
    scene->addChild(layer);
    return scene;
}

bool BuyPro::init()
{
    if (!Layer::init())
    {
        return false;
    }
   
   Size visibleSize = Director::getInstance()->getVisibleSize();
   //Vec2 origin = Director::getInstance()->getVisibleOrigin();
   
    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
   float wScene;
   float hScene;
   
   //khoi tao gia tri ban dau
   wScene = visibleSize.width;
   hScene = visibleSize.height;
   
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(6);
    }
    
    back(wScene, hScene);
    createBgPro(wScene, hScene);
    return true;
}

void BuyPro::onEnter() {
    Layer::onEnter();

    // Đăng ký callback khi mua thành công
    IAPManager::getInstance()->setOnPurchaseSuccess([this](std::string productID) {
        log("🎉 Mua thành công - restore thanh cong: %s", productID.c_str());
        UserDefault::getInstance()->setBoolForKey("isProVer", true);
        //Variable().isProVer = true;
        UserDefault::getInstance()->flush();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
        UserDefault::getInstance()->setBoolForKey("dachoi", true);
        UserDefault::getInstance()->flush(); // Lưu thay đổi ngay lập tức
    });

    // Đăng ký callback khi mua thất bại
    IAPManager::getInstance()->setOnPurchaseFailed([this](std::string productID, std::string error) {
        log("❌ Mua thất bại: %s | Lỗi: %s", productID.c_str(), error.c_str());
        //this->finish();
        UserDefault::getInstance()->setBoolForKey("dachoi", true);
        UserDefault::getInstance()->flush(); // Lưu thay đổi ngay lập tức
        
    });
    
    // Đăng ký callback lấy giá
    IAPManager::getInstance()->setOnPriceRetrieved([this](std::string productID, std::string price) {
        log("📦 Giá của %s là: %s", productID.c_str(), price.c_str());
        // Gợi ý: update label nút mua
        //this->price->setString(price.c_str());
        UserDefault::getInstance()->setStringForKey("gia", price.c_str());
    });

    // Yêu cầu lấy giá từ App Store
    IAPManager::getInstance()->requestProductInfo(Variable().proProductionID);
}

void BuyPro::createBgPro(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg01.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    LanguageManager::getInstanceRestart();
    
//    auto bgTexture = Director::getInstance()->getTextureCache()->addImage("bg-nen-tet.png");
//
//    // Set texture parameters to repeat
//    Texture2D::TexParams texParams = { GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_REPEAT };
//    bgTexture->setTexParameters(texParams);
//
//    // Create a sprite with repeated texture
//    bgNenPro = Sprite::createWithTexture(bgTexture, Rect(0, 0, wScene, hScene));
//    bgNenPro->setAnchorPoint(Vec2(0, 0)); // Align to bottom-left
//    bgNenPro->setOpacity(245);
//    //bgNenPro->setOpacity(0);
//    this->addChild(bgNenPro, 100);
    
    float fontSize = 0.06 * wScene;
    float fontSizePrice = 0.09 * wScene;
    auto fontStyle = "Helvetica-Bold";
    
//    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
//    {
//        fontStyle = "fonts/KosugiMaru.ttf";
//        fontSize = 0.06 * wScene;
//    }
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.03 * wScene;
        fontSizePrice = 0.06 * wScene;
        if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
        {
           
            fontSize = 0.035 * wScene;
        }
    }
    //create title pro version
    std::string titleValue = LanguageManager::getInstance()->getStringForKey("VIP_TITLE").c_str();
    auto titlePro = Label::createWithSystemFont(titleValue, fontStyle, fontSize);
    titlePro->setColor(Color3B().YELLOW);
    titlePro->setWidth(wScene - 20);
    titlePro->setHorizontalAlignment(cocos2d::TextHAlignment::CENTER);
    // position the label on the center of the
    auto btnHeightKey = titlePro->getContentSize().height;
    double ytitlePro = hScene * 0.89;
    float ratiobgVIP = 1.1;
    if (hScene / wScene <= 1.8)
    {
        ytitlePro = hScene * 0.91;
        ratiobgVIP = 1.2;
    }
    double xtitlePro = wScene / 2;// - (btnWidthKey / 2 + 5);
    titlePro->setPosition(Vec2(xtitlePro, ytitlePro));
    // add the label as a child to this layer
    addChild(titlePro, 101);
    
    std::string title2Value = LanguageManager::getInstance()->getStringForKey("VIP_DESC").c_str();
    auto title2Pro = Label::createWithSystemFont(title2Value, fontStyle, fontSize * 0.75);
    title2Pro->setColor(Color3B().WHITE);
    title2Pro->setWidth(wScene - 20);
    title2Pro->setHorizontalAlignment(cocos2d::TextHAlignment::CENTER);
    // position the label on the center of the
    double ytitle2Pro = titlePro->getPositionY() - titlePro->getContentSize().height / 2 - title2Pro->getContentSize().height / 2 - 5;
    double xtitle2Pro = wScene / 2;// - (btnWidthKey / 2 + 5);
    title2Pro->setPosition(Vec2(xtitle2Pro, ytitle2Pro));
    // add the label as a child to this layer
    addChild(title2Pro, 101);
    
    //create PRICE
    std::string priceValue = UserDefault::getInstance()->getStringForKey("gia", "");
    auto price = Label::createWithSystemFont(priceValue, "fonts/NunitoSans-Bold.ttf", fontSizePrice);
    price->setColor(Color3B::YELLOW);
    // position the label on the center of the
    double yprice = title2Pro->getPositionY() - title2Pro->getContentSize().height /2 - price->getContentSize().height / 2 - hScene / 8;
    double xprice = wScene / 2;// - (btnWidthKey / 2 + 5);
    price->setPosition(Vec2(xprice, yprice));
    // add the label as a child to this layer
    addChild(price, 101);
    
    auto bgVIP = Sprite::create("bg-remove-ads.png");
    

    float fixHeightIpad = 20;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        fixHeightIpad = 5;
    }
    
    if (hScene / wScene <= 1.53)
    {
        ratiobgVIP = 2.2;
    }
    
    float scalebgVIP = wScene / ratiobgVIP / bgVIP->getContentSize().width;
    bgVIP->setScale(scalebgVIP);
    bgVIP->setPosition(Vec2(wScene / 2, price->getPositionY() - price->getContentSize().height / 2 - 1 - bgVIP->getContentSize().height * scalebgVIP / 2)); // Đặt vị trí
    this->addChild(bgVIP, 101);

    auto iconUnlock = Sprite::create("unlook-icon.png");
    float ratioiconUnlock = 8;
    float fixIpad = 1;
    float fixWidthIpad = 0.7;
    if (hScene / wScene <= 1.53)
    {
        ratioiconUnlock = 16;
        fixIpad = 1.5;
        fixWidthIpad = 0.65;
    }
    float scaleiconUnlock = wScene / ratioiconUnlock / iconUnlock->getContentSize().width;
    iconUnlock->setScale(scaleiconUnlock);
    iconUnlock->setPosition(Vec2(bgVIP->getPositionX() - bgVIP->getContentSize().width * scalebgVIP / 2 + iconUnlock->getContentSize().width * scaleiconUnlock / 2 + wScene / 10 / fixIpad, bgVIP->getPositionY() + bgVIP->getContentSize().height / 2 - iconUnlock->getContentSize().height * scaleiconUnlock / 2 - wScene / 9 * fixIpad)); // Đặt vị trí
    this->addChild(iconUnlock, 101);
    
    std::string titleUnlockString = LanguageManager::getInstance()->getStringForKey("UNLOCK_ALL").c_str();
    auto titleUnlock = Label::createWithSystemFont(titleUnlockString, fontStyle, fontSize * 0.75);
    titleUnlock->setColor(Color3B().WHITE);
    titleUnlock->setWidth(bgVIP->getContentSize().width * scalebgVIP * fixWidthIpad);
    //log("wd: %d",bgVIP->getContentSize().width * scalebgVIP  - iconUnlock->getContentSize().width * scaleiconUnlock / 2 - fixWidthIpad);
    //titleUnlock->setHorizontalAlignment(cocos2d::TextHAlignment::CENTER);
    double ytitleUnlock = iconUnlock->getPositionY();
    double xtitleUnlock = iconUnlock->getPositionX() + iconUnlock->getContentSize().width * scaleiconUnlock / 2 + wScene / 20 + titleUnlock->getContentSize().width / 2;
    titleUnlock->setPosition(Vec2(xtitleUnlock, ytitleUnlock));
    addChild(titleUnlock, 101);
    //==============================
    auto iconRemoveAds = Sprite::create("tv-ads.png");
    float ratioiconRemoveAds = 9;
    if (hScene / wScene <= 1.53)
    {
        ratioiconRemoveAds = 16;
    }
    float scaleiconRemoveAds = wScene / ratioiconRemoveAds / iconRemoveAds->getContentSize().width;
    iconRemoveAds->setScale(scaleiconRemoveAds);
    iconRemoveAds->setPosition(Vec2(iconUnlock->getPositionX(), iconUnlock->getPositionY() - iconUnlock->getContentSize().height * scaleiconUnlock * 1.5)); // Đặt vị trí
    this->addChild(iconRemoveAds, 101);
    
    std::string titleRemoveAdsString = LanguageManager::getInstance()->getStringForKey("REMOVE_ADS").c_str();
    auto titleRemoveAds = Label::createWithSystemFont(titleRemoveAdsString, fontStyle, fontSize * 0.75);
    titleRemoveAds->setColor(Color3B().WHITE);
    titleRemoveAds->setWidth(titleUnlock->getWidth());
    titleRemoveAds->setHorizontalAlignment(cocos2d::TextHAlignment::LEFT);
    
    titleRemoveAds->setPosition(Vec2(titleUnlock->getPositionX(), iconRemoveAds->getPositionY()));
    addChild(titleRemoveAds, 101);
    
    
    fontSize = 0.04 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.02 * wScene;
    }
    
    
    float fontSize2 = 0.06 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize2 = 0.035 * wScene;
    }
    auto upProBtn = ui::Button::create("button-pro.png");
    upProBtn->setPressedActionEnabled(true);
    upProBtn->setZoomScale(-0.1f);
    upProBtn->setScale9Enabled(true);
    upProBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("PRO_BUY").c_str());
    if(appLang == "en" || appLang == "vi"){
        upProBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    upProBtn->setTitleColor(Color3B().WHITE);
    upProBtn->setTouchEnabled(true);
    float ratiotitle = 3;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 5;
        
    }
    auto ratioUpProBtn = 2;
    if (hScene / wScene <= 1.53)
    {
        ratioUpProBtn = 3.8;
       
    }
    auto scaleUpProBtn = wScene / ratioUpProBtn / upProBtn->getContentSize().width;
    upProBtn->setScale(scaleUpProBtn);
    upProBtn->setTitleFontSize(fontSize2 / scaleUpProBtn);
    if (appLang == "ja")
    {
        upProBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        upProBtn->setTitleFontSize(0.05 * wScene / scaleUpProBtn);
    }
    auto ytitle = bgVIP->getPositionY() - bgVIP->getContentSize().height * scalebgVIP / 2 - upProBtn->getContentSize().height * scaleUpProBtn / 2 - 20;
    if (hScene / wScene <= 1.53)
    {
      
        if (appLang == "ja")
        {
            upProBtn->setTitleFontSize(0.025 * wScene / scaleUpProBtn);
        }
    }
    upProBtn->setPosition(Vec2(wScene / 2, ytitle));
    upProBtn->setEnabled(true);
    upProBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("up to pro");
                IAPManager::getInstance()->purchase(Variable().proProductionID);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(upProBtn, 101);
    float timeAnimation = 0.4;
    auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * upProBtn->getScale());
    auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.2, upProBtn->getScale() * 0.95);
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    upProBtn->runAction((RepeatForever::create(sq3)));
    
    auto restorePurchaseBtn = ui::Button::create("empty.png");
    restorePurchaseBtn->setPressedActionEnabled(true);
    restorePurchaseBtn->setZoomScale(-0.1f);
    restorePurchaseBtn->setScale9Enabled(true);
    restorePurchaseBtn->setTitleText("Restore Purchase");
    if(appLang == "en" || appLang == "vi"){
        restorePurchaseBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    restorePurchaseBtn->setTitleColor(Color3B().WHITE);
    restorePurchaseBtn->setOpacity(200);
    restorePurchaseBtn->setTouchEnabled(true);
    
    auto scalerestoreBtn = wScene / ratiotitle / restorePurchaseBtn->getContentSize().width;
    restorePurchaseBtn->setScale(scalerestoreBtn);
    restorePurchaseBtn->setTitleFontSize(fontSize / scalerestoreBtn);
    if (appLang == "ja")
    {
        restorePurchaseBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        restorePurchaseBtn->setTitleFontSize(0.045 * wScene / scalerestoreBtn);
    }
    ytitle = upProBtn->getPositionY() - upProBtn->getContentSize().height * scaleUpProBtn / 2 - 8;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        
        //ytitle = upProBtn->getPositionY() - upProBtn->getContentSize().height * scaleUpProBtn / 2 - 8;
    }
    if (hScene / wScene <= 1.53)
    {
        if (appLang == "ja")
        {
            restorePurchaseBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
        }
    }
    restorePurchaseBtn->setPosition(Vec2(wScene / 2, ytitle));
    restorePurchaseBtn->setEnabled(true);
    restorePurchaseBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("restore purchasing");
                IAPManager::getInstance()->restorePurchases();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(restorePurchaseBtn, 101);
    
//    auto bgFree = Sprite::create("picture-free.png");
//    bgFree->setScale(scalebgVIP);
//    bgFree->setPosition(Vec2(wScene / 2, restorePurchaseBtn->getPositionY() - restorePurchaseBtn->getContentSize().height / 2 - bgFree->getContentSize().height * scalebgVIP / 2 - 10)); // Đặt vị trí
//    this->addChild(bgFree, 101);
    auto preeBtn = ui::Button::create("empty.png");
    preeBtn->setPressedActionEnabled(true);
    preeBtn->setZoomScale(-0.1f);
    preeBtn->setScale9Enabled(true);
    preeBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("USE_FREE").c_str());
    if(appLang == "en" || appLang == "vi"){
        preeBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    preeBtn->setTitleColor(Color3B().WHITE);
    
    preeBtn->setTouchEnabled(true);
    
    scalerestoreBtn = wScene / ratiotitle / preeBtn->getContentSize().width;
    preeBtn->setScale(scalerestoreBtn);
    preeBtn->setTitleFontSize(fontSize * 1.3 / scalerestoreBtn);
    if (appLang == "ja")
    {
        preeBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        preeBtn->setTitleFontSize(0.065 * wScene / scalerestoreBtn);
    }
    ytitle = upProBtn->getPositionY() - upProBtn->getContentSize().height * scaleUpProBtn / 2 - 8;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        
        ytitle = 20;
    }
    if (hScene / wScene <= 1.53)
    {
        
        if (appLang == "ja")
        {
            
            preeBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
        }
    }
    preeBtn->setPosition(Vec2(wScene / 2, hScene * 0.05 + preeBtn->getContentSize().height * preeBtn->getScale() / 2 - 10));
    preeBtn->setEnabled(true);
    preeBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
                
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                HuyFunctions().animationClickedButton(button, [](){
                    if (Variable().isProduction == true) {
                        HuyFunctions().showAds();
                    }
                    if(isOnboarding) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Onboarding5::createScene(), Color3B().WHITE));
                    }else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(preeBtn, 101);
}

void BuyPro::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel), Color3B().WHITE));
}
void BuyPro::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    if (isOnboarding) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, AllowNoti::createScene(), Color3B().WHITE));
                    }else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                    }
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 101);//add button vao scene
}
