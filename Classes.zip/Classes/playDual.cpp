#include "playDual.h"
#include "mathSelect.h"
#include "finishDual.h"
#include "SelectGame.hpp"
#include "ui/CocosGUI.h"
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "Huy_functions/CreatePhepToan.hpp"
#include "LanguageManager.h"
#include "IAPManager.h"
using namespace std;
USING_NS_CC;

int d_typeOfW;
int d_levelOfW;
int d_isMulti = false;
bool fromChallengeDual;
Scene* PlayDual::createScene(int type, int level, bool fromChallenge)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    d_typeOfW = type;
    if(d_typeOfW == 1){
        d_isMulti = true;
    }
    fromChallengeDual = fromChallenge;
    d_levelOfW = level;
    // 'layer' is an autorelease object
    auto layer = PlayDual::create();
    // add layer as a child to scene
    scene->addChild(layer);
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool PlayDual::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }
    d_score = 0;
    d_scoreDup = 0;

    if (UserDefault::getInstance()->getIntegerForKey("height-score", 99999) == 99999)
    {
        UserDefault::getInstance()->setIntegerForKey(D_HIGH_SCORE, 0);
        UserDefault::getInstance()->flush();
    }
    auto mLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    d_maxDoiSo = HuyFunctions().SoLonNhat(mLang);
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;

    ratioScreenPlay = hScene / wScene;

    d_wScenePlay = wScene;
    d_hScenePlay = hScene;

    //set bg
    createBg(wScene, hScene);



    d_realType = d_typeOfW;

    back(wScene, hScene);
    //createButtonKey(wScene, hScene);

    auto arr = CreatePhepToan().createAnswerQuestions(d_typeOfW, d_levelOfW, d_prevA, d_prevB, d_maxDoiSo);
    log("test improve function");
    //    0 - prevA
    //    1 - prevB
    //    2 - phepToan
    //    3 - correctAnswer
    //    4 - answer1
    //    5 - answer2
    //    6 - answer3
    //    7 - answer4
    d_prevA = std::stoi(arr.at(0));
    d_prevB = std::stoi(arr.at(1));
    d_phepToan = cocos2d::__String::createWithFormat("%s", arr.at(2).c_str());
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", arr.at(8).c_str());
    d_correctAnswer = std::stoi(arr.at(3));
    d_answer1 = std::stoi(arr.at(4));
    d_answer2 = std::stoi(arr.at(5));
    d_answer3 = std::stoi(arr.at(6));
    d_answer4 = std::stoi(arr.at(7));
    
    log("cau hoi: %s",  arr.at(2).c_str());
    log("4 dap an: %i, %i, %i, %i",  std::stoi(arr.at(4)), std::stoi(arr.at(5)), std::stoi(arr.at(6)), std::stoi(arr.at(7)));
    log("dap dung: %i",  std::stoi(arr.at(3)));
    
    int randomImageNameDapAn = cocos2d::RandomHelper::random_int(1, 5);
    ImageNamDapAn = __String::create(StringUtils::format("button-dap-an-%d.png", randomImageNameDapAn));
    ImageNamDapAnX = __String::create(StringUtils::format("button-dap-an-%d-x.png", randomImageNameDapAn));
    ImageNamDapAnV = __String::create(StringUtils::format("button-dap-an-%d-v.png", randomImageNameDapAn));
    
    if (dualModel == false){
        //countdown timer + loading bar
        coundownTimer(wScene, hScene);
        //end: countdown timer + loading bar

        createMainTemplate(wScene, hScene);
        createAnswer(wScene, hScene);
        createScore(wScene, hScene);
    }else{
        //countdown timer + loading bar
        coundownTimer(wScene, hScene / 2 + 40);
        //end: countdown timer + loading bar

        createMainTemplate(wScene, hScene / 2  + 40);
        
        createAnswer(wScene, hScene / 2);
        createScore(wScene, hScene / 2 + 40);

    }
    //log("HUY ----- type: %i, level: %i", typeOfW, levelOfW);

    //log("hLoadingBar: %f", hLoadingBar);
    MaxNumberQuestion = 10;
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(0);
    }else{
        MaxNumberQuestion = Variable().soCauHoiDualModeTest;
    }
    //this->setKeypadEnabled(true);

    player1Choised = false;
    player2Choised = false;
    allPlayerChoised = 0;
    numQuestion = 0;
    
    return true;
}
void PlayDual::createBg(float w, float h) {
    //create bg color
    int bgIndex = cocos2d::RandomHelper::random_int(1, 4);
    auto bgColor = ui::Button::create(StringUtils::format("bg0%d.jpg", bgIndex)); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    if (h / w <= 1.53)
    {
        //ytitle = 1.3 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    //bgColor->setPosition(Vec2(w / 2, ytitle));
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));

    bgColor->setEnabled(true);
    this->addChild(bgColor, 1);
}
void PlayDual::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathLevel::createScene(typeOfW), Color3B().WHITE));
}

void PlayDual::coundownTimer(float w, float h){
    switch (d_levelOfW)
    {
        case 1:
            d_timeRemaining = Variable().timeBasic;
            d_timeMax = Variable().timeBasic;
            if (d_typeOfW == 3 || d_typeOfW == 2) {
                d_timeRemaining = Variable().timeBasicNhan;
                d_timeMax = Variable().timeBasicNhan;
            }
            break;
        case 2:
            d_timeRemaining = Variable().timeHard;
            d_timeMax = Variable().timeHard;
            if (d_typeOfW == 3 || d_typeOfW == 2) {
                d_timeRemaining = Variable().timeHardNhan;
                d_timeMax = Variable().timeHardNhan;
            }
            break;
        case 3:
            d_timeRemaining = Variable().timeVeryHard;
            d_timeMax = Variable().timeVeryHard;
            if (d_typeOfW == 3 || d_typeOfW == 2) {
                d_timeRemaining = Variable().timeVeryHardNhan;
                d_timeMax = Variable().timeVeryHardNhan;
            }
            break;
        default:
            d_timeRemaining = 20.f;
            d_timeMax = 20.f;
            break;
    }

    d_ratioLoadingBar = 100 / d_timeRemaining;

    this->scheduleUpdate();


//    switch (d_typeOfW)
//    {
//        //2 - nhan; 3 - chia; 4 - cong; 5 - tru; 1 - multi
//        case 1:
//            d_loadingBar = ui::LoadingBar::create("loadingbar-mul.png");
//            break;
//        case 2:
//            d_loadingBar = ui::LoadingBar::create("loadingbar-nhan.png");
//            break;
//        case 3:
//            d_loadingBar = ui::LoadingBar::create("loadingbar-chia.png");
//            break;
//        case 4:
//            d_loadingBar = ui::LoadingBar::create("loadingbar-cong.png");
//            break;
//        case 5:
//            d_loadingBar = ui::LoadingBar::create("loadingbar-tru.png");
//            break;
//        default:
//            d_loadingBar = ui::LoadingBar::create("loadingbar-nhan.png");
//            break;
//    }
    
    d_loadingBar = ui::LoadingBar::create("loadingbar-chia.png");
    
    d_loadingBar->setPosition(Vec2(w / 2, 0.9 * h));
    float scaleLoading = w / 1.7  / d_loadingBar->getContentSize().width;
    if (ratioScreenPlay <= 1.53)
    {
        scaleLoading = w / 3.4  / d_loadingBar->getContentSize().width;
        
        
    }
    d_loadingBar->setScale(scaleLoading);
    d_loadingBar->setDirection(ui::LoadingBar::Direction::LEFT);
    d_loadingBar->setPercent(0);
    this->addChild(d_loadingBar, 2);
    d_hLoadingBar = d_loadingBar->getContentSize().height * scaleLoading - 5;


    d_loadingBarWrap = ui::LoadingBar::create("loadingbar-wrap.png");
    d_loadingBarWrap->setPosition(Vec2(w / 2, 0.9 * h));

    d_loadingBarWrap->setScale(scaleLoading);
    d_loadingBarWrap->setDirection(ui::LoadingBar::Direction::LEFT);
    d_loadingBarWrap->setPercent(100);
    this->addChild(d_loadingBarWrap, 10);
}
void PlayDual::update(float dt) {
    // make sure game is still running
    if (d_timeRemaining > 0.f) {
        d_timeRemaining -= dt;
        if (d_isPause == true)
        {
            //log("da pause");
        }
        else{
            d_loadingBar->setPercent(d_timeRemaining * d_ratioLoadingBar);
        }
        // update the label or whatever displays the time here. if displaying the number, use ceilf to round
        // up the time remaining so that you don't display lots of numbers after the decimal point

        // check if time ran out
        if (d_timeRemaining <= 0.f && d_isPause == false) {
            // timer ran out; react here

            allPlayerChoised = 2;
            handlerClickAnswer(0, true);
            log("Het gio");
        }
    }
}


void PlayDual::createScore(float w, float h){
    float fontName = 0.08 * w;
    if (ratioScreenPlay <= 1.53)
    {
        fontName = 0.04 * w;
        
        
    }
    d_scoreString = cocos2d::__String::createWithFormat("%i", d_score); //d_score
    d_lblScore = Label::createWithTTF(d_scoreString->getCString(), "fonts/ComicNeue-Bold.ttf", fontName);

    d_scoreStringDup = cocos2d::__String::createWithFormat("%i", d_scoreDup);//d_scoreDup
    d_lblScoreDup = Label::createWithTTF(d_scoreStringDup->getCString(), "fonts/ComicNeue-Bold.ttf", fontName);

//    switch(d_typeOfW) {
//        case 1:
//            d_lblScore->setColor(Color3B(188, 232, 233));
//            d_lblScoreDup->setColor(Color3B(188, 232, 233));
//            break;
//        case 2:
//            d_lblScore->setColor(Color3B(72, 193, 255));
//            d_lblScoreDup->setColor(Color3B(72, 193, 255));
//
//            break;
//        case 3:
//            d_lblScore->setColor(Color3B(255, 234, 47));
//            d_lblScoreDup->setColor(Color3B(255, 234, 47));
//            break;
//        case 4:
//            d_lblScore->setColor(Color3B(171, 204, 92));
//            d_lblScoreDup->setColor(Color3B(171, 204, 92));
//            break;
//        case 5:
//            d_lblScore->setColor(Color3B(69, 255, 236));
//            d_lblScoreDup->setColor(Color3B(69, 255, 236));
//            break;
//        default:
//            d_lblScore->setColor(Color3B(188, 232, 233));
//            d_lblScoreDup->setColor(Color3B(188, 232, 233));
//    }
    
    d_lblScore->setColor(Color3B().WHITE);
    d_lblScoreDup->setColor(Color3B().WHITE);
    
    
    float xScore = w / 2 + (d_lblScore->getContentSize().width);
    //lblScore->setPosition(Vec2(xScore, h / 2 - 6 - (lblScore->getContentSize().height / 2)));
    d_lblScore->setPosition(Vec2(xScore, d_buttonAnswer1->getPosition().y + d_buttonAnswer1->getContentSize().height * d_scaleButtonAnswer1 * 0.8));
    d_lblScore->setAnchorPoint(Vec2({1, 0.5}));
    addChild(d_lblScore, 10);

    d_lblScoreDup->setPosition(Vec2(w / 2 - 5, d_buttonAnswer3Dup->getPosition().y - d_buttonAnswer1->getContentSize().height * d_scaleButtonAnswer1 * 0.8));
    d_lblScoreDup->setAnchorPoint(Vec2({0, 0.5}));
    d_lblScoreDup->runAction(RotateTo::create(0, 180.0f));
    addChild(d_lblScoreDup, 10);

    //show lblscore with animation
    d_lblScore->setOpacity(0);
    float valScale = 1.4;
    float time = 0.1;
    d_lblScore->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, valScale), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, 1), FadeIn::create(time), nullptr), nullptr));
    d_lblScoreDup->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, valScale), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, 1), FadeIn::create(time), nullptr), nullptr));
    
    //create d_scoreIcon
    d_scoreIcon = ui::Button::create("gold.png"); // tao button
    d_scoreIcon->setTouchEnabled(false);
    float ratiod_scoreIcon = 10;
    int fixResponsiveIpadScore1 = 0;
    int fixResponsiveIpadScore2 = 0;
    if (ratioScreenPlay <= 1.53)
    {
        ratiod_scoreIcon = 20;
        fixResponsiveIpadScore1 = 1;
        fixResponsiveIpadScore2 = 2;
        
    }
    float scaled_scoreIcon = w / ratiod_scoreIcon / d_scoreIcon->getContentSize().width;
    d_scoreIcon->setScale(scaled_scoreIcon);
    d_scoreIcon->setAnchorPoint(Vec2({1, 0.5}));
    d_scoreIcon->setPosition(Vec2(d_lblScore->getPositionX() - 3 + fixResponsiveIpadScore1 - d_lblScore->getContentSize().width, d_lblScore->getPositionY()));
    d_scoreIcon->setEnabled(true);
    this->addChild(d_scoreIcon, 11);
    
    
    //create d_scoreIconDup
    d_scoreIconDup = ui::Button::create("gold.png"); // tao button
    d_scoreIconDup->setTouchEnabled(false);
    float scaled_scoreIconDup = w / ratiod_scoreIcon / d_scoreIconDup->getContentSize().width;
    d_scoreIconDup->setScale(scaled_scoreIconDup);
    d_scoreIconDup->setAnchorPoint(Vec2({0, 0.5}));
    d_scoreIconDup->setPosition(Vec2(d_lblScoreDup->getPositionX() - 5 + fixResponsiveIpadScore2 + d_lblScoreDup->getContentSize().width / 2 + d_scoreIconDup->getContentSize().width * scaled_scoreIconDup / 2, d_lblScoreDup->getPositionY()));
    d_scoreIconDup->setEnabled(true);
    d_scoreIconDup->runAction(RotateTo::create(0, 180.0f));
    this->addChild(d_scoreIconDup, 11);
    
    
    //show lblscore with animation
    d_scoreIcon->setOpacity(0);
    
    float scaleScoreIcon = 1;
    if (ratioScreenPlay <= 1.53)
    {
        scaleScoreIcon = 0.55;
        
    }
    d_scoreIcon->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, 1), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, scaleScoreIcon), FadeIn::create(time), nullptr), nullptr));
    
    d_scoreIconDup->setOpacity(0);
    d_scoreIconDup->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, 1), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, scaleScoreIcon), FadeIn::create(time), nullptr), nullptr));
}

void PlayDual::showMedal(float wScene, float hScene, std::string medal){
    auto fixIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        fixIpad = 2;
    }

    auto iconMedal = Sprite::create(medal);

    float ratioMedal = 6 * fixIpad;
    float scaleiconMedal = wScene / ratioMedal / iconMedal->getContentSize().width;

    // Vị trí giữa màn hình
    iconMedal->setPosition(Vec2(wScene / 2, hScene * 0.7));

    // Bắt đầu từ 0
    iconMedal->setScale(0.0f);
    iconMedal->setOpacity(0);

    this->addChild(iconMedal, 15);

    /// ===== ANIMATION =====

    // Move lên khi xuất hiện (30px)
    auto moveUp = MoveBy::create(0.2f, Vec2(0, 30 / fixIpad));

    // Scale từ 0 -> x1.3
    auto scaleUp = ScaleTo::create(0.2f, scaleiconMedal * 1.3);

    // Fade in
    auto fadeIn = FadeTo::create(0.2f, 255);

    // Scale + Fade + Move lên cùng lúc
    auto spawnIn = Spawn::create(scaleUp, fadeIn, moveUp, nullptr);

    // Giữ 1 chút
    auto delay = DelayTime::create(0.4f);

    // Move xuống nhẹ khi hide
    auto moveDown = MoveBy::create(0.6f, Vec2(0, -15 / fixIpad));

    // Fade out
    auto fadeOut = FadeOut::create(0.6f);

    // Fade + Move xuống cùng lúc khi hide
    auto spawnOut = Spawn::create(fadeOut, moveDown, nullptr);

    // Xóa sprite sau khi xong
    auto remove = RemoveSelf::create();

    // Chạy sequence
    iconMedal->runAction(
        Sequence::create(
            spawnIn,
            delay,
            spawnOut,
            remove,
            nullptr
        )
    );
}

void PlayDual::createAnswer(float w, float h){

    float fontSize = 0.084 * w;

    d_buttonAnswer1 = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer1->setPressedActionEnabled(true);
    d_buttonAnswer1->setZoomScale(0);
    d_buttonAnswer1->setScale9Enabled(true);
    d_buttonAnswer1->setTitleText(HuyFunctions().NumberToString(d_answer1));
    if (d_answer1 == d_correctAnswer)
    {
        d_buttonAnswer1->setTag(1);
    }
    else
    {
        d_buttonAnswer1->setTag(0);
    }
    d_buttonAnswer1->setTitleFontName("fonts/ComicNeue-Bold.ttf");

    d_buttonAnswer1->setTitleColor(Color3B().WHITE);
    d_buttonAnswer1->setTouchEnabled(true);
    float ratioButtonAnswer1 = 3;//2.2
    if ( ratioScreenPlay <= 1.8)
    {
        ratioButtonAnswer1 = 3.6;
    }
    if ( ratioScreenPlay <= 1.65)
    {
        ratioButtonAnswer1 = 5.2;
    }
    if (ratioScreenPlay <= 1.53)
    {
        ratioButtonAnswer1 = 7.4;
        fontSize = 0.043 * w;
    }
    d_scaleButtonAnswer1 = w / ratioButtonAnswer1 / d_buttonAnswer1->getContentSize().width;
    d_buttonAnswer1->setScale(d_scaleButtonAnswer1);
    d_buttonAnswer1->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    float yButtonAnswer1 = 50 + d_buttonAnswer1->getContentSize().height / 2 * d_scaleButtonAnswer1;

    d_buttonAnswer1->setPosition(Vec2(w / 4, yButtonAnswer1));
    if (ratioScreenPlay <= 1.53)
    {
        d_buttonAnswer1->setPosition(Vec2(w / 2.75, yButtonAnswer1));
        
        
    }
    d_buttonAnswer1->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer1 != d_correctAnswer)
                {
                    player1Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer(d_answer1, true);
                    d_buttonAnswer1->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer1->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer(d_answer1, true);
                }


                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer1, 2);//add button vao scene



    d_buttonAnswer2 = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer2->setPressedActionEnabled(true);
    d_buttonAnswer2->setZoomScale(0);
    d_buttonAnswer2->setScale9Enabled(true);
    d_buttonAnswer2->setTitleText(HuyFunctions().NumberToString(d_answer2));
    if (d_answer2 == d_correctAnswer)
    {
        d_buttonAnswer2->setTag(1);
    }
    else
    {
        d_buttonAnswer2->setTag(0);
    }
    d_buttonAnswer2->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    d_buttonAnswer2->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    d_buttonAnswer2->setTitleColor(Color3B().WHITE);
    d_buttonAnswer2->setTouchEnabled(true);
    float scaleButtonAnswer2 = w / ratioButtonAnswer1 / d_buttonAnswer2->getContentSize().width;
    d_buttonAnswer2->setScale(scaleButtonAnswer2);
    float yButtonAnswer2 = 50 + d_buttonAnswer2->getContentSize().height / 2 * scaleButtonAnswer2;

    d_buttonAnswer2->setPosition(Vec2(w * 3 / 4, yButtonAnswer2));
    if (ratioScreenPlay <= 1.53)
    {
        d_buttonAnswer2->setPosition(Vec2(w / 2.05 + d_buttonAnswer2->getContentSize().width * scaleButtonAnswer2, yButtonAnswer2));
       
    }

    d_buttonAnswer2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer2 != d_correctAnswer)
                {
                    player1Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer(d_answer2, true);
                    d_buttonAnswer2->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer2->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer(d_answer2, true);
                    d_buttonAnswer2->loadTextureNormal("box-correct.png");
                }

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:

                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer2, 2);//add button vao scene

    d_buttonAnswer3 = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer3->setPressedActionEnabled(true);
    d_buttonAnswer3->setZoomScale(0);
    d_buttonAnswer3->setScale9Enabled(true);
    d_buttonAnswer3->setTitleText(HuyFunctions().NumberToString(d_answer3));
    if (d_answer3 == d_correctAnswer)
    {
        d_buttonAnswer3->setTag(1);
    }
    else
    {
        d_buttonAnswer3->setTag(0);
    }
    d_buttonAnswer3->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    d_buttonAnswer3->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    d_buttonAnswer3->setTitleColor(Color3B().WHITE);
    d_buttonAnswer3->setTouchEnabled(true);
    float scaleButtonAnswer3 = w / ratioButtonAnswer1 / d_buttonAnswer3->getContentSize().width;
    d_buttonAnswer3->setScale(scaleButtonAnswer3);
    float yButtonAnswer3 = yButtonAnswer1 + d_buttonAnswer3->getContentSize().height * scaleButtonAnswer3 + 20;
    
    if (ratioScreenPlay <= 1.8)
    {
        yButtonAnswer3 = yButtonAnswer1 + d_buttonAnswer3->getContentSize().height * scaleButtonAnswer3 + 10;
    }
    
    d_buttonAnswer3->setPosition(Vec2(w / 4, yButtonAnswer3));
    if (ratioScreenPlay <= 1.53)
    {
        d_buttonAnswer3->setPosition(Vec2(w / 2.75, yButtonAnswer3));
        
        
    }
    d_buttonAnswer3->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer3 != d_correctAnswer)
                {
                    player1Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer(d_answer3, true);
                    d_buttonAnswer3->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer3->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer(d_answer3, true);
                }

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer3, 2);//add button vao scene
    d_buttonAnswer4 = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer4->setPressedActionEnabled(true);
    d_buttonAnswer4->setZoomScale(0);
    d_buttonAnswer4->setScale9Enabled(true);
    d_buttonAnswer4->setTitleText(HuyFunctions().NumberToString(d_answer4));
    if (d_answer4 == d_correctAnswer)
    {
        d_buttonAnswer4->setTag(1);
    }
    else
    {
        d_buttonAnswer4->setTag(0);
    }
    d_buttonAnswer4->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    d_buttonAnswer4->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    d_buttonAnswer4->setTitleColor(Color3B().WHITE);
    d_buttonAnswer4->setTouchEnabled(true);
    float scaleButtonAnswer4 = w / ratioButtonAnswer1 / d_buttonAnswer4->getContentSize().width;
    d_buttonAnswer4->setScale(scaleButtonAnswer4);


    d_buttonAnswer4->setPosition(Vec2(w * 3 / 4, yButtonAnswer3));
    if (ratioScreenPlay <= 1.53)
        {
            d_buttonAnswer4->setPosition(Vec2(w / 2.05 + d_buttonAnswer4->getContentSize().width * scaleButtonAnswer2, yButtonAnswer3));
           
        }
    d_buttonAnswer4->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer4 != d_correctAnswer)
                {
                    player1Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer((d_answer4), true);
                    d_buttonAnswer4->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer4->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer((d_answer4), true);

                }

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer4, 2);//add button vao scene

    d_buttonAnswer1Dup = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer1Dup->setPressedActionEnabled(true);
    d_buttonAnswer1Dup->setZoomScale(0);
    d_buttonAnswer1Dup->setScale9Enabled(true);
    d_buttonAnswer1Dup->setTitleText(HuyFunctions().NumberToString(d_answer1));
    if (d_answer1 == d_correctAnswer)
    {
        d_buttonAnswer1Dup->setTag(1);
    }
    else
    {
        d_buttonAnswer1Dup->setTag(0);
    }
    d_buttonAnswer1Dup->setTitleFontName("fonts/ComicNeue-Bold.ttf");

    d_buttonAnswer1Dup->setTitleColor(Color3B().WHITE);
    d_buttonAnswer1Dup->setTouchEnabled(true);

    d_buttonAnswer1Dup->setScale(d_scaleButtonAnswer1);
    d_buttonAnswer1Dup->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    float yButtonAnswer1Dup = 30 + d_buttonAnswer1Dup->getContentSize().height * d_scaleButtonAnswer1 + d_hScenePlay / 1.8 + d_loadingBarWrap->getContentSize().height;
    if (ratioScreenPlay <= 1.8)
    {
        yButtonAnswer1Dup = 30 + d_buttonAnswer1Dup->getContentSize().height * d_scaleButtonAnswer1 + d_hScenePlay / 1.8 + d_loadingBarWrap->getContentSize().height;
    }

    d_buttonAnswer1Dup->setPosition(Vec2(w / 4, yButtonAnswer1Dup));
    if (ratioScreenPlay <= 1.53)
    {
        yButtonAnswer1Dup = 50 + d_buttonAnswer1Dup->getContentSize().height * d_scaleButtonAnswer1 + d_hScenePlay / 1.8 + d_loadingBarWrap->getContentSize().height;
        d_buttonAnswer1Dup->setPosition(Vec2(w / 2.75, yButtonAnswer1Dup));
        
        
    }
    d_buttonAnswer1Dup->runAction(RotateTo::create(0, 180.0f));

    d_buttonAnswer1Dup->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer1 != d_correctAnswer)
                {
                    player2Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer(d_answer1, false);
                    d_buttonAnswer1Dup->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer1Dup->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer(d_answer1, false);
                }
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer1Dup, 2);//add button vao scene
    d_buttonAnswer2Dup = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer2Dup->setPressedActionEnabled(true);
    d_buttonAnswer2Dup->setZoomScale(0);
    d_buttonAnswer2Dup->setScale9Enabled(true);
    d_buttonAnswer2Dup->setTitleText(HuyFunctions().NumberToString(d_answer2));
    if (d_answer2 == d_correctAnswer)
    {
        d_buttonAnswer2Dup->setTag(1);
    }
    else
    {
        d_buttonAnswer2Dup->setTag(0);
    }
    d_buttonAnswer2Dup->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    d_buttonAnswer2Dup->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    d_buttonAnswer2Dup->setTitleColor(Color3B().WHITE);
    d_buttonAnswer2Dup->setScale(scaleButtonAnswer2);
    //float yButtonAnswer2Dup = 50 + buttonAnswer2Dup->getContentSize().height * scaleButtonAnswer2 + hScenePlay / 2 + loadingBarWrap->getContentSize().height;

    d_buttonAnswer2Dup->setPosition(Vec2(w * 3 / 4, yButtonAnswer1Dup));
    if (ratioScreenPlay <= 1.53)
        {
            d_buttonAnswer2Dup->setPosition(Vec2(w / 2.05 + d_buttonAnswer2Dup->getContentSize().width * scaleButtonAnswer2, yButtonAnswer1Dup));
           
        }
    d_buttonAnswer2Dup->runAction(RotateTo::create(0, 180.0f));
    d_buttonAnswer2Dup->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer2 != d_correctAnswer)
                {
                    player2Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer(d_answer2,false);
                    d_buttonAnswer2Dup->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer2Dup->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer(d_answer2,false);
                    d_buttonAnswer2->loadTextureNormal("box-correct.png");
                }

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:

                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer2Dup, 2);//add button vao scene

    d_buttonAnswer3Dup = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer3Dup->setPressedActionEnabled(true);
    d_buttonAnswer3Dup->setZoomScale(0);
    d_buttonAnswer3Dup->setScale9Enabled(true);
    d_buttonAnswer3Dup->setTitleText(HuyFunctions().NumberToString(d_answer3));
    if (d_answer3 == d_correctAnswer)
    {
        d_buttonAnswer3Dup->setTag(1);
    }
    else
    {
        d_buttonAnswer3Dup->setTag(0);
    }
    d_buttonAnswer3Dup->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    d_buttonAnswer3Dup->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    d_buttonAnswer3Dup->setTitleColor(Color3B().WHITE);
    d_buttonAnswer3Dup->setTouchEnabled(true);
    d_buttonAnswer3Dup->setScale(scaleButtonAnswer3);
    float yButtonAnswer3Dup = yButtonAnswer1 + d_buttonAnswer3Dup->getContentSize().height * scaleButtonAnswer3 * 4.1/2  + d_hScenePlay / 2 + d_loadingBarWrap->getContentSize().height;
    
    //log("ti le man hinh: %f", ratioScreenPlay);
    if (ratioScreenPlay <= 1.8)
    {
        yButtonAnswer3Dup = yButtonAnswer1 + d_buttonAnswer3Dup->getContentSize().height * scaleButtonAnswer3 * 4.1/2 - 10 + d_hScenePlay / 2 + d_loadingBarWrap->getContentSize().height;
        
    }
    d_buttonAnswer3Dup->setPosition(Vec2(w / 4, yButtonAnswer3Dup));
    if (ratioScreenPlay <= 1.53)
    {
        yButtonAnswer3Dup = yButtonAnswer1 + d_buttonAnswer3Dup->getContentSize().height * scaleButtonAnswer3 * 4.1/2 + 20 + d_hScenePlay / 2 + d_loadingBarWrap->getContentSize().height;
        d_buttonAnswer3Dup->setPosition(Vec2(w / 2.75, yButtonAnswer3Dup));
        
        
    }
    d_buttonAnswer3Dup->runAction(RotateTo::create(0, 180.0f));
    d_buttonAnswer3Dup->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer3 != d_correctAnswer)
                {
                    player2Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer(d_answer3, false);
                    d_buttonAnswer3Dup->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer3Dup->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer(d_answer3, false);
                }

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer3Dup, 2);//add button vao scene

    d_buttonAnswer4Dup = ui::Button::create(ImageNamDapAn->getCString()); // tao button
    d_buttonAnswer4Dup->setPressedActionEnabled(true);
    d_buttonAnswer4Dup->setZoomScale(0);
    d_buttonAnswer4Dup->setScale9Enabled(true);
    d_buttonAnswer4Dup->setTitleText(HuyFunctions().NumberToString(d_answer4));
    if (d_answer4 == d_correctAnswer)
    {
        d_buttonAnswer4Dup->setTag(1);
    }
    else
    {
        d_buttonAnswer4Dup->setTag(0);
    }
    d_buttonAnswer4Dup->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    d_buttonAnswer4Dup->setTitleFontSize(fontSize / d_scaleButtonAnswer1);
    d_buttonAnswer4Dup->setTitleColor(Color3B().WHITE);
    d_buttonAnswer4Dup->setTouchEnabled(true);
    d_buttonAnswer4Dup->setScale(scaleButtonAnswer4);
    d_buttonAnswer4Dup->setPosition(Vec2(w * 3 / 4, yButtonAnswer3Dup));
    if (ratioScreenPlay <= 1.53)
        {
            d_buttonAnswer4Dup->setPosition(Vec2(w / 2.05 + d_buttonAnswer4Dup->getContentSize().width * scaleButtonAnswer2, yButtonAnswer3Dup));
           
        }
    d_buttonAnswer4Dup->runAction(RotateTo::create(0, 180.0f));
    d_buttonAnswer4Dup->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (d_answer4 != d_correctAnswer)
                {
                    player2Choised = true;
                    allPlayerChoised = allPlayerChoised + 1;
                    handlerClickAnswer((d_answer4), false);
                    d_buttonAnswer4Dup->loadTextureNormal("box-wrong.png");
                    d_buttonAnswer4Dup->setTitleColor(Color3B().WHITE);
                }else{
                    allPlayerChoised = 2;
                    handlerClickAnswer((d_answer4), false);
                }
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(d_buttonAnswer4Dup, 2);//add button vao scene
    //show 4 button with animation

    //show lblscore with animation
    float valScale = 1.4;
    float time = 0.1;
    animationShowAnswer(d_buttonAnswer1, time, valScale);
    animationShowAnswer(d_buttonAnswer2, time, valScale);
    animationShowAnswer(d_buttonAnswer3, time, valScale);
    animationShowAnswer(d_buttonAnswer4, time, valScale);
    animationShowAnswer(d_buttonAnswer1Dup, time, valScale);
    animationShowAnswer(d_buttonAnswer2Dup, time, valScale);
    animationShowAnswer(d_buttonAnswer3Dup, time, valScale);
    animationShowAnswer(d_buttonAnswer4Dup, time, valScale);
    
    if (strcmp(loaiPhepTinh->getCString(), "ss") == 0) {
        phepTinhSoSanh1 = true;
        
        if (d_buttonAnswer1->getTitleText() == "1") {
            
            d_buttonAnswer1->loadTextureNormal(ImageNamDapAnV->getCString());
            d_buttonAnswer2->loadTextureNormal(ImageNamDapAnX->getCString());
            
            d_buttonAnswer1Dup->loadTextureNormal(ImageNamDapAnV->getCString());
            d_buttonAnswer2Dup->loadTextureNormal(ImageNamDapAnX->getCString());
        }else{
            d_buttonAnswer1Dup->loadTextureNormal(ImageNamDapAnX->getCString());
            d_buttonAnswer2Dup->loadTextureNormal(ImageNamDapAnV->getCString());
            
            d_buttonAnswer1->loadTextureNormal(ImageNamDapAnX->getCString());
            d_buttonAnswer2->loadTextureNormal(ImageNamDapAnV->getCString());
        }
        d_buttonAnswer1Dup->setPositionY(d_buttonAnswer3Dup->getPositionY());
        d_buttonAnswer2Dup->setPositionY(d_buttonAnswer4Dup->getPositionY());
        
        
        
        d_buttonAnswer1->setTitleText("");
        d_buttonAnswer2->setTitleText("");
        d_buttonAnswer3->setVisible(false);
        d_buttonAnswer4->setVisible(false);
        
        d_buttonAnswer1Dup->setTitleText("");
        d_buttonAnswer2Dup->setTitleText("");
        d_buttonAnswer3Dup->setVisible(false);
        d_buttonAnswer4Dup->setVisible(false);
        //log("ban dang lam bai so sanh");
    }
    
}
void PlayDual::animationShowAnswer(cocos2d::ui::Button* button, float time, float scale){
    auto opButton1 = FadeOut::create(0);
    button->setOpacity(0);

    auto scaleButton1 = ScaleTo::create(0, d_scaleButtonAnswer1 * scale);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, d_scaleButtonAnswer1);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    auto sq = Sequence::create(sqButton1, sqB, nullptr);
    button->runAction(sq);
}
void PlayDual::handlerClickAnswer(int v, bool buttonSide){
    //log("v: %i, correctAnswer: %i", v, d_correctAnswer);

    int myTime = d_timeMax - d_timeRemaining;
    int isCorrect = 0;
    if(v == d_correctAnswer) {
        isCorrect = 1;
    }
    std::string ph = d_lblPhepToan->getString().c_str();
    
    if(phepTinhSoSanh1){
    //if (strcmp(loaiPhepTinh->getCString(), "ss") == 0) {
        
        if (v == d_correctAnswer) {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 9999, myTime, d_levelOfW, 1, true);
        } else {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 222, myTime, d_levelOfW, 1, true);
        }
    }else {
        HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, v, myTime, d_levelOfW, 1, true);
    }

    d_sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);

    if(player1Choised){
        d_buttonAnswer1->setTouchEnabled(false);
        d_buttonAnswer2->setTouchEnabled(false);
        d_buttonAnswer3->setTouchEnabled(false);
        d_buttonAnswer4->setTouchEnabled(false);
        d_buttonAnswer1->loadTextureNormal("xam3.png");
        d_buttonAnswer2->loadTextureNormal("xam3.png");
        d_buttonAnswer3->loadTextureNormal("xam3.png");
        d_buttonAnswer4->loadTextureNormal("xam3.png");
    }
    if(player2Choised){

        d_buttonAnswer1Dup->setTouchEnabled(false);
        d_buttonAnswer2Dup->setTouchEnabled(false);
        d_buttonAnswer3Dup->setTouchEnabled(false);
        d_buttonAnswer4Dup->setTouchEnabled(false);
        d_buttonAnswer1Dup->loadTextureNormal("xam3.png");
        d_buttonAnswer2Dup->loadTextureNormal("xam3.png");
        d_buttonAnswer3Dup->loadTextureNormal("xam3.png");
        d_buttonAnswer4Dup->loadTextureNormal("xam3.png");

    }
    if(allPlayerChoised >= 2){


        if (d_buttonAnswer1->getTag() == 1)
        {
            d_buttonAnswer1->loadTextureNormal("box-correct.png");
            d_buttonAnswer1->setTitleColor(Color3B().WHITE);
        }
        if (d_buttonAnswer2->getTag() == 1)
        {
            d_buttonAnswer2->loadTextureNormal("box-correct.png");
            d_buttonAnswer2->setTitleColor(Color3B().WHITE);
        }
        if (d_buttonAnswer3->getTag() == 1)
        {
            d_buttonAnswer3->loadTextureNormal("box-correct.png");
            d_buttonAnswer3->setTitleColor(Color3B().WHITE);
        }
        if (d_buttonAnswer4->getTag() == 1)
        {
            d_buttonAnswer4->loadTextureNormal("box-correct.png");
            d_buttonAnswer4->setTitleColor(Color3B().WHITE);
        }

        if (d_buttonAnswer1Dup->getTag() == 1)
        {
            d_buttonAnswer1Dup->loadTextureNormal("box-correct.png");
            d_buttonAnswer1Dup->setTitleColor(Color3B().WHITE);
        }
        if (d_buttonAnswer2Dup->getTag() == 1)
        {
            d_buttonAnswer2Dup->loadTextureNormal("box-correct.png");
            d_buttonAnswer2Dup->setTitleColor(Color3B().WHITE);
        }
        if (d_buttonAnswer3Dup->getTag() == 1)
        {
            d_buttonAnswer3Dup->loadTextureNormal("box-correct.png");
            d_buttonAnswer3Dup->setTitleColor(Color3B().WHITE);
        }
        if (d_buttonAnswer4Dup->getTag() == 1)
        {
            d_buttonAnswer4Dup->loadTextureNormal("box-correct.png");
            d_buttonAnswer4Dup->setTitleColor(Color3B().WHITE);
        }

        //hide pheptoan
        float time = 0.2;
        d_lblPhepToan->runAction(Spawn::create(ScaleTo::create(time, 1.4), FadeOut::create(time), nullptr));
        d_lblPhepToanDup->runAction(Spawn::create(ScaleTo::create(time, 1.4), FadeOut::create(time), nullptr));

        //hide score
        d_lblScore->runAction(Spawn::create(FadeOut::create(time), nullptr));
        d_lblScoreDup->runAction(Spawn::create(FadeOut::create(time), nullptr));
        d_scoreIcon->runAction(Spawn::create(FadeOut::create(time), nullptr));
        d_scoreIconDup->runAction(Spawn::create(FadeOut::create(time), nullptr));

        //hide LoadingBar
        auto opaLoadingBar = FadeOut::create(time);
        auto sqLoadingBar = Spawn::create(opaLoadingBar, nullptr);
        d_loadingBar->runAction(sqLoadingBar);

        auto opaLoadingBarW = FadeOut::create(time);
        auto sqLoadingBarW = Spawn::create(opaLoadingBarW, nullptr);
        d_loadingBarWrap->runAction(sqLoadingBarW);
        
        //auto opaBg = FadeOut::create(time);
        //auto sqBg = Spawn::create(opaBg, nullptr);
        //bgColor->runAction(sqBg);

        /*
        //hide pause
        auto opaPause = FadeOut::create(time);
        auto sqPause = Spawn::create(opaPause, nullptr);
        buttonPause->runAction(sqPause);
        */

        //hide 4 answer
        DelayTime *pauseButtonAnswer = DelayTime::create(0.3);
        d_buttonAnswer1->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));
        d_buttonAnswer2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));
        d_buttonAnswer3->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));
        d_buttonAnswer4->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));

        d_buttonAnswer1Dup->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));
        d_buttonAnswer2Dup->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));
        d_buttonAnswer3Dup->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));
        d_buttonAnswer4Dup->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(time), nullptr));
    }

    DelayTime *pause = DelayTime::create(0.5);


    if (v == d_correctAnswer)
    {
        //auto dungLienTiep = HuyFunctions().saveSoPhepTinhDungLienTiep(true);
        auto dungMoiNgay = HuyFunctions().saveSoPhepTinhDungMoiNgay(true);
//        if (dungLienTiep != "") {
//            showMedal(d_wScenePlay, d_hScenePlay, dungLienTiep);
//        }
        if (dungMoiNgay != "") {
            showMedal(d_wScenePlay, d_hScenePlay, dungMoiNgay);
        }
        
        d_buttonAnswer1->setTouchEnabled(false);
        d_buttonAnswer2->setTouchEnabled(false);
        d_buttonAnswer3->setTouchEnabled(false);
        d_buttonAnswer4->setTouchEnabled(false);
        d_buttonAnswer1->loadTextureNormal("xam3.png");
        d_buttonAnswer2->loadTextureNormal("xam3.png");
        d_buttonAnswer3->loadTextureNormal("xam3.png");
        d_buttonAnswer4->loadTextureNormal("xam3.png");
        d_buttonAnswer1Dup->setTouchEnabled(false);
        d_buttonAnswer2Dup->setTouchEnabled(false);
        d_buttonAnswer3Dup->setTouchEnabled(false);
        d_buttonAnswer4Dup->setTouchEnabled(false);
        d_buttonAnswer1Dup->loadTextureNormal("xam3.png");
        d_buttonAnswer2Dup->loadTextureNormal("xam3.png");
        d_buttonAnswer3Dup->loadTextureNormal("xam3.png");
        d_buttonAnswer4Dup->loadTextureNormal("xam3.png");
        
        if (buttonSide == true) {
            d_score++;
        }else{
            d_scoreDup++;
        }
        if (d_sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }

        log("ban da tra loi dung");

        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(PlayDual::nextPlay, this)), NULL);
        runAction(sqBOver);

        log("check xem da close chua");

    }
    else{
        log("ban da tra loi sai");
        if (d_sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/crash2.mp3");
        }

        //isPause = false;
        //auto opaB = FadeOut::create(v);
        if(allPlayerChoised >= 2){

            auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(PlayDual::nextPlay, this)), NULL);
            runAction(sqBOver);
        }

        //::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score, typeOfW, levelOfW), Color3B().WHITE));
    }

    if(numQuestion > MaxNumberQuestion - 2) {
        if(d_score != d_scoreDup && allPlayerChoised >= 2) {
            auto sqBBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(PlayDual::moveSceneGameOver, this)), NULL);
            runAction(sqBBOver);
        }

    }

}
void PlayDual::nextPlay()
{

    if(numQuestion <= MaxNumberQuestion - 2 || d_score == d_scoreDup) {
        numQuestion = numQuestion + 1;
        log("Number Question: %i", numQuestion);
        player1Choised = false;
        player2Choised = false;
        allPlayerChoised = 0;
        if (d_realType == 1)
        {
            d_typeOfW = cocos2d::RandomHelper::random_int(2, 5);
        }
        removeChild(d_lblPhepToan);
        removeChild(d_lblPhepToanDup);
        removeChild(d_lblScore);
        removeChild(d_lblScoreDup);
        removeChild(d_buttonAnswer1);
        removeChild(d_buttonAnswer2);
        removeChild(d_buttonAnswer3);
        removeChild(d_buttonAnswer4);
        removeChild(d_buttonAnswer1Dup);
        removeChild(d_buttonAnswer2Dup);
        removeChild(d_buttonAnswer3Dup);
        removeChild(d_buttonAnswer4Dup);
        removeChild(d_loadingBar);

        /*
        //reset pause
        isPause = false;
        buttonPause->loadTextureNormal("pause.png");
        */

        auto arr = CreatePhepToan().createAnswerQuestions(d_typeOfW, d_levelOfW, d_prevA, d_prevB, d_maxDoiSo);
        log("test improve function");
        //    0 - prevA
        //    1 - prevB
        //    2 - phepToan
        //    3 - correctAnswer
        //    4 - answer1
        //    5 - answer2
        //    6 - answer3
        //    7 - answer4
        d_prevA = std::stoi(arr.at(0));
        d_prevB = std::stoi(arr.at(1));
        d_phepToan = cocos2d::__String::createWithFormat("%s", arr.at(2).c_str());
        loaiPhepTinh = cocos2d::__String::createWithFormat("%s", arr.at(8).c_str());
        d_correctAnswer = std::stoi(arr.at(3));
        d_answer1 = std::stoi(arr.at(4));
        d_answer2 = std::stoi(arr.at(5));
        d_answer3 = std::stoi(arr.at(6));
        d_answer4 = std::stoi(arr.at(7));
        
        log("cau hoi: %s",  arr.at(2).c_str());
        log("4 dap an: %i, %i, %i, %i",  std::stoi(arr.at(4)), std::stoi(arr.at(5)), std::stoi(arr.at(6)), std::stoi(arr.at(7)));
        log("dap dung: %i",  std::stoi(arr.at(3)));

        int randomImageNameDapAn = cocos2d::RandomHelper::random_int(1, 5);
        ImageNamDapAn = __String::create(StringUtils::format("button-dap-an-%d.png", randomImageNameDapAn));
        ImageNamDapAnX = __String::create(StringUtils::format("button-dap-an-%d-x.png", randomImageNameDapAn));
        ImageNamDapAnV = __String::create(StringUtils::format("button-dap-an-%d-v.png", randomImageNameDapAn));
        
        if (dualModel == false){
            //countdown timer + loading bar
            coundownTimer(d_wScenePlay, d_hScenePlay);
            //end: countdown timer + loading bar

            createMainTemplate(d_wScenePlay, d_hScenePlay);
            
            createAnswer(d_wScenePlay, d_hScenePlay);
            createScore(d_wScenePlay, d_hScenePlay);
        }else{
            //countdown timer + loading bar
            coundownTimer(d_wScenePlay, d_hScenePlay / 2 + 40);
            //end: countdown timer + loading bar

            createMainTemplate(d_wScenePlay, d_hScenePlay / 2  + 40);
            createAnswer(d_wScenePlay, d_hScenePlay / 2);
            createScore(d_wScenePlay, d_hScenePlay / 2 + 40);

        }
    }
}
void PlayDual::moveSceneGameOver()
{
    //kiem tra xem co show man hinh mua hang khong
    if (Variable().isProVer == false && d_score >= Variable().soDiemShowPro &&  UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) >= Variable().showProSauBaoNhieuLan) {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", 0);
        createBgPro(d_wScenePlay, d_hScenePlay);
    } else {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) + 1);
        finish();
    }
}
void PlayDual::createMainTemplate(float w, float h){
    
    
    log("Ratio Play %f", ratioScreenPlay);
    float fontSizeMain = 0.18;
    if ( ratioScreenPlay <= 1.65)
    {
        fontSizeMain = 0.15;
    }
    if (ratioScreenPlay <= 1.53)
    {
        fontSizeMain = 0.09;
    }
    d_lblPhepToan = Label::createWithTTF(d_phepToan->getCString(), "fonts/DeliusSwashCaps.ttf", fontSizeMain * w);


    d_lblPhepToan->setColor(Color3B().WHITE);//Color3B().BLACK
    // position the label on the center of the screen
    d_lblPhepToan->setPosition(Vec2(w / 2, h * 0.75));
    // add the label as a child to this layer
    addChild(d_lblPhepToan, 2);
    auto opaA = FadeOut::create(0);
    d_lblPhepToan->setOpacity(0);
    float time = 0.2;
    auto opaB = FadeIn::create(time);
    auto sq = Sequence::create(opaA, opaB, nullptr);
    d_lblPhepToan->runAction(sq);

    d_lblPhepToanDup = Label::createWithTTF(d_phepToan->getCString(), "fonts/DeliusSwashCaps.ttf", fontSizeMain * w);
    d_lblPhepToanDup->setColor(Color3B().WHITE);//Color3B().BLACK
    // position the label on the center of the screen
    d_lblPhepToanDup->setPosition(Vec2(w / 2, d_loadingBarWrap->getPosition().y + 45));
    // add the label as a child to this layer
    d_lblPhepToanDup->runAction(RotateTo::create(0, 180.0f));
    addChild(d_lblPhepToanDup, 2);
    auto opaADup = FadeOut::create(0);
    d_lblPhepToanDup->setOpacity(0);
    float timeDup = 0.2;
    auto opaBDup = FadeIn::create(timeDup);
    auto sqDup = Sequence::create(opaADup, opaBDup, nullptr);
    d_lblPhepToanDup->runAction(sqDup);

}
void PlayDual::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                if (Variable().isProduction == true) {
                    HuyFunctions().showAds();
                }
                
                HuyFunctions().animationClickedButton(button, [](){
                    if (fromChallengeDual) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(d_typeOfW, d_levelOfW), Color3B().WHITE));
                    } else {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(1, 0), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 2);//add button vao scene
}
void PlayDual::createValueKey(float w, float h){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    d_valueKey3 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * w);
    d_valueKey3->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = d_valueKey3->getContentSize().height;
    auto btnWidthKey = d_valueKey3->getContentSize().width;
    d_yValueKey3 = h - d_hLoadingBar - (btnHeightKey / 2 + 5);
    d_xValueKey3 = w - (btnWidthKey / 2 + 5);
    d_valueKey3->setPosition(Vec2(d_xValueKey3, d_yValueKey3));
    // add the label as a child to this layer
    addChild(d_valueKey3);
}
void PlayDual::createButtonKey(float w, float h){
    createValueKey(w, h);
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    auto btnWidth = btn->getContentSize().width;
    float scale = w / ratio / btnWidth;
    float xBtn = d_xValueKey3 - 7 - d_valueKey3->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, d_yValueKey3));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                //restart valueKey Label
                removeChild(d_valueKey3);
                createValueKey(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
void PlayDual::createBgPro(float wScene, float hScene) {
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    LanguageManager::getInstanceRestart();
    
    auto bgTexture = Director::getInstance()->getTextureCache()->addImage("bg-nen-tet.png");

    // Set texture parameters to repeat
    Texture2D::TexParams texParams = { GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_REPEAT };
    bgTexture->setTexParameters(texParams);

    // Create a sprite with repeated texture
    auto bgNenPro = Sprite::createWithTexture(bgTexture, Rect(0, 0, wScene, hScene));
    bgNenPro->setAnchorPoint(Vec2(0, 0)); // Align to bottom-left
    bgNenPro->setOpacity(245);
    //bgNenPro->setOpacity(0);
    this->addChild(bgNenPro, 100);
    
    //close
    auto btn = ui::Button::create("close-btn.png"); // tao button
    float ratio = 10;
    if (hScene/wScene <= 1.53)
    {
        ratio = 17;
    }
    //CCLOG("Debug: 2");
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                finish();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 101);//add button vao scene
    
    float fontSize = 0.1 * wScene;
    float fontSizePrice = 0.135 * wScene;
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
        fontSize = 0.07 * wScene;
    }
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.05 * wScene;
        fontSizePrice = 0.06 * wScene;
        if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
        {
           
            fontSize = 0.035 * wScene;
        }
    }
    //create title pro version
    std::string titleValue = LanguageManager::getInstance()->getStringForKey("TITLE_PRO").c_str();
    auto titlePro = Label::createWithTTF(titleValue, fontStyle, fontSize);
    titlePro->setColor(Color3B().WHITE);
    // position the label on the center of the
    auto btnHeightKey = titlePro->getContentSize().height;
    double ytitlePro = hScene * 0.9 - (btnHeightKey / 2 + 5);
    double xtitlePro = wScene / 2;// - (btnWidthKey / 2 + 5);
    titlePro->setPosition(Vec2(xtitlePro, ytitlePro));
    // add the label as a child to this layer
    addChild(titlePro, 101);
    
    auto bgVIP = Sprite::create("tv-ads.png");
    float ratiobgVIP = 2.4;

    float fixHeightIpad = 20;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        fixHeightIpad = 5;
    }
    
    if (hScene / wScene <= 1.53)
    {
        ratiobgVIP = 4.4;
    }
    
    float scalebgVIP = wScene / ratiobgVIP / bgVIP->getContentSize().width;
    bgVIP->setScale(scalebgVIP);
    bgVIP->setPosition(Vec2(wScene / 2, titlePro->getPositionY() - titlePro->getContentSize().height - 20 - bgVIP->getContentSize().height * scalebgVIP / 2)); // Đặt vị trí
    this->addChild(bgVIP, 101);
    
    
    //create desc pro version
    std::string descValue = LanguageManager::getInstance()->getStringForKey("REMOVE_ADS").c_str();
    auto descPro = Label::createWithTTF(descValue, fontStyle , fontSize * 0.8);
    descPro->setColor(Color3B().WHITE);
    // position the label on the center of the
    double ydescPro = bgVIP->getPositionY() - descPro->getContentSize().height /2 - 20 - bgVIP->getContentSize().height * scalebgVIP / 2;
    double xdescPro = wScene / 2;// - (btnWidthKey / 2 + 5);
    descPro->setPosition(Vec2(xdescPro, ydescPro));
    // add the label as a child to this layer
    addChild(descPro, 101);
    
    //create PRICE
    std::string priceValue = UserDefault::getInstance()->getStringForKey("gia", "");
    auto price = Label::createWithTTF(priceValue, "fonts/NunitoSans-Bold.ttf", fontSizePrice);
    price->setColor(Color3B(255, 195, 77));
    // position the label on the center of the
    double yprice = descPro->getPositionY() - descPro->getContentSize().height /2 - fixHeightIpad - price->getContentSize().height / 2;
    double xprice = wScene / 2;// - (btnWidthKey / 2 + 5);
    price->setPosition(Vec2(xprice, yprice));
    // add the label as a child to this layer
    addChild(price, 101);
    
    //create Underline
    auto underlineImg = Sprite::create("underline-pro.png");
    float ratiounderlineImg = 2;
    //float fixHeightNotiIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        ratiounderlineImg = 4;
        //fixHeightNotiIpad = 0.5;
    }
    
    float scaleunderlineImg = wScene / ratiounderlineImg / underlineImg->getContentSize().width;
    underlineImg->setScale(scaleunderlineImg);
    underlineImg->setPosition(Vec2(wScene / 2, price->getPositionY() - price->getContentSize().height / 2 - underlineImg->getContentSize().height * scaleunderlineImg * 0.15)); // Đặt vị trí
    this->addChild(underlineImg, 101);
    
    
    
    fontSize = 0.05 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.02 * wScene;
    }
    auto restorePurchaseBtn = ui::Button::create("empty.png");
    restorePurchaseBtn->setPressedActionEnabled(true);
    restorePurchaseBtn->setZoomScale(-0.1f);
    restorePurchaseBtn->setScale9Enabled(true);
    restorePurchaseBtn->setTitleText("Restore Purchase");
    if(appLang == "en" || appLang == "vi"){
        restorePurchaseBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    restorePurchaseBtn->setTitleColor(Color3B().WHITE);
    restorePurchaseBtn->setOpacity(200);
    restorePurchaseBtn->setTouchEnabled(true);
    float ratiotitle = 3;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 6;
        
    }
    auto scalerestoreBtn = wScene / ratiotitle / restorePurchaseBtn->getContentSize().width;
    restorePurchaseBtn->setScale(scalerestoreBtn);
    restorePurchaseBtn->setTitleFontSize(fontSize / scalerestoreBtn);
    if (appLang == "ja")
    {
        restorePurchaseBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        restorePurchaseBtn->setTitleFontSize(0.045 * wScene / scalerestoreBtn);
    }
    float ytitle = 40;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        
        ytitle = 20;
    }
    if (hScene / wScene <= 1.53)
    {
        
        if (appLang == "ja")
        {
            
            restorePurchaseBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
        }
    }
    restorePurchaseBtn->setPosition(Vec2(wScene / 2, ytitle));
    restorePurchaseBtn->setEnabled(true);
    restorePurchaseBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("restore purchasing");
                IAPManager::getInstance()->restorePurchases();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(restorePurchaseBtn, 101);
    
    float fontSize2 = 0.07 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize2 = 0.035 * wScene;
    }
    auto upProBtn = ui::Button::create("button-pro.png");
    upProBtn->setPressedActionEnabled(true);
    upProBtn->setZoomScale(-0.1f);
    upProBtn->setScale9Enabled(true);
    upProBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("PRO_BUY").c_str());
    if(appLang == "en" || appLang == "vi"){
        upProBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    upProBtn->setTitleColor(Color3B().WHITE);
    upProBtn->setTouchEnabled(true);
    ratiotitle = 1.5;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 3.4;
       
    }
    auto scaleUpProBtn = wScene / ratiotitle / upProBtn->getContentSize().width;
    upProBtn->setScale(scaleUpProBtn);
    upProBtn->setTitleFontSize(fontSize2 / scaleUpProBtn);
    if (appLang == "ja")
    {
        upProBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        upProBtn->setTitleFontSize(0.05 * wScene / scaleUpProBtn);
    }
    ytitle = ytitle + restorePurchaseBtn->getContentSize().height * scalerestoreBtn / 2 + upProBtn->getContentSize().height * scaleUpProBtn / 2 + 7;
    if (hScene / wScene <= 1.53)
    {
      
        if (appLang == "ja")
        {
            upProBtn->setTitleFontSize(0.025 * wScene / scaleUpProBtn);
        }
    }
    upProBtn->setPosition(Vec2(wScene / 2, ytitle));
    upProBtn->setEnabled(true);
    upProBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("up to pro");
                IAPManager::getInstance()->purchase(Variable().proProductionID);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(upProBtn, 101);
    
}

void PlayDual::onEnter() {
    Layer::onEnter();

    // Đăng ký callback khi mua thành công
    IAPManager::getInstance()->setOnPurchaseSuccess([this](std::string productID) {
        log("🎉 Mua thành công - restore thanh cong: %s", productID.c_str());
        UserDefault::getInstance()->setBoolForKey("isProVer", true);
        //Variable().isProVer = true;
        UserDefault::getInstance()->flush();
        this->finish();
    });

    // Đăng ký callback khi mua thất bại
    IAPManager::getInstance()->setOnPurchaseFailed([this](std::string productID, std::string error) {
        log("❌ Mua thất bại: %s | Lỗi: %s", productID.c_str(), error.c_str());
        //this->finish();
        
        
    });
    
    // Đăng ký callback lấy giá
    IAPManager::getInstance()->setOnPriceRetrieved([this](std::string productID, std::string price) {
        log("📦 Giá của %s là: %s", productID.c_str(), price.c_str());
        // Gợi ý: update label nút mua
        //this->price->setString(price.c_str());
        UserDefault::getInstance()->setStringForKey("gia", price.c_str());
    });

    // Yêu cầu lấy giá từ App Store
    IAPManager::getInstance()->requestProductInfo(Variable().proProductionID);
}
void PlayDual::finish() {
    if (Variable().isProduction == true) {
        HuyFunctions().showAds();
    }

    HuyFunctions().saveSoGame("g2");
    if(d_isMulti == true){
        d_typeOfW = 1;
    }
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, FinishDual::createScene(d_score, d_scoreDup, d_typeOfW, d_levelOfW), Color3B().WHITE));
}
