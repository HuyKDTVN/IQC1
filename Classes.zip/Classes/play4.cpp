#include "play4.hpp"
#include "mathSelect.h"
#include "finish.h"
#include "SelectGame.hpp"
#include "ui/CocosGUI.h"
#include <SimpleAudioEngine.h>
#include <iostream>
#include <string>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "Huy_functions/CreatePhepToan.hpp"
#include <cmath> // Thư viện toán học tiêu chuẩn
#include "LanguageManager.h"
#include "IAPManager.h"

using namespace std;
USING_NS_CC;

int typeOfW4;
int levelOfW4;
int isMulti4 = false;
int backTypePT4 = 0;
bool fromChallenge4;
Scene* Play4::createScene(int type, int level, int backTypePhepTinh, bool fromChallenge)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    typeOfW4 = type;
    if(typeOfW4 == 1){
        isMulti4 = true;
    }
    levelOfW4 = level;
    fromChallenge4 = fromChallenge;
    // 'layer' is an autorelease object
    backTypePT4 = backTypePhepTinh;
    
    auto layer = Play4::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
// on "init" you need to initialize your instance
bool Play4::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }
    score2 = 0;
    if (UserDefault::getInstance()->getIntegerForKey("height-score2", 99999) == 99999)
    {
        UserDefault::getInstance()->setIntegerForKey(HIGH_SCORE2, 0);
        UserDefault::getInstance()->flush();
    }
    auto mLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    maxDoiSo2 = HuyFunctions().SoLonNhat(mLang);
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float wScene;
    float hScene;
    
    batDauHienCandyTuCauHoi = Variable().batDauHienCandyTuCauHoi;
    batDauHienSaoChoiTuCauHoi = Variable().batDauHienSaoChoiTuCauHoi;
    batDauHienHoDenTuCauHoi = Variable().batDauHienHoDenTuCauHoi;
    batDauHienVirusTuCauHoi = Variable().batDauHienVirusTuCauHoi;
    batDauTangChuyenDongVirusTuCauHoi = Variable().batDauTangChuyenDongVirusTuCauHoi;
    
    count = 1;
    countVang = 1;
    viTriVatCan = true;
    soVatCan = 1;
    soVang = 1;
    soCandy = 1;
    
    scalePhiThuyen = 1;
    
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    wScenePlay2 = wScene;
    hScenePlay2 = hScene;
    
    if (hScene / wScene <= 1.53)
    {
        isIpad = true;
    }

    //set bg
    //createBg(wScene, hScene);

    //countdown timer + loading bar
    coundownTimer(wScene, hScene);
    //end: countdown timer + loading bar

    realType2 = typeOfW4;

    back(wScene, hScene);
    //createButtonKey(wScene, hScene);

    randomQuestionAndAnswer();
    
    indexThemDiem = HuyFunctions().getRandomForThemDiem();

    createScore(wScene, hScene);
    createMainTemplate(wScene, hScene);
    createPhiThuyen(wScene, hScene);
    scalePhiThuyen = phithuyenHienThi->getScale();
    createVatCan(wScene, hScene);
    createSaoChoi(wScenePlay2, hScenePlay2);
    
    createGroupGold(wScene, hScene);
    
    
    createAnswer(wScene, hScene);
    createPopupFinish(wScene, hScene);
    
    //log("HUY ----- type: %i, level: %i", typeOfW4, levelOfW4);
    
    createBgColor(wScene, hScene);

    //log("hLoadingBar: %f", hLoadingBar);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(4);
    }
    //this->setKeypadEnabled(true);
    
    auto arrNoti = CreatePhepToan().createAnswerQuestions(typeOfW4, levelOfW4, prevA2, prevB2, maxDoiSo2);
    UserDefault::getInstance()->setStringForKey("noti-title1", HuyFunctions().createPhepToanWithEmoji(arrNoti.at(2).c_str()));
    
    log("FPS rate: %f", cocos2d::Director::getInstance()->getFrameRate());
    return true;
}
void Play4::showMedal(float wScene, float hScene, std::string medal){
    auto fixIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        fixIpad = 2;
    }

    auto iconMedal = Sprite::create(medal);

    float ratioMedal = 6 * fixIpad;
    float scaleiconMedal = wScene / ratioMedal / iconMedal->getContentSize().width;

    // Vị trí giữa màn hình
    iconMedal->setPosition(Vec2(wScene / 2, hScene * 0.7));

    // Bắt đầu từ 0
    iconMedal->setScale(0.0f);
    iconMedal->setOpacity(0);

    this->addChild(iconMedal, 15);

    /// ===== ANIMATION =====

    // Move lên khi xuất hiện (30px)
    auto moveUp = MoveBy::create(0.2f, Vec2(0, 30 / fixIpad));

    // Scale từ 0 -> x1.3
    auto scaleUp = ScaleTo::create(0.2f, scaleiconMedal * 1.3);

    // Fade in
    auto fadeIn = FadeTo::create(0.2f, 255);

    // Scale + Fade + Move lên cùng lúc
    auto spawnIn = Spawn::create(scaleUp, fadeIn, moveUp, nullptr);

    // Giữ 1 chút
    auto delay = DelayTime::create(0.4f);

    // Move xuống nhẹ khi hide
    auto moveDown = MoveBy::create(0.6f, Vec2(0, -15 / fixIpad));

    // Fade out
    auto fadeOut = FadeOut::create(0.6f);

    // Fade + Move xuống cùng lúc khi hide
    auto spawnOut = Spawn::create(fadeOut, moveDown, nullptr);

    // Xóa sprite sau khi xong
    auto remove = RemoveSelf::create();

    // Chạy sequence
    iconMedal->runAction(
        Sequence::create(
            spawnIn,
            delay,
            spawnOut,
            remove,
            nullptr
        )
    );
}
void Play4::createBgColor(float w, float h) {
    //create bg color
    Sprite* bgColor = Sprite::create("bg13.jpg");
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    this->addChild(bgColor, 1);
    
    Sprite* bgColor2 = Sprite::create("bg13.jpg");
    bgColor2->setScale(scalebgColor);
    bgColor2->setAnchorPoint(Vec2(0, 0));
    bgColor2->setPosition(Vec2(0, 0));
    this->addChild(bgColor2, 1);
    
    bgColor->setPosition(Vec2(0, 0));
    bgColor2->setPosition(Vec2(0, bgColor->getContentSize().height * scalebgColor));

    // Tạo hành động di chuyển
 
    float duration = 8.0f; // Thời gian di chuyển từ một bên sang bên kia
    MoveBy* moveByAction = MoveBy::create(duration, Vec2(0, -h));
    bgColor->runAction(RepeatForever::create(Sequence::create(moveByAction, MoveTo::create(0, Vec2(0, h)), nullptr)));
    bgColor2->runAction(RepeatForever::create(Sequence::create(moveByAction->clone(), MoveTo::create(0, Vec2(0,  h - bgColor->getContentSize().height * scalebgColor)), nullptr)));

    
}
void Play4::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathLevel::createScene(typeOfW4), Color3B().WHITE));
}
void Play4::createGold (float w, float h, float xVang, float yVang){
    //create gold
    vang = ui::Button::create("coin.png"); // tao button
    vang->setTouchEnabled(false);
    float ratioVang = 23;
    if (isIpad)
    {
        ratioVang = 50;
    }
    float scaleVang = w / ratioVang / vang->getContentSize().width;
    
    vang->setScale(scaleVang);
    
    vang->setPosition(Vec2(xVang, yVang));
    vang->setEnabled(true);
    vang->setName(cocos2d::__String::createWithFormat("%i", soVang)->getCString());
    listGold.pushBack(vang);
    this->addChild(vang, 2);
    
    vang->setOpacity(0);
    vang->runAction(Sequence::create(FadeIn::create(0.5), nullptr));
    float duration = timeMax2; // Thời gian di chuyển từ một bên sang bên kia
    MoveBy* moveByAction = MoveBy::create(duration * 1.1, Vec2(0, -h * 1.5));
    vang->runAction(Sequence::create(
            moveByAction,
            RemoveSelf::create(),
            nullptr
            )
    );
    soVang++;
}

void Play4::createCandy (float w, float h, float x, float y){
    //create gold
    candy = ui::Button::create("candy.png"); // tao button
    candy->setTouchEnabled(false);
    float ratiocandy = 13;
    if (isIpad)
    {
        ratiocandy = 26;
    }
    float scalecandy = w / ratiocandy / candy->getContentSize().width;
    
    candy->setScale(scalecandy);

     
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (candy->getContentSize().height / 2 * scalebgColor);
    }
    
    candy->setPosition(Vec2(x, y));
    candy->setEnabled(true);
    candy->setName(cocos2d::__String::createWithFormat("%i", soCandy)->getCString());
    listCandy.pushBack(candy);
    this->addChild(candy, 2);
    
    
    candy->setOpacity(0);
    candy->runAction(Sequence::create(FadeIn::create(0.5), nullptr));
    float duration = timeMax2; // Thời gian di chuyển từ một bên sang bên kia
    MoveBy* moveByAction = MoveBy::create(duration * 1.1, Vec2(0, -h * 1.5));
    candy->runAction(Sequence::create(
            moveByAction,
            RemoveSelf::create(),
            nullptr
            )
    );
    // Tạo hành động nghiêng sang trái
    
    float t = cocos2d::RandomHelper::random_int(5, 9) / 10.f;
    int angle = cocos2d::RandomHelper::random_int(12, 18);
    auto tiltLeft = RotateBy::create(t, 0 - angle);  // Xoay -2 độ
    // Tạo hành động nghiêng sang phải
    auto tiltRight = RotateBy::create(t, angle);   // Xoay +2 độ
    // Lặp lại hành động
    auto tilting = RepeatForever::create(Sequence::create(tiltLeft, tiltRight, nullptr));
    // Chạy animation cho phi thuyền
    candy->runAction(tilting);
    
    
    auto moveUp = MoveBy::create(t, Vec2(0, 7));
    auto moveDown = MoveBy::create(t, Vec2(0, -7));
    auto waveMotion = RepeatForever::create(Sequence::create(moveUp, moveDown, nullptr));

    candy->runAction(waveMotion);

    soCandy++;
}

void Play4::createStar (float w, float h, float xStar, float yStar, bool isMain){
    //create star
    auto star = ui::Button::create("star-small.png"); // tao button
    star->setTouchEnabled(false);
    float ratiostar = 12;
    if (isMain == false) {
        ratiostar = 16;
    }
    if (isIpad)
    {
        ratiostar = 24;
        if (isMain == false) {
            ratiostar = 32;
        }
    }
    float scalestar = w / ratiostar / star->getContentSize().width;
    
    star->setScale(scalestar);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (star->getContentSize().height / 2 * scalebgColor);
    }
    
    star->setPosition(Vec2(xStar, yStar));
    star->setEnabled(true);
    //star->setName(cocos2d::__String::createWithFormat("%i", sostar)->getCString());
    //listGold.pushBack(star);
    this->addChild(star, 2);
    
    
    star->setOpacity(0);
  
    star->runAction(
        Sequence::create(
            Spawn::create(FadeIn::create(0.1), RotateTo::create(0.1, 25), nullptr),
            DelayTime::create(0.2),
            Spawn::create(FadeOut::create(0.1), RotateTo::create(0.1, -25), nullptr),
            RemoveSelf::create(),
        nullptr)
    );
}
void Play4::createPhiThuyen (float w, float h){
    // create Phi thuyen
    auto viTriPhiThuyen = UserDefault::getInstance()->getIntegerForKey("phithuyendachon", 0) + 1;
    auto sprite_cachePhiThuyen = SpriteFrameCache::getInstance();
    sprite_cachePhiThuyen->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d1.plist", viTriPhiThuyen));
    Vector<SpriteFrame*> phiThuyen;
    phiThuyen.reserve(2);
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1a.png", viTriPhiThuyen)));
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1b.png", viTriPhiThuyen)));
    Animation* animationPhiThuyen = Animation::createWithSpriteFrames(phiThuyen, 0.2f, -1);
    Animate* animatePhiThuyen = Animate::create(animationPhiThuyen);

    phithuyenHienThi = Sprite::createWithSpriteFrame(phiThuyen.front());
    float fixPhiThuyenType = 0;
    float fixPhiThuyenTypeEarth = 1;
    float fixPhiThuyenScale = 1;
    if (viTriPhiThuyen > 1) {
        fixPhiThuyenType = 20;
    }
    if (viTriPhiThuyen > 2) {
        fixPhiThuyenScale = 0.6;
        fixPhiThuyenTypeEarth = 0.5;
    }
//    if (viTriPhiThuyen == 3) {
//        fixPhiThuyenTypeEarth = 0.3;
//    }
    float ratioPhiThuyen = 5;
    float fixWidthIpad = 0.3;
    if (isIpad)
    {
        ratioPhiThuyen = 10;
        fixWidthIpad = 0.2;
    }
    float scalePhiThuyen = w / ratioPhiThuyen / phithuyenHienThi->getContentSize().width;
    phithuyenHienThi->setScale(scalePhiThuyen * fixPhiThuyenScale);

    //float ytitle = h * 0.9 - (earth->getContentSize().height / 2 * scalebgColor);
    float xtitlePhiThuyen = w * fixWidthIpad - (phithuyenHienThi->getContentSize().width / 2 * scalePhiThuyen);
    float ytitlePhiThuyen = h * 0.3 - (phithuyenHienThi->getContentSize().height / 2 * scalePhiThuyen) + fixPhiThuyenType;
    
    phithuyenHienThi->setPosition(Vec2(xtitlePhiThuyen, ytitlePhiThuyen));
    phithuyenHienThi->runAction(animatePhiThuyen);
    this->addChild(phithuyenHienThi, 11);
    phithuyenHienThi->setTag(0);
    phithuyenHienThi->setOpacity(0);
    phithuyenHienThi->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(0.5), nullptr));
    
    // Tạo hành động nghiêng sang trái
    auto tiltLeft = RotateBy::create(0.7f, -4);  // Xoay -2 độ
    // Tạo hành động nghiêng sang phải
    auto tiltRight = RotateBy::create(0.7f, 4);   // Xoay +2 độ
    // Lặp lại hành động
    auto tilting = RepeatForever::create(Sequence::create(tiltLeft, tiltRight, nullptr));
    // Chạy animation cho phi thuyền
    phithuyenHienThi->runAction(tilting);
    
    
    auto moveUp = MoveBy::create(0.7f, Vec2(0, 12));
    auto moveDown = MoveBy::create(0.7f, Vec2(0, -12));
    auto waveMotion = RepeatForever::create(Sequence::create(moveUp, moveDown, nullptr));

    phithuyenHienThi->runAction(waveMotion);
    
    
    
    
    //create bom phiThuyen
    auto sprite_cachePhiThuyenBom = SpriteFrameCache::getInstance();
    sprite_cachePhiThuyenBom->addSpriteFramesWithFile("bom-tim.plist");
    Vector<SpriteFrame*> phiThuyenBom;
    phiThuyenBom.reserve(12);
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("1.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("2.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("3.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("4.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("5.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("6.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("7.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("8.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("9.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("10.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("11.png"));
    phiThuyenBom.pushBack(sprite_cachePhiThuyenBom->getSpriteFrameByName("12.png"));
    Animation* animationPhiThuyenBom = Animation::createWithSpriteFrames(phiThuyenBom, 0.06f, -1);
    Animate* animatePhiThuyenBom = Animate::create(animationPhiThuyenBom);

    bomPhiThuyenHienThi = Sprite::createWithSpriteFrame(phiThuyenBom.front());
    float ratioPhiThuyenBom = 3.5;
    if (isIpad)
    {
        ratioPhiThuyenBom = 7;
    }
    float scalePhiThuyenBom = w / ratioPhiThuyenBom / bomPhiThuyenHienThi->getContentSize().width;
    bomPhiThuyenHienThi->setScale(scalePhiThuyenBom);

    //float ytitle = h * 0.9 - (phiThuyen->getContentSize().height / 2 * scalebgColor);
    //float xtitlePhiThuyenBom = phi->getPositionX() + bomPhiThuyenHienThi->getContentSize().width / 2 * scalebgColor - (bomPhiThuyenHienThi->getContentSize().width / 2 * scalePhiThuyenBom) * 0.8;
    //float ytitlePhiThuyenBom = bomPhiThuyenHienThi->getPositionY() + bomPhiThuyenHienThi->getContentSize().height / 2 * scalebgColor - (bomPhiThuyenHienThi->getContentSize().height / 2 * scalePhiThuyenBom) * 0.9;
    
    bomPhiThuyenHienThi->setPosition(Vec2(w/2, h*0.9));
    bomPhiThuyenHienThi->runAction(animatePhiThuyenBom);
    this->addChild(bomPhiThuyenHienThi, 2);
    bomPhiThuyenHienThi->setOpacity(0);
}

void Play4::createBomCandy(float w, float h, float x, float y){
    auto sprite_cacheCandyBom = SpriteFrameCache::getInstance();
    sprite_cacheCandyBom->addSpriteFramesWithFile("bom-candy.plist");
    Vector<SpriteFrame*> CandyBom;
    CandyBom.reserve(7);
    CandyBom.pushBack(sprite_cacheCandyBom->getSpriteFrameByName("bomcandy1.png"));
    CandyBom.pushBack(sprite_cacheCandyBom->getSpriteFrameByName("bomcandy2.png"));
    CandyBom.pushBack(sprite_cacheCandyBom->getSpriteFrameByName("bomcandy3.png"));
    CandyBom.pushBack(sprite_cacheCandyBom->getSpriteFrameByName("bomcandy4.png"));
    CandyBom.pushBack(sprite_cacheCandyBom->getSpriteFrameByName("bomcandy5.png"));
    CandyBom.pushBack(sprite_cacheCandyBom->getSpriteFrameByName("bomcandy6.png"));
    CandyBom.pushBack(sprite_cacheCandyBom->getSpriteFrameByName("bomcandy7.png"));
    Animation* animationCandyBom = Animation::createWithSpriteFrames(CandyBom, 0.06f, 1);
    Animate* animateCandyBom = Animate::create(animationCandyBom);

    bomCandyHienThi = Sprite::createWithSpriteFrame(CandyBom.front());
    float ratioCandyBom = 4.5;
    if (isIpad)
    {
        ratioCandyBom = 9;
    }
    float scaleCandyBom = w / ratioCandyBom / bomCandyHienThi->getContentSize().width;
    bomCandyHienThi->setScale(scaleCandyBom);
    bomCandyHienThi->setPosition(Vec2(x, y));
    bomCandyHienThi->runAction(animateCandyBom);
    this->addChild(bomCandyHienThi, 2);
    bomCandyHienThi->setOpacity(0);
}

void Play4::createVatCan(float w, float h) {
    //create vat can
    int vatCanIndex = cocos2d::RandomHelper::random_int(1, 5); //1, 7
    auto loaiVatCan = StringUtils::format("thienthach%d.png", vatCanIndex);
    
//    if (soCauHoiDaVuotQua > 0) {
//    //if (soCauHoiDaVuotQua > batDauHienHoDenTuCauHoi) {
//        if (cocos2d::RandomHelper::random_int(1, 3) == 1) {
//            loaiVatCan = "lo-den.png";
//        }
//    }
    
    if (soCauHoiDaVuotQua > batDauHienHoDenTuCauHoi) {
    //if (soCauHoiDaVuotQua > batDauHienVirusTuCauHoi) {
        if (cocos2d::RandomHelper::random_int(1, 3) == 1) {
            vatCanIndex = cocos2d::RandomHelper::random_int(1, 5);
            loaiVatCan = StringUtils::format("vikhuan%d.png", vatCanIndex);

        }
    }
    earth = ui::Button::create(loaiVatCan); // tao button
    earth->setTouchEnabled(false);
    float ratiobgColor = 8;
    if (isIpad)
    {
        ratiobgColor = 12;
    }
    float scalebgColor = w / ratiobgColor / earth->getContentSize().width;
    
    earth->setScale(scalebgColor);
    
    float fixWidthIpad = 0.3;
    if (isIpad)
    {
        fixWidthIpad = 0.2;
    }
    float ytitle = h * 1.7;// - (earth->getContentSize().height / 2 * scalebgColor);
    float xtitle = w * fixWidthIpad - (earth->getContentSize().width / 2 * scalebgColor);
    if (viTriVatCan == false) {
        xtitle = w - xtitle;
        viTriVatCan = true;
    } else {
        viTriVatCan = false;
    }
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (earth->getContentSize().height / 2 * scalebgColor);
    }
    
    earth->setPosition(Vec2(xtitle, ytitle));
    earth->setEnabled(true);
    earth->setName(cocos2d::__String::createWithFormat("%i", soVatCan)->getCString());
    this->addChild(earth, 3);
    cacVatCan.pushBack(earth);
    
    earth->setOpacity(0);
    earth->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(0.5), nullptr));
    
    float duration = timeMax2; // Thời gian di chuyển từ một bên sang bên kia
    MoveBy* moveByAction = MoveBy::create(duration, Vec2(0, -h * 1.7));
    earth->runAction(Sequence::create(
            moveByAction,
            RemoveSelf::create(),
            nullptr
            )
    );
    
    float timeAnimation = 0.9;
    auto playAnimationZoomOut1 = ScaleTo::create(timeAnimation, 1 * scalebgColor);
    auto playAnimationZoomOut2 = ScaleTo::create(timeAnimation, scalebgColor * 0.9);
    auto sq1 = Sequence::create(playAnimationZoomOut1, playAnimationZoomOut2, nullptr);
    earth->runAction((RepeatForever::create(sq1)));

    
    soVatCan++;
}

void Play4::createSaoChoi(float w, float h) {
    if (soCauHoiDaVuotQua >= batDauHienSaoChoiTuCauHoi) {
        if (cocos2d::RandomHelper::random_int(1, 8) == 1) {
            //create vat can
            int vatCanIndex = cocos2d::RandomHelper::random_int(1, 3); //1, 7
            earth = ui::Button::create(StringUtils::format("sao-choi-%d.png", vatCanIndex)); // tao button
            earth->setTouchEnabled(false);
            float ratiobgColor = 8;
            if (isIpad)
            {
                ratiobgColor = 12;
            }
            float scalebgColor = w / ratiobgColor / earth->getContentSize().width;
            
            earth->setScale(scalebgColor);

            float ytitle = h * 0.8 - h * cocos2d::RandomHelper::random_int(1, 3) / 30;// - (earth->getContentSize().height / 2 * scalebgColor);
            float xtitle = w * 0.5;// + (earth->getContentSize().width / 2 * scalebgColor);
            if (viTriVatCan == false) {
                xtitle = w - xtitle;
                viTriVatCan = true;
            } else {
                viTriVatCan = false;
            }
            if (h / w <= 1.8)
            {
                //ytitle = 1.06 * h - (earth->getContentSize().height / 2 * scalebgColor);
            }
            xtitle = w - phithuyenHienThi->getPositionX();
            Vec2 dist = Vec2(phithuyenHienThi->getPositionX() * 2, phithuyenHienThi->getPositionY() * 2);
            if (xtitle >= w / 2) {
                xtitle = w / 2 + xtitle;
                dist = Vec2(phithuyenHienThi->getPositionX() * 2, phithuyenHienThi->getPositionY() * 2);
            } else{
                xtitle = - w / 2  + xtitle;
            }
            earth->setPosition(Vec2(xtitle, ytitle));
            
            float tanA = (xtitle - phithuyenHienThi->getPositionX()) / (ytitle - phithuyenHienThi->getPositionY());
            float angleInRadians = atanf(tanA);
            float gocA = CC_RADIANS_TO_DEGREES(angleInRadians);
            
            earth->setEnabled(true);
            earth->setName(cocos2d::__String::createWithFormat("%i", soVatCan)->getCString());
            earth->setRotation(gocA);
            this->addChild(earth, 3);
            cacVatCan.pushBack(earth);
            
            earth->setOpacity(0);
            earth->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(0.5), nullptr));
            
            float duration = timeMax2; // Thời gian di chuyển từ một bên sang bên kia
            
            MoveBy* moveByAction = MoveTo::create(duration * 1.4, dist);
            earth->runAction(Sequence::create(
                    moveByAction,
                    RemoveSelf::create(),
                    nullptr
                    )
            );
            soVatCan++;
        }
    }
    
}
void Play4::coundownTimer(float w, float h){
    switch (levelOfW4)
    {
        case 1:
            timeRemaining2 = Variable().timeBasic;
            timeMax2 = Variable().timeBasic;
            if (typeOfW4 == 3 || typeOfW4 == 2) {
                timeRemaining2 = Variable().timeBasicNhan;
                timeMax2 = Variable().timeBasicNhan;
            }
            break;
        case 2:
            timeRemaining2 = Variable().timeHard;
            timeMax2 = Variable().timeHard;
            if (typeOfW4 == 3 || typeOfW4 == 2) {
                timeRemaining2 = Variable().timeHardNhan;
                timeMax2 = Variable().timeHardNhan;
            }
            break;
        case 3:
            timeRemaining2 = Variable().timeVeryHard;
            timeMax2 = Variable().timeVeryHard;
            if (typeOfW4 == 3 || typeOfW4 == 2) {
                timeRemaining2 = Variable().timeVeryHardNhan;
                timeMax2 = Variable().timeVeryHardNhan;
            }
            break;
        default:
            timeRemaining2 = 20.f;
            timeMax2 = 20.f;
            break;
    }

    
    this->scheduleUpdate();
}
void Play4::update(float dt) {
    
    // make sure game is still running
    if (timeRemaining2 > 0.f) {
        
        timeRemaining2 -= dt;
        //log("timeRemaining2: %f", timeRemaining2);
        //if (isPause2 == true)
        //{
            //log("da pause");
        //}
        //else{
            //log("loadingBar_2: %f", timeRemaining2 * ratioLoadingBar_2);
            //if (count == 200) {
                
                //count = 1;
                
                //countVang = 1;
            //}
            
            //log("vi tri phi thuyen: %f, %f", phithuyenHienThi->getPositionX(), phithuyenHienThi->getPositionY());
            
            for (auto button : cacVatCan) {
                if(button) {
                    Vec2 positionC = button->getPosition();
                    Vec2 positionD = phithuyenHienThi->getPosition();
                    float scaleThienThach = button->getScale();
                // Kiểm tra xem button A có va chạm với button B hay không
                if (positionC.distance(positionD) < (button->getContentSize().width * scaleThienThach / 2  + phithuyenHienThi->getContentSize().width * phithuyenHienThi->getScale() / 2 )) {
                    
                        handlerClickAnswer(33391);
                        button->runAction(Sequence::create(
                               DelayTime::create(0.2),
                               ScaleTo::create(0.03, scaleThienThach * 1.5),
                               DelayTime::create(0.05),
                               ScaleTo::create(0.03, scaleThienThach),
                               nullptr));
                        
                        log("co van cham voi vat can: %s", button->getName().c_str());
                    } else {
                        //log("khong va cham");
                    }
                }
            }

            for (auto button : listGold) {
                if(button) {
                    //log("test gold %s", button->getName().c_str());
                    //log("ten vat can %s", button->getName().c_str());
//                    Rect rectC = button->getBoundingBox();
//                    rectC.origin.x -= rectC.size.width;
//                        rectC.origin.y -= rectC.size.height / 5;
//                        //rectC.size.width *= 3;
//                        rectC.size.height *= 5;
//                    
//                    Rect rectD = phithuyenHienThi->getBoundingBox();
//
//                        // Check if the bounding boxes intersect
//                    if (rectC.intersectsRect(rectD)) {
                    
                    
                    // Lấy vị trí hiện tại của button A và B
                        Vec2 positionA = button->getPosition();
                        Vec2 positionB = phithuyenHienThi->getPosition();

                    // Kiểm tra xem button A có va chạm với button B hay không
                    if (positionA.distance(positionB) < (button->getContentSize().width * button->getScale() / 2 * 1.05 + phithuyenHienThi->getContentSize().width * phithuyenHienThi->getScale() / 2 * 1.1)) {
                    //float scalePopup = 1;
                        positionGold = button->getPosition();
                        auto callFunc = CallFunc::create([this]() {
                                this->updateScore(false);
                            });
                        
                        
                        button->runAction(Sequence::create(FadeOut::create(0.1),RemoveSelf::create(), callFunc, NULL));
                        
                        //log("an vang: %s", button->getName().c_str());
                    } else {
                        //log("khong va cham");
                    }
                }
            }
        
        for (auto button : listCandy) {
            if(button) {
                    Vec2 positionA = button->getPosition();
                    Vec2 positionB = phithuyenHienThi->getPosition();

                // Kiểm tra xem button A có va chạm với button B hay không
                if (positionA.distance(positionB) < (button->getContentSize().width * button->getScale() / 2 * 1.05 + phithuyenHienThi->getContentSize().width * phithuyenHienThi->getScale() / 2 * 1.05)) {
                //float scalePopup = 1;
                    positionCandy = button->getPosition();
                    auto callFunc = CallFunc::create([this]() {
                            this->updateScore(true);
                        });
                    
                    
                    button->runAction(Sequence::create(FadeOut::create(0.1),RemoveSelf::create(), callFunc, NULL));
                    
                    //log("an vang: %s", button->getName().c_str());
                } else {
                    //log("khong va cham");
                }
            }
        }

        //}
        // update the label or whatever displays the time here. if displaying the number, use ceilf to round
        // up the time remaining so that you don't display lots of numbers after the decimal point

        // check if time ran out
        if (timeRemaining2 <= 0.f && isPause2 == false) {
            // timer ran out; react here
            timeRemaining2 = timeMax2; //khong bao gio het gio
            //handlerClickAnswer(33391);
            
            createVatCan(wScenePlay2, hScenePlay2);
            createSaoChoi(wScenePlay2, hScenePlay2);
            createGroupGold(wScenePlay2, hScenePlay2);
            earth->setPositionX(phithuyenHienThi->getPositionX());
            log("Het gio");
        }
    }
    count++;
    countVang++;
}
void Play4::updateScore(bool isCandy) {
    if (sound2 == 0)
    {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
    }

    
    float time = 0.2;
    if (isCandy) {
        score2 = score2 + 10;
        createpPopUpCongDiem(wScenePlay2, hScenePlay2, positionCandy.x, positionCandy.y + hScenePlay2 / 15);
        createBomCandy(wScenePlay2, hScenePlay2, positionCandy.x, positionCandy.y);
        bomCandyHienThi->runAction(Sequence::create(FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
    } else {
        
        score2++;
        createGroupStar(wScenePlay2, hScenePlay2, positionGold.x, positionGold.y);
    }
    
    lblScore2->runAction(Sequence::create(DelayTime::create(1.9), FadeOut::create(time), NULL));
    score2Icon2->runAction(Sequence::create(DelayTime::create(2.0), FadeOut::create(time), NULL));
    removeChild(lblScore2);
    removeChild(score2Icon2);
    createScore(wScenePlay2, hScenePlay2);
    
//    float scalePopup = popupthanhCong->getScale();
//    popupthanhCong->runAction(
//      Sequence::create(
//           
//           Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr),
//           ScaleTo::create(0.03, 0.94 * scalePopup),DelayTime::create(0.1),
////           Spawn::create(
////                 MoveTo::create(1.3, Vec2(score2Icon2->getPositionX() + score2Icon2->getScale() * score2Icon2->getContentSize().width, score2Icon2->getPositionY())),
////                 ScaleTo::create(1.3, scalePopup / 2.5),
////                 nullptr),
//           FadeTo::create(0.1, 0), NULL)
//    );
    phithuyenHienThi->runAction(Sequence::create(
         ScaleTo::create(0.05, scalePhiThuyen * 1.2),
         ScaleTo::create(0.05, scalePhiThuyen),
         DelayTime::create(0.1),
         NULL));
    
}
void Play4::createpPopUpCongDiem(float w, float h, float x, float y) {
    //int bgIndex = cocos2d::RandomHelper::random_int(1, 4);
    //popupthanhCong = ui::Button::create(StringUtils::format("popup-thanh-cong-%d.png", bgIndex)); // tao button
    //auto imgNameThemDiem = Variable().diemNgauNhienImg.at(indexThemDiem);
    //popupthanhCong = ui::Button::create(imgNameThemDiem.c_str());
    auto popupthanhCong = ui::Button::create("+10.png");
    popupthanhCong->setTouchEnabled(false);
    float ratiopopupthanhCong = 5;
    if (isIpad)
    {
        ratiopopupthanhCong = 10;
    }
    float scalepopupthanhCong = w / ratiopopupthanhCong / popupthanhCong->getContentSize().width;
    

    //log("ti le test: %f", scalepopupthanhCong);
    //log("ti le test theo w: %f", w / ratiopopupthanhCong / popupthanhCong->getContentSize().width);
    popupthanhCong->setScale(scalepopupthanhCong);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }

    Vec2 positionPopupThanhCong = Vec2(x, y);
//    if (isIpad)
//    {
//        positionPopupThanhCong = Vec2(w * 2.8 / 4, h * 0.9);
//    }

    popupthanhCong->setPosition(positionPopupThanhCong);
    popupthanhCong->setEnabled(true);
    this->addChild(popupthanhCong, 12);
    popupthanhCong->setOpacity(0);
    popupthanhCong->setScale(0.6);
    popupthanhCong->runAction(
      Sequence::create(
            Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalepopupthanhCong), nullptr),
            ScaleTo::create(0.03, 0.94 * scalepopupthanhCong),
            DelayTime::create(0.7),
            FadeTo::create(0.2, 0),
            RemoveSelf::create(),
            NULL)
    );
}
void Play4::createGroupGold(float w, float h) {
    int randX = 1;
    int randY = 1;
    
    float xVang = w * 0.5;
    float yVang = h * 0.5;
    
    bool flagCandy = true;
    if (soCauHoiDaVuotQua >= batDauHienCandyTuCauHoi) {
        flagCandy = false;
    }
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < (5 - i); j++) {
            randX = cocos2d::RandomHelper::random_int(1, 10);
            randY = cocos2d::RandomHelper::random_int(1, 10);
            //log("randY: %i", randY);
            xVang = w / 4 + w * (j + i * 0.5) / 10 * (1 - randX / 10 * 0.5);
            yVang = h * 1 + i * (h/ 10) + randY / 10 * h / 40;
            
            if (cocos2d::RandomHelper::random_int(1, 20) == 1 && flagCandy == false) {
                createCandy(w, h, xVang, yVang);
                flagCandy = true;
            } else {
                createGold(w, h, xVang, yVang);
                
            }
        }
    }
    
    
}
void Play4::createGroupStar(float w, float h, float xStarO, float yStarO) {
    createStar(w, h, xStarO, yStarO, true);
    createStar(w, h, xStarO + w / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, yStarO + w / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, false);
    createStar(w, h, xStarO - w  / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, yStarO + w / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, false);
    //createStar(w, h, xStarO + w / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, yStarO - w / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, false);
    //createStar(w, h, xStarO - w  / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, yStarO - w / 40 + cocos2d::RandomHelper::random_int(1, 4) * w / 120, false);
}
void Play4::randomQuestionAndAnswer() {

    if (typeOfW4 == 1)
    {
        typeOfW4 = cocos2d::RandomHelper::random_int(2, 5);
    }
    switch (typeOfW4)
    {
        //2 - nhan; 3 - chia; 4 - cong; 5 - tru; 1 - multi
        case 2:
            switch (levelOfW4)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomNhan1();
                    break;
                case 2:
                    randomNhan2();
                    break;
                case 3:
                    randomNhan3();
                    break;
                default:
                    randomNhan1();
                    break;
            }
            break;
        case 3:
            switch (levelOfW4)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomChia1();
                    break;
                case 2:
                    randomChia2();
                    break;
                case 3:
                    randomChia3();
                    break;
                default:
                    randomChia1();
                    break;
            }
            break;
        case 4:
            switch (levelOfW4)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomCong1();
                    break;
                case 2:
                    randomCong2();
                    break;
                case 3:
                    randomCong3();
                    break;
                default:
                    randomCong1();
                    break;
            }
            break;
        case 5:
            switch (levelOfW4)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomTru1();
                    break;
                case 2:
                    randomTru2();
                    break;
                case 3:
                    randomTru3();
                    break;
                default:
                    randomTru1();
                    break;
            }
            break;
        case 6:
           
            //huy33391
            switch (levelOfW4)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomSoSanh1();
                    break;
                case 2:
                    randomSoSanh2();
                    break;
                case 3:
                    randomSoSanh3();
                    break;
                default:
                    randomSoSanh1();
                    break;
            }
            break;
        default:
            randomNhan1();
            break;
    }


}
void Play4::randomSoSanh1(){
    int myMinA = 1;
    int myMaxA = 9;
    
    int myMinB = 1;
    int myMaxB = 9;
    
    int scoreSoSanh = UserDefault::getInstance()->getIntegerForKey("phep-so-sanh", 0);
    log("test score so sanh: %i", scoreSoSanh);
    if (scoreSoSanh < 11) {
        myMaxA = 5;
        
        myMinB = 0;
        myMaxB = 1;
    }
    if (scoreSoSanh > 10 && scoreSoSanh < 21) {
        myMaxA = 9;
        myMinB = 0;
        myMaxB = 3;
    }
    if (scoreSoSanh > 20 && scoreSoSanh < 31) {
        myMinB = 1;
        myMaxB = 4;
    }
    if (scoreSoSanh > 30) {
        myMaxB = 9;
    }
    
    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a + b > 10 || a == prevA2 || a == prevB2 || b == prevA2 || b == prevB2);
    
    string loaiPhepToan = ">"; // < - 0, <  - 1, =  - 2
    
    string loaiPhepTinhSai = "<";
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        loaiPhepTinhSai = "=";
    }
    if (a == b) {
        loaiPhepToan = "=";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "<";
        }
    }
    if (a < b) {
        loaiPhepToan = "<";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "=";
        }
    }
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        correctAnswer2 = 1; //dap an dung
    } else{
        correctAnswer2 = 2; // dap an sai
        loaiPhepToan = loaiPhepTinhSai;
    }

    prevA2 = a;
    prevB2 = b;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i %s %i", a, loaiPhepToan.c_str(), b);

//    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
//    {
//        phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " + ", b, " = ?");
//    }
//    else
//    {
//        phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", b, " + ", a, " = ?");
//    }

    //4 answer
    answer3_2 = 0; // 0 - an dap an, 1 - dap an dung, 2 - dap an sai
    answer4_2 = 0;
    answer1_2 = 1;
    answer2_2 = 2;
    
   
}

void Play4::randomSoSanh2(){
    int myMinA = 3;
    int myMaxA = 9;
    
    int myMinB = 3;
    int myMaxB = 9;

    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a == prevA2 || a == prevB2 || b == prevA2 || b == prevB2);
    
    string loaiPhepToan = ">"; // < - 0, <  - 1, =  - 2
    
    string loaiPhepTinhSai = "<";
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        loaiPhepTinhSai = "=";
    }
    if (a == b) {
        loaiPhepToan = "=";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "<";
        }
    }
    if (a < b) {
        loaiPhepToan = "<";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "=";
        }
    }
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        correctAnswer2 = 1; //dap an dung
    } else{
        correctAnswer2 = 2; // dap an sai
        loaiPhepToan = loaiPhepTinhSai;
    }

    prevA2 = a;
    prevB2 = b;

    //question
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        phepToan2 = cocos2d::__String::createWithFormat("%i %s %s", a, loaiPhepToan.c_str(), generateRandomExpression(b).c_str());
    } else{
        phepToan2 = cocos2d::__String::createWithFormat("%s %s %i", generateRandomExpression(a).c_str(), loaiPhepToan.c_str(), b);
    }
    
    //4 answer
    answer3_2 = 0; // 0 - an dap an, 1 - dap an dung, 2 - dap an sai
    answer4_2 = 0;
    answer1_2 = 1;
    answer2_2 = 2;
}
std::string Play4::generateRandomExpression(int tong) {
    int c = std::rand() % (tong + 1); // c thuộc [0, a]
    int b = tong - c;
    return std::to_string(c) + "+" + std::to_string(b);
}
void Play4::randomSoSanh3(){
    int myMinA = 5;
    int myMaxA = 9;
    
    int myMinB = 3;
    int myMaxB = 9;

    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a == prevA2 || a == prevB2 || b == prevA2 || b == prevB2);
    
    string loaiPhepToan = ">"; // < - 0, <  - 1, =  - 2
    
    string loaiPhepTinhSai = "<";
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        loaiPhepTinhSai = "=";
    }
    if (a == b) {
        loaiPhepToan = "=";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "<";
        }
    }
    if (a < b) {
        loaiPhepToan = "<";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "=";
        }
    }
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        correctAnswer2 = 1; //dap an dung
    } else{
        correctAnswer2 = 2; // dap an sai
        loaiPhepToan = loaiPhepTinhSai;
    }

    prevA2 = a;
    prevB2 = b;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%s %s %s", generateRandomExpression(a).c_str(), loaiPhepToan.c_str(), generateRandomExpression(b).c_str());
    
    //4 answer
    answer3_2 = 0; // 0 - an dap an, 1 - dap an dung, 2 - dap an sai
    answer4_2 = 0;
    answer1_2 = 1;
    answer2_2 = 2;
}
void Play4::randomNhan1() {
    int myMinA = 2;
    int myMaxA = maxDoiSo2;
    
    int myMinB = 2;
    int myMaxB = maxDoiSo2;
    
    
    int scoreNhan = HuyFunctions().tongDiemPhepNhan();
    log("test score nhan: %i", scoreNhan);
    
    if (scoreNhan < 15) {
        myMaxA = 5;
        
        myMinB = 1;
        myMaxB = 1;
    }
    
    if (scoreNhan > 14 && scoreNhan < 31) {
        myMaxA = maxDoiSo2;
        myMinB = 1;
        myMaxB = 2;
    }
    
    if (scoreNhan > 30 && scoreNhan < 41) {
        myMinB = 1;
        myMaxB = 3;
    }
    if (scoreNhan > 40 && scoreNhan < 51) {
        myMinB = 1;
        myMaxB = 5;
    }
    if (scoreNhan > 50) {
        myMinB = 2;
        myMaxB = maxDoiSo2;
    }
    
    int a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
    int b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    
   
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        if (a > 2) {
            a = a - 1;
        }
        if (b > 1) {
            b = b - 1;
        }
    }
    prevA2 = a;
    prevB2 = b;
    correctAnswer2 = a * b;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", a, "x",b, "=");

    //4 answer
    random4AnswerNhan1(a, b);

    //log("random:: a : %i, b : %i, correctAnswer2: %i, phepToan2: %s", a, b, correctAnswer2, phepToan2);
    //log("random:: answer1_2 : %i, answer1_2 : %i, answer3_2: %i, answer4_2: %i", answer1_2, answer2_2, answer3_2, answer4_2);
}
void Play4::randomNhan2() {
    int a = cocos2d::RandomHelper::random_int(5, maxDoiSo2);
    int b = cocos2d::RandomHelper::random_int(4, maxDoiSo2);
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(5, maxDoiSo2);
        b = cocos2d::RandomHelper::random_int(4, maxDoiSo2);
    }
    prevA2 = a;
    prevB2 = b;

    correctAnswer2 = a * b;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", a, "x",b, "=");

    //4 answer
    random4AnswerNhan1(a, b);
}
void Play4::randomNhan3() {
    int a = cocos2d::RandomHelper::random_int(7, 12);
    int b = cocos2d::RandomHelper::random_int(5, 10);
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(7, 12);
        b = cocos2d::RandomHelper::random_int(5, 10);
    }
    prevA2 = a;
    prevB2 = b;

    correctAnswer2 = a * b;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", a, "x",b, "=");

    //4 answer
    random4AnswerNhan1(a, b);
}

void Play4::randomCong1(){
    int myMinA = 1;
    int myMaxA = 9;
    
    int myMinB = 1;
    int myMaxB = 9;
    
    int scoreCong = HuyFunctions().tongDiemPhepCong();
    log("test score cong: %i", scoreCong);
    if (scoreCong < 11) {
        myMaxA = 5;
        
        myMinB = 0;
        myMaxB = 1;
    }
    if (scoreCong > 10 && scoreCong < 21) {
        myMaxA = 9;
        myMinB = 0;
        myMaxB = 3;
    }
    if (scoreCong > 20 && scoreCong < 31) {
        myMinB = 1;
        myMaxB = 4;
    }
    if (scoreCong > 30) {
        myMaxB = 9;
    }
    
    int a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
    int b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    if (a + b > 10){
        do {
            a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
            b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
        }
        while (a + b > 10);
    }
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
//        a = cocos2d::RandomHelper::random_int(myMin, myMax);
//        b = cocos2d::RandomHelper::random_int(myMin, myMin);
        if (a > 1) {
            a = a - 1;
        }
        if (b > 0) {
            b = b - 1;
        }
    }
    prevA2 = a;
    prevB2 = b;
    correctAnswer2 = a + b;

    //question
    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", a, "+", b, "=");
    }
    else
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", b, "+", a, "=");
    }

    //4 answer
    random4AnswerCong1(a, b);

    //log("random:: a : %i, b : %i, correctAnswer2: %i, phepToan2: %s", a, b, correctAnswer2, phepToan2);
    //log("random:: answer1_2 : %i, answer1_2 : %i, answer3_2: %i, answer4_2: %i", answer1_2, answer2_2, answer3_2, answer4_2);
}
void Play4::randomCong2(){
    log("chuan bi load dap an random buoc 1");
    
    int a = cocos2d::RandomHelper::random_int(9, 30);
    int b = cocos2d::RandomHelper::random_int(9, 30);
    
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(9, 30);
        b = cocos2d::RandomHelper::random_int(9, 30);
    }
    prevA2 = a;
    prevB2 = b;
    correctAnswer2 = a + b;

    //question
    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", a, "+", b, "=");
    }
    else
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", b, "+", a, "=");
    }

    log("chuan bi load dap an random +2");
    //4 answer
    random4AnswerCong1(a, b);

    //log("random:: a : %i, b : %i, correctAnswer2: %i, phepToan2: %s", a, b, correctAnswer2, phepToan2);
    //log("random:: answer1_2 : %i, answer1_2 : %i, answer3_2: %i, answer4_2: %i", answer1_2, answer2_2, answer3_2, answer4_2);
}
void Play4::randomCong3(){
    int a = cocos2d::RandomHelper::random_int(9, 49);
    int b = cocos2d::RandomHelper::random_int(9, 49);
    
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(9, 49);
        b = cocos2d::RandomHelper::random_int(9, 49);
    }
    prevA2 = a;
    prevB2 = b;
    correctAnswer2 = a + b;

    //question
    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", a, "+", b, "=");
    }
    else
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", b, "+", a, "=");
    }

    //4 answer
    random4AnswerCong1(a, b);

    //log("random:: a : %i, b : %i, correctAnswer2: %i, phepToan2: %s", a, b, correctAnswer2, phepToan2);
    //log("random:: answer1_2 : %i, answer1_2 : %i, answer3_2: %i, answer4_2: %i", answer1_2, answer2_2, answer3_2, answer4_2);
}
void Play4::randomTru1(){
    int myMinA = 1;
    int myMaxA = 9;
    
    int myMinB = 1;
    int myMaxB = 9;
    
    int scoreTru = HuyFunctions().tongDiemPhepTru();
    log("test score tru: %i", scoreTru);
    if (scoreTru < 15) {
        myMaxA = 5;
        
        myMinB = 0;
        myMaxB = 1;
    }
    
    if (scoreTru > 14 && scoreTru < 31) {
        myMaxA = 9;
        myMinB = 0;
        myMaxB = 3;
    }
    
    if (scoreTru > 30 && scoreTru < 41) {
        myMinB = 1;
        myMaxB = 3;
    }
    if (scoreTru > 40 && scoreTru < 51) {
        myMinB = 1;
        myMaxB = 5;
    }
    if (scoreTru > 50) {
        myMaxB = 9;
    }
    
    int a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
    int b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    if (a + b > 10){
        do {
            a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
            b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
        }
        while (a + b > 10);
    }
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
//        a = cocos2d::RandomHelper::random_int(myMin, myMax);
//        b = cocos2d::RandomHelper::random_int(myMin, myMin);
        if (a > 1) {
            a = a - 1;
        }
        if (b > 0) {
            b = b - 1;
        }
    }
    
    prevA2 = a;
    prevB2 = b;
    int tmpTong = a + b;
    correctAnswer2 = a;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", tmpTong, "-", b, "=");

    //4 answer
    random4AnswerTru1(b, tmpTong);
}
void Play4::randomTru2(){
    int a = cocos2d::RandomHelper::random_int(8, 30);
    int b = cocos2d::RandomHelper::random_int(8, 30);
   
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(8, 30);
        b = cocos2d::RandomHelper::random_int(8, 30);
    }
    prevA2 = a;
    prevB2 = b;
    int tmpTong = a + b;
    correctAnswer2 = a;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", tmpTong, "-", b, "=");

    //4 answer
    random4AnswerTru1(b, tmpTong);
}
void Play4::randomTru3(){
    int a = cocos2d::RandomHelper::random_int(9, 49);
    int b = cocos2d::RandomHelper::random_int(9, 49);
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(9, 49);
        b = cocos2d::RandomHelper::random_int(9, 49);
    }
    prevA2 = a;
    prevB2 = b;
    correctAnswer2 = a + b;

    //question
    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", a, "+", b, "=");
    }
    else
    {
        phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", b, "+", a, "=");
    }

    //4 answer
    random4AnswerCong1(a, b);

    //log("random:: a : %i, b : %i, correctAnswer2: %i, phepToan2: %s", a, b, correctAnswer2, phepToan2);
    //log("random:: answer1_2 : %i, answer1_2 : %i, answer3_2: %i, answer4_2: %i", answer1_2, answer2_2, answer3_2, answer4_2);
}
void Play4::randomChia1(){
    int myMinA = 2;
    int myMaxA = maxDoiSo2;
    
    int myMinB = 2;
    int myMaxB = maxDoiSo2;
    
    int scoreChia = HuyFunctions().tongDiemPhepChia();
    log("test score chia: %i", scoreChia);
    if (scoreChia < 15) {
        myMaxA = 5;
        
        myMinB = 1;
        myMaxB = 1;
    }
    
    if (scoreChia > 14 && scoreChia < 31) {
        myMaxA = maxDoiSo2;
        myMinB = 1;
        myMaxB = 2;
    }
    if (scoreChia > 30 && scoreChia < 41) {
        myMinB = 1;
        myMaxB = 4;
    }
    if (scoreChia > 40 && scoreChia < 51) {
        myMinB = 1;
        myMaxB = 6;
    }
    if (scoreChia > 50) {
        myMinB = 2;
        myMaxB = maxDoiSo2;
    }
    
    int a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
    int b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        if (a > 2) {
            a = a - 1;
        }
        if (b > 1) {
            b = b - 1;
        }
    }
    
    prevA2 = a;
    prevB2 = b;
    int tmpResult = a * b;
    correctAnswer2 = a;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", tmpResult, ":", b, "=");

    //4 answer
    random4AnswerChia1(b , tmpResult);
}
void Play4::randomChia2(){
    int a = cocos2d::RandomHelper::random_int(5, maxDoiSo2);
    int b = cocos2d::RandomHelper::random_int(4, maxDoiSo2);
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(5, maxDoiSo2);
        b = cocos2d::RandomHelper::random_int(4, maxDoiSo2);
    }
    prevA2 = a;
    prevB2 = b;
    int tmpResult = a * b;
    correctAnswer2 = a;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", tmpResult, ":", b, "=");

    //4 answer
    random4AnswerChia1(b , tmpResult);
}
void Play4::randomChia3(){
    int a = cocos2d::RandomHelper::random_int(7, maxDoiSo2);
    int b = cocos2d::RandomHelper::random_int(5, maxDoiSo2);
    if ((a == prevA2 && b == prevB2) or (b == prevA2 && a == prevB2))
    {
        a = cocos2d::RandomHelper::random_int(7, maxDoiSo2);
        b = cocos2d::RandomHelper::random_int(5, maxDoiSo2);
    }
    prevA2 = a;
    prevB2 = b;
    int tmpResult = a * b;
    correctAnswer2 = a;

    //question
    phepToan2 = cocos2d::__String::createWithFormat("%i%s%i%s", tmpResult, ":", b, "=");

    //4 answer
    random4AnswerChia1(b , tmpResult);
}
void Play4::random4AnswerChia1(int a, int b){
    //chua check truong hop co dap an trung nhau

    std::vector<int> arr2;
    for (int i = 2; i <= maxDoiSo2; i++)
    {
        if (i != correctAnswer2)
        {
            arr2.push_back(i);
        }
    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 2);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), correctAnswer2);
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), result1);
            break;

        default:
            break;
    }
}
void Play4::random4AnswerChia2(int a, int b){

}
void Play4::random4AnswerChia3(int a, int b){

}
void Play4::random4AnswerTru1(int a, int b){
    std::vector<int> arr2;
    
    //chac chan rang a > b
    int c = 0;
    if (b > a) {
        c = b;
        b = a;
        a = c;
    }
    
    int start = a - b + 1;
    int finish = a - b + 5;
    log("test tru 1 | %i - %i", a, b);
    if ((a - b) > 1) {
        start = a - b - 1;
        finish = a - b + 3;
        log("test tru 2| %i - %i", a, b);
    }
    
    if ((a - b) > 2) {
        start = a - b - 2;
        finish = a - b + 2;
        
        log("test tru 3 | %i - %i", a, b);
    }
    for (int i = start; i <= finish; i++)
    {
        if (i != correctAnswer2)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 2);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), correctAnswer2);
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), result1);
            break;

        default:
            break;
    }
}
void Play4::random4AnswerTru2(int a, int b){
    std::vector<int> arr2;
    for (int i = a + 2; i <= a + 10; i++)
    {
        if (i != correctAnswer2)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 3:
            answer3_2 = correctAnswer2;
            answer2_2 = result1;
            answer1_2 = result2;
            answer4_2 = result3;
            break;
        case 4:
            answer4_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer1_2 = result3;
            break;
        default:
            break;
    }
}
void Play4::random4AnswerTru3(int a, int b){
    std::vector<int> arr2;
    for (int i = a + 1; i <= a + b + 7; i++)
    {
        if (i != correctAnswer2)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 3:
            answer3_2 = correctAnswer2;
            answer2_2 = result1;
            answer1_2 = result2;
            answer4_2 = result3;
            break;
        case 4:
            answer4_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer1_2 = result3;
            break;
        default:
            break;
    }
}
void Play4::random4AnswerCong1(int a, int b){
    log("test loi: a = %i, b = %i, cau tra loi dung = %i", a, b, correctAnswer2);
    std::vector<int> arr2;
    int start = a + 1;
    if (a + b - 2 >= 0) {
        start = a + b - 2;
    }
    for (int i = start; i <= a + b + 4; i++)
    {
        if (i != correctAnswer2)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 2);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), correctAnswer2);
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), result1);
            break;
        default:
            break;
    }
}
void Play4::random4AnswerCong2(int a, int b){
    //chua check truong hop co dap an trung nhau
    std::vector<int> arr2;
    for (int i = 9; i <= 49; i++)
    {
        if (i != correctAnswer2)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 2);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), correctAnswer2);
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), result1);
            break;
        default:
            break;
    }
}

void Play4::random4AnswerCong3(int a, int b){

}
void Play4::random4AnswerNhan1(int a, int b){
    log("test loi phep nhan: a = %i, b = %i, cau tra loi dung = %i", a, b, correctAnswer2);
    //chua check truong hop co dap an trung nhau
    int result1 = a + b;
    if(a >= b){
        if(a > 2){
            result1 = (a - 1) * b;
        }
    }else{
        if(b > 2){
            result1 = (b - 1) * a;
        }
    }

    if (result1 == correctAnswer2){
        result1 = (a + b) * 2;
    }

    std::vector<int> arr2;
    for (int i = (a * b + 2) ; i <= a * b + 6; i++)
    {
        if (i != correctAnswer2 && i != result1)
        {
            arr2.push_back(i);
        }
    }

    std::random_shuffle(arr2.begin(), arr2.end());
    int result2 = arr2.at(0);

    std::vector<int> arr3;
    for (int i = result2 + 1; i <= result2 + 7; i++)
    {
        if (i != correctAnswer2 && i != result1)
        {
            arr3.push_back(i);
        }

    }
    std::random_shuffle(arr3.begin(), arr3.end());
    int result3 = arr3.at(0);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 2);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), correctAnswer2);
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            phepToan2 = cocos2d::__String::createWithFormat("%s%i", phepToan2->getCString(), result1);
            break;

        default:
            break;
    }
}

void Play4::random4AnswerNhan2(int a, int b){
    //chua check truong hop co dap an trung nhau
    std::vector<int> arr2;
    for (int i = 4; i <= maxDoiSo2; i++)
    {
        if (i != correctAnswer2)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 3:
            answer3_2 = correctAnswer2;
            answer2_2 = result1;
            answer1_2 = result2;
            answer4_2 = result3;
            break;
        case 4:
            answer4_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer1_2 = result3;
            break;
        default:
            break;
    }
}

void Play4::random4AnswerNhan3(int a, int b){
    int tich = b;
    //chua check truong hop co dap an trung nhau
    int result1 = tich - a;
    if (result1 == correctAnswer2){
        result1 = tich - a + 2;
    }

    std::vector<int> arr2;
    for (int i = a + 2; i <= a + 6; i++)
    {
        if (i != correctAnswer2 && i != result1)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result2 = arr2.at(0);

    std::vector<int> arr3;
    for (int i = result2 + 1; i <= result2 + 7; i++)
    {
        if (i != correctAnswer2 && i != result1)
        {
            arr3.push_back(i);
        }

    }
    std::random_shuffle(arr3.begin(), arr3.end());
    int result3 = arr3.at(0);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 2:
            answer2_2 = correctAnswer2;
            answer1_2 = result1;
            answer3_2 = result2;
            answer4_2 = result3;
            break;
        case 3:
            answer3_2 = correctAnswer2;
            answer2_2 = result1;
            answer1_2 = result2;
            answer4_2 = result3;
            break;
        case 4:
            answer4_2 = correctAnswer2;
            answer2_2 = result1;
            answer3_2 = result2;
            answer1_2 = result3;
            break;
        default:
            break;
    }
}
void Play4::createScore(float w, float h){
    score2String2 = cocos2d::__String::createWithFormat("%i", score2);//score2
    lblScore2 = Label::createWithTTF(score2String2->getCString(), "fonts/ComicNeue-Bold.ttf", 0.065 * w);
    if (isIpad)
    {
        lblScore2 = Label::createWithTTF(score2String2->getCString(), "fonts/ComicNeue-Bold.ttf", 0.04 * w);
    }
    lblScore2->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xScore = w - (lblScore2->getContentSize().width / 2 + 14);
    lblScore2->setPosition(Vec2(xScore, h - 6 - (lblScore2->getContentSize().height / 2)));
    // add the label as a child to this layer
    addChild(lblScore2, 11);
    
    //create score2Icon2
    score2Icon2 = ui::Button::create("gold.png"); // tao button
    score2Icon2->setTouchEnabled(false);
    float ratioscore2Icon2 = 10;
    float scaleI = 1;
    if (isIpad)
    {
        ratioscore2Icon2 = 20;
        scaleI = 0.55;
        
    }
    float scalescore2Icon2 = w / ratioscore2Icon2 / score2Icon2->getContentSize().width;
    score2Icon2->setScale(scalescore2Icon2);
    score2Icon2->setAnchorPoint(Vec2({1, 0.5}));
    score2Icon2->setPosition(Vec2(lblScore2->getPositionX() - 3 - lblScore2->getContentSize().width / 2, h - 6 - (lblScore2->getContentSize().height / 2)));
    score2Icon2->setEnabled(true);
    this->addChild(score2Icon2, 11);
    
    //show lblscore2 with animation
    lblScore2->setOpacity(0);

    float valScale = 1.4;
    float time = 0.1;
    lblScore2->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, valScale), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, 1), FadeIn::create(time), nullptr), nullptr));

    score2Icon2->setOpacity(0);
    score2Icon2->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, 1), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, scaleI), FadeIn::create(time), nullptr), nullptr));
}
void Play4::createAnswer(float w, float h){
    buttonAnswer1 = ui::Button::create("button-c.png", "button-c.png"); // tao button
    buttonAnswer1->setPressedActionEnabled(true);
    buttonAnswer1->setZoomScale(0);
    buttonAnswer1->setScale9Enabled(true);
    //buttonAnswer1->setTitleText(HuyFunctions().NumberToString(answer1_2));
    if (answer1_2 == correctAnswer2)
    {
        buttonAnswer1->setTag(1);
    }
    else
    {
        buttonAnswer1->setTag(0);
    }
    //buttonAnswer1->setTitleFontName("fonts/ComicNeue-Bold.ttf");

    //buttonAnswer1->setTitleColor(Color3B().WHITE);
    buttonAnswer1->setTouchEnabled(true);
    float ratioButtonAnswer1 = 4.5;
    if (isIpad)
    {
        ratioButtonAnswer1 = 9;
        
    }
    
    scaleButtonAnswer1 = w / ratioButtonAnswer1 / buttonAnswer1->getContentSize().width;
    buttonAnswer1->setScale(scaleButtonAnswer1);
    
    float yButtonAnswer1 = 50 + buttonAnswer1->getContentSize().height / 2 * scaleButtonAnswer1;
    
    if (h / w <= 1.8)
    {
        yButtonAnswer1 = 20 + buttonAnswer1->getContentSize().height / 2 * scaleButtonAnswer1;
    }
    buttonAnswer1->setPosition(Vec2(w / 4 + w/25, yButtonAnswer1));
    if (isIpad)
    {
        buttonAnswer1->setPosition(Vec2(w / 3 + w / 20, yButtonAnswer1));
    }
    buttonAnswer1->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (answer1_2 != correctAnswer2)
                {
                    buttonAnswer1->loadTextureNormal("box-wrong.png");
                    buttonAnswer1->setTitleColor(Color3B().WHITE);
                }
                viTriCauTraLoi = 1;
                handlerClickAnswer(answer1_2);
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer1, 10);//add button vao scene

    buttonAnswer2 = ui::Button::create("button-w.png", "button-w.png"); // tao button
    buttonAnswer2->setPressedActionEnabled(true);
    buttonAnswer2->setZoomScale(0);
    buttonAnswer2->setScale9Enabled(true);
    //buttonAnswer2->setTitleText(HuyFunctions().NumberToString(answer2_2));
    if (answer2_2 == correctAnswer2)
    {
        buttonAnswer2->setTag(1);
    }
    else
    {
        buttonAnswer2->setTag(0);
    }
    //buttonAnswer2->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    //buttonAnswer2->setTitleFontSize(fontSize / scaleButtonAnswer1);
    //buttonAnswer2->setTitleColor(Color3B().WHITE);
    buttonAnswer2->setTouchEnabled(true);
    float scaleButtonAnswer2 = w / ratioButtonAnswer1 / buttonAnswer2->getContentSize().width;
    buttonAnswer2->setScale(scaleButtonAnswer2);
    //float yButtonAnswer2 = 50 + buttonAnswer2->getContentSize().height / 2 * scaleButtonAnswer2;

    buttonAnswer2->setPosition(Vec2(w * 3 / 4 - w/25, yButtonAnswer1));
    if (isIpad)
    {
        buttonAnswer2->setPosition(Vec2(w * 4 / 6 - w / 20, yButtonAnswer1));
       
    }
    buttonAnswer2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (answer2_2 != correctAnswer2)
                {
                    buttonAnswer2->loadTextureNormal("box-wrong.png");
                    buttonAnswer2->setTitleColor(Color3B().WHITE);
                }
                viTriCauTraLoi = 2;
                handlerClickAnswer(answer2_2);
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                buttonAnswer2->loadTextureNormal("box-wrong.png");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer2, 10);//add button vao scene

}
void Play4::animationShowAnswer(cocos2d::ui::Button* button, float time, float scale){
    
}
void Play4::hideAnswer1(float myDelay, float myTime){
    DelayTime *pauseButtonAnswer = DelayTime::create(myDelay);
    buttonAnswer1->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
   
}
void Play4::hideAnswer2(float myDelay, float myTime){
    DelayTime *pauseButtonAnswer = DelayTime::create(myDelay);
    buttonAnswer2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
   
}
void Play4::handlerClickAnswer(int v){
    this->unscheduleUpdate();
    
    double scalePopup = 1;
    if (isIpad)
    {
        scalePopup = 0.4;
    }
    int myTime = timeMax2 - timeRemaining2;
    int isCorrect = 0;
    if(v == correctAnswer2) {
        isCorrect = 1;
    }
    std::string ph = lblPhepToan2->getString().c_str();
    sound2 = UserDefault::getInstance()->getIntegerForKey("sound", 0);
   
    this->getEventDispatcher()->removeEventListenersForTarget(buttonAnswer1);
    this->getEventDispatcher()->removeEventListenersForTarget(buttonAnswer2);

    //hide pheptoan
    float time = 0.2;
    float valScale = 1.4;
    auto scaleTitle = ScaleTo::create(time, valScale);
    auto opaA = FadeOut::create(time);
    auto sqA = Spawn::create(scaleTitle, opaA, nullptr);
    lblPhepToan2->runAction(sqA);
    
    //hide bg phep toan
    bgPhepToan->runAction(FadeOut::create(time));

    //hide score2
    //lblScore2->runAction(Sequence::create(DelayTime::create(1.9), FadeOut::create(time), NULL));
    //score2Icon2->runAction(Sequence::create(DelayTime::create(2.0), FadeOut::create(time), NULL));

    float time1  =  0.2;
    float time2  =  0.3;
                              
    if (correctAnswer2 == answer1_2) {

        hideAnswer2(time2, time);
        
        
    }else if(correctAnswer2 == answer2_2)
    {
       
        hideAnswer1(time2, time);
        
    }
    
    if (v == correctAnswer2)
    {
        //auto dungLienTiep = HuyFunctions().saveSoPhepTinhDungLienTiep(true);
        auto dungMoiNgay = HuyFunctions().saveSoPhepTinhDungMoiNgay(true);
//        if (dungLienTiep != "") {
//            showMedal(wScenePlay2, hScenePlay2, dungLienTiep);
//        }
        if (dungMoiNgay != "") {
            showMedal(wScenePlay2, hScenePlay2, dungMoiNgay);
        }
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
        //tra loi dung
        soCauHoiDaVuotQua++;
        createVatCan(wScenePlay2, hScenePlay2);
        createSaoChoi(wScenePlay2, hScenePlay2);
        createGroupGold(wScenePlay2, hScenePlay2);
        
        float fixWidthIpad = 0.3;
        if (isIpad)
        {
            fixWidthIpad = 0.2;
        }
        
        float xDichPhiThuyen = wScenePlay2 * fixWidthIpad - phithuyenHienThi->getScale() * phithuyenHienThi->getContentSize().width / 2;
        if(phithuyenHienThi->getTag() == 0) {
            xDichPhiThuyen = wScenePlay2 - wScenePlay2 * fixWidthIpad + phithuyenHienThi->getScale() * phithuyenHienThi->getContentSize().width / 2;
            phithuyenHienThi->setTag(1);
        } else {
            xDichPhiThuyen = wScenePlay2 * fixWidthIpad - phithuyenHienThi->getScale() * phithuyenHienThi->getContentSize().width / 2;
            phithuyenHienThi->setTag(0);
        }
        //DelayTime::create(time1),
        
        int tocdoPhiThuyen = 3;
        if (isIpad)
        {
            tocdoPhiThuyen = 5;
        }
        phithuyenHienThi->runAction(
                Sequence::create(
                    //RotateTo::create(0.03, 20.f),
                    //MoveTo::create(0.1, Vec2( phithuyenHienThi->getPositionX() * 0.8, phithuyenHienThi->getPositionY())),
                    MoveTo::create(tocdoPhiThuyen, Vec2( xDichPhiThuyen, phithuyenHienThi->getPositionY())),
                    NULL
                )
                
        );
        
        //timeRemaining2 = timeRemaining2 + 1;
//        popupthanhCong->runAction(
//          Sequence::create(
//               DelayTime::create(0.65),
//               Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr),
//               ScaleTo::create(0.03, 0.94 * scalePopup),DelayTime::create(0.05),
//               Spawn::create(
//                     MoveTo::create(1.3, Vec2(score2Icon2->getPositionX() + score2Icon2->getScale() * score2Icon2->getContentSize().width, score2Icon2->getPositionY())),
//                     ScaleTo::create(1.3, scalePopup / 2.5),
//                     nullptr),
//               FadeTo::create(0.1, 0), NULL)
//        );
        
        if (v == answer1_2) {
            buttonAnswer1->runAction(Sequence::create(DelayTime::create(time1), ScaleTo::create(0.05, 1.1 * buttonAnswer1->getScale()), FadeTo::create(time1, 0), NULL));
            
            
        }else if(v == answer2_2)
        {
            buttonAnswer2->runAction(Sequence::create(DelayTime::create(time1), ScaleTo::create(0.05, 1.1 * buttonAnswer2->getScale()), FadeTo::create(time1, 0), NULL));
        }
        
    }else{
        //tra loi sai
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/bom-no-cham.mp3");
        }
        phithuyenHienThi->runAction(Sequence::create(DelayTime::create(0.1), FadeTo::create(0.2, 0), NULL));
        
        bomPhiThuyenHienThi->Node::setPosition(Vec2(phithuyenHienThi->getPositionX(), phithuyenHienThi->getPositionY()));
        bomPhiThuyenHienThi->runAction(Sequence::create(DelayTime::create(0.1), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        
        if (correctAnswer2 == answer1_2) {
         buttonAnswer1->runAction(Sequence::create(DelayTime::create(0.1), ScaleBy::create(0.05, 1.2f), DelayTime::create(0.2),ScaleBy::create(0.05, 0.8f), NULL));
            
        }else if(correctAnswer2 == answer2_2)
        {
            buttonAnswer2->runAction(Sequence::create(DelayTime::create(0.1), ScaleBy::create(0.05, 1.2f), DelayTime::create(0.2),ScaleBy::create(0.05, 0.8f), NULL));
            
        }
       
        popupthatBai->runAction(Sequence::create(DelayTime::create(0.7), Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr), ScaleTo::create(0.03, 0.94 * scalePopup),DelayTime::create(1), FadeTo::create(0.1, 0), NULL));

    }

    DelayTime *pause = DelayTime::create(0.3);


    if (v == correctAnswer2)
    {
        
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound2/hit.mp3");
        }

        log("ban da tra loi dung");
        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(Play4::nextPlay, this)), NULL);
        runAction(sqBOver);
    }
    else{
        log("ban da tra loi sai");
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound2/bom-no-cham.mp3");
            
            //runAction(Sequence::create(DelayTime::create(0.3), CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound2/bom-no.mp3"), NULL));
        }

        //isPause2 = false;
        //auto opaB = FadeOut::create(v);
        auto sqBOver = Sequence::create(DelayTime::create(2.3), CCCallFuncN::create(CC_CALLBACK_0(Play4::moveSceneGameOver, this)), NULL);
        runAction(sqBOver);

        //::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score2, typeOfW4, levelOfW4), Color3B().WHITE));
    }
    if(typeOfW4){
    //if (strcmp(loaiPhepTinh->getCString(), "ss") == 0) {
        if (v == correctAnswer2) {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 9999, myTime, levelOfW4, score2, false, true, viTriCauTraLoi);
        } else {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 2222, myTime, levelOfW4, score2, false, true, viTriCauTraLoi);
        }
    }else {
        HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, v, myTime, levelOfW4, score2, false, true, viTriCauTraLoi);
    }
}
void Play4::nextPlay()
{
    if (realType2 == 1)
    {
        typeOfW4 = cocos2d::RandomHelper::random_int(2, 5);
    }
    removeChild(lblPhepToan2);
    removeChild(bgPhepToan);
   
    //removeChild(lblScore2);
    //removeChild(score2Icon2);

    removeChild(buttonAnswer1);
    removeChild(buttonAnswer2);
    removeChild(popupthanhCong);
    removeChild(popupthatBai);

    /*
    //reset pause
    isPause2 = false;
    buttonPause2->loadTextureNormal("pause.png");
    */
    indexThemDiem = HuyFunctions().getRandomForThemDiem(score2);
    
    coundownTimer(wScenePlay2, hScenePlay2);
    //createScore(wScenePlay2, hScenePlay2);
    randomQuestionAndAnswer();
    createMainTemplate(wScenePlay2, hScenePlay2);
    createAnswer(wScenePlay2, hScenePlay2);
    createPopupFinish(wScenePlay2, hScenePlay2);
}
void Play4::createPopupFinish(float w, float h) {
    //int bgIndex = cocos2d::RandomHelper::random_int(1, 4);
    //popupthanhCong = ui::Button::create(StringUtils::format("popup-thanh-cong-%d.png", bgIndex)); // tao button
    auto imgNameThemDiem = Variable().diemNgauNhienImg.at(0);
    popupthanhCong = ui::Button::create(imgNameThemDiem.c_str());
    popupthanhCong->setTouchEnabled(false);
    float ratiopopupthanhCong = 3;
    if (isIpad)
    {
        ratiopopupthanhCong = 7;
    }
    float scalepopupthanhCong = w / ratiopopupthanhCong / popupthanhCong->getContentSize().width;
    

    //log("ti le test: %f", scalepopupthanhCong);
    //log("ti le test theo w: %f", w / ratiopopupthanhCong / popupthanhCong->getContentSize().width);
    popupthanhCong->setScale(scalepopupthanhCong);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }

    Vec2 positionPopupThanhCong = Vec2(w/2, h * 0.89);
    if (isIpad)
    {
        positionPopupThanhCong = Vec2(w * 2.8 / 4, h * 0.9);
    }

    popupthanhCong->setPosition(positionPopupThanhCong);

    popupthanhCong->setEnabled(true);
    this->addChild(popupthanhCong, 12);
    popupthanhCong->setOpacity(0);
    popupthanhCong->setScale(0.6);
    
    popupthatBai = ui::Button::create("popup-that-bai2-1.png"); // tao button
    popupthatBai->setTouchEnabled(false);
   

    
    popupthatBai->setScale(scalepopupthanhCong);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    if (isIpad)
    {
        //ytitle = 1.3 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    //popupthanhCong->setPosition(Vec2(w / 2, ytitle));
    //popupthanhCong->setAnchorPoint(Vec2(0, 0));
    popupthatBai->setPosition(Vec2(w/2, h * 0.65));

    popupthatBai->setEnabled(true);
    this->addChild(popupthatBai, 12);
    popupthatBai->setOpacity(0);
    popupthatBai->setScale(0.8);
}
void Play4::moveSceneGameOver()
{
    //kiem tra xem co show man hinh mua hang khong
    if (Variable().isProVer == false && score2 >= Variable().soDiemShowPro &&  UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) >= Variable().showProSauBaoNhieuLan) {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", 0);
        createBgPro(wScenePlay2, hScenePlay2);
    } else {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) + 1);
        finish();
    }
}
void Play4::createMainTemplate(float w, float h){
    bgPhepToan = ui::Button::create("bg-cau-hoi.png"); // tao button
    bgPhepToan->setTouchEnabled(false);
    float ratiobgPhepToan = 2.2;
    if (isIpad)
    {
        ratiobgPhepToan = 5;
        //fontSize = 0.04 * w;
    }
    float scalebgPhepToan = w / ratiobgPhepToan / bgPhepToan->getContentSize().width;
    bgPhepToan->setScale(scalebgPhepToan);
    //bgPhepToan->setTitleFontSize(fontSize / scalebgPhepToan);
    bgPhepToan->setPosition(Vec2(w / 2, h * 0.88));
    
    addChild(bgPhepToan, 9);//add button vao scene
    
    lblPhepToan2 = Label::createWithTTF(phepToan2->getCString(), "fonts/DeliusSwashCaps.ttf", 0.087 * w);
    if (isIpad)
    {
        lblPhepToan2 = Label::createWithTTF(phepToan2->getCString(), "fonts/DeliusSwashCaps.ttf", 0.042 * w);
        
    }
    lblPhepToan2->setColor(Color3B().WHITE);//Color3B().BLACK
    // position the label on the center of the screen
    lblPhepToan2->setPosition(Vec2(w / 2, h * 0.88));

//    if (h / w > 1.53 && h / w <= 1.8){
//        lblPhepToan2->setPosition(Vec2(w / 2, h * 0.84));
//    }
    // add the label as a child to this layer
    addChild(lblPhepToan2, 10);

    auto opaA = FadeOut::create(0);
    lblPhepToan2->setOpacity(0);
    //int valScale = 4;
    //auto scaleTitle = ScaleTo::create(0, valScale);
    //auto sqA = Spawn::create(scaleTitle, nullptr);
    //lblPhepToan2->runAction(sqA);



    float time = 0.2;
    auto opaB = FadeIn::create(time);
    //auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    //DelayTime *pause2 = DelayTime::create(0.2);

    auto sq = Sequence::create(opaA, opaB, nullptr);
    lblPhepToan2->runAction(sq);

}
void Play4::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (isIpad)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                HuyFunctions().animationClickedButton(button, [](){
                    if (Variable().isProduction == true) {
                        HuyFunctions().showAds();
                    }
                    
                    if (fromChallenge4) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(typeOfW4, levelOfW4), Color3B().WHITE));
                    } else {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(4, backTypePT4), Color3B().WHITE));
                    }
                });

                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 2);//add button vao scene
}
void Play4::createValueKey(float w, float h){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    valueKey3_2 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * w);
    valueKey3_2->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = valueKey3_2->getContentSize().height;
    auto btnWidthKey = valueKey3_2->getContentSize().width;
    yValueKey3_2 = h - (btnHeightKey / 2 + 5);
    xValueKey3_2 = w - (btnWidthKey / 2 + 5);
    valueKey3_2->setPosition(Vec2(xValueKey3_2, yValueKey3_2));
    // add the label as a child to this layer
    addChild(valueKey3_2);
}
void Play4::createButtonKey(float w, float h){
    createValueKey(w, h);
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    auto btnWidth = btn->getContentSize().width;
    float scale = w / ratio / btnWidth;
    float xBtn = xValueKey3_2 - 7 - valueKey3_2->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, yValueKey3_2));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                //restart valueKey Label
                removeChild(valueKey3_2);
                createValueKey(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
void Play4::createBgPro(float wScene, float hScene) {
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    LanguageManager::getInstanceRestart();
    
    auto bgTexture = Director::getInstance()->getTextureCache()->addImage("bg-nen-tet.png");

    // Set texture parameters to repeat
    Texture2D::TexParams texParams = { GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_REPEAT };
    bgTexture->setTexParameters(texParams);

    // Create a sprite with repeated texture
    auto bgNenPro = Sprite::createWithTexture(bgTexture, Rect(0, 0, wScene, hScene));
    bgNenPro->setAnchorPoint(Vec2(0, 0)); // Align to bottom-left
    bgNenPro->setOpacity(245);
    //bgNenPro->setOpacity(0);
    this->addChild(bgNenPro, 100);
    
    //close
    auto btn = ui::Button::create("close-btn.png"); // tao button
    float ratio = 10;
    if (hScene/wScene <= 1.53)
    {
        ratio = 17;
    }
    //CCLOG("Debug: 2");
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                finish();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 101);//add button vao scene
    
    float fontSize = 0.1 * wScene;
    float fontSizePrice = 0.135 * wScene;
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
        fontSize = 0.07 * wScene;
    }
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.05 * wScene;
        fontSizePrice = 0.06 * wScene;
        if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
        {
           
            fontSize = 0.035 * wScene;
        }
    }
    //create title pro version
    std::string titleValue = LanguageManager::getInstance()->getStringForKey("TITLE_PRO").c_str();
    auto titlePro = Label::createWithTTF(titleValue, fontStyle, fontSize);
    titlePro->setColor(Color3B().WHITE);
    // position the label on the center of the
    auto btnHeightKey = titlePro->getContentSize().height;
    double ytitlePro = hScene * 0.9 - (btnHeightKey / 2 + 5);
    double xtitlePro = wScene / 2;// - (btnWidthKey / 2 + 5);
    titlePro->setPosition(Vec2(xtitlePro, ytitlePro));
    // add the label as a child to this layer
    addChild(titlePro, 101);
    
    auto bgVIP = Sprite::create("tv-ads.png");
    float ratiobgVIP = 2.4;

    float fixHeightIpad = 20;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        fixHeightIpad = 5;
    }
    
    if (hScene / wScene <= 1.53)
    {
        ratiobgVIP = 4.4;
    }
    
    float scalebgVIP = wScene / ratiobgVIP / bgVIP->getContentSize().width;
    bgVIP->setScale(scalebgVIP);
    bgVIP->setPosition(Vec2(wScene / 2, titlePro->getPositionY() - titlePro->getContentSize().height - 20 - bgVIP->getContentSize().height * scalebgVIP / 2)); // Đặt vị trí
    this->addChild(bgVIP, 101);
    
    
    //create desc pro version
    std::string descValue = LanguageManager::getInstance()->getStringForKey("REMOVE_ADS").c_str();
    auto descPro = Label::createWithTTF(descValue, fontStyle , fontSize * 0.8);
    descPro->setColor(Color3B().WHITE);
    // position the label on the center of the
    double ydescPro = bgVIP->getPositionY() - descPro->getContentSize().height /2 - 20 - bgVIP->getContentSize().height * scalebgVIP / 2;
    double xdescPro = wScene / 2;// - (btnWidthKey / 2 + 5);
    descPro->setPosition(Vec2(xdescPro, ydescPro));
    // add the label as a child to this layer
    addChild(descPro, 101);
    
    //create PRICE
    std::string priceValue = UserDefault::getInstance()->getStringForKey("gia", "");
    auto price = Label::createWithTTF(priceValue, "fonts/NunitoSans-Bold.ttf", fontSizePrice);
    price->setColor(Color3B(255, 195, 77));
    // position the label on the center of the
    double yprice = descPro->getPositionY() - descPro->getContentSize().height /2 - fixHeightIpad - price->getContentSize().height / 2;
    double xprice = wScene / 2;// - (btnWidthKey / 2 + 5);
    price->setPosition(Vec2(xprice, yprice));
    // add the label as a child to this layer
    addChild(price, 101);
    
    //create Underline
    auto underlineImg = Sprite::create("underline-pro.png");
    float ratiounderlineImg = 2;
    //float fixHeightNotiIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        ratiounderlineImg = 4;
        //fixHeightNotiIpad = 0.5;
    }
    
    float scaleunderlineImg = wScene / ratiounderlineImg / underlineImg->getContentSize().width;
    underlineImg->setScale(scaleunderlineImg);
    underlineImg->setPosition(Vec2(wScene / 2, price->getPositionY() - price->getContentSize().height / 2 - underlineImg->getContentSize().height * scaleunderlineImg * 0.15)); // Đặt vị trí
    this->addChild(underlineImg, 101);
    
    
    
    fontSize = 0.05 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.02 * wScene;
    }
    auto restorePurchaseBtn = ui::Button::create("empty.png");
    restorePurchaseBtn->setPressedActionEnabled(true);
    restorePurchaseBtn->setZoomScale(-0.1f);
    restorePurchaseBtn->setScale9Enabled(true);
    restorePurchaseBtn->setTitleText("Restore Purchase");
    if(appLang == "en" || appLang == "vi"){
        restorePurchaseBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    restorePurchaseBtn->setTitleColor(Color3B().WHITE);
    restorePurchaseBtn->setOpacity(200);
    restorePurchaseBtn->setTouchEnabled(true);
    float ratiotitle = 3;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 6;
        
    }
    auto scalerestoreBtn = wScene / ratiotitle / restorePurchaseBtn->getContentSize().width;
    restorePurchaseBtn->setScale(scalerestoreBtn);
    restorePurchaseBtn->setTitleFontSize(fontSize / scalerestoreBtn);
    if (appLang == "ja")
    {
        restorePurchaseBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        restorePurchaseBtn->setTitleFontSize(0.045 * wScene / scalerestoreBtn);
    }
    float ytitle = 40;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        
        ytitle = 20;
    }
    if (hScene / wScene <= 1.53)
    {
        
        if (appLang == "ja")
        {
            
            restorePurchaseBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
        }
    }
    restorePurchaseBtn->setPosition(Vec2(wScene / 2, ytitle));
    restorePurchaseBtn->setEnabled(true);
    restorePurchaseBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("restore purchasing");
                IAPManager::getInstance()->restorePurchases();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(restorePurchaseBtn, 101);
    
    float fontSize2 = 0.07 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize2 = 0.035 * wScene;
    }
    auto upProBtn = ui::Button::create("button-pro.png");
    upProBtn->setPressedActionEnabled(true);
    upProBtn->setZoomScale(-0.1f);
    upProBtn->setScale9Enabled(true);
    upProBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("PRO_BUY").c_str());
    if(appLang == "en" || appLang == "vi"){
        upProBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    upProBtn->setTitleColor(Color3B().WHITE);
    upProBtn->setTouchEnabled(true);
    ratiotitle = 1.5;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 3.4;
       
    }
    auto scaleUpProBtn = wScene / ratiotitle / upProBtn->getContentSize().width;
    upProBtn->setScale(scaleUpProBtn);
    upProBtn->setTitleFontSize(fontSize2 / scaleUpProBtn);
    if (appLang == "ja")
    {
        upProBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        upProBtn->setTitleFontSize(0.05 * wScene / scaleUpProBtn);
    }
    ytitle = ytitle + restorePurchaseBtn->getContentSize().height * scalerestoreBtn / 2 + upProBtn->getContentSize().height * scaleUpProBtn / 2 + 7;
    if (hScene / wScene <= 1.53)
    {
      
        if (appLang == "ja")
        {
            upProBtn->setTitleFontSize(0.025 * wScene / scaleUpProBtn);
        }
    }
    upProBtn->setPosition(Vec2(wScene / 2, ytitle));
    upProBtn->setEnabled(true);
    upProBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("up to pro");
                IAPManager::getInstance()->purchase(Variable().proProductionID);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(upProBtn, 101);
    
}

void Play4::onEnter() {
    Layer::onEnter();

    // Đăng ký callback khi mua thành công
    IAPManager::getInstance()->setOnPurchaseSuccess([this](std::string productID) {
        log("🎉 Mua thành công - restore thanh cong: %s", productID.c_str());
        UserDefault::getInstance()->setBoolForKey("isProVer", true);
        //Variable().isProVer = true;
        UserDefault::getInstance()->flush();
        this->finish();
    });

    // Đăng ký callback khi mua thất bại
    IAPManager::getInstance()->setOnPurchaseFailed([this](std::string productID, std::string error) {
        log("❌ Mua thất bại: %s | Lỗi: %s", productID.c_str(), error.c_str());
        //this->finish();
        
        
    });
    
    // Đăng ký callback lấy giá
    IAPManager::getInstance()->setOnPriceRetrieved([this](std::string productID, std::string price) {
        log("📦 Giá của %s là: %s", productID.c_str(), price.c_str());
        // Gợi ý: update label nút mua
        //this->price->setString(price.c_str());
        UserDefault::getInstance()->setStringForKey("gia", price.c_str());
    });

    // Yêu cầu lấy giá từ App Store
    IAPManager::getInstance()->requestProductInfo(Variable().proProductionID);
}
void Play4::finish() {
    if (Variable().isProduction == true) {
        HuyFunctions().showAds();
    }
    
    HuyFunctions().saveSoGame("g5");
    if(isMulti4 == true){
        typeOfW4 = 1;
    }
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score2, typeOfW4, levelOfW4, 4, fromChallenge4), Color3B().WHITE));
}
