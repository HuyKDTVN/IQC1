#include "finish.h"
#include "play.h"
#include "play2.h"
#include "play3.h"
#include "play4.hpp"
#include "playGame1.hpp"
#include "buy.hpp"
# include "HelloWorldScene.h"
#include "ParentScreen.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <string>
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "cocos2d.h"
#include "giftDiamond.hpp"
#include "GameCenterBridge.h"
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    #include "AdmobHelper.h"
#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    #include "NDKHelper.h"
#endif

using std::string;

USING_NS_CC;

int currentScore;
int cType;
int cLevel;
int cTypePlayBefore;
float margin;

cocos2d::__String *labelScore;

cocos2d::__String *labelHightScore;
cocos2d::ui::Button* bgScore;
cocos2d::ui::Button* bgBest;
cocos2d::ui::Button* buttonAdd200Gold;
cocos2d::ui::Button* buttonNoThanks;
ui::Button* titleGameOver;
//CCLabelTTF* subTitle;

Label* valueKey4;
float yValueKey4;
float xValueKey4;
float ratioManhinh;
int soundMathfinish;
bool fromChallengeFinish;
Scene* Finish::createScene(int score, int type, int level, int typePlayBefore, bool fromChallenge)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    currentScore = score;
    cType = type;
    cLevel = level;
    cTypePlayBefore = typePlayBefore;
    fromChallengeFinish = fromChallenge;
    // 'layer' is an autorelease object
    auto layer = Finish::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Finish::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    log("phien ban hien tai: %d", Variable().isProVer);
    
    //log("Debug: 0");
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioManhinh = hScene / wScene;
    
    soundMathfinish = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
    HuyFunctions().requestRewardedAd1();
    
    //set bg
    createBg(wScene, hScene);
    if (Variable().hasTet) {
        createBgTet(wScene, hScene);
        randThemVang = cocos2d::RandomHelper::random_int(2, 12);
        createLiXi(wScene, hScene);
    }
    
    if (Variable().hasLePhucSinh) {
        createBgTet(wScene, hScene);
        randThemVang = cocos2d::RandomHelper::random_int(2, 8);
        createTrungLixi(wScene, hScene);
    }
    
    hasHideRetryButton = false;
    //createButtonKey(wScene, hScene);
    
    //log("Debug: 1");

    //back
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (hScene / wScene <= 1.53)
    {
        ratio = 17;
    }
    //log("Debug: 2");
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                HuyFunctions().animationClickedButton(button, [](){
                    switch (cTypePlayBefore) {
                        case 1:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 2:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 3:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 4:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 5:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(cType + 1, cLevel + 1, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        default:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
   
    addChild(btn, 11);//add button vao scene
    //log("Debug: 3");
    if (UserDefault::getInstance()->getIntegerForKey("height-score", 0) < currentScore)
    {
        
        UserDefault::getInstance()->setIntegerForKey("height-score", currentScore);
        UserDefault::getInstance()->flush();
    }
    
    createScore(wScene, hScene);
    //log("Debug: 4");
    
    createButtonNextAndAddKey(wScene, hScene);
    //log("Debug: 5");
    
    
    //log("dien hien tai cua ban la: %i", currentScore);
    //this->setKeypadEnabled(true);
    
    //detect de phat hien quoc gia co tet Nguyen Dan
    //chi tang lixi cho cac quoc gia co tet
    if (Variable().hasTet) {
        if (HuyFunctions().hasTet()) {
            if (soundMathfinish == 0) {
                CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("sound/chucmung.wav");
            }
            DelayTime *pause = DelayTime::create(1);
            auto sqBOver = Sequence::create(
                pause,
                CCCallFunc::create([this]() {
                    this->showGiftTet(wScene, hScene);
                }),
                NULL);
            runAction(sqBOver);
        }
    }
    
    if (Variable().hasLePhucSinh) {
        if (cocos2d::RandomHelper::random_int(0, 1) == 0 && currentScore > 0) {
            if (soundMathfinish == 0) {
                CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("sound/chucmung.wav");
            }
            DelayTime *pause = DelayTime::create(1);
            auto sqBOver = Sequence::create(
                pause,
                CCCallFunc::create([this]() {
                    this->showGiftTet(wScene, hScene);
                }),
                NULL);
            runAction(sqBOver);
        }
        
    }
    return true;
}

void Finish::showGiftTet(float w, float h){
    log("hien bg tet");
    //save to DB
    
    auto tongDiem = HuyFunctions().getSoVang();
    UserDefault::getInstance()->setIntegerForKey("sovang", tongDiem + randThemVang);
    // Gửi điểm số
    
    int soVangDaily = UserDefault::getInstance()->getIntegerForKey("daily-sovang", 0);
    
    if (HuyFunctions().inVietNam() == false) {
        // Gửi điểm số
        GameCenterBridge::submitScore(soVangDaily + randThemVang, "com.huy.mentalmath.dailygold");
        GameCenterBridge::submitScore(tongDiem + randThemVang, "com.huy.mentalmath.Golds");
    }
        bgNenTet->runAction(Sequence::create(DelayTime::create(0.5), FadeTo::create(0.5, 200), nullptr));
        if (Variable().hasTet) {
            bgNamMoi->runAction(
                Sequence::create(
                        DelayTime::create(0.5),
                        FadeIn::create(0.5),
                         CallFunc::create([this, w, h]() {
                             createPhaoHoa(w, h);
                             if (soundMathfinish == 0)
                             {
                                 
                                 CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/chucmung.wav", false);
                             }
                         }),
                        nullptr)
            );
        }
        
    if (Variable().hasTet) {
        lixi->runAction(
                Sequence::create(
                        DelayTime::create(1),
                        FadeIn::create(0.5),
                        DelayTime::create(0.5),
                         CallFunc::create([this]() {
                             lixi->loadTextureNormal("phongbimo.png");
                         }),
                        nullptr)
        );
    }
    
    if (Variable().hasLePhucSinh) {
        lixi->runAction(
                Sequence::create(
                        DelayTime::create(2),
                        FadeIn::create(0.5),
                        nullptr)
        );
        lePhucSinhTho->runAction(
                Sequence::create(
                        DelayTime::create(1.4),
                        FadeIn::create(0.3),
                        nullptr)
        );
    }
    int count = 0;
    done = false;
    Vec2 positionDich = Vec2(bgScore->getPositionX() - bgScore->getContentSize().width * bgScore->getScale() / 2 + 20, bgScore->getPositionY());
    if (h / w <= 1.53)
    {
        positionDich = Vec2(bgScore->getPositionX() - bgScore->getContentSize().width * bgScore->getScale() / 2 + 8, bgScore->getPositionY());
    }
    
    for (auto& btn : listGold) {
        
        btn->runAction(
            Sequence::create(
                DelayTime::create(float(3 + count / 5.0f)),
                FadeIn::create(0.5),
                DelayTime::create(0.1),
                             MoveTo::create(0.9, Vec2(positionDich.x + btn->getContentSize().width * btn->getScale() / 2, positionDich.y)),
                     FadeOut::create(0.1),
                     RemoveSelf::create(),
                        CallFunc::create([this, count, w]() {
                         auto children = bgScore->getChildren();
                         for (auto& child : children) {
                             auto label = dynamic_cast<Label*>(child);
                             if (label && label->getTag() == 10) {
                                 try {
                                     label->setString(std::to_string(std::stoi(label->getString()) + 1));
                                     } catch (const std::exception& e) {
                                        
                                     } catch (...) {
                                         
                                     }
                                 label->setScale(2);
                                 label->setOpacity(0);

                                 float delayAnimationDesc = 0.3;
                                 if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0) {
                                     label->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc), CallFunc::create([&]() {
                                         CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                                     })));
                                 }

                                 float timeAnimation = 0.3;
                                 auto sq3 = Sequence::create(
                                     DelayTime::create(delayAnimationDesc),
                                     Spawn::create(
                                         ScaleTo::create(timeAnimation / 1.2, 0.8),
                                         FadeIn::create(timeAnimation / 1.2), nullptr),
                                     DelayTime::create(0.1),
                                     ScaleTo::create(timeAnimation / 1, 1),
                                     nullptr);
                                 label->runAction(sq3);
                             }
                         }
                         
                         if (count == randThemVang - 1) {
                             done = true;
                             lixi->runAction(
                                     Sequence::create(
                                             MoveTo::create(0.3, Vec2(-100, -100)),
                                             nullptr)
                             );
                             if (Variable().hasLePhucSinh) {
                                 lePhucSinhTho->runAction(
                                         Sequence::create(
                                                 MoveTo::create(0.3, Vec2(w + 100, -100)),
                                                 nullptr)
                                 );
                             }
                             
                             bgNenTet->runAction(Sequence::create(FadeOut::create(0.2), nullptr));
                             bgNamMoi->runAction(Sequence::create(FadeOut::create(0.2), nullptr));
                             for (auto& ph : listPhaoHoa) {
                                 ph->runAction(Sequence::create(ScaleTo::create(0.2, 0), RemoveSelf::create(), nullptr));
                             }
                         }
                         
                     }),
                nullptr)
        );
        
        count++;
    }
    
    if (done) {
        log("done");
        
    }
}
void Finish::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-blurr.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}
void Finish::createBgTet(float wScene, float hScene) {
    auto bgTexture = Director::getInstance()->getTextureCache()->addImage("bg-nen-tet.png");

    // Set texture parameters to repeat
    Texture2D::TexParams texParams = { GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_REPEAT };
    bgTexture->setTexParameters(texParams);

    // Create a sprite with repeated texture
    bgNenTet = Sprite::createWithTexture(bgTexture, Rect(0, 0, wScene, hScene));
    bgNenTet->setAnchorPoint(Vec2(0, 0)); // Align to bottom-left
    bgNenTet->setOpacity(200);
    bgNenTet->setOpacity(0);
    this->addChild(bgNenTet, 10);
   
    bgNamMoi = ui::Button::create("bg-nam-moi.png"); // tao button
    bgNamMoi->setTouchEnabled(false);
    float ratiobgNamMoi = 1;
    float scalebgNamMoi = wScene / ratiobgNamMoi / bgNamMoi->getContentSize().width;
//    if(scalebgNamMoi < wScene / ratiobgNamMoi / bgNamMoi->getContentSize().width) {
//        scalebgNamMoi = wScene / ratiobgNamMoi / bgNamMoi->getContentSize().width;
//    }
    //log("ti le test: %f", scalebgNamMoi);
    //log("ti le test theo w: %f", w / ratiobgNamMoi / bgNamMoi->getContentSize().width);
    bgNamMoi->setScale(scalebgNamMoi);
    bgNamMoi->setAnchorPoint(Vec2(0, 0));
    bgNamMoi->setPosition(Vec2(0, 0));
    bgNamMoi->setEnabled(true);
    bgNamMoi->setOpacity(0);
    this->addChild(bgNamMoi, 11);
    
}

void Finish::createPhaoHoa(float w, float h) {
    int randomX = cocos2d::RandomHelper::random_int((int)w/2, (int)(w - w/8));
    int randomY = cocos2d::RandomHelper::random_int((int)h/6, (int)(h/3));
    int widthPhaoHoa = createPhaoHoaElement(w, h, randomX, randomY);
    
    int wNewPhaoHoa = randomX + widthPhaoHoa;
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        wNewPhaoHoa = randomX - widthPhaoHoa;
    }
    int hNewPhaoHoa = randomY + widthPhaoHoa;
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        hNewPhaoHoa = randomY - widthPhaoHoa;
    }
    createPhaoHoaElement(w, h, wNewPhaoHoa, hNewPhaoHoa);
    
    //tao chum phao hoa thu 2
    randomX = cocos2d::RandomHelper::random_int((int)w/2, (int)(w - w/8));
    randomY = cocos2d::RandomHelper::random_int((int) h/20, (int)(h/6));
    widthPhaoHoa = createPhaoHoaElement(w, h, randomX, randomY);
    
    wNewPhaoHoa = randomX + widthPhaoHoa;
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        wNewPhaoHoa = randomX - widthPhaoHoa;
    }
    hNewPhaoHoa = randomY + widthPhaoHoa;
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        hNewPhaoHoa = randomY - widthPhaoHoa;
    }
    createPhaoHoaElement(w, h, wNewPhaoHoa, hNewPhaoHoa);
    
    //tao chum phao hoa thu 3
    randomX = cocos2d::RandomHelper::random_int((int)w/20, (int)(w/4));
    randomY = cocos2d::RandomHelper::random_int((int) h/5, (int)(h/3.5));
    widthPhaoHoa = createPhaoHoaElement(w, h, randomX, randomY);
    
    wNewPhaoHoa = randomX + widthPhaoHoa;
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        wNewPhaoHoa = randomX - widthPhaoHoa;
    }
    hNewPhaoHoa = randomY + widthPhaoHoa;
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        hNewPhaoHoa = randomY - widthPhaoHoa;
    }
    createPhaoHoaElement(w, h, wNewPhaoHoa, hNewPhaoHoa);
}
int Finish::createPhaoHoaElement(float w, float h, int x, int y) {
    int rand = cocos2d::RandomHelper::random_int(1, 6);
    auto mainActor = ui::Button::create(cocos2d::__String::createWithFormat("phaohoa%i.png", rand)->getCString()); // tao button
    mainActor->setTouchEnabled(false);
    float ratiomainActor = cocos2d::RandomHelper::random_int(7, 15);
    if (h / w <= 1.53)
    {
        ratiomainActor = ratiomainActor * 2;
    }
    float scalemainActor = w / ratiomainActor / mainActor->getContentSize().width;
    mainActor->setScale(0);
    
    mainActor->setPosition(Vec2(x, y));
    listPhaoHoa.pushBack(mainActor);
    this->addChild(mainActor, 12);
    
    float timeAnimation = 0.4;
    mainActor->runAction(
             RepeatForever::create(
                    Sequence::create(
                        DelayTime::create(CCRANDOM_0_1() / 4),
                         ScaleTo::create(timeAnimation * 0.5,  scalemainActor),
                         DelayTime::create(0.2),
                         ScaleTo::create(timeAnimation,  0),
                         CallFunc::create([this, mainActor]() {
                             int random = cocos2d::RandomHelper::random_int(1, 6);
                             mainActor->loadTextureNormal(cocos2d::__String::createWithFormat("phaohoa%i.png", random)->getCString());
                         }),
                         nullptr)
    ));
    
    return (int)mainActor->getContentSize().width * scalemainActor;
}
void Finish::createLiXi(float w, float h) {
    lixi = ui::Button::create("phongbi.png"); // tao button
    lixi->setTouchEnabled(false);
    float ratiolixi = 3;
    if (h / w <= 1.53)
    {
        ratiolixi = 6;
    }
    float scalelixi = w / ratiolixi / lixi->getContentSize().width;
    lixi->setScale(scalelixi);

    float ylixi = 0.7 * h - (lixi->getContentSize().height / 2 * scalelixi);
    log("ti le man hinh: %f", h / w);
    
    if (h / w <= 1.8)
    {
        ylixi = 0.73 * h - (lixi->getContentSize().height / 2 * scalelixi);
    }
    //lixi->setAnchorPoint(Vec2(0, 0));
    lixi->setPosition(Vec2(lixi->getContentSize().width * scalelixi / 2 , lixi->getContentSize().height * scalelixi / 2));
    lixi->setOpacity(0);
    this->addChild(lixi, 14);
    
//    float timeAnimation = 0.4;
//    auto sq3 = Sequence::create(
//                                ScaleTo::create(timeAnimation,  scalemainActor),
//                                ScaleTo::create(timeAnimation,  0),
//                                nullptr);
//    mainActor->runAction((RepeatForever::create(sq3)));
    
    for (int i = 1; i <= randThemVang; ++i) {
        log("vang thu: %i", i);
        auto imageName = "gold.png";
        auto gold = ui::Button::create(imageName, imageName); // tao button
        float ratiomyImg = 22;
        if (h / w <= 1.53)
        {
            ratiomyImg = 44;
        }
        float scalegold = w / ratiomyImg / gold->getContentSize().width;
        gold->setPressedActionEnabled(false);
        gold->setScale(scalegold);
        gold->setPosition(Vec2(lixi->getPositionX() + w/20, lixi->getPositionY() + h / 13));
        gold->setEnabled(true);
        gold->setTag(i);
        listGold.pushBack(gold);
        gold->setOpacity(0);
        this->addChild(gold, 15);
    }
    
}
void Finish::createTrungLixi(float w, float h) {
    int lixiIndex = cocos2d::RandomHelper::random_int(1, 6);
    lixi = ui::Button::create(StringUtils::format("trung%d.png", lixiIndex));
    lixi->setTouchEnabled(false);
    float ratiolixi = 3;
    if (h / w <= 1.53)
    {
        ratiolixi = 6;
    }
    float scalelixi = w / ratiolixi / lixi->getContentSize().width;
    lixi->setScale(scalelixi);
    lixi->setPosition(Vec2(lixi->getContentSize().width * scalelixi * 0.45 , lixi->getContentSize().height * scalelixi * 0.35));
    lixi->setOpacity(0);
    this->addChild(lixi, 14);
    
    lePhucSinhTho = ui::Button::create("tho.png"); // tao button
    lePhucSinhTho->setTouchEnabled(false);
    float ratiolePhucSinhTho = 3;
    if (h / w <= 1.53)
    {
        ratiolePhucSinhTho = 6;
    }
    float scalelePhucSinhTho = w / ratiolePhucSinhTho / lePhucSinhTho->getContentSize().width;
    lePhucSinhTho->setScale(scalelePhucSinhTho);

    lePhucSinhTho->setPosition(Vec2(w - lePhucSinhTho->getContentSize().width * scalelePhucSinhTho / 2, lePhucSinhTho->getContentSize().height * scalelePhucSinhTho / 2));
    lePhucSinhTho->setOpacity(0);
    this->addChild(lePhucSinhTho, 14);
    
//    float timeAnimation = 0.4;
//    auto sq3 = Sequence::create(
//                                ScaleTo::create(timeAnimation,  scalemainActor),
//                                ScaleTo::create(timeAnimation,  0),
//                                nullptr);
//    mainActor->runAction((RepeatForever::create(sq3)));
    
    for (int i = 1; i <= randThemVang; ++i) {
        log("vang thu: %i", i);
        auto imageName = "gold.png";
        auto gold = ui::Button::create(imageName, imageName); // tao button
        float ratiomyImg = 22;
        if (h / w <= 1.53)
        {
            ratiomyImg = 44;
        }
        float scalegold = w / ratiomyImg / gold->getContentSize().width;
        gold->setPressedActionEnabled(false);
        gold->setScale(scalegold);
        gold->setPosition(Vec2(lixi->getPositionX() + w/20, lixi->getPositionY() + h / 13));
        gold->setEnabled(true);
        gold->setTag(i);
        listGold.pushBack(gold);
        gold->setOpacity(0);
        this->addChild(gold, 13);
    }
    
}
void Finish::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel), Color3B().WHITE));
}

void Finish::createScore(float w, float h){
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");


    int iHighScore = UserDefault::getInstance()->getIntegerForKey("diamond", 0);

    if (currentScore > iHighScore)
    {
        HuyFunctions().saveDiamondToDBAndGameCenterAchievement(1);
        iHighScore++;
    }
    float fontSize = 0.12 * w;
    auto bgName = "bg-title.png";
    
    if (h / w <= 1.8)
    {
        
        //bgName = "bg-finish-iphone6.png";
    }
    if (h / w <= 1.53)
    {
        
        //bgName = "finish-ipad.png";
    }
    
    titleGameOver = ui::Button::create(bgName); // tao button
    auto fontName = "fonts/NunitoSans-Bold.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontName = "fonts/KosugiMaru.ttf";
    }
    //log("Debug: 3-0");
    //subTitle = CCLabelTTF::create(LanguageManager::getInstance()->getStringForKey("SUBTITLEWIN"), fontName, 0.07 * w);
    if (currentScore > iHighScore)
    {

        titleGameOver->setTitleText(LanguageManager::getInstance()->getStringForKey("SUBTITLEWIN").c_str());
        //log("Debug: 3-1x");

    }
    else
    {
        //subTitle = CCLabelTTF::create(LanguageManager::getInstance()->getStringForKey("SUBTITLEWRONG"), fontName, 0.07 * w);
        titleGameOver->setTitleText(LanguageManager::getInstance()->getStringForKey("SUBTITLEWRONG").c_str());
        if (h / w <= 1.8)
        {
            titleGameOver->setTitleText(LanguageManager::getInstance()->getStringForKey("SUBTITLEWRONGIPHONE6").c_str());
        }
        //log("Debug: 3-1");

    }
    if(appLang == "en" || appLang == "vi"){
        titleGameOver->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    

    titleGameOver->setTitleColor(Color3B().WHITE);
    titleGameOver->setTouchEnabled(false);
    float ratiotitleGameOver = 1;
    
    float scaletitleGameOver = w / ratiotitleGameOver / titleGameOver->getContentSize().width;
    titleGameOver->setScale(scaletitleGameOver);
    titleGameOver->setTitleFontSize(fontSize / scaletitleGameOver);
    //log("Debug: 3-1-1");
    if (appLang == "ja")
    {
        titleGameOver->setTitleFontName("fonts/KosugiMaru.ttf");
        titleGameOver->setTitleFontSize(0.09 * w / scaletitleGameOver);
    }
    float ytitleGameOver = h - titleGameOver->getContentSize().height * 0.45 * scaletitleGameOver;
    //log("Debug: 3-1-2");
    if (h / w <= 1.8)
    {
        ytitleGameOver = h * 1.08 - (titleGameOver->getContentSize().height * 0.45 * scaletitleGameOver);
        titleGameOver->setTitleFontSize(0.1 * w / scaletitleGameOver);
    }
    //log("Debug: 3-1-3");
    if (h / w <= 1.53)
    {
        titleGameOver->setTitleFontSize(0.06 * w / scaletitleGameOver);
        ytitleGameOver = h * 1.13 - (titleGameOver->getContentSize().height / 2 * scaletitleGameOver);
    }
    titleGameOver->setPosition(Vec2(w / 2, ytitleGameOver));
    titleGameOver->setEnabled(true);
    float fixPositionYScore = 0;
    if (fromChallengeFinish) {
        
        fixPositionYScore = - h / 9;
    } else {
        addChild(titleGameOver);
    }
    //log("Debug: 3-2");
    
    labelScore = cocos2d::__String::createWithFormat("%i", currentScore);
    labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (currentScore + 200 ));
    labelHightScore = cocos2d::__String::createWithFormat("%i", iHighScore);
    
    int soNgayChoiInt = UserDefault::getInstance()->getIntegerForKey("songay", 0);
    
    auto soNgayChoi = cocos2d::__String::createWithFormat("%i", soNgayChoiInt);
    
    
//    int percent = ceil(((iHighScore / double(Variable().diemVang) ) * 100));
//    
//    log("percent: %i, %i", percent, Variable().diemVang);
//    auto percentString = cocos2d::__String::createWithFormat("%i%%", percent);
//    auto bgTienDo = HuyFunctions().creategGroupInfor(w, h, ytitleGameOver - titleGameOver->getContentSize().height / 2 - 10, "cong-finish2.png", "", "", percentString->getCString());
//    addChild(bgTienDo);
    
    float yBest = ytitleGameOver - titleGameOver->getContentSize().height * scaletitleGameOver / 2 - h/15 + fixPositionYScore;
    float fixHeightIphone = 1;
    if (h / w <= 1.8)
    {
        yBest = ytitleGameOver - titleGameOver->getContentSize().height * scaletitleGameOver / 2 - h/20 + fixPositionYScore;
        fixHeightIphone = 0.9;
    }
//    if (h / w <= 1.53)
//    {
//        yBest = ytitleGameOver - titleGameOver->getContentSize().height * scaletitleGameOver / 2 - h/20;
//        
//    }
//    
    bgScore = HuyFunctions().creategGroupInfor(w, h, yBest, "gold.png", "", "Score", labelScore->getCString(), "", 0.3);
    
    //if (currentScore < iHighScore) {
        soLanChayHam = 0;
        soLanChayHamAddGold = 0;
        this->schedule(CC_SCHEDULE_SELECTOR(Finish::updateEverySecondToLoadAds), 1.0f);
        
        addChild(bgScore, 11);
        if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0)
        {
            this->runAction(Sequence::createWithTwoActions(DelayTime::create(0.3), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3"); })));
        }
        
        yBest = bgScore->getPositionY() - bgScore->getContentSize().height * bgScore->getScale() * 1.2 * fixHeightIphone;
//    }else {
//        labelHightScore = labelScore;
//    }
    bgBest = HuyFunctions().creategGroupInfor(w, h, yBest, "diamond.png", "", LanguageManager::getInstance()->getStringForKey("DIAMOND").c_str(), labelHightScore->getCString(), "xanh", 0.9);
    addChild(bgBest, 11);
    if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0)
    {
        this->runAction(Sequence::createWithTwoActions(DelayTime::create(0.9), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");; })));
    }
    auto bgSoNgay = HuyFunctions().creategGroupInfor(w, h, bgBest->getPositionY() - bgBest->getContentSize().height * bgBest->getScale() * 1.2 * fixHeightIphone, "heart 3.png", "", LanguageManager::getInstance()->getStringForKey("HEART").c_str(), soNgayChoi->getCString(), "", 1.5);
    if (fromChallengeFinish == false) {
        
        addChild(bgSoNgay, 11);
    }
    if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0)
    {
        this->runAction(Sequence::createWithTwoActions(DelayTime::create(1.5), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");; })));
    }
    margin = bgBest->getPositionX() - bgBest->getContentSize().width / 2 * bgBest->getScale();
    auto rateTime = UserDefault::getInstance()->getIntegerForKey("ratetime", 0);
    log("rateTime: %i", rateTime);
    log("iHighScore: %i", iHighScore);
    log("random: %i", cocos2d::RandomHelper::random_int(1, 1 + (rateTime * 6)));
    if(iHighScore > 2 && cocos2d::RandomHelper::random_int(1, 1 + (rateTime * 6)) == 1){
        //show popup rate app
        #if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
            sendMessageWithParams("showPopUpReview", cocos2d::Value());
        #endif

        #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                AdmobHelper::showRating();
        #endif
        
        if(rateTime < 5) {
            UserDefault::getInstance()->setIntegerForKey("ratetime", rateTime + 1);
        }
    }
    
    if (fromChallengeFinish) {
        createTemplateChallenge();
    }
    
    buttonAdd200Gold = ui::Button::create("gif.png"); // tao button
    //if (currentScore < iHighScore ) { //and Variable().isProduction == true
        //show button Ads
        hasHideRetryButton = true;
        soLanChayHam = 0;
        soLanChayHamAddGold = 0;
        this->schedule(CC_SCHEDULE_SELECTOR(Finish::updateEverySecondToLoadAds), 1.0f);
        
        buttonAdd200Gold->setTouchEnabled(true);
        buttonAdd200Gold->setName(labelScoreAdd200->getCString());
        float ratiobuttonAdd200Gold = 1.8;
        fixHeightIphone = h / 23;
        if (h / w <= 1.8)
        {
            ratiobuttonAdd200Gold = 2;
            fixHeightIphone = h / 40;
        }
        if (h / w <= 1.53)
        {
            ratiobuttonAdd200Gold = 3.6;
            fixHeightIphone = h / 23;
        }
        float scalebuttonAdd200Gold = w / ratiobuttonAdd200Gold / buttonAdd200Gold->getContentSize().width;
        buttonAdd200Gold->setScale(scalebuttonAdd200Gold);
        buttonAdd200Gold->setPosition(Vec2(w / 2,  bgSoNgay->getPositionY() - bgSoNgay->getContentSize().height * bgSoNgay->getScale() - fixHeightIphone));
        if (Variable().isProduction) {
            buttonAdd200Gold->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        HuyFunctions().showRewardedAd1();
                        buttonAdd200Gold->setOpacity(0);
                        buttonAdd200Gold->setTouchEnabled(false);
                        
                        //addGold();
                        
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        
                        break;
                    default:
                        break;
                }
            });
        }
        addChild(buttonAdd200Gold);//add button vao scene

        buttonAdd200Gold->runAction(Spawn::create(FadeOut::create(0), nullptr));
        buttonAdd200Gold->setTouchEnabled(false);
        
        //buttonAdd200Gold->runAction(Sequence::create(DelayTime::create(3), FadeIn::create(0.2), nullptr));
        
        //buttonAdd200Gold->runAction((RepeatForever::create(Sequence::create(ScaleTo::create(0.4, 1.05 * scalebuttonAdd200Gold), ScaleTo::create(0.3, scalebuttonAdd200Gold * 0.95), nullptr))));
        
        buttonNoThanks = ui::Button::create(); // tao button
        buttonNoThanks->setTouchEnabled(true);
        //float ratiobuttonAdd200Gold = 1.8;
        fixHeightIphone = h / 23;
        if (h / w <= 1.8)
        {
            ratiobuttonAdd200Gold = 2;
            fixHeightIphone = h / 40;
        }
        if (h / w <= 1.53)
        {
            ratiobuttonAdd200Gold = 3.6;
            fixHeightIphone = h / 23;
        }
        //float scalebuttonAdd200Gold = w / ratiobuttonAdd200Gold / buttonAdd200Gold->getContentSize().width;
        buttonNoThanks->setScale(scalebuttonAdd200Gold);
        buttonNoThanks->setPosition(Vec2(w / 2,  buttonAdd200Gold->getPositionY() - buttonAdd200Gold->getContentSize().height * scalebuttonAdd200Gold / 2 - fixHeightIphone));
        buttonNoThanks->setTitleText("No, Thanks!");
            // Set the title font name
        buttonNoThanks->setTitleFontName("fonts/NunitoSans-Bold.ttf");
            // Set the title font size
        buttonNoThanks->setTitleFontSize(w * 0.06);
            // Set the title color
        buttonNoThanks->setTitleColor(Color3B::WHITE);
        
        buttonNoThanks->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    buttonNoThanksClick(button);
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
            }
        });
        addChild(buttonNoThanks);//add button vao scene
        buttonNoThanks->setOpacity(0);
    //}
}
void Finish::createTemplateChallenge() {
    int challengeIndex = UserDefault::getInstance()->getIntegerForKey("challenge-index", 0);
    //challengeIndex = 2;
    
    int perCent = HuyFunctions().perCentChallenge(challengeIndex);
    
    //create bg
    auto bgChallenge = ui::Button::create("bg-challege.png"); // tao button
    bgChallenge->setTouchEnabled(false);
    float ratiobgChallenge = 1.05;
    float fixWidth = wScene / 20;
    float fixHeight = hScene * 0.53;
    float heightChallengeBg = hScene * 0.82;
    if (ratioManhinh <= 1.8)
    {
        heightChallengeBg = hScene * 0.87;
    }
    if (ratioManhinh <= 1.53)
    {
        ratiobgChallenge = 2.1;
        heightChallengeBg = hScene * 0.82;
    }
    float scalebgChallenge = wScene / ratiobgChallenge / bgChallenge->getContentSize().width;
    bgChallenge->setScale(scalebgChallenge);
    bgChallenge->setPosition(Vec2(wScene/2, heightChallengeBg - bgChallenge->getContentSize().height * scalebgChallenge / 2));
    bgChallenge->setEnabled(true);
    this->addChild(bgChallenge);
    
    //them con cho
    auto viTriNhanVat = UserDefault::getInstance()->getIntegerForKey("nhanvatdachon", 0) + 1;
    
    auto imageName = StringUtils::format("home-nv%d.png", viTriNhanVat);
//    if (h / w <= 1.53)
//    {
//        imageName = "bg-home-ipad2.png";
//    }
    auto mainActor = ui::Button::create(imageName); // tao button
    mainActor->setTouchEnabled(false);
    float ratiomainActor = 3.2;
    if (hScene / wScene <= 1.53)
    {
        ratiomainActor = 6.4;
    }
    float scalemainActor = wScene / ratiomainActor / mainActor->getContentSize().width;
    mainActor->setScale(scalemainActor);

    float ymainActor = 0.73 * hScene - (mainActor->getContentSize().height / 2 * scalemainActor);
    log("ti le man hinh: %f", hScene / wScene);
    
    if (hScene / wScene <= 1.8)
    {
        ymainActor = 0.73 * hScene - (mainActor->getContentSize().height / 2 * scalemainActor);
    }
    mainActor->setPosition(Vec2(wScene / 2 + mainActor->getContentSize().width * scalemainActor / 2, bgChallenge->getPositionY() + bgChallenge->getContentSize().height * scalebgChallenge * 0.57));
    mainActor->setEnabled(true);
    mainActor->setRotation(50);
    this->addChild(mainActor);
    
    //them icon cong tru nhan chia
    auto iconPhepTinh = Sprite::create(StringUtils::format("challenge-type%i.png", Variable().arrChallenge.at(0).at(challengeIndex)));
    
    float ratioiconPhepTinh = 9;
    float fontSizeNoti = 0.04 * wScene;
    
    if (ratioManhinh <= 1.53)
    {
        ratioiconPhepTinh = 18;
      
    }
    float scaleiconPhepTinh = wScene / ratioiconPhepTinh / iconPhepTinh->getContentSize().width;
    iconPhepTinh->setScale(scaleiconPhepTinh);
    iconPhepTinh->setPosition(Vec2(bgChallenge->getPositionX() + iconPhepTinh->getContentSize().width * scaleiconPhepTinh / 2 - bgChallenge->getContentSize().width * scalebgChallenge * 0.4, bgChallenge->getPositionY())); // Đặt vị trí
    this->addChild(iconPhepTinh);
    float fixWidthIpad = 1;
    if (ratioManhinh <= 1.53) {
        fixWidthIpad = 0.5;
    }
    //them so phep tinh cua thu thach
    auto soPhepTinhString = StringUtils::format("%i", Variable().arrChallenge.at(1).at(challengeIndex));
    auto soPhepTinh = Label::createWithTTF(soPhepTinhString, "fonts/NunitoSans-Bold.ttf", 0.045 * wScene * fixWidthIpad);
    soPhepTinh->setColor(Color3B().WHITE);
    auto ysoPhepTinh = iconPhepTinh->getPositionY();
    auto xsoPhepTinh = iconPhepTinh->getPositionX() + iconPhepTinh->getContentSize().width * scaleiconPhepTinh * 0.65 + soPhepTinh->getContentSize().width / 2;
    soPhepTinh->setPosition(Vec2(xsoPhepTinh, ysoPhepTinh));
    addChild(soPhepTinh);
    
    
    // Thêm slider
    auto loadingBar = ui::LoadingBar::create(StringUtils::format("challenge-loading%i.png", Variable().arrChallenge.at(0).at(challengeIndex)));
    float heightLoadingBar = 0.92 * hScene;
    float scaleLoading = wScene / 2.5  / loadingBar->getContentSize().width;
    if (ratioManhinh <= 1.53) {
        scaleLoading = wScene / 5  / loadingBar->getContentSize().width;
    }
    loadingBar->setPosition(Vec2(iconPhepTinh->getPositionX() + loadingBar->getContentSize().width * scaleLoading / 2 - iconPhepTinh->getContentSize().width * scaleiconPhepTinh / 2, bgChallenge->getPositionY() + bgChallenge->getContentSize().height * scalebgChallenge * 0.25));
    loadingBar->setScale(scaleLoading);
    loadingBar->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBar->setPercent(0); // Bắt đầu từ 0%
    this->addChild(loadingBar, 2);

    // Thêm hiệu ứng di chuyển từ 0 đến 50% trong 2 giây (có thể thay đổi thời gian)
    auto progressTo = ProgressTo::create(1.0f, perCent); // Thời gian 2 giây
    loadingBar->runAction(progressTo);

   
    auto hLoadingBar = loadingBar->getContentSize().height * scaleLoading - 5;

    // Tạo một loading bar wrap (bao quanh)
    auto loadingBarWrap = ui::LoadingBar::create("loadingbar-wrap2.png");
    loadingBarWrap->setPosition(loadingBar->getPosition());
    loadingBarWrap->setScale(scaleLoading);
    loadingBarWrap->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBarWrap->setPercent(100);
    this->addChild(loadingBarWrap);

    
    //them icon level
    auto iconLevel = Sprite::create(StringUtils::format("challenge-%i%i.png", Variable().arrChallenge.at(0).at(challengeIndex), Variable().arrChallenge.at(2).at(challengeIndex)));
    float ratioiconLevel = 11;
    if (ratioManhinh <= 1.53)
    {
        ratioiconLevel = 22;
    }
    float scaleiconLevel = wScene / ratioiconLevel / iconLevel->getContentSize().width;
    iconLevel->setScale(scaleiconLevel);
    iconLevel->setPosition(Vec2(loadingBar->getPositionX() + loadingBar->getContentSize().width * scaleLoading / 2  - iconLevel->getContentSize().width * scaleiconLevel / 2, iconPhepTinh->getPositionY()));
    this->addChild(iconLevel);
    
    //them bg cho gift thu thach
    auto bgGiftChallenge = Sprite::create(StringUtils::format("bg-gift%i-challenge.png", Variable().arrChallenge.at(3).at(challengeIndex)));
    float ratiobgGiftChallenge = 3.2;
    if (ratioManhinh <= 1.53)
    {
        ratiobgGiftChallenge = 6.4;
      
    }
    float scalebgGiftChallenge = wScene / ratiobgGiftChallenge / bgGiftChallenge->getContentSize().width;
    bgGiftChallenge->setScale(scalebgGiftChallenge);
    bgGiftChallenge->setPosition(Vec2(bgChallenge->getPositionX() + bgChallenge->getContentSize().width * scalebgChallenge / 2 - bgGiftChallenge->getContentSize().width * scalebgGiftChallenge * 0.75, iconPhepTinh->getPositionY()));
    this->addChild(bgGiftChallenge);
    //them icon gift
    auto imgGiftName = "gold-daily-reward.png";
    int loaiPhanThuong = Variable().arrChallenge.at(3).at(challengeIndex);
    if (loaiPhanThuong == 2) {
        imgGiftName = "diamod-daily-reward.png";
    }
    auto iconGift0 = Sprite::create(imgGiftName);
    float ratioiconGift = 7;
    if (ratioManhinh <= 1.53)
    {
        ratioiconGift = 14;
    }
    float scaleiconGift = wScene / ratioiconGift / iconGift0->getContentSize().width;
    
    iconGift0->setScale(scaleiconGift);
    iconGift0->setPosition(Vec2(bgGiftChallenge->getPositionX() - iconGift0->getContentSize().width * scaleiconGift * 0.4 , bgGiftChallenge->getPositionY() - bgGiftChallenge->getContentSize().height * scalebgChallenge * 0.15));
    this->addChild(iconGift0);
    auto iconGift = Sprite::create(imgGiftName);
    iconGift->setScale(scaleiconGift);
    iconGift->setPosition(iconGift0->getPosition());
    this->addChild(iconGift);
    
    //them text cho Gift
    int giftNumber = Variable().arrChallenge.at(4).at(challengeIndex);
    auto labelGiftValueColor = Color4B(13, 113, 154, 255);
    auto giftValueString = cocos2d::__String::createWithFormat("+%i", giftNumber);
    auto giftValue = Label::createWithTTF(giftValueString->getCString(), "fonts/NunitoSans-Bold.ttf", 0.045 * wScene * fixWidthIpad);
    giftValue->setTextColor(labelGiftValueColor);
    giftValue->enableOutline(cocos2d::Color4B::WHITE, 1);
    auto ygiftValue = iconGift->getPositionY();
    auto xgiftValue = iconGift->getPositionX() + iconGift->getContentSize().width * scaleiconGift * 0.55 + giftValue->getContentSize().width / 2;
    giftValue->setPosition(Vec2(xgiftValue, ygiftValue));
    addChild(giftValue);
    
    if (perCent == 100) {
        UserDefault::getInstance()->setIntegerForKey("bat-dau-thu-thach-moi", 0);
        UserDefault::getInstance()->setIntegerForKey("challenge-index", challengeIndex + 1);
        
        //move vang va kim cuong vao score va diem so duoc cong them
        
        if (loaiPhanThuong == 1) {
            auto tongDiem = HuyFunctions().getSoVang();
            UserDefault::getInstance()->setIntegerForKey("sovang", tongDiem + giftNumber);
            // Gửi điểm số
            int soVangDaily = UserDefault::getInstance()->getIntegerForKey("daily-sovang", 0);
            UserDefault::getInstance()->setIntegerForKey("daily-sovang", soVangDaily + giftNumber);
            if (HuyFunctions().inVietNam() == false) {
                // Gửi điểm số
                GameCenterBridge::submitScore(soVangDaily + giftNumber, "com.huy.mentalmath.dailygold");
                GameCenterBridge::submitScore(tongDiem + giftNumber, "com.huy.mentalmath.Golds");
            }
            
            Vec2 positionDich = Vec2(bgScore->getPositionX() - bgScore->getContentSize().width * bgScore->getScale() / 2 + 20, bgScore->getPositionY());
            if (ratioManhinh <= 1.53)
            {
                positionDich = Vec2(bgScore->getPositionX() - bgScore->getContentSize().width * bgScore->getScale() / 2 + 8, bgScore->getPositionY());
            }

            iconGift->runAction(
                    Sequence::create(
                        DelayTime::create(1),
                        EaseExponentialIn::create(MoveTo::create(0.7, Vec2(positionDich.x, positionDich.y))),
                        FadeOut::create(0.2),
                        CallFunc::create([this, giftNumber]() {
                             auto children = bgScore->getChildren();
                             for (auto& child : children) {
                                 auto label = dynamic_cast<Label*>(child);
                                 if (label && label->getTag() == 10) {
                                     try {
                                         label->setString(std::to_string(std::stoi(label->getString()) + giftNumber));
                                     } catch (const std::exception& e) {
                                         
                                     } catch (...) {
                                         
                                     }
                                     label->setScale(2);
                                     label->setOpacity(0);
                                     
                                     float delayAnimationDesc = 0.3;
                                     if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0) {
                                         label->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc), CallFunc::create([&]() {
                                             CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                                         })));
                                     }
                                     
                                     float timeAnimation = 0.3;
                                     auto sq3 = Sequence::create(
                                         DelayTime::create(delayAnimationDesc),
                                         Spawn::create(
                                                       ScaleTo::create(timeAnimation / 1.2, 0.8),
                                                       FadeIn::create(timeAnimation / 1.2), nullptr),
                                         DelayTime::create(0.1),
                                         ScaleTo::create(timeAnimation / 1, 1),
                                         nullptr);
                                     label->runAction(sq3);
                                 }
                             }
                         }),
                         nullptr)          
            );
        } else {
            HuyFunctions().saveDiamondToDBAndGameCenterAchievement(giftNumber);
            
            Vec2 positionDich = Vec2(bgBest->getPositionX() - bgBest->getContentSize().width * bgBest->getScale() / 2 + 20, bgBest->getPositionY());
            if (ratioManhinh <= 1.53)
            {
                positionDich = Vec2(bgBest->getPositionX() - bgBest->getContentSize().width * bgBest->getScale() / 2 + 8, bgBest->getPositionY());
            }

            iconGift->runAction(
                    Sequence::create(
                        DelayTime::create(1),
                        EaseExponentialIn::create(MoveTo::create(0.7, Vec2(positionDich.x, positionDich.y))),
                        FadeOut::create(0.3),
                        CallFunc::create([this, giftNumber]() {
                             auto children = bgBest->getChildren();
                             for (auto& child : children) {
                                 auto label = dynamic_cast<Label*>(child);
                                 if (label && label->getTag() == 10) {
                                     try {
                                         label->setString(std::to_string(std::stoi(label->getString()) + giftNumber));
                                     } catch (const std::exception& e) {
                                         
                                     } catch (...) {
                                         
                                     }
                                     label->setScale(2);
                                     label->setOpacity(0);
                                     
                                     float delayAnimationDesc = 0.3;
                                     if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0) {
                                         label->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc), CallFunc::create([&]() {
                                             CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                                         })));
                                     }
                                     
                                     float timeAnimation = 0.3;
                                     auto sq3 = Sequence::create(
                                         DelayTime::create(delayAnimationDesc),
                                         Spawn::create(
                                                       ScaleTo::create(timeAnimation / 1.2, 0.8),
                                                       FadeIn::create(timeAnimation / 1.2), nullptr),
                                         DelayTime::create(0.1),
                                         ScaleTo::create(timeAnimation / 1, 1),
                                         nullptr);
                                     label->runAction(sq3);
                                 }
                             }
                         }),
                         nullptr)
                                     
                                    
            );
        }
        
        
        
    }
    
}
void Finish::buttonNoThanksClick(cocos2d::ui::Button *me) {
    
    float scaleButtonHome = buttonHome->getScale();
    
   

    buttonNext->runAction(
        Sequence::create(
            Spawn::create(
                FadeIn::create(0.3),
                ScaleTo::create(0.3, 1.1f * scaleButtonHome),
                nullptr
            ),
            ScaleTo::create(0.1f, 1.0f * scaleButtonHome),
            CallFunc::create([&](){ buttonNext->setTouchEnabled(true); }),
            nullptr
        )
    );
    
    buttonHome->runAction(
        Sequence::create(
            DelayTime::create(0.5),
            Spawn::create(
                FadeIn::create(0.3),
                ScaleTo::create(0.3, 1.1f * scaleButtonHome),
                nullptr
            ),
            ScaleTo::create(0.1f, 1.0f * scaleButtonHome),
            CallFunc::create([&](){ buttonHome->setTouchEnabled(true); }),
            nullptr
        )
    );
    
    buttonAddKey->runAction(
        Sequence::create(
            DelayTime::create(1),
            Spawn::create(
                FadeIn::create(0.3),
                ScaleTo::create(0.3, 1.1f * scaleButtonHome),
                nullptr
            ),
            ScaleTo::create(0.1f, 1.0f * scaleButtonHome),
            CallFunc::create([&](){ buttonAddKey->setTouchEnabled(true); }),
            nullptr
        )
    );
    me->runAction(
        Sequence::create(
            FadeOut::create(0.3),
            nullptr
        )
    );
    buttonAdd200Gold->runAction(
        Sequence::create(
            FadeOut::create(0.3),
            nullptr
        )
    );
    
    me->setEnabled(false);
    buttonAdd200Gold->setEnabled(false);
}
void Finish::updateEverySecondToLoadAds(float dt) {
    if (soLanChayHamAddGold == 0) {
        int didLoadAds = UserDefault::getInstance()->getIntegerForKey("loadads", 0);
        if (didLoadAds == 1) {
            showButtonAdd200();
            soLanChayHam = 10;
            soLanChayHamAddGold = 1;
        }
        log("so lan chay ham update lien tuc %d, da load ads chua: %d", soLanChayHam, didLoadAds);
    }
    if (soLanChayHam >= 7) { // Điều kiện dừng, ví dụ a == 10
        if (soLanChayHamAddGold == 0) {
            // Hủy bỏ schedule
            this->unschedule(CC_SCHEDULE_SELECTOR(Finish::updateEverySecondToLoadAds));
            buttonNoThanksClick(buttonNoThanks);
            log("Stopped scheduling because cannot load Ads");
            
        } else {
            
            int didCloseAds = UserDefault::getInstance()->getIntegerForKey("addgoldads", 0);
            if (didCloseAds == 1) {
                addGold();
                
                soLanChayHamAddGold = 1000;
            }
            log("so lan chay ham update lien tuc truoc khi close Ads by User %d, da load ads chua: %d", soLanChayHamAddGold, didCloseAds);
            if (soLanChayHamAddGold == 1000) {
                this->unschedule(CC_SCHEDULE_SELECTOR(Finish::updateEverySecondToLoadAds));
                log("Stopped scheduling because User close Ads Popup (Add gold)");
            }
            
            soLanChayHamAddGold++;
        }
        
    }

    // Tăng giá trị của a hoặc thực hiện công việc khác
    soLanChayHam++;
}
void Finish::showButtonAdd200() {
    if (!buttonAdd200Gold) {
        log("buttonAdd200Gold is null");
        return;
    }
    
    buttonAdd200Gold->setTouchEnabled(true);
    float scale = buttonAdd200Gold->getScale();
    buttonAdd200Gold->runAction(
        Sequence::create(
            Spawn::create(
                FadeIn::create(0.3),
                ScaleTo::create(0.3, 1.1f * scale),
                nullptr
            ),
            ScaleTo::create(0.1f, 1.0f * scale),
            nullptr
        )
    );
    buttonNoThanks->runAction(
        Spawn::create(
            DelayTime::create(1),
            FadeIn::create(0.3),
            nullptr
        )
    );
    
    
}
void Finish::addGold() {
    // Kiểm tra null pointer
    if (!bgScore) {
        log("bgScore is null");
        return;
    }
    if ( !buttonAdd200Gold) {
        log("buttonAdd200Gold is null");
        return;
    }

    log("Starting the add gold effect");

    auto children = bgScore->getChildren();
    for (auto& child : children) {
        auto label = dynamic_cast<Label*>(child);
        if (label && label->getTag() == 10) {
            try {
                    // Giả sử buttonAdd200Gold không phải là nullptr và có phương thức getName()
                    label->setString(buttonAdd200Gold->getName());
                } catch (const std::exception& e) {
                    // Bắt các ngoại lệ chuẩn của C++ và ghi log thông tin lỗi
                    log("Exception occurred: %s", e.what());
                    label->setString("+200");
                } catch (...) {
                    // Bắt tất cả các ngoại lệ khác và ghi log
                    log("Unknown exception occurred.");
                    label->setString("+200");
                }
            label->setScale(2);
            label->setOpacity(0);

            float delayAnimationDesc = 0.3;
            if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0) {
                label->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc), CallFunc::create([&]() {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                })));
            }

            float timeAnimation = 0.3;
            auto sq3 = Sequence::create(
                DelayTime::create(delayAnimationDesc),
                Spawn::create(
                    ScaleTo::create(timeAnimation / 1.2, 0.8),
                    FadeIn::create(timeAnimation / 1.2), nullptr),
                DelayTime::create(0.1),
                ScaleTo::create(timeAnimation / 1, 1),
                nullptr);
            label->runAction(sq3);
        }
    }
    
    buttonNoThanksClick(buttonNoThanks);
}

void Finish::createButtonNextAndAddKey(float w, float h){
    //float fontSize = 0.05 * w;
    
    buttonNext = ui::Button::create("button-retry.png", "button-retry.png"); // tao button
    buttonNext->setTouchEnabled(true);
    float ratiobuttonNext = 4.5;
    float fixMarginIpad = 0;
    int fixHeightiPhone = 30;
    if (h / w <= 1.8)
    {
        fixHeightiPhone = 14;
    }
    if (h / w <= 1.53)
    {
        //fontSize = 0.03 * w;
        ratiobuttonNext = 8;
        fixMarginIpad = w/10;
    }
    float scalebuttonNext = w / ratiobuttonNext / buttonNext->getContentSize().width;
    buttonNext->setScale(scalebuttonNext);
    //buttonNext->setTitleFontSize(fontSize / scalebuttonNext);
    float ybuttonNext = fixHeightiPhone + buttonNext->getContentSize().height / 2 * scalebuttonNext;
    buttonNext->setAnchorPoint(Vec2({0, 0.5}));
    
    buttonNext->setPosition(Vec2(margin - fixMarginIpad, ybuttonNext));
    buttonNext->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (soundMathfinish == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                button->setTouchEnabled(false);
                HuyFunctions().animationClickedButton(button, [](){
                    switch (cTypePlayBefore) {
                        case 1:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 2:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 3:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 4:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        case 5:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(cType + 1, cLevel + 1, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                        default:
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel, 0, fromChallengeFinish), Color3B().WHITE));
                            break;
                    }
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                
                break;
            default:
                break;
        }
    });
    addChild(buttonNext);//add button vao

    buttonHome = ui::Button::create("button-home.png", "button-home.png"); // tao button
    buttonHome->setTouchEnabled(true);
   
    buttonHome->setScale(scalebuttonNext);
    
    buttonHome->setAnchorPoint(Vec2({0, 0.5}));
    buttonHome->setPosition(Vec2(w / 2 - buttonHome->getContentSize().width * scalebuttonNext / 2, ybuttonNext));
    buttonHome->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                button->setTouchEnabled(false);
                if (soundMathfinish == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonHome);//add button vao
    
    buttonAddKey = ui::Button::create("icon-gift.png", "icon-gift.png"); // tao button
    
//  buttonAddKey->setPressedActionEnabled(true);
//  buttonAddKey->setZoomScale(-0.1f);
//  buttonAddKey->setScale9Enabled(true);
    //buttonAddKey->setTitleText(LanguageManager::getInstance()->getStringForKey("ADDKEY").c_str());
    //buttonAddKey->setTitleFontName("fonts/comfortaa.ttf");
    //buttonAddKey->setTitleFontSize(fontSize / scalebuttonNext);
    buttonAddKey->setTitleColor(Color3B().BLACK);
    buttonAddKey->setTouchEnabled(true);
    float ratiobuttonAddKey = 4.5;
    if (h / w <= 1.53)
    {
        ratiobuttonAddKey = 8;
        
        
    }
    float scalebuttonAddKey = w / ratiobuttonAddKey / buttonAddKey->getContentSize().width;
    buttonAddKey->setScale(scalebuttonAddKey);
   
    buttonAddKey->setAnchorPoint(Vec2({1, 0.5}));
    buttonAddKey->setPosition(Vec2(w - margin + fixMarginIpad, ybuttonNext));
    buttonAddKey->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                button->setTouchEnabled(false);
                if (soundMathfinish == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                if (HuyFunctions().inVietNam()) {
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftDiamond::createScene(), Color3B().WHITE));
                    });
                }else {
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Buy::createScene(2), Color3B().WHITE));
                    });
                }
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAddKey);//add button vao scene

    
    
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        buttonNext->setTitleFontName("fonts/KosugiMaru.ttf");
        buttonNext->setTitleFontSize(0.06 * w / scalebuttonAddKey);

        buttonAddKey->setTitleFontName("fonts/KosugiMaru.ttf");
        buttonAddKey->setTitleFontSize(0.06 * w / scalebuttonAddKey);
    }
    if (h / w <= 1.53)
    {
        if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
        {
            buttonNext->setTitleFontSize(0.04 * w / scalebuttonAddKey);
        }
    }
    
    if (hasHideRetryButton == true) {
        buttonHome->setOpacity(0);
        buttonNext->setOpacity(0);
        buttonAddKey->setOpacity(0);
        buttonHome->setTouchEnabled(false);
        buttonNext->setTouchEnabled(false);
        buttonAddKey->setTouchEnabled(false);
    }
}
void Finish::createValueKey(float w, float h){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    valueKey4 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * w);
    valueKey4->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = valueKey4->getContentSize().height;
    auto btnWidthKey = valueKey4->getContentSize().width;
    yValueKey4 = h - (btnHeightKey / 2 + 5);
    xValueKey4 = w - (btnWidthKey / 2 + 5);
    valueKey4->setPosition(Vec2(xValueKey4, yValueKey4));
    // add the label as a child to this layer
    addChild(valueKey4);
}
void Finish::createButtonKey(float w, float h){
    createValueKey(w, h);
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    //auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;
    float scale = w / ratio / btnWidth;
    float xBtn = xValueKey4 - 7 - valueKey4->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, yValueKey4));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                //UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY") + 1);
                //restart valueKey Label
                //removeChild(valueKey4);
                createValueKey(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
