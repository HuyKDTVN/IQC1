#include "mathSelect.h"
#include "SelectGame.hpp"
#include "mathLevel.h" // will delete
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "play.h"
#include "playDual.h"
#include "play2.h"
#include "playGame1.hpp"
#include "play3.h"
#include "play4.hpp"
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "AdmobHelper.h"
#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
#include "NDKHelper.h"
#endif

USING_NS_CC;

float wScene1;
float hScene1;

Label* valueKey1;
float yValueKey1;
float xValueKey1;
float ratioScreen;

int soundMathSelect;
int modelOfWork;
int typePT;

Scene* MathSelect::createScene(int mode, int typePhepTinh = 0)
//typePhepTinh = 0 - hien thi tat ca + - x :
//typePhepTinh = 1 - chi hien thi phep tinh +
//typePhepTinh = 2 - chi hien thi phep tinh -
//typePhepTinh = 3 - chi hien thi phep tinh x
//typePhepTinh = 4 - chi hien thi phep tinh :
//typePhepTinh = 5 - chi hien thi phep tinh >=<

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    modelOfWork = mode;
    typePT = typePhepTinh;
    log("typePhepTinh: %i, modelOfWork: %i", typePT, modelOfWork);
    // 'layer' is an autorelease object
    auto layer = MathSelect::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool MathSelect::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;
    wScene1 = wScene;
    hScene1 = hScene;
    
    soundMathSelect = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    back(wScene, hScene);
    if (typePT == 0) {
        createTite(wScene, hScene);
    }else {
        createTiteEachType(wScene, hScene);
    }
    
    //createButtonKey();
    #if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
        requestAds();
    #endif
    //this->setKeypadEnabled(true);
    return true;
}
void MathSelect::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-blurr.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void MathSelect::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void MathSelect::showAds()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("showIntertistitalAds", cocos2d::Value());
#endif

}
void MathSelect::requestAds()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("requestIntertistialAds", cocos2d::Value());
#endif
}

void MathSelect::createTite(float w, float h){
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    auto fontSize = 0.045 * w;
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
    }
    //auto fontStyle = "fonts/NunitoSans-Bold.ttf";
    if (h / w <= 1.53)
    {
        fontSize = 0.025 * w;
    }
    auto title1 = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LEVEL1").c_str(), fontStyle, fontSize);
    title1->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xTitle1 = w / 6 - title1->getContentSize().width / 2;//  myImg->getContentSize().width * scalemyImg / 2 + 2;
    float yTitle1 = h * 0.92 - title1->getContentSize().height  / 2;// - title1->getContentSize().width;
    
    title1->setPosition(Vec2(xTitle1, yTitle1));
    title1->setAnchorPoint({0, 0.5});
    title1->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(title1, 1);
    
    auto title2 = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LEVEL2").c_str(), fontStyle, fontSize);
    title2->setColor(Color3B().WHITE);
    float xTitle2 = w / 2 - title2->getContentSize().width / 2;
    title2->setPosition(Vec2(xTitle2, yTitle1));
    title2->setAnchorPoint({0, 0.5});
    title2->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(title2, 1);
    
    auto title3 = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LEVEL3").c_str(), fontStyle, fontSize);
    title3->setColor(Color3B().WHITE);
    float xTitle3 = 5 * w / 6 - title3->getContentSize().width / 2;
    title3->setPosition(Vec2(xTitle3, yTitle1));
    title3->setAnchorPoint({0, 0.5});
    title3->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(title3, 1);
    
    //add cac button cot 1
    auto buttonLonHon = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, yTitle1 - 10, 1, 6);
    addChild(buttonLonHon, 1);
    buttonLonHon->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
                HuyFunctions().animationClickedButton(button, [](){
                    
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(6, 1), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(6, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(6, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(6, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(6, 1, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(6, 1, typePT), Color3B().WHITE));
                    }
                });

                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    if (UserDefault::getInstance()->getIntegerForKey("phep-so-sanh", 0) == 0) {
        float timeAnimation = 0.4;
        auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * buttonLonHon->getScale());
        auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.2, buttonLonHon->getScale() * 0.95);
        auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
        buttonLonHon->runAction((RepeatForever::create(sq3)));
    }
    
    if (modelOfWork == 5) {
        buttonLonHon->setPositionY(buttonLonHon->getPositionY() + buttonLonHon->getContentSize().height * buttonLonHon->getScale() * 1.5);
        buttonLonHon->setContentSize(Size(0, 0));
        buttonLonHon->setVisible(false);
    }
    //add cac button cot 1
    auto buttonCong = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonLonHon->getPositionY() - h * 0.042, 1, 1);
    addChild(buttonCong, 1);
    buttonCong->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
                HuyFunctions().animationClickedButton(button, [](){
                    
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(4, 1), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(4, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(4, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(4, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(4, 1, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(4, 1, typePT), Color3B().WHITE));
                    }
                });

                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
//    if (UserDefault::getInstance()->getIntegerForKey("phep-cong", 0) == 0) {
//        float timeAnimation = 0.4;
//        auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * buttonCong->getScale());
//        auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.2, buttonCong->getScale() * 0.95);
//        auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
//        buttonCong->runAction((RepeatForever::create(sq3)));
//    }
    
    //if (typePT == 0 || typePT == 1) {
        auto buttonTru = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonCong->getPositionY() - h * 0.042, 1, 2);
        addChild(buttonTru, 1);
        buttonTru->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    if (soundMathSelect == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    CCLOG("Button 1 touch");
                    //showAds();
                    #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                        //AdmobHelper::showAds();
                        //AdmobHelper::loadAds();
                    #endif
                    //redirect to play
                    HuyFunctions().animationClickedButton(button, [](){
                        if(modelOfWork == 1){
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(5, 1), Color3B().WHITE));
                        }
                        else if(modelOfWork == 2){
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(5, 1, typePT), Color3B().WHITE));
                        }
                        else if(modelOfWork == 3){
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(5, 1, typePT), Color3B().WHITE));
                        }
                        else if(modelOfWork == 4){
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(5, 1, typePT), Color3B().WHITE));
                        }
                        else if(modelOfWork == 5){
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(5, 1, typePT), Color3B().WHITE));
                        }
                        else{
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(5, 1, typePT), Color3B().WHITE));
                        }
                    });

                    
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //CCLOG("Button 1 clicked");
                    break;
                default:
                    break;
            }
        });
    //}
    
    auto buttonNhan = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonTru->getPositionY() - h * 0.042, 1, 3);
    addChild(buttonNhan, 1);
    buttonNhan->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(2, 1), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(2, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(2, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(2, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(2, 1, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(2, 1, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    auto buttonChia = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonNhan->getPositionY() - h * 0.042, 1, 4);
    addChild(buttonChia, 1);
    buttonChia->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                //AdmobHelper::showAds();
                //AdmobHelper::loadAds();
#endif
                //redirect to play
                
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(3, 1), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(3, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(3, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(3, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(3, 1, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(3, 1, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    auto buttonAll = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonChia->getPositionY() - h * 0.042, 1, 5);
    addChild(buttonAll, 1);
    buttonAll->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(1, 1), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(1, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(1, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(1, 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(1, 1, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(1, 1, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    float arrow1X = buttonLonHon->getPositionX() + buttonLonHon->getContentSize().width * buttonLonHon->getScale() / 2 + 5;
    auto arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonLonHon->getPositionY());
    if (modelOfWork != 5) {
        addChild(arrow1, 2);
    }
    
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonCong->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonTru->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonNhan->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonChia->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonAll->getPositionY());
    addChild(arrow1, 2);
    
    //add cac button cot 2
    buttonLonHon = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, yTitle1 - 10, 2, 6);
    this->addChild(buttonLonHon, 1);
    buttonLonHon->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(6, 2), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(6, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(6, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(6, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(6, 2, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(6, 2, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    if (modelOfWork == 5) {
        buttonLonHon->setPositionY(buttonLonHon->getPositionY() + buttonLonHon->getContentSize().height * buttonLonHon->getScale() * 1.5);
        buttonLonHon->setContentSize(Size(0, 0));
        buttonLonHon->setVisible(false);
    }
    buttonCong = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonLonHon->getPositionY() - h * 0.042, 2, 1);
    this->addChild(buttonCong, 1);
    buttonCong->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(4, 2), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(4, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(4, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(4, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(4, 2, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(4, 2, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonTru = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonCong->getPositionY() - h * 0.042, 2, 2);
    addChild(buttonTru, 1);
    buttonTru->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                //AdmobHelper::showAds();
                //AdmobHelper::loadAds();
#endif
                //redirect to play
                
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(5, 2), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(5, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(5, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(5, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(5, 2, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(5, 2, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonNhan = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonTru->getPositionY() - h * 0.042, 2, 3);
    addChild(buttonNhan, 1);
    buttonNhan->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(2, 2), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(2, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(2, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(2, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(2, 2, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(2, 2, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonChia = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonNhan->getPositionY() - h * 0.042, 2, 4);
    addChild(buttonChia, 1);
    buttonChia->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(3, 2), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(3, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(3, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(3, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(3, 2, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(3, 2, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonAll = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonChia->getPositionY() - h * 0.042, 2, 5);
    addChild(buttonAll, 1);
    buttonAll->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(1, 2), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(1, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(1, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(1, 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(1, 2, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(1, 2, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    arrow1X = buttonLonHon->getPositionX() + buttonLonHon->getContentSize().width * buttonLonHon->getScale() / 2 + 5;
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonLonHon->getPositionY());
    if (modelOfWork != 5) {
        addChild(arrow1, 2);
    }
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonCong->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonTru->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonNhan->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonChia->getPositionY());
    addChild(arrow1, 2);
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonAll->getPositionY());
    addChild(arrow1, 2);
    
    
    //add cac button cot 3
    buttonLonHon = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, yTitle1 - 10, 3, 6);
    addChild(buttonLonHon, 1);
    buttonLonHon->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(6, 3), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(6, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(6, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(6, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(6, 3, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(6, 3, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    if (modelOfWork == 5) {
        buttonLonHon->setPositionY(buttonLonHon->getPositionY() + buttonLonHon->getContentSize().height * buttonLonHon->getScale() * 1.5);
        buttonLonHon->setContentSize(Size(0, 0));
        buttonLonHon->setVisible(false);
    }
    
    buttonCong = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonLonHon->getPositionY() - h * 0.042, 3, 1);
    addChild(buttonCong, 1);
    buttonCong->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(4, 3), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(4, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(4, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(4, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(4, 3, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(4, 3, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonTru = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonCong->getPositionY() - h * 0.042, 3, 2);
    addChild(buttonTru, 1);
    buttonTru->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(5, 3), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(5, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(5, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(5, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(5, 3, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(5, 3, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonNhan = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonTru->getPositionY() - h * 0.042, 3, 3);
    addChild(buttonNhan, 1);
    buttonNhan->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(2, 3), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(2, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(2, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(2, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(2, 3, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(2, 3, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonChia = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonNhan->getPositionY() - h * 0.042, 3, 4);
    addChild(buttonChia, 1);
    buttonChia->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(3, 3), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(3, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(3, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(3, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(3, 3, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(3, 3, typePT), Color3B().WHITE));
                    }
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    buttonAll = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, buttonChia->getPositionY() - h * 0.042, 3, 5);
    addChild(buttonAll, 1);
    buttonAll->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(button, [](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(1, 3), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(1, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(1, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(1, 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(1, 3, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(1, 3, typePT), Color3B().WHITE));
                    }
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    
}
void MathSelect::createTiteEachType(float w, float h){
    //add title + or - or x or : neu nguoi dung dieu huong tu + - x : tren home screen
    float fixHeightHasTypePT = 0;
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    
    float fontSize = 0.08 * w;
    
    
    auto titleName = "title+.png";
    int diemSo = HuyFunctions().tongDiemPhepCong();
    switch (typePT) {
        case 1:
            titleName = "title+.png";
            break;
        case 2:
            titleName = "title-.png";
            diemSo = HuyFunctions().tongDiemPhepTru();
            break;
        case 3:
            titleName = "titlex.png";
            diemSo = HuyFunctions().tongDiemPhepNhan();
            break;
        case 4:
            titleName = "title-chia.png";
            diemSo = HuyFunctions().tongDiemPhepChia();
            break;
            
        default:
            titleName = "title+.png";
            break;
    }
    auto titlePhepTinh = ui::Button::create(titleName, titleName); // tao button
    float ratioTitlePT = 2.3;
    if (h / w <= 1.53)
    {
        ratioTitlePT = 4;
        fontSize = 0.04 * w;
        
    }
    float scaleTitlePT = w / ratioTitlePT / titlePhepTinh->getContentSize().width;
    titlePhepTinh->setScale(scaleTitlePT);
    float xTitlePH = w / 2;
    float yTitlePH = h * 0.82;
    if (h / w <= 1.53)
    {
        //xButtonPlay2 = 0.7 * wScene - buttonPlay2->getContentSize().width / 2 * scaleButtonPlay;
        //heightButtonPlay2 = buttonPlay->getPositionY() + buttonPlay2->getContentSize().height *  scaleButtonPlay + 0.04 * wScene;
    }
    titlePhepTinh->setPosition(Vec2(xTitlePH, yTitlePH));
    titlePhepTinh->setTouchEnabled(false);
    this->addChild(titlePhepTinh, 2);//add button vao scene
    fixHeightHasTypePT = w / ratioTitlePT * 1.1;
    
    
    auto labelHightScore = cocos2d::__String::createWithFormat("%i", diemSo);
    auto valueHeightScore = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize);
    valueHeightScore->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xValueScore = titlePhepTinh->getPositionX();
    float yValueScore = titlePhepTinh->getPositionY() - valueHeightScore->getContentSize().height * 0.6;
//    if (h/ w <= 1.53)
//    {
//        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueHeightScore->getContentSize().width;
//
//    }
    valueHeightScore->setPosition(Vec2(xValueScore, yValueScore));
    valueHeightScore->setAnchorPoint({0.5, 0.5});
    valueHeightScore->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(valueHeightScore, 2);
    
    
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    fontSize = 0.045 * w;
    fontStyle = "fonts/ArialUnicodeMS.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
    }
    //auto fontStyle = "fonts/NunitoSans-Bold.ttf";
    if (h / w <= 1.53)
    {
        fontSize = 0.035 * w;
    }
    auto title1 = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LEVEL1").c_str(), fontStyle, fontSize);
    title1->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xTitle1 = w / 6 - title1->getContentSize().width / 2;//  myImg->getContentSize().width * scalemyImg / 2 + 2;
    float yTitle1 = h * 0.89 - fixHeightHasTypePT - title1->getContentSize().height  / 2;// - title1->getContentSize().width;
    
    title1->setPosition(Vec2(xTitle1, yTitle1));
    title1->setAnchorPoint({0, 0.5});
    title1->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(title1, 1);
    
    auto title2 = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LEVEL2").c_str(), fontStyle, fontSize);
    title2->setColor(Color3B().WHITE);
    float xTitle2 = w / 2 - title2->getContentSize().width / 2;
    title2->setPosition(Vec2(xTitle2, yTitle1));
    title2->setAnchorPoint({0, 0.5});
    title2->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(title2, 1);
    
    auto title3 = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LEVEL3").c_str(), fontStyle, fontSize);
    title3->setColor(Color3B().WHITE);
    float xTitle3 = 5 * w / 6 - title3->getContentSize().width / 2;
    title3->setPosition(Vec2(xTitle3, yTitle1));
    title3->setAnchorPoint({0, 0.5});
    title3->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(title3, 1);
    
    //add cac button cot 1
    
    auto buttonCong = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, yTitle1, 1, typePT);
    
    int redirectToLoaiPT = 4;
    if (typePT == 2) {
        redirectToLoaiPT = 5;
    } else if (typePT == 3) {
        redirectToLoaiPT = 2;
    } else if (typePT == 1) {
        redirectToLoaiPT = 4;
    } else {
        redirectToLoaiPT = 3;
    }
    buttonCong->setTag(redirectToLoaiPT);
    
    addChild(buttonCong, 1);
    buttonCong->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
                HuyFunctions().animationClickedButton(clickedButton, [clickedButton](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(clickedButton->getTag(), 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(clickedButton->getTag(), 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(clickedButton->getTag(), 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(clickedButton->getTag(), 1, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(clickedButton->getTag(), 1, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(clickedButton->getTag(), 1, typePT), Color3B().WHITE));
                    }
                });
                
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
                
        }
        if (UserDefault::getInstance()->getIntegerForKey("hide-hand-guide-congtru", 0) == 0) {
            handButton->runAction(Spawn::create(FadeOut::create(0.3), nullptr));
            UserDefault::getInstance()->setIntegerForKey("hide-hand-guide-congtru", 1);
        }
    });
    
    
    handButton = ui::Button::create("hand.png"); // tao button
    handButton->setTouchEnabled(false);
    float ratiohandButton = 10;
    if (ratioScreen <= 1.53)
    {
        ratiohandButton = 20;
        //fontSize = 0.04 * w;
    }
    
    if (UserDefault::getInstance()->getIntegerForKey("hide-hand-guide-congtru", 0) == 0) {
        float scalehandButton = w / ratiohandButton / handButton->getContentSize().width;
        handButton->setScale(scalehandButton);
        //handButton->setTitleFontSize(fontSize / scalehandButton);
        handButton->setPosition(Vec2(buttonCong->getPositionX() +  handButton->getContentSize().width * scalehandButton * 0.5, buttonCong->getPositionY() -  handButton->getContentSize().height * scalehandButton * 0.5));
        if (ratioScreen <= 1.53)
        {
            //handButton->setPosition(Vec2(w / 2.5 - 10, yhandButton));
        }
        addChild(handButton, 10);//add button vao scene
        float timeAnimationHand = 0.2;
        handButton->runAction(
             RepeatForever::create(
                Sequence::create(
                     ScaleTo::create(timeAnimationHand / 1.1, 1.1 * scalehandButton),
                     DelayTime::create(0.5),
                     ScaleTo::create(timeAnimationHand  / 1.2, scalehandButton * 0.9),
                     nullptr)
              )
        );
        
    }

    float arrow1X = buttonCong->getPositionX() + buttonCong->getContentSize().width * buttonCong->getScale() / 2 + 5;
    auto arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonCong->getPositionY());
    addChild(arrow1, 2);
    
    //add cac button cot 2
    buttonCong = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, yTitle1, 2, typePT);
    buttonCong->setTag(redirectToLoaiPT);
    this->addChild(buttonCong, 1);
    buttonCong->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
                HuyFunctions().animationClickedButton(clickedButton, [clickedButton](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(clickedButton->getTag(), 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(clickedButton->getTag(), 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(clickedButton->getTag(), 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(clickedButton->getTag(), 2, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(clickedButton->getTag(), 2, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(clickedButton->getTag(), 2, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });

    arrow1X = buttonCong->getPositionX() + buttonCong->getContentSize().width * buttonCong->getScale() / 2 + 5;
    arrow1 = HuyFunctions().createArrow(w, h, arrow1X, buttonCong->getPositionY());
    addChild(arrow1, 2);
    
    //add cac button cot 3
    buttonCong = HuyFunctions().createButtonPhepTinh(w, h, modelOfWork, yTitle1, 3, typePT);
    buttonCong->setTag(redirectToLoaiPT);
    addChild(buttonCong, 1);
    buttonCong->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //showAds();
                #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                    //AdmobHelper::showAds();
                    //AdmobHelper::loadAds();
                #endif
                //redirect to play
               
                HuyFunctions().animationClickedButton(clickedButton, [clickedButton](){
                    if(modelOfWork == 1){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(clickedButton->getTag(), 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 2){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(clickedButton->getTag(), 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 3){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(clickedButton->getTag(), 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 4){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(clickedButton->getTag(), 3, typePT), Color3B().WHITE));
                    }
                    else if(modelOfWork == 5){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(clickedButton->getTag(), 3, typePT), Color3B().WHITE));
                    }
                    else{
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(clickedButton->getTag(), 3, typePT), Color3B().WHITE));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    auto line = ui::Button::create("devide.png", "devide.png"); // tao button
    float ratioLINE = 1.2;
    if (h / w <= 1.53)
    {
        ratioLINE = 1.2;
        
    }
    float scaleLINE = w / ratioLINE / line->getContentSize().width;
    line->setScale(scaleLINE);
    float xLINE = w / 2;
    float yLINE = buttonCong->getPositionY() - buttonCong->getContentSize().height * buttonCong->getScale() * 1.2;
    if (h / w <= 1.53)
    {
        //xButtonPlay2 = 0.7 * wScene - buttonPlay2->getContentSize().width / 2 * scaleButtonPlay;
        //heightButtonPlay2 = buttonPlay->getPositionY() + buttonPlay2->getContentSize().height *  scaleButtonPlay + 0.04 * wScene;
    }
    line->setPosition(Vec2(xLINE, yLINE));
    line->setTouchEnabled(false);
    this->addChild(line, 2);//add button vao scene
    
    
    //button play 1
    buttonPlay1 = ui::Button::create("play1Active.png"); // tao button
    buttonPlay1->setPressedActionEnabled(false);
    buttonPlay1->setZoomScale(-0.1f);
    buttonPlay1->setScale9Enabled(false);
    buttonPlay1->setTag(1);
    float ratioButtonPlay1 = 5;
    if (h / w <= 1.53)
    {
        ratioButtonPlay1 = 10;
    }
    float scaleButtonPlay1 = w / ratioButtonPlay1 / buttonPlay1->getContentSize().width;
    buttonPlay1->setScale(scaleButtonPlay1);
    float xButtonPlay1 = 0.05 * w + buttonPlay1->getContentSize().width / 2 * scaleButtonPlay1;
    float yButtonPlay1 = line->getPositionY() - buttonCong->getContentSize().height * buttonCong->getScale() * 1.6 / 2 - buttonPlay1->getContentSize().height * scaleButtonPlay1 / 2;
    if (h / w <= 1.53)
    {
        //xButtonPlay1 = 0.05 * w + buttonPlay1->getContentSize().width / 2 * scaleButtonPlay1;
    }
    buttonPlay1->setPosition(Vec2(xButtonPlay1, yButtonPlay1));
    addChild(buttonPlay1);//add button vao scene
    buttonPlay1->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                if (clickedButton->getTag() == 0) {
                    clickedButton->loadTextureNormal("play1Active.png");
                    clickedButton->setTag(1);
                    modelOfWork = 1;
                }
                buttonPlay2->setTag(0);
                buttonPlay3->setTag(0);
                
                buttonPlay2->loadTextureNormal("play3.png");
                buttonPlay3->loadTextureNormal("play2.png");
                buttonPlay4->setTag(0);
                buttonPlay4->loadTextureNormal("button-play4.png");
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
            }
        });
    
    //button play 2
    buttonPlay2 = ui::Button::create("play3.png"); // tao button
    buttonPlay2->setTag(0);
    buttonPlay2->setPressedActionEnabled(false);
    buttonPlay2->setZoomScale(-0.1f);
    buttonPlay2->setScale9Enabled(false);
    float scaleButtonPlay2 = w / ratioButtonPlay1 / buttonPlay2->getContentSize().width;
    buttonPlay2->setScale(scaleButtonPlay2);
    float xButtonPlay2 = buttonPlay1->getPositionX() + buttonPlay1->getScale() * buttonPlay1->getContentSize().width + w / 30;
    if (h / w <= 1.53)
    {
        //xButtonPlay2 = 0.3 * w + buttonPlay2->getContentSize().width / 2 * scaleButtonPlay2;
        //heightButtonPlay = 0.05 * wScene + yButtonLearn + buttonLearn->getContentSize().height * scaleButtonLearn;
    }
    buttonPlay2->setPosition(Vec2(xButtonPlay2, yButtonPlay1));
    addChild(buttonPlay2);//add button vao scene
    buttonPlay2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                if (clickedButton->getTag() == 0) {
                    clickedButton->loadTextureNormal("play3Active.png");
                    clickedButton->setTag(1);
                    modelOfWork = 3;
                }
                buttonPlay1->setTag(0);
                buttonPlay3->setTag(0);
                buttonPlay1->loadTextureNormal("play1.png");
                buttonPlay3->loadTextureNormal("play2.png");
                buttonPlay4->setTag(0);
                buttonPlay4->loadTextureNormal("button-play4.png");
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
        }
    });
    
    //button play 4
    buttonPlay4 = ui::Button::create("button-play4.png"); // tao button
    buttonPlay4->setTag(0);
    buttonPlay4->setPressedActionEnabled(false);
    buttonPlay4->setZoomScale(-0.1f);
    buttonPlay4->setScale9Enabled(false);
    
    buttonPlay4->setScale(scaleButtonPlay2 * 1.15);
    float xButtonPlay4 = buttonPlay2->getPositionX() + buttonPlay1->getScale() * buttonPlay1->getContentSize().width + w / 30;
    
    buttonPlay4->setPosition(Vec2(xButtonPlay4, yButtonPlay1));
    addChild(buttonPlay4);//add button vao scene
    buttonPlay4->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                if (clickedButton->getTag() == 0) {
                    clickedButton->loadTextureNormal("button-play4-active.png");
                    clickedButton->setTag(1);
                    modelOfWork = 4;
                }
                buttonPlay1->setTag(0);
                buttonPlay3->setTag(0);
                buttonPlay1->loadTextureNormal("play1.png");
                buttonPlay3->loadTextureNormal("play2.png");
                
                buttonPlay2->setTag(0);
                buttonPlay2->loadTextureNormal("play3.png");
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
        }
    });
    
    //button play 3
    buttonPlay3 = ui::Button::create("play2.png"); // tao button
    buttonPlay3->setPressedActionEnabled(false);
    buttonPlay3->setTag(0);
    
    float scaleButtonPlay3 = w / ratioButtonPlay1 / buttonPlay3->getContentSize().width;
    buttonPlay3->setScale(scaleButtonPlay3);
    float xButtonPlay3 = w - xButtonPlay1;
    if (h / w <= 1.53)
    {
        //xButtonPlay3 = 0.3 * w + buttonPlay3->getContentSize().width / 2 * scaleButtonPlay3;
        //heightButtonPlay = 0.05 * wScene + yButtonLearn + buttonLearn->getContentSize().height * scaleButtonLearn;
    }
    buttonPlay3->setPosition(Vec2(xButtonPlay3, yButtonPlay1));
    
    addChild(buttonPlay3);//add button vao scene
    buttonPlay3->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathSelect == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                if (clickedButton->getTag() == 0) {
                    clickedButton->loadTextureNormal("play2Active.png");
                    clickedButton->setTag(1);
                    modelOfWork = 2;
                }
                buttonPlay1->setTag(0);
                buttonPlay2->setTag(0);
                buttonPlay1->loadTextureNormal("play1.png");
                buttonPlay2->loadTextureNormal("play3.png");
                buttonPlay4->setTag(0);
                buttonPlay4->loadTextureNormal("button-play4.png");
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
        }
    });
    
    if (HuyFunctions().getSoVang() < Variable().soDiemMoKhoaGame3) {
        buttonPlay2->setTouchEnabled(false);
        buttonPlay2->setOpacity(0);
    }
    if (HuyFunctions().getSoVang() < Variable().soDiemMoKhoaGame2) {
        buttonPlay3->setTouchEnabled(false);
        buttonPlay3->setOpacity(0);
    }
}
void MathSelect::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(), Color3B().WHITE));
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}

void MathSelect::createValueKey(){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    valueKey1 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * wScene1);
    valueKey1->setColor(Color3B().BLACK);
    valueKey1->setHorizontalAlignment(TextHAlignment::LEFT);
    // position the label on the center of the
    auto btnHeightKey = valueKey1->getContentSize().height;
    auto btnWidthKey = valueKey1->getContentSize().width;
    yValueKey1 = hScene1 - (btnHeightKey / 2 + 5);
    xValueKey1 = wScene1 - (btnWidthKey / 2 + 5);
    valueKey1->setPosition(Vec2(xValueKey1, yValueKey1));
    // add the label as a child to this layer
    addChild(valueKey1);
}
void MathSelect::createButtonKey(){
    createValueKey();
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    //auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;
    float scale = wScene1 / ratio / btnWidth;
    float xBtn = xValueKey1 - 7 - valueKey1->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, yValueKey1));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                //restart valueKey Label
                removeChild(valueKey1);
                createValueKey();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
