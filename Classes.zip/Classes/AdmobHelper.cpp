#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "AdmobHelper.h"
#include "platform/android/jni/JniHelper.h"
#include <jni.h>
#include <android/log.h>

const char* NativeActivityClassName = "org/cocos2dx/cpp/AppActivity";
void AdmobHelper::loadAds(){
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	cocos2d::JniMethodInfo t;
	if (cocos2d::JniHelper::getStaticMethodInfo(t
			, NativeActivityClassName
			, "loadInterstitalAgain"
			, "()V"))
	{
		t.env->CallStaticVoidMethod(t.classID, t.methodID);
		t.env->DeleteLocalRef(t.classID);
	}

#endif
}
void AdmobHelper::showAds(){
	#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
		cocos2d::JniMethodInfo t;
		if (cocos2d::JniHelper::getStaticMethodInfo(t
			, NativeActivityClassName
			, "showInterstitial"
			, "()V"))
		{
			t.env->CallStaticVoidMethod(t.classID, t.methodID);
			t.env->DeleteLocalRef(t.classID);
		}

	#endif
}
void AdmobHelper::showRating(){
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	cocos2d::JniMethodInfo t;
	if (cocos2d::JniHelper::getStaticMethodInfo(t
			, NativeActivityClassName
			, "showRating"
			, "()V"))
	{
		t.env->CallStaticVoidMethod(t.classID, t.methodID);
		t.env->DeleteLocalRef(t.classID);
	}

#endif
}

bool AdmobHelper::getPhoneLanguage(){
	bool flag = false;
	#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
		cocos2d::JniMethodInfo methodInfo;
		if (cocos2d::JniHelper::getStaticMethodInfo(methodInfo, NativeActivityClassName, "getPhoneLang", "()Z"))
		{
			jboolean returned = methodInfo.env->CallStaticBooleanMethod(methodInfo.classID, methodInfo.methodID);

			if ((bool)(returned == JNI_TRUE) == true) {
				flag = true;
			}
			methodInfo.env->DeleteLocalRef(methodInfo.classID);
		}
	#endif
	return flag;
}
#endif