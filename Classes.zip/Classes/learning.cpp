#include "learnSelect.h"
#include "learning.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "play.h"
#include "play2.h"
#include "play3.h"
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include <SimpleAudioEngine.h>

USING_NS_CC;

bool tFlag;
float ytitle;
float yButton1;
int level;
cocos2d::__String* pt;
float rarioScreen;
int soundLearning;

Scene* Learning::createScene(bool flag, int i)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    tFlag = flag;
    level = i;
    // 'layer' is an autorelease object
    auto layer = Learning::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Learning::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    float wScene;
    float hScene;


    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    rarioScreen = hScene / wScene;
    //CCLOG("ratioScene %f, %f, $f", rarioScreen, hScene, wScene);
    
    soundLearning = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg();

    createTite(wScene, hScene);
    createButtonSelectLevel(wScene, hScene);
    createMainTemplate(wScene, hScene);

    //back button
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (hScene / wScene <= 1.53)
    {
        ratio = 17;
        
        
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    float yBack = hScene - (btnHeight / 2 * scale + 13);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), yBack));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                CCLOG("Button back to learn select");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, LearnSelect::createScene(), Color3B().WHITE));
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene

    //next button
    auto btnNext = ui::Button::create("next3.png", "next3.png"); // tao button

    btnNext->setScale(scale);
    btnNext->setPosition(Vec2(wScene - (btnWidth / 2 * scale + 13), yBack));
    btnNext->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        //redirect to previous scene 3
        int max = 3;
        if (HuyFunctions().getSoVang() < Variable().soDiemMoKhoaGame2) {
            max = 2;
        }
        if (HuyFunctions().getSoVang() < Variable().soDiemMoKhoaGame3) {
            max = 1;
        }
        
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                CCLOG("Button back to learn select");
                HuyFunctions().animationClickedButton(button, [max](){
                    switch (cocos2d::RandomHelper::random_int(1,max)) {
                        case 1:
                            if (tFlag == true)
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(2, 1, 0), Color3B().WHITE));
                            }
                            else
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(3, 1, 0), Color3B().WHITE));
                            }
                            break;
                        case 2:
                            if (tFlag == true)
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(2, 1, 0), Color3B().WHITE));
                            }
                            else
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(3, 1, 0), Color3B().WHITE));
                            }
                            break;
                        case 3:
                            if (tFlag == true)
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(2, 1, 0), Color3B().WHITE));
                            }
                            else
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(3, 1, 0), Color3B().WHITE));
                            }
                            break;
                            
                        default:
                            if (tFlag == true)
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(2, 1, 0), Color3B().WHITE));
                            }
                            else
                            {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(3, 1, 0), Color3B().WHITE));
                            }
                            break;
                    }
                });
                
                if (cocos2d::RandomHelper::random_int(1, 3) == 1) {
                    
                }else{
                    
                }
                

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btnNext);//add button vao scene

    if (tFlag == true)
    {
        CCLOG("hien phep nhan");
    }
    else
    {
        CCLOG("hien phep chia");
    }
    //this->setKeypadEnabled(true);
    return true;
}
void Learning::createBg() {
    float wScene;
    float hScene;

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    auto imageName = "bg-kid-top-3.png";
    if (hScene / wScene <= 1.53)
    {
        imageName = "bg-top-ipad.png";
        
    }
    auto bgTopKid = ui::Button::create(imageName); // tao button
    float ratioButtonkidTop = 1;
    float scaleButtonKidTop = wScene / ratioButtonkidTop / bgTopKid->getContentSize().width;
    bgTopKid->setScale(scaleButtonKidTop);
    float yButtonKidTop = hScene - bgTopKid->getContentSize().height / 2 * scaleButtonKidTop;
    float xButtonKidTop = bgTopKid->getContentSize().width / 2 * scaleButtonKidTop;
    bgTopKid->setPosition(Vec2(xButtonKidTop, yButtonKidTop));
    bgTopKid->setEnabled(false);
    this->addChild(bgTopKid);//add button vao scene
    
    auto imageNameBottom = "bg-kid.png";
    if (hScene / wScene <= 1.53)
    {
        imageNameBottom = "bg-bottom-ipad.png";
        
    }
    
    auto bgKid = ui::Button::create(imageNameBottom); // tao button
    float ratioButtonkid = 1;
    float scaleButtonKid = wScene / ratioButtonkid / bgKid->getContentSize().width;
    bgKid->setScale(scaleButtonKid);
    float yButtonKid = 0 + bgKid->getContentSize().height / 2 * scaleButtonKid;
    float xButtonKid = 0 + bgKid->getContentSize().width / 2 * scaleButtonKid;
    bgKid->setPosition(Vec2(xButtonKid, yButtonKid));
    bgKid->setEnabled(false);
    this->addChild(bgKid);//add button vao scene
}
void Learning::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, LearnSelect::createScene(), Color3B().WHITE));
}

void Learning::createTite(float w, float h){
    
    //create bg color
    auto bgColor = ui::Button::create("bg-app.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    
    float fontSize = 0.12 * w;
    if (h / w <= 1.53)
    {
        fontSize = 0.06 * w;
    }
    auto title = ui::Button::create("bg-title.png"); // tao button
    title->setPressedActionEnabled(true);
    title->setZoomScale(-0.1f);
    title->setScale9Enabled(true);
    if (tFlag == true)
    {
        title->setTitleText(LanguageManager::getInstance()->getStringForKey("MULTIPLICATION").c_str());
    }
    else
    {
        title->setTitleText(LanguageManager::getInstance()->getStringForKey("DIVISION").c_str());
    }
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    if(appLang == "en" || appLang == "vi"){
        title->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }

    title->setTitleColor(Color3B().WHITE);
    title->setTouchEnabled(false);
    float ratiotitle = 1;
    float scaletitle = w / ratiotitle / title->getContentSize().width;
    title->setScale(scaletitle);
    title->setTitleFontSize(fontSize / scaletitle);
    if (appLang == "ja")
    {
        title->setTitleFontName("fonts/KosugiMaru.ttf");
        title->setTitleFontSize(0.09 * w / scaletitle);
    }
    ytitle = h - (title->getContentSize().height / 2 * scaletitle);
    if (h / w <= 1.8)
    {
        ytitle = h * 1.07 - (title->getContentSize().height / 2 * scaletitle);
    }
    if (h / w <= 1.53)
    {
        ytitle = h * 1.1 - (title->getContentSize().height / 2 * scaletitle);
        if (appLang == "ja")
        {
            title->setTitleFontSize(0.05 * w / scaletitle);
        }
    }
    title->setPosition(Vec2(w / 2, ytitle));
    title->setEnabled(true);
    addChild(title);

    yButton1 = ytitle - (title->getContentSize().height / 2 * scaletitle);
    
}
void Learning::createButtonSelectLevel(float w, float h){
    float fontSize = 0.05 * w;
    int ratiobuttonSelectLevel = 9;
    float fixHeigh = 0;
    auto mLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    if (mLang == "en"
        || mLang == "ja"
        || mLang == "de"
        || mLang == "ko"
        || mLang == "th"
        || mLang == "fr"
        || mLang == "sp"
        || mLang == "ma"
        || mLang == "da")
    {
        ratiobuttonSelectLevel = 12;
        fixHeigh = h / 10;
    }
    for (int i = 2; i <= ratiobuttonSelectLevel; i++)
    {
        //add 9 buttons
        auto lbl = cocos2d::__String::createWithFormat("%i", i);
        auto buttonSelectLevel = ui::Button::create("vsmall2.png", "vsmallActive2.png"); // tao button
        buttonSelectLevel->setPressedActionEnabled(true);
        buttonSelectLevel->setZoomScale(-0.1f);
        buttonSelectLevel->setScale9Enabled(true);
        buttonSelectLevel->setTitleText(lbl->getCString());
        buttonSelectLevel->setTitleFontName("fonts/comfortaa.ttf");

        buttonSelectLevel->setTouchEnabled(true);
        buttonSelectLevel->setTitleColor(Color3B().WHITE);
        buttonSelectLevel->setTag(i);
        if (level == i)
        {
            buttonSelectLevel->loadTextureNormal("vsmallActive2.png");
            buttonSelectLevel->setTouchEnabled(false);
            buttonSelectLevel->setEnabled(true);
        }

        float scalebuttonSelectLevel = w / 7 / buttonSelectLevel->getContentSize().width;
        if (rarioScreen <= 1.65)
        {
            scalebuttonSelectLevel = w / 10 / buttonSelectLevel->getContentSize().width;
        }
        
        if (rarioScreen <= 1.534)
        {
            scalebuttonSelectLevel = w / 14 / buttonSelectLevel->getContentSize().width;
            fontSize = 0.04 * w;

        }
        
        buttonSelectLevel->setTitleFontSize(fontSize / scalebuttonSelectLevel);
        //CCLOG("button select level: %f", scalebuttonSelectLevel);
        buttonSelectLevel->setScale(scalebuttonSelectLevel);
        //float y = (buttonSelectLevel->getContentSize().height / 2 * scalebuttonSelectLevel);
        float x = 0.2 * w + buttonSelectLevel->getContentSize().width / 2 * scalebuttonSelectLevel;
        float yButton = yButton1 + fixHeigh  - i * (buttonSelectLevel->getContentSize().height * scalebuttonSelectLevel + 5.5);
        if (rarioScreen <= 1.65)
        {
            buttonSelectLevel->setTitleFontSize(0.05 * w / scalebuttonSelectLevel);
            yButton = yButton1 + 30 - i * (buttonSelectLevel->getContentSize().height * scalebuttonSelectLevel + 1.5);
        }
        else if (rarioScreen <= 1.8)
        {
            yButton = yButton1 + 70 - i * (buttonSelectLevel->getContentSize().height * scalebuttonSelectLevel + 1.2);
        }
        
        if (rarioScreen <= 1.534)
        {
            buttonSelectLevel->setTitleFontSize(0.028 * w / scalebuttonSelectLevel);
            yButton = yButton1 + 20 - i * (buttonSelectLevel->getContentSize().height * scalebuttonSelectLevel + 1.5);
        }
        
        buttonSelectLevel->setPosition(Vec2(x, yButton));
        buttonSelectLevel->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    
                    if (soundLearning == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }

                    //redirect to previous scene
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Learning::createScene(tFlag, ((ui::Button*) sender)->getTag()), Color3B().WHITE));
                    
                   
                    
//                    HuyFunctions().animationClickedButton(button, [button](){
//                        Director::getInstance()->replaceScene(Learning::createScene(tFlag, ((ui::Button*) button)->getTag()));
//                    });

                    
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //CCLOG("Button 1 clicked");
                    break;
                default:
                    break;
            }
        });
        addChild(buttonSelectLevel);

        //add 9 phep tinh
        //"20 : 2 = 10"

        if (tFlag == true)
        {
            pt = cocos2d::__String::createWithFormat("%i%s%i%s%i", level, " x ", i, " = ", level * i);
        }
        else
        {
            pt = cocos2d::__String::createWithFormat("%i%s%i%s%i", level * i, " : ", level, " = ", i);
        }

        auto title = ui::Button::create("bgNumber.png", "bgNumber.png"); // tao button
        float ratiotitle = 3;
        if (rarioScreen <= 1.65){
            ratiotitle = 3.5;
            fontSize = 0.05 * w;
        }
        if (rarioScreen <= 1.534){
            ratiotitle = 4.8;
            fontSize = 0.028 * w;
        }
        title->setPressedActionEnabled(false);
        title->setZoomScale(-0.1f);
        title->setScale9Enabled(false);
        title->setTitleText(pt->getCString());
        title->setTitleFontName("fonts/comfortaa.ttf");
        title->setTouchEnabled(false);
        title->setTitleColor(Color3B().WHITE);
        float scaletitle = w / ratiotitle / title->getContentSize().width;
        title->setTitleFontSize(fontSize / scaletitle);
        title->setScale(scaletitle);
        title->setPosition(Vec2(w / 2, yButton));
        title->setEnabled(true);
        addChild(title);
    }


}
void Learning::createMainTemplate(float w, float h){

}
void Learning::handleClickButtonSelectLevel(int level){

}
