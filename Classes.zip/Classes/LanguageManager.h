#ifndef LanguageManager_h
#define LanguageManager_h

#include <string>

#include "json/rapidjson.h"
#include "json/document.h"

using namespace rapidjson;
using std::string;

class LanguageManager
{
public:
	static LanguageManager* getInstance();
	static LanguageManager* getInstanceRestart();
	string getStringForKey(string key) const;
public:
	static LanguageManager* _instance;

	LanguageManager();
	virtual ~LanguageManager();

	Document _document;
	string _fileName;
};

#endif
