//
//  SelectGame.cpp
//  mentalmath
//
//  Created by Huy Le on 22/2/25.
//

#include "SelectGame.hpp"
#include "HelloWorldScene.h"
#include "mathLevel.h" // will delete
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "play.h"
#include "playDual.h"
#include "play2.h"
#include "playGame1.hpp"
#include "play3.h"
#include "play4.hpp"
#include "Variable.hpp"
#include "mathSelect.h"
#include "Huy_functions/HuyFunctions.hpp"
#include "BuyPro.hpp"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "AdmobHelper.h"
#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
#include "NDKHelper.h"
#endif

USING_NS_CC;
int levelPT;
int loaiPhepTinh;
Scene* SelectGame::createScene(int typePhepTinh, int level) //100 - la khong chon
//2 - nhan; 3 - chia; 4 - cong; 5 - tru; 1 - multi

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    levelPT = level;
    loaiPhepTinh = typePhepTinh;
    log("loai PT: %i", loaiPhepTinh);
    // 'layer' is an autorelease object
    auto layer = SelectGame::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool SelectGame::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;

    arrImage = {"play1-moi.png", "button-play2.png", "lucky-button-new.png", "button-play4.png",  "game o chu.png", "button-dual.png"};
    
    arrLink = {0, 2, 3, 4, 5, 1};
    
    soundSelectGame = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    back(wScene, hScene);
    createTemplate(wScene, hScene);
    
    //createButtonKey();
    #if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
        requestAds();
    #endif
    //this->setKeypadEnabled(true);
    return true;
}
void SelectGame::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-blurr.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void SelectGame::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void SelectGame::showAds()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("showIntertistitalAds", cocos2d::Value());
#endif

}
void SelectGame::requestAds()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("requestIntertistialAds", cocos2d::Value());
#endif
}

void SelectGame::createTemplate(float w, float h){
    //button PlayDual
    int soHang = 0;
    for (int i = 0; i < Variable().soGame; i++) {
        
        auto buttonPlayDual = ui::Button::create(arrImage[i].c_str(), arrImage[i].c_str()); // tao button
        float ratioButtonPlayDual = 3.3;
        if (hScene / wScene <= 1.53)
        {
            ratioButtonPlayDual = 6.6;
            
        }
        float scaleButtonPlayDual = wScene / ratioButtonPlayDual / buttonPlayDual->getContentSize().width;
        buttonPlayDual->setScale(scaleButtonPlayDual);
        float yButtonPlayDual = h * 0.9 - buttonPlayDual->getContentSize().height * scaleButtonPlayDual / 2 - (buttonPlayDual->getContentSize().height * scaleButtonPlayDual * soHang * 1.4);

        float xButtonPlayDual  = wScene * 0.3 ;
        if (i % 2 == 1) {
            xButtonPlayDual  = wScene - wScene * 0.3;
        }
//        if (hScene / wScene <= 1.8)
//        {
//            yButtonPlayDual = buttonPlayDual->getContentSize().height * scaleButtonPlayDual * 0.8;
//            
//        }
//        if (hScene / wScene <= 1.53)
//        {
//            xButtonPlayDual = wScene * 0.7 - buttonPlayDual->getContentSize().width / 2 * scaleButtonPlayDual;
//            yButtonPlayDual = 0.05 * wScene + buttonPlayDual->getContentSize().height * scaleButtonPlayDual;
//        }
        buttonPlayDual->setPosition(Vec2(xButtonPlayDual, yButtonPlayDual));
        buttonPlayDual->setTag(arrLink[i]);
        buttonPlayDual->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    //log("Button 1 clicked");
                    //HuyFunctions().animationClickedButton(button);
                    if (soundSelectGame == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    log("Button 1 touch");
                    //redirect to play
                    HuyFunctions().animationClickedButton(button, [button]() {
                        log("test ABC");
                        //log("%i", arrLink[i]);
                        int mode = button->getTag();
                        if (mode == 0 or Variable().isProVer) {
                            if (levelPT == 100) {
                                Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(mode, 0), Color3B().WHITE));
                            } else {
                                if(mode == 1){
                                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(loaiPhepTinh, levelPT, true), Color3B().WHITE));
                                }
                                else if(mode == 2){
                                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(loaiPhepTinh, levelPT, 0, true), Color3B().WHITE));
                                }
                                else if(mode == 3){
                                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(loaiPhepTinh, levelPT, 0, true), Color3B().WHITE));
                                }
                                else if(mode == 4){
                                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play4::createScene(loaiPhepTinh, levelPT, 0, true), Color3B().WHITE));
                                }
                                else if(mode == 5){
                                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayGame1::createScene(loaiPhepTinh, levelPT, 0, true), Color3B().WHITE));
                                }
                                else{
                                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(loaiPhepTinh, levelPT, 0, true), Color3B().WHITE));
                                }
                                
                                
                            }
                        }else{
                            Director::getInstance()->replaceScene(TransitionFade::create(0.5, BuyPro::createScene(false)));
                        }
                        
//                        if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
//                            HuyFunctions().showAds();
//                        }
                    });
                    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(1, 0), Color3B().WHITE));
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
                }
            });
        addChild(buttonPlayDual);//add button vao scene
        
        auto vuongMien = Sprite::create("vuong-mien2.png");
        float ratiovuongMien = 16;
        float ratiovuongMien2 = 20;
//        if (ratioScreen <= 1.53)
//        {
//            ratiovuongMien = 32;
//            ratiovuongMien2 = 40;
//        }
        float scalevuongMien = w / ratiovuongMien / vuongMien->getContentSize().width;
        vuongMien->setScale(scalevuongMien);
        vuongMien->setPosition(Vec2(buttonPlayDual->getContentSize().height / 2, buttonPlayDual->getContentSize().height + vuongMien->getContentSize().height * 0.18));
        if (i != 0 && Variable().isProVer == false) {
            buttonPlayDual->addChild(vuongMien);
        }
        
        
        if (i == 0) {
//            float timeAnimation = 0.4;
//            auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * scaleButtonPlayDual);
//            auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.1, scaleButtonPlayDual * 0.95);
//            auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
//            buttonPlayDual->runAction((RepeatForever::create(sq3)));
        }
        if (i % 2 == 1) {
            soHang++;
            scalevuongMien = w / ratiovuongMien2 / vuongMien->getContentSize().width;
            vuongMien->setScale(scalevuongMien);
        }
        
        if (i == 4 && loaiPhepTinh == 6) { // phep tinh so sanh -> an game o chu vi game nay khong co phep tinh so sanh
            buttonPlayDual->setVisible(false);
            buttonPlayDual->setEnabled(false);
        }
    }
    if(Variable().isProVer == false) {
        auto preeBtn = ui::Button::create("button-pro.png");
        preeBtn->setPressedActionEnabled(true);
        preeBtn->setZoomScale(-0.1f);
        preeBtn->setScale9Enabled(true);
        preeBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("REMOVE_ADS").c_str());
        auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
        if(appLang == "en" || appLang == "vi"){
            preeBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
        }
        preeBtn->setTitleColor(Color3B().WHITE);
        
        preeBtn->setTouchEnabled(true);
        float ratiotitle = 1.8;
        float fontSize = 0.035 * wScene;
        if (hScene / wScene <= 1.53)
        {
            ratiotitle = 3.6;
            fontSize = 0.017 * wScene;
        }
        auto scalerestoreBtn = wScene / ratiotitle / preeBtn->getContentSize().width;
        preeBtn->setScale(scalerestoreBtn);
        preeBtn->setTitleFontSize(fontSize * 1.3 / scalerestoreBtn);
        if (appLang == "ja")
        {
            preeBtn->setTitleFontName("fonts/KosugiMaru.ttf");
            preeBtn->setTitleFontSize(0.065 * wScene / scalerestoreBtn);
        }
        auto ytitle = hScene/6;
        if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
        {
            
            ytitle = 20;
        }
        if (hScene / wScene <= 1.53)
        {
            
            if (appLang == "ja")
            {
                
                preeBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
            }
        }
        preeBtn->setPosition(Vec2(wScene / 2, hScene / 8));
        preeBtn->setEnabled(true);
        preeBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                    
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    HuyFunctions().animationClickedButton(button, [](){
//                        if (Variable().isProduction == true) {
//                            HuyFunctions().showAds();
//                        }
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, BuyPro::createScene(false), Color3B().WHITE));
                    });
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //CCLOG("Button 1 clicked");
                    break;
                default:
                    break;
            }
        });
        
        addChild(preeBtn, 101);
    }
    
    
}
void SelectGame::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
