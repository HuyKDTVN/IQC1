#ifndef  __Admob_Helper_H_
#define  __Admob_Helper_H_

class AdmobHelper
{
public:
	static void showAds();
	static void loadAds();
	static bool getPhoneLanguage();
	static void showRating();
};
#endif  //__INTERFACE_FACEBOOK_H_

