//
//  Onboarding1.cpp
//  mentalmath
//
//  Created by Huy Le on 21/2/26.
//

//
//  Onboarding1.cpp
//  mentalmath
//
//  Created by Huy Le on 18/11/25.
//


#include "Onboarding1.hpp"
#include "Onboarding2.hpp"
#include "setting.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"

USING_NS_CC;

Scene* Onboarding1::createScene()

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = Onboarding1::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Onboarding1::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;

    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    //back(wScene, hScene);
    createTemplate(wScene, hScene);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(6);
    }
    //this->setKeypadEnabled(true);
    return true;
}
void Onboarding1::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg01.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void Onboarding1::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void Onboarding1::createTemplate(float w, float h){
    
    auto fontStyle = "Helvetica-Bold";
//    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
//    {
//        fontStyle = "fonts/KosugiMaru.ttf";
//    }
    auto fontTitle = 0.06 * w;
    auto fixIpad = 1;
    Size sizeOfEditBox = Size(200,50);
    if (h / w <= 1.53)
    {
        fontTitle = 0.03 * w;
        sizeOfEditBox = Size(100,25);
        fixIpad = 0.5;
    }
    
    labelTitleNguoiChoi = Label::createWithSystemFont(LanguageManager::getInstance()->getStringForKey("BANTENLAGI").c_str(), fontStyle, fontTitle);
    labelTitleNguoiChoi->setHorizontalAlignment(TextHAlignment::CENTER);
    labelTitleNguoiChoi->setTextColor(Color4B::YELLOW);
    labelTitleNguoiChoi->setPosition(Vec2(w/2, h * 0.85));
    this->addChild(labelTitleNguoiChoi, 13);
    
    auto bgSprite = ui::Scale9Sprite::create();
    bgSprite->setContentSize(sizeOfEditBox);
    bgSprite->setColor(Color3B::WHITE);  // nền trắng
    bgSprite->setOpacity(255);
    nameEditBox = ui::EditBox::create(sizeOfEditBox, bgSprite);
    //nameEditBox->setPosition(Vec2(w/ 2, h / 2));
    nameEditBox->setFontColor(Color3B::BLACK);
    nameEditBox->setMaxLength(20);
    nameEditBox->setFontSize(fontTitle);
    nameEditBox->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    nameEditBox->setInputMode(ui::EditBox::InputMode::SINGLE_LINE);
    nameEditBox->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    
    auto tenNguoiChoi = UserDefault::getInstance()->getStringForKey("ten-nguoi-choi");
    nameEditBox->setText(tenNguoiChoi.c_str());
    // Tự động focus:
    nameEditBox->openKeyboard();
    
    float paddingX = 30 * fixIpad, paddingY = 5 * fixIpad;
    Size bgSize(nameEditBox->getContentSize().width + paddingX,
                nameEditBox->getContentSize().height + paddingY);
    auto bg = DrawNode::create();
    HuyFunctions().drawSolidRoundedRect(bg, Vec2::ZERO, bgSize, bgSize.height / 2, Color4F(1, 1, 1, 1.0f));
    node = Node::create();
    node->addChild(bg);
    node->addChild(nameEditBox);
    nameEditBox->setPosition(Vec2(bgSize.width * 0.5f, bgSize.height * 0.5f));
    this->addChild(node, 12);
    node->setPosition(w/2 - bgSize.width / 2, labelTitleNguoiChoi->getPositionY() - h / 7);
    
    labelErr = Label::createWithSystemFont(LanguageManager::getInstance()->getStringForKey("LOI_DIEN_TEN").c_str(), fontStyle, fontTitle * 0.7);
    labelErr->setHorizontalAlignment(TextHAlignment::CENTER);
    labelErr->setColor(Color3B::RED);
    labelErr->setPosition(Vec2(w/2, node->getPositionY() - labelErr->getContentSize().height));
    this->addChild(labelErr, 13);
    labelErr->setVisible(false);
    
    
    auto dogName = Sprite::create("dog-whatname.png");
    
    float ratioDogName = 2;
  
    if (ratioScreen <= 1.53)
    {
        ratioDogName = 4;
      
    }
    float scaleDogName = wScene / ratioDogName / dogName->getContentSize().width;
    dogName->setScale(scaleDogName);
    dogName->setPosition(Vec2(wScene - dogName->getContentSize().width * scaleDogName * 0.6, node->getPositionY() - labelErr->getContentSize().height - dogName->getContentSize().height * scaleDogName / 2 - h / 50)); // Đặt vị trí
    this->addChild(dogName, 13);
    
    //create claim button
    okButton = ui::Button::create("button-claim.png", "button-claim.png"); // tao button
    float ratioButtonClaim = 4.5;
    if (h / w <= 1.53)
    {
        ratioButtonClaim = 9;
    }
    //auto okButtonHeight = okButton->getContentSize().height;
    auto okButtonWidth = okButton->getContentSize().width;

    float scaleokButton = w / ratioButtonClaim / okButtonWidth;
    okButton->setScale(scaleokButton);
    okButton->setPosition(Vec2(w/2, dogName->getPositionY() - dogName->getContentSize().height * scaleDogName - h / 10));
    okButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                inputTenHandle(w, h);

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(okButton, 12);//add button vao scene
    float timeAnimation = 0.4;
    auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * okButton->getScale());
    auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.2, okButton->getScale() * 0.95);
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    okButton->runAction((RepeatForever::create(sq3)));
    
}
void Onboarding1::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
//                HuyFunctions().animationClickedButton(button, [](){
//                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
//                });
                
                HuyFunctions().requestATTAds();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
void Onboarding1::inputTenHandle(float w, float h) {
    std::string name = HuyFunctions().trim(nameEditBox->getText());
    log("hien thi ten: %s", name.c_str());
    UserDefault::getInstance()->setStringForKey("ten-nguoi-choi", name);
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Onboarding2::createScene(), Color3B().WHITE));
    
    
}
