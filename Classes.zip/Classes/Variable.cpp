//
//  Variable.cpp
//  mentalmath-mobile 
//
//  Created by Huy Le on 06/03/2024.
//

#include "Variable.hpp"
Variable::Variable() {
    isProduction = false; // chuyen quang cao co thang thuong ve dang publish
    //isProVer = false;
    isProVer = cocos2d::UserDefault::getInstance()->getBoolForKey("isProVer", false);
    //cocos2d::UserDefault::getInstance()->setBoolForKey("isProVer", false);
    soDiemShowPro = 40;//40;
    showProSauBaoNhieuLan = 200;// 10;
    hasTet = false;
    hasLePhucSinh = false;
    hasHaloween = false; // (11/10 - 2/11)
    soGame = 6; //g1- ban ten lua, g2 - 2 players, g3 - game tro ve phi thuyen me, g4 - vong quay may man,  g5 - game an vang, g6 game o chu(playgame1.cpp)
    languageTest = "vi";//vi
    soCauHoiDualModeTest = 10;
    
    timeBasic = 25.f;
    timeHard = 20.f;
    timeVeryHard = 19.f;
    
    timeBasicNhan = 20.f;
    timeHardNhan = 14.f;
    timeVeryHardNhan = 12.f;
    
    diemVang = 150;
    diemXanh = 100;
    diemDo = 50;
    diemTim = 20;
    showSoPhepTinhParentScreen = 100;
    
    soDiemMoKhoaGame4 = 300;
    soDiemMoKhoaGame3 = 100;
    soDiemMoKhoaGame2 = 500;
    
    emojiStart = {"🚀", "🧠", " 🎉", "🎯💪", "🎊", "💖", "🍒", "🛸"};
    emojiEnd = {"🎯", "🏆", "📚", "👑", "🎁", "🎮✨", "🏅✨", "🍄🍄🍄"};
    
    diemNgauNhienImg = {"+1.png","+1.png", "+1.png","+1.png", "+1.png", "+2.png", "+2.png", "+2.png", "+2.png","+2.png","+2.png", "+3.png","+3.png","+3.png", "+3.png","+3.png", "+4.png","+4.png","+4.png", "+4.png", "+3.png","+2.png","+2.png", "+10.png", "+3.png", "+10.png"};
    diemNgauNhien = {1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4, 4, 4, 3, 2, 2, 10, 3, 10};
    diemNgauNhienPhepTinh = {"+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+"};
    
    diemMayManImg = {"+2.png","+4.png", "x2.png","+3.png", "-2.png", "+1.png", "+5.png", "-1.png", "+3.png","+10.png","+2.png", "+1.png"};
    diemMayMan = {2, 4, 2, 3, 2, 1, 5, 1, 3, 10, 2, 1};
    diemMayManPhepTinh = {"+", "+", "*", "+", "-", "+", "+", "-", "+", "+", "+", "+"};
    
    // diemNgauNhienImg = {"+1.png","+1.png", "+1.png","+1.png", "+1.png", "+2.png", "+2.png", "+2.png", "+2.png","+2.png","+2.png", "+3.png","+3.png","+3.png", "+3.png","+3.png", "+4.png","+4.png","+4.png", "+4.png", "+5.png","+5.png","+5.png", "+10.png", "x2.png", "x3.png"};
    // diemNgauNhien = {1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 10, 2, 3};
    // diemNgauNhienPhepTinh = {"+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "+", "*", "*"};
    
    // diemMayManImg = {"+2.png","+4.png", "x2.png","+3.png", "-2.png", "+1.png", "+5.png", "-1.png", "+7.png","+10.png","+6.png", "+1.png"};
    // diemMayMan = {2, 4, 2, 3, 2, 1, 5, 1, 7, 10, 6, 1};
    // diemMayManPhepTinh = {"+", "+", "*", "+", "-", "+", "+", "-", "+", "+", "+", "+"};

    arrNhanVat = {500, 3000,7000, 9900};
    arrPhiThuyen = {5, 25, 100, 299};
    arrTenLua = {1, 7, 40, 100};
    
//    arrPhiThuyen = {400, 800, 2000, 4000};
//    arrTenLua = {400, 1000, 2000, 5500};
    
    //cai dat play 4
    batDauHienCandyTuCauHoi = 4;
    batDauHienSaoChoiTuCauHoi = 6;
    batDauHienHoDenTuCauHoi = 8;
    batDauHienVirusTuCauHoi = 14;
    batDauTangChuyenDongVirusTuCauHoi = 20;
    
    proProductionID = "com.huy.mentalmath.pro";
    //daily reward
    arrDailyRewardType = {1, 1, 2, 1, 2, 1, 2}; //1 - gold, 2 - diamond
    arrDailyRewardValue = {
        {50, 100, 2, 200, 4, 300, 10},
        {60, 110, 3, 250, 5, 330, 12},
        {65, 120, 4, 270, 6, 350, 13},
        {70, 135, 4, 280, 7, 380, 15},
        {80, 150, 5, 290, 8, 390, 16},
        {85, 160, 6, 300, 9, 400, 17},
        {90, 170, 7, 320, 9, 420, 18},
    };
    
arrChallenge = {//vi du: 10 phep tinh cong de duoc nhan 30 vang
{4, 0, 4,  1, 4,  0,  1, 4,  0, 4,  1, 4,  0,  1,4,  0,  1, 4,  0,  1, 4,  0,  1, 4,  0,  1, 4,  0,  1,  0,  1,  0,  1,  0,  1,  0,  1,  2,  3,  2,  3,  2,  3,  2,  3,  2,  3,  2,  3,  2,  3,  2,  3,  2,  3,  2,  3}, // type:: +:0, -:1, x:2, :3, >=<4
{10, 10, 15, 10, 20, 40, 50,45, 50, 40, 50, 60, 10, 60, 40, 10, 10, 50, 40, 45, 10, 50, 45, 40, 70, 70, 10, 50, 10, 30, 30, 60, 60, 70, 75, 80, 75, 30, 35, 70, 65, 75, 80, 75, 70, 40, 40, 60, 60, 30, 30, 70, 70, 75, 80, 75, 70}, //number: 10
{ 1, 1,  1, 1, 1,  1,  1, 1,  1,  1,  1, 1,2, 1,2,  2,  2, 2,  2,  2, 3,  2,  2,3,  2,  2,  3,3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  1,  1,  1,  1,  2,  2,  2,  2,  2,  2,  2,  2,  3,  3,  3,  3,  3,  3,  3,  3}, //level: 1 - de, 2 - vua, 3 - kho
{1, 1, 2,  1,  2, 1,  1,  1, 1,  2,  1,  1, 1, 1, 2,  1,  1, 1,  2,  1, 2,  1,  1, 2,  1,  1,  2, 1,  1,  1,  1,  1,  2,  1,  1,  1,  1,  1,  1,  1,  1,  2,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1}, //giftType: 1 - gold, 2 - diamond
{20 ,30, 8, 35, 10, 100, 150, 160, 170, 12,190, 195, 50 ,200, 20, 50, 55, 210, 15,270, 7, 300,310, 30, 360,365, 10, 230, 75,220,230,500, 30,550,570,590,605,200,250,500,500, 50,500,700,730,650,680,700,710,240,250,600,700,710,725,730,750}, //giftValue: 30
};
   //20 - 23 - 27
    
}
Variable::~Variable() {
    // Destructor
}
