#ifndef __PLAY4_H__
#define __PLAY4_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class Play4 : public cocos2d::Layer
{
public:
    bool isIpad = false;
    cocos2d::Vector<cocos2d::ui::Button*> listGold;
    cocos2d::ui::Button* vang;
    cocos2d::Vec2 positionGold;
    
    cocos2d::Vector<cocos2d::ui::Button*> listCandy;
    cocos2d::ui::Button* candy;
    cocos2d::Vec2 positionCandy;
    
    int soVang;
    int soCandy;
    
    cocos2d::Vector<cocos2d::ui::Button*> cacVatCan;
    int soVatCan;
    int count;
    int countVang;
    bool viTriVatCan;
    const char *HIGH_SCORE2 = "height-score2";
    
    int viTriCauTraLoi;
    
    int realType2;
    int answer1_2;
    int answer2_2;
    int answer3_2;
    int answer4_2;

    double wScenePlay2;
    double hScenePlay2;

    float scalePhiThuyen;
    
    int correctAnswer2;
    int score2;
    
    int indexThemDiem;
    
    int maxDoiSo2;

    cocos2d::__String *phepToan2;
    cocos2d::__String *score2String2;
    float xDichPhiThuyen2;
    float yTenLua2;
    
    cocos2d::Label* lblPhepToan2;
    
    cocos2d::ui::Button* bgPhepToan;
    cocos2d::Label* lblScore2;
    cocos2d::ui::Button* score2Icon2;

    
    cocos2d::ui::Button* buttonAnswer1;
    cocos2d::ui::Button* buttonAnswer2;
    
    float scaleButtonAnswer1;
    float scaleButtonAnswer2;

    float timeRemaining2;
    float timeMax2;
    bool isPause2 = false;

    cocos2d::Label* valueKey3_2;
    float yValueKey3_2;
    float xValueKey3_2;

    cocos2d::Label* buttonAnswer1NumberLabel_2;
    cocos2d::Label* buttonAnswer2NumberLabel_2;

    cocos2d::ui::Button* popupthanhCong;
    cocos2d::ui::Button* popupthatBai;
    
    cocos2d::Sprite* phithuyenHienThi;
    cocos2d::ui::Button* earth;
    
    cocos2d::Sprite* bomPhiThuyenHienThi;
    cocos2d::Sprite* bomCandyHienThi;
    
    int sound2;
    int prevA2 = 2;
    int prevB2 = 2;
    
    int soCauHoiDaVuotQua = 0;
    
    int batDauHienCandyTuCauHoi;
    int batDauHienSaoChoiTuCauHoi;
    int batDauHienHoDenTuCauHoi;
    int batDauHienVirusTuCauHoi;
    int batDauTangChuyenDongVirusTuCauHoi;
    
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int type, int level, int backTypePhepTinh, bool fromChallenge = false);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void update(float dt);
    void coundownTimer(float w, float h);
    void back(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void createButtonKey(float w, float h);
    void createValueKey(float w, float h);
    void createScore(float w, float h);
    void createMainTemplate(float w, float h);
    void createPhiThuyen(float w, float h);
    void createPopupFinish(float w, float h);
    
    void createBg();
    void createBgColor(float w, float h);
    void createAnswer(float w, float h);
    void animationShowAnswer(cocos2d::ui::Button* button, float time, float scale);
    void handlerClickAnswer(int v);
    
    void randomQuestionAndAnswer();
    void randomNhan1();
    void randomNhan2();
    void randomNhan3();

    void randomCong1();
    void randomCong2();
    void randomCong3();

    void randomTru1();
    void randomTru2();
    void randomTru3();

    void randomChia1();
    void randomChia2();
    void randomChia3();
    
    void randomSoSanh1();
    void randomSoSanh2();
    void randomSoSanh3();
    std::string generateRandomExpression(int tong);
    
    
    void random4AnswerNhan1(int a, int b);
    void random4AnswerNhan2(int a, int b);
    void random4AnswerNhan3(int a, int b);

    void random4AnswerCong1(int a, int b);
    void random4AnswerCong2(int a, int b);
    void random4AnswerCong3(int a, int b);

    void random4AnswerTru1(int a, int b);
    void random4AnswerTru2(int a, int b);
    void random4AnswerTru3(int a, int b);

    void random4AnswerChia1(int a, int b);
    void random4AnswerChia2(int a, int b);
    void random4AnswerChia3(int a, int b);

    void moveSceneGameOver();
    void nextPlay();
    
    void hideAnswer1(float myDelay, float myTime);
    void hideAnswer2(float myDelay, float myTime);
    void createVatCan(float w, float h);
    void createGold(float w, float h, float xVang, float yVang);
    void createGroupGold(float w, float h);
    
    void createStar(float w, float h, float xVang, float yVang, bool isMain);
    void createGroupStar(float w, float h, float x, float y);
    
    void createCandy(float w, float h, float x, float y);
    void createBomCandy(float w, float h, float x, float y);
    
    void updateScore(bool isCandy);
    void createpPopUpCongDiem(float w, float h, float x, float y);
    void createSaoChoi(float w, float h);

    void createBgPro(float w, float h);
    void finish();
    virtual void onEnter() override;
    void showMedal(float w, float h, std::string medal);
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(Play4);
    
    

};

#endif // __PLAY2_H__
