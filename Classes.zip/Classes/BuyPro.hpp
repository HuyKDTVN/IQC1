//
//  BuyPro.hpp
//  mentalmath
//
//  Created by Huy Le on 23/8/25.
//

#ifndef __BUYPRO_SCREEN_H__
#define __BUYPRO_SCREEN_H__
#include "ui/CocosGUI.h"
#include "cocos2d.h"
#include <iostream>
#include <sstream>
class BuyPro : public cocos2d::Layer
{
public:
    int sound;
    virtual void onEnter() override;
    cocos2d::Sprite* bgNenPro;
    static cocos2d::Scene* createScene(bool hasOnboarding);
    virtual bool init();
    void createBgPro(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void back(float w, float h);
    
    CREATE_FUNC(BuyPro);
};

#endif // __BUYPRO_SCREEN_H__
