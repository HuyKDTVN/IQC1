//
//  playGame1.cpp
//  mentalmath
//
//  Created by Huy Le on 11/11/24.
//

#include "playGame1.hpp"
#include "mathLevel.h"
#include "mathSelect.h"
#include "finish.h"
#include "ui/CocosGUI.h"
#include <SimpleAudioEngine.h>
#include <iostream>
#include <string>
#include "Variable.hpp"
#include "SelectGame.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "Huy_functions/CreatePhepToan.hpp"
#include "Huy_functions/PhepToanOChu.hpp"
#include "giftDiamond.hpp"
#include <cstdlib>
#include "cocos2d.h"
#include "GameCenterBridge.h"
#include "LanguageManager.h"
#include "IAPManager.h"

using namespace std;
USING_NS_CC;

int typeOfWGame1;
int levelOfWGame1;
int backTypePTGame1 = 0;
float arrBack[9][5];
bool fromChallengeG1;
Scene* PlayGame1::createScene(int type, int level, int backTypePhepTinh, bool fromChallenge)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    if (type > 0) {
        typeOfWGame1 = type - 1;
    } else {
        typeOfWGame1 = type;
    }
    if (typeOfWGame1 > 4) {
        typeOfWGame1 = 4;
    }
    backTypePTGame1 = backTypePhepTinh;
    
    if (level > 0) {
        levelOfWGame1 = level - 1;
    }else {
        levelOfWGame1 = level;
    }
    if (levelOfWGame1 > 2) {
        levelOfWGame1 = 2;
    }
    fromChallengeG1 = fromChallenge;
    // 'layer' is an autorelease object
    auto layer = PlayGame1::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
// on "init" you need to initialize your instance
bool PlayGame1::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }
    timeInSeconds = 0;
    timeInSecondsFor1PhepTinh = 0;
    soMang = 3;
    countThaoTac = 0;
    
    score = 0;
    if (UserDefault::getInstance()->getIntegerForKey("height-score", 99999) == 99999)
    {
        UserDefault::getInstance()->setIntegerForKey(HIGH_SCORE, 0);
        UserDefault::getInstance()->flush();
    }
    auto mLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
   
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    wScenePlay = wScene;
    hScenePlay = hScene;
    
    isIpad = false;
    if (hScene / wScene <= 1.53) {
        isIpad = true;
    }
    cauTraLoiLuaChon = 0;
    randomColor = cocos2d::RandomHelper::random_int(1, 3);
    realType = typeOfWGame1;
    resumeButtonFullWith(wScene, hScene);
    back(wScene, hScene);
    status(wScene, hScene);
    pauseButton(wScene, hScene);
    createButtonUndoAndHint(wScene, hScene);

    createBgColor(wScene, hScene);
    createEarth(wScene, hScene);
    
    createMainActor(wScene, hScene);
    //log("hLoadingBar: %f", hLoadingBar);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(5);
    }
    
    maxDoiSo = HuyFunctions().SoLonNhat(mLang);
    auto arrNoti = CreatePhepToan().createAnswerQuestions(typeOfWGame1 + 1, levelOfWGame1, 2, 2, maxDoiSo);
    UserDefault::getInstance()->setStringForKey("noti-title1", HuyFunctions().createPhepToanWithEmoji(arrNoti.at(2).c_str()));
    
    log("create phep tinh noti: %s", arrNoti.at(2).c_str());
    
    createMainTempate(wScene, hScene);
    //this->setKeypadEnabled(true);
    return true;
}
void PlayGame1::showMedal(float wScene, float hScene, std::string medal){
    auto fixIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        fixIpad = 2;
    }

    auto iconMedal = Sprite::create(medal);

    float ratioMedal = 6 * fixIpad;
    float scaleiconMedal = wScene / ratioMedal / iconMedal->getContentSize().width;

    // Vị trí giữa màn hình
    iconMedal->setPosition(Vec2(wScene / 2, hScene * 0.7));

    // Bắt đầu từ 0
    iconMedal->setScale(0.0f);
    iconMedal->setOpacity(0);

    this->addChild(iconMedal, 15);

    /// ===== ANIMATION =====

    // Move lên khi xuất hiện (30px)
    auto moveUp = MoveBy::create(0.2f, Vec2(0, 30 / fixIpad));

    // Scale từ 0 -> x1.3
    auto scaleUp = ScaleTo::create(0.2f, scaleiconMedal * 1.3);

    // Fade in
    auto fadeIn = FadeTo::create(0.2f, 255);

    // Scale + Fade + Move lên cùng lúc
    auto spawnIn = Spawn::create(scaleUp, fadeIn, moveUp, nullptr);

    // Giữ 1 chút
    auto delay = DelayTime::create(0.4f);

    // Move xuống nhẹ khi hide
    auto moveDown = MoveBy::create(0.6f, Vec2(0, -15 / fixIpad));

    // Fade out
    auto fadeOut = FadeOut::create(0.6f);

    // Fade + Move xuống cùng lúc khi hide
    auto spawnOut = Spawn::create(fadeOut, moveDown, nullptr);

    // Xóa sprite sau khi xong
    auto remove = RemoveSelf::create();

    // Chạy sequence
    iconMedal->runAction(
        Sequence::create(
            spawnIn,
            delay,
            spawnOut,
            remove,
            nullptr
        )
    );
}
void PlayGame1::createMainTempate(float wScene, float hScene) {
    // 100_None; 101_+; 102_-; 103_x; 104_:; 105_=; 106_empty
    
    int random = cocos2d::RandomHelper::random_int(0, 9);
    
    
    log("typeOfWGame1 %i, levelOfWGame1: %i", typeOfWGame1, levelOfWGame1);
    arrCauHoi = PhepToanOChu().arrCauHoiTong[typeOfWGame1][levelOfWGame1][random];
    arrDapAn = PhepToanOChu().arrDapAnTong[typeOfWGame1][levelOfWGame1][random];
    
    arrTraloi = PhepToanOChu().arrTraloiTong[typeOfWGame1][levelOfWGame1][random];
    shuffleArray(arrTraloi);
    // Kích thước của bàn cờ
    int margin = 10;
    float fontSize = 0.06 * wScene;
    if (isIpad) {
        margin = wScene * 0.2;
        fontSize = 0.03 * wScene;
    }
    float boardSize = wScene - margin * 2; // 8x60px = 480px
    int soOVuong = 11;
    
    
    float squareSize = boardSize / soOVuong;
    // Vòng lặp để tạo các ô cờ
    for (int row = 0; row < soOVuong; ++row)
    {
        for (int col = 0; col < soOVuong; ++col)
        {
            if (arrCauHoi[row][col] != 100) {
                // Tạo button cho mỗi ô cờ
                auto button = ui::Button::create(cocos2d::__String::createWithFormat("rec-normal%i.png", randomColor)->getCString());  // Hình ảnh của ô cờ (tùy chỉnh)
                button->setPressedActionEnabled(true);
                button->setZoomScale(0);
                button->setPosition(Vec2(margin + col * squareSize + squareSize / 2, (hScene - boardSize) * 0.6 + row * squareSize + squareSize / 2));
                button->setScale9Enabled(true);
                button->setTag(arrCauHoi[row][col]);
                button->setContentSize(Size(squareSize, squareSize));
                listButtonCauHoi.pushBack(button);
                auto val = cocos2d::__String::createWithFormat("%i", arrCauHoi[row][col]);
                button->setName(cocos2d::__String::createWithFormat("%i,%i", row, col)->getCString());
                if (arrCauHoi[row][col] == 101) {
                    val = cocos2d::__String::createWithFormat("%s", "+");
                    //button->setName("+");
                }
                if (arrCauHoi[row][col] == 102) {
                    val = cocos2d::__String::createWithFormat("%s", "-");
                    //button->setName("-");
                }
                if (arrCauHoi[row][col] == 103) {
                    val = cocos2d::__String::createWithFormat("%s", "x");
                    //button->setName("*");
                }
                if (arrCauHoi[row][col] == 104) {
                    val = cocos2d::__String::createWithFormat("%s", ":");
                    //button->setName("/");
                }
                if (arrCauHoi[row][col] == 105) {
                    val = cocos2d::__String::createWithFormat("%s", "=");
                    //button->setName("=");
                }
                if (arrCauHoi[row][col] == 106) {
                    
                    val = cocos2d::__String::createWithFormat("%s", "");
                    button->loadTextureNormal(cocos2d::__String::createWithFormat("rec-empty_noselect%i.png", randomColor)->getCString());
                    //button->setName("N");
                    
                    button->addClickEventListener([row, col, button, this](Ref* sender) {
                        auto me = static_cast<cocos2d::ui::Button*>(sender);
                        me->loadTextureNormal(cocos2d::__String::createWithFormat("rec-empty%i.png", randomColor)->getCString());
                        log("Button clicked at row: %d, col: %d", row, col);
                        viTriCauHoiSelected = me->getPosition();
                        xSelected = col;
                        ySelected = row;
                        for (auto& btn : listButtonCauHoi) {
                            if (btn != me) {
                                if (btn->getTag() == 106) {
                                    btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-empty_noselect%i.png", randomColor)->getCString());
                                }
                                
                            }
                        }
                    });
                }
                button->setTitleText(val->getCString());
                
                button->setTitleFontName("fonts/NunitoSans-Bold.ttf");
                button->setTitleFontSize(fontSize);
                button->setTitleColor(Color3B().BLACK);
                // Thêm sự kiện khi nhấn vào ô cờ
                
                // Thêm button vào scene
                this->addChild(button);
            }
            
        }
    }
    
    //show cau tra loi
    
    //randomizeArray(arrTraloi);
    
    // Kích thước của bàn cờ
    int marginTraLoi = wScene * 0.35;
    float fontSizeTraLoi = 0.07 * wScene;
    if (isIpad) {
        marginTraLoi = wScene * 0.4;
        fontSizeTraLoi = 0.035 * wScene;
    }
    float boardSizeTraLoi = wScene - marginTraLoi * 2; // 8x60px = 480px
    int soOVuongTraLoi = 3;
    
    int countCauTraLoi = 0;
    float squareSizeTL = boardSizeTraLoi / soOVuongTraLoi;
    // Vòng lặp để tạo các ô cờ
    for (int row = 0; row < soOVuongTraLoi; ++row)
    {
        for (int col = 0; col < soOVuongTraLoi; ++col)
        {
            // Tạo button cho mỗi ô cờ
            auto button = ui::Button::create(cocos2d::__String::createWithFormat("rec-answer%i.png", randomColor)->getCString());  // Hình ảnh của ô cờ (tùy chỉnh)
            //button->setPressedActionEnabled(true);
            //button->setZoomScale(0);
            button->setPosition(Vec2(marginTraLoi + col * (squareSizeTL + 5) + squareSizeTL / 2 - 10, (boardSizeTraLoi) * 0.25 + row * (squareSizeTL + 5) + squareSizeTL / 4 + 5));
                button->setScale9Enabled(true);
            button->setTag(countCauTraLoi);
            countCauTraLoi++;
            button->setContentSize(Size(squareSizeTL, squareSizeTL));
            auto valTL = cocos2d::__String::createWithFormat("%i", arrTraloi[row][col]);
            
            button->setTitleText(valTL->getCString());
            
            button->setTitleFontName("fonts/NunitoSans-Bold.ttf");
            button->setTitleFontSize(fontSizeTraLoi);
            button->setTitleColor(Color3B().WHITE);
            listButtonTraLoi.pushBack(button);
            // Thêm sự kiện khi nhấn vào ô cờ
            button->addClickEventListener([=](Ref* sender) {
                auto me = static_cast<cocos2d::ui::Button*>(sender);
                log("cau tra loi: %i, vi tri x cau hoi: %f, vi tri y cau hoi: %f, vi tri x trong mang: %i, vi tri y trong mang %i", me->getTag(), viTriCauHoiSelected.x, viTriCauHoiSelected.y, xSelected, ySelected);
                if (viTriCauHoiSelected != Vec2()) {
                    float timeAnimation = 0.4;
                    float scale80 = squareSize / squareSizeTL;
                    float scale100 = 1.0;
                    //record information for back function
                    arrBack[countThaoTac][0] = me->getPositionX();
                    arrBack[countThaoTac][1] = me->getPositionY();
                    arrBack[countThaoTac][2] = (float)me->getTag();
                    arrBack[countThaoTac][3] = (float)xSelected;
                    arrBack[countThaoTac][4] = (float)ySelected;
                    countThaoTac++;
                    
                    backButton->setTouchEnabled(true);
                    backButton->setEnabled(true);
                    int x = xSelected;
                    int y = ySelected;
                    me->runAction(
                        Sequence::create(
                              Spawn::create(
                                  ScaleTo::create(timeAnimation, scale100),
                                       MoveTo::create(timeAnimation, Vec2(viTriCauHoiSelected.x,  viTriCauHoiSelected.y)),
                                  nullptr
                              ),
                            DelayTime::create(0.1),
                             Spawn::create(
                                 ScaleTo::create(timeAnimation / 3, scale80),
                                 nullptr
                             ),
                             CallFunc::create([this, me, x, y]() {
                                 this->checkCorrectOrNot(me, x, y);
                             }),
                                         
                            nullptr
                        )
                    );
                    
                    viTriCauHoiSelected = Vec2();
                    me->setTouchEnabled(false);
                } else {
                    
                    if (sound == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    float timeAnimation = 0.1;
                    me->runAction(
                          Sequence::create(
                               MoveBy::create(timeAnimation, Vec2(0,  50)),
                               DelayTime::create(0.1),
                               MoveBy::create(timeAnimation, Vec2(0,  -50)),
                               nullptr
                            )
                    );
                    
                }
            });
            // Thêm button vào scene
            this->addChild(button, 10 - row - col);
            
            if (Variable().isProduction == true) {
                HuyFunctions().showAds();
            }
        }
    }
}

void PlayGame1::checkCorrectOrNot(cocos2d::ui::Button* me, int xLuaChon, int yLuaChon) {
    hintButton->setTouchEnabled(true);
    //stop all animation for buttons
    for (auto& btn : listButtonCauHoi) {
        btn->stopAllActions();
    }
    for (auto& btn : listButtonTraLoi) {
        btn->stopAllActions();
    }
    
    int soOVuong = 11;
    
    cauTraLoiLuaChon = std::stoi(me->getTitleText());
    arrCauHoi[yLuaChon][xLuaChon] = cauTraLoiLuaChon;
    
    //me->setTitleFontSize(fontSize);
//    for (auto& btn : listButtonCauHoi) {
//
//        if (btn->getName() == cocos2d::__String::createWithFormat("%i,%i", yLuaChon, xLuaChon)->getCString()) {
//            //btn->setTag(me->getTag());
//            arrCauHoi[yLuaChon][xLuaChon] = me->getTag();
//            log("co thay the: %i", me->getTag());
//        }
//    }
    
    //phat hien dung - sai
    int x[4] = {33391, 33391, 33391, 33391};
    cocos2d::__String viTriX[4] = {"", "", "", ""};
    int y[4] = {33391, 33391, 33391, 33391};
    cocos2d::__String viTriY[4] = {"", "", "", ""};
    
    int xHover = xLuaChon - 1;
    int yHover = yLuaChon - 1;
    int countX = 0;
    int countY = 0;
    for (int i = 1; i < 5; ++i) {
        xHover = xLuaChon - i;
        if (xHover >= 0) {
            log("vi tri x%i: %i, %i", countX, yLuaChon, xLuaChon - i);
            if (arrCauHoi[yLuaChon][xLuaChon - i] != 100 && arrCauHoi[yLuaChon][xLuaChon - i] != 106) {
                x[countX] = arrCauHoi[yLuaChon][xLuaChon - i];
                std::string temp = cocos2d::__String::createWithFormat("%i,%i", yLuaChon, xLuaChon - i)->getCString();
                viTriX[countX] = temp;
                countX++;
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    for (int i = 1; i < 5; ++i) {
        xHover = xLuaChon + i;
        if (xHover < soOVuong) {
            log("vi tri x%i: %i, %i", countX, yLuaChon, xLuaChon + i);
            if (arrCauHoi[yLuaChon][xLuaChon + i] != 100 && arrCauHoi[yLuaChon][xLuaChon + i] != 106) {
                
                //if (countX < 4) {
                    x[countX] = arrCauHoi[yLuaChon][xLuaChon + i];
                    std::string temp = cocos2d::__String::createWithFormat("%i,%i", yLuaChon, xLuaChon + i)->getCString();
                    viTriX[countX] = temp;
                    countX++;
                //}
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    auto hoanThanhCauTraLoiX = true;
    for (int i = 0; i < 4; ++i) {
        log("x%i : %i", i, x[i]);
        if (x[i] == 33391) {
            hoanThanhCauTraLoiX = false;
            //break;
        }
    }
    
   
    if (hoanThanhCauTraLoiX) {
        log("thoi gian cho phep nay: %i", timeInSecondsFor1PhepTinh);
        
        hintButton->stopAllActions();
        hintLabel->stopAllActions();
        hintLabel->setOpacity(255);
        hintButton->setOpacity(255);
        
        if (arrDapAn[yLuaChon][xLuaChon] == std::stoi(me->getTitleText()) and getValueOfArray(arrCauHoi, viTriX[0].getCString()) == getValueOfArray(arrDapAn, viTriX[0].getCString()) and getValueOfArray(arrCauHoi, viTriX[1].getCString()) == getValueOfArray(arrDapAn, viTriX[1].getCString()) and getValueOfArray(arrCauHoi, viTriX[2].getCString()) == getValueOfArray(arrDapAn, viTriX[2].getCString()) and getValueOfArray(arrCauHoi, viTriX[3].getCString()) == getValueOfArray(arrDapAn, viTriX[3].getCString()) ) {
            log("tra loi dung");
            auto dungLienTiep = HuyFunctions().saveSoPhepTinhDungLienTiep(true);
            auto dungMoiNgay = HuyFunctions().saveSoPhepTinhDungMoiNgay(true);
            if (dungLienTiep != "") {
                showMedal(wScenePlay, hScenePlay, dungLienTiep);
            }
            if (dungMoiNgay != "") {
                showMedal(wScenePlay, hScenePlay, dungMoiNgay);
            }
            auto ch = getCauHoi(xLuaChon, yLuaChon, viTriX[0].getCString(), viTriX[1].getCString(), viTriX[2].getCString(), viTriX[3].getCString(), cauTraLoiLuaChon, false);
            
            log("lich su cau hoi - hang ngang: %s", ch.c_str());
            if (ch != "" && cauTraLoiLuaChon) {
                HuyFunctions().savePhepTinhToDataBase(1, ch, cauTraLoiLuaChon, timeInSecondsFor1PhepTinh, levelOfWGame1, 0);
            }
            
            int i = 0;
            for (auto& btn : listButtonCauHoi) {
               
                if (btn->getName() == viTriX[0].getCString() || btn->getName() == viTriX[1].getCString() || btn->getName() == viTriX[2].getCString() || btn->getName() == viTriX[3].getCString()) {
                    btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-answer%i.png", randomColor)->getCString());
                    btn->setTitleColor(Color3B().WHITE);
                    btn->runAction(
                        Sequence::create(
                            DelayTime::create(i * 0.05),
                              Spawn::create(
                                    //FadeIn::create(0.2),
                                    ScaleTo::create(0.2, 1.15), nullptr),
                                    ScaleTo::create(0.05, 1), nullptr)
                    );
                    i++;
                }
            }
            if (sound == 0)
            {
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
            }
            kiemTraChienThang();
        }else {
            log("tra loi sai");
            auto ch = getCauHoi(xLuaChon, yLuaChon, viTriX[0].getCString(), viTriX[1].getCString(), viTriX[2].getCString(), viTriX[3].getCString(), cauTraLoiLuaChon, false);
            
            log("lich su cau hoi - hang ngang: %s", ch.c_str());
            if (ch != "" && cauTraLoiLuaChon) {
                HuyFunctions().savePhepTinhToDataBase(0, ch, cauTraLoiLuaChon, timeInSecondsFor1PhepTinh, levelOfWGame1, 0);
            }
            if (sound == 0)
            {
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/crash2.mp3");
            }
            for (auto& btn : listButtonCauHoi) {
               
                if (btn->getName() == viTriX[0].getCString() || btn->getName() == viTriX[1].getCString() || btn->getName() == viTriX[2].getCString() || btn->getName() == viTriX[3].getCString()) {
                    btn->loadTextureNormal("rec-wrong.png");
                    btn->setTitleColor(Color3B().WHITE);
                }
            }
            me->loadTextureNormal("rec-wrong.png");
            
            giamSoMang();

        }
        timeInSecondsFor1PhepTinh = 0;
    } else{
        log("chua hoan thanh cau tra loi");
        //cai dat mau sac ve ban dau
//        for (auto& btn : listButtonCauHoi) {
//            if (btn->getName() == viTriX[0].getCString() || btn->getName() == viTriX[1].getCString() || btn->getName() == viTriX[2].getCString() || btn->getName() == viTriX[3].getCString()) {
//                btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-normal%i.png", randomColor)->getCString());
//                btn->setTitleColor(Color3B().BLACK);
//            }
//
//        }
    }
    
    //so sanh y
    for (int i = 1; i < 5; ++i) {
        yHover = yLuaChon - i;
        if (yHover >= 0) {
            log("vi tri y%i: %i, %i", countY, yLuaChon - i, xLuaChon);
            if (arrCauHoi[yLuaChon - i][xLuaChon] != 100 && arrCauHoi[yLuaChon - i][xLuaChon] != 106) {
                
                y[countY] = arrCauHoi[yLuaChon - i][xLuaChon];
                std::string temp = cocos2d::__String::createWithFormat("%i,%i", yLuaChon - i, xLuaChon)->getCString();
                viTriY[countY] = temp;
                countY++;
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    for (int i = 1; i < 5; ++i) {
        yHover = yLuaChon + i;
        if (yHover < soOVuong) {
            log("vi tri y%i: %i, %i", countY, yLuaChon + i, xLuaChon);
            if (arrCauHoi[yLuaChon + i][xLuaChon] != 100 && arrCauHoi[yLuaChon + i][xLuaChon] != 106) {
                //if (countY < 4) {
                    y[countY] = arrCauHoi[yLuaChon + i][xLuaChon];
                    std::string temp = cocos2d::__String::createWithFormat("%i,%i", yLuaChon + i, xLuaChon)->getCString();
                    viTriY[countY] = temp;
                    countY++;
                //}
                
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    auto hoanThanhCauTraLoiY = true;
    for (int i = 0; i < 4; ++i) {
        log("y%i : %i", i, y[i]);
        if (y[i] == 33391) {
            hoanThanhCauTraLoiY = false;
            //break;
        }
    }
    log("cau tra loi : %i, dapan can so sanh: %i", std::stoi(me->getTitleText()), arrDapAn[yLuaChon][xLuaChon]);
    if (hoanThanhCauTraLoiY) {
        
        log("thoi gian cho phep nay: %i", timeInSecondsFor1PhepTinh);
        hintButton->stopAllActions();
        hintLabel->stopAllActions();
        hintLabel->setOpacity(255);
        hintButton->setOpacity(255);
        
        log("cau tra loi: %i", cauTraLoiLuaChon);
        
        
        if (arrDapAn[yLuaChon][xLuaChon] == std::stoi(me->getTitleText()) and getValueOfArray(arrCauHoi, viTriY[0].getCString()) == getValueOfArray(arrDapAn, viTriY[0].getCString()) and getValueOfArray(arrCauHoi, viTriY[1].getCString()) == getValueOfArray(arrDapAn, viTriY[1].getCString()) and getValueOfArray(arrCauHoi, viTriY[2].getCString()) == getValueOfArray(arrDapAn, viTriY[2].getCString()) and getValueOfArray(arrCauHoi, viTriY[3].getCString()) == getValueOfArray(arrDapAn, viTriY[3].getCString()) ) {
            log("tra loi dung");
            auto dungLienTiep = HuyFunctions().saveSoPhepTinhDungLienTiep(true);
            auto dungMoiNgay = HuyFunctions().saveSoPhepTinhDungMoiNgay(true);
            if (dungLienTiep != "") {
                showMedal(wScenePlay, hScenePlay, dungLienTiep);
            }
            if (dungMoiNgay != "") {
                showMedal(wScenePlay, hScenePlay, dungMoiNgay);
            }
            auto ch = getCauHoi(xLuaChon, yLuaChon, viTriY[0].getCString(), viTriY[1].getCString(), viTriY[2].getCString(), viTriY[3].getCString(), cauTraLoiLuaChon, true);
            log("lich su cau hoi: %s", ch.c_str());
            log("timeInSecondsFor1PhepTinh: %i", timeInSecondsFor1PhepTinh);
            if (ch != "" && cauTraLoiLuaChon) {
                HuyFunctions().savePhepTinhToDataBase(1, ch, cauTraLoiLuaChon, timeInSecondsFor1PhepTinh, levelOfWGame1, 0);
            }
            int i = 0;
            for (auto& btn : listButtonCauHoi) {
               
                if (btn->getName() == viTriY[0].getCString() || btn->getName() == viTriY[1].getCString() || btn->getName() == viTriY[2].getCString() || btn->getName() == viTriY[3].getCString()) {
                    btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-answer%i.png", randomColor)->getCString());
                    btn->setTitleColor(Color3B().WHITE);
                    btn->runAction(
                        Sequence::create(
                            DelayTime::create(i * 0.05),
                              Spawn::create(
                                    //FadeIn::create(0.2),
                                    ScaleTo::create(0.2, 1.15), nullptr),
                                    ScaleTo::create(0.05, 1), nullptr)
                    );
                    i++;
                }
            }
            if (sound == 0)
            {
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
            }
            kiemTraChienThang();
        }else {
            log("tra loi sai");
            
            auto ch = getCauHoi(xLuaChon, yLuaChon, viTriY[0].getCString(), viTriY[1].getCString(), viTriY[2].getCString(), viTriY[3].getCString(), cauTraLoiLuaChon, true);
            log("lich su cau hoi: %s", ch.c_str());
            if (ch != "" && cauTraLoiLuaChon) {
                HuyFunctions().savePhepTinhToDataBase(0, ch, cauTraLoiLuaChon, timeInSecondsFor1PhepTinh, levelOfWGame1, 0);
            }
            if (sound == 0)
            {
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/crash2.mp3");
            }
            for (auto& btn : listButtonCauHoi) {
               
                if (btn->getName() == viTriY[0].getCString() || btn->getName() == viTriY[1].getCString() || btn->getName() == viTriY[2].getCString() || btn->getName() == viTriY[3].getCString()) {
                    btn->loadTextureNormal("rec-wrong.png");
                    btn->setTitleColor(Color3B().WHITE);
                }
            }
            me->loadTextureNormal("rec-wrong.png");
            giamSoMang();
        }
        timeInSecondsFor1PhepTinh = 0;
    } else{
        log("chua hoan thanh cau tra loi");
        //cai dat mau sac ve ban dau
//        for (auto& btn : listButtonCauHoi) {
//            if (btn->getName() == viTriX[0].getCString() || btn->getName() == viTriX[1].getCString() || btn->getName() == viTriX[2].getCString() || btn->getName() == viTriX[3].getCString()) {
//                btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-normal%i.png", randomColor)->getCString());
//                btn->setTitleColor(Color3B().BLACK);
//            }
//
//        }
    }
}

int PlayGame1::getNumberOfString(std::string input, bool first) {
    int result = 100;
    if (input != "") {
        // Tìm dấu phẩy ','
        size_t commaPos = input.find(',');

        // Tách chuỗi
        std::string part1 = input.substr(0, commaPos);
        std::string part2 = input.substr(commaPos + 1);

        // Chuyển đổi thành số
        int num1 = std::stoi(part1);
        int num2 = std::stoi(part2);
        
        if (first) {
            result = num1;
        }else {
            result = num2;
        }
    }
    
    return result;
}
int PlayGame1::getValueOfArray(std::vector<std::vector<int>> arr, std::string viTri) {
    ///if (viTri != "") {
        log("vi tri: %s", viTri.c_str());
        // Tìm dấu phẩy ','
        size_t commaPos = viTri.find(',');

        // Tách chuỗi
        std::string part1 = viTri.substr(0, commaPos);
        std::string part2 = viTri.substr(commaPos + 1);

        // Chuyển đổi thành số
        int num1 = std::stoi(part1);
        int num2 = std::stoi(part2);
        if (num1 >= 0 and num2 >= 0) {
            log("vi tri cau hoi: %i",  arr[num1][num2]);
            return arr[num1][num2];
        }
    //}
    return 100;
}
int PlayGame1::soDiem() {
//    - tính số điểm: số điểm = 130 - 2* số giây
//            if sodiem < 0 then
//              sodiem = 0
//            end if
//
//            sodiem = sodiem + random (1->8)
    
    int result = 130 - (2 * timeInSeconds);
    if (result < 0) {
        result = 0;
    }
    result = result + cocos2d::RandomHelper::random_int(1, 15);
    return result;
}
void PlayGame1::backColorForCells(cocos2d::ui::Button* me) {
    //stop all animation for buttons
    
    int soOVuong = 11;
    
    //me->setTitleFontSize(fontSize);
//    for (auto& btn : listButtonCauHoi) {
//        if (btn->getName() == cocos2d::__String::createWithFormat("%i,%i", ySelected, xSelected)->getCString()) {
//            //btn->setTag(me->getTag());
//            arrCauHoi[ySelected][xSelected] = me->getTag();
//            log("co thay the");
//        }
//    }
    //phat hien dung - sai
    int x[4] = {33391, 33391, 33391, 33391};
    cocos2d::__String viTriX[4] = {"", "", "", ""};
    int y[4] = {33391, 33391, 33391, 33391};
    cocos2d::__String viTriY[4] = {"", "", "", ""};
    
    int xHover = xSelected - 1;
    int yHover = ySelected - 1;
    int countX = 0;
    int countY = 0;
    for (int i = 1; i < 5; ++i) {
        xHover = xSelected - i;
        if (xHover >= 0) {
            log("vi tri x%i: %i, %i", countX, ySelected, xSelected - i);
            if (arrCauHoi[ySelected][xSelected - i] != 100 && arrCauHoi[ySelected][xSelected - i] != 106) {
                
                x[countX] = arrCauHoi[ySelected][xSelected - i];
                viTriX[countX] = cocos2d::__String::createWithFormat("%i,%i", ySelected, xSelected - i)->getCString();
                countX++;
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    for (int i = 1; i < 5; ++i) {
        xHover = xSelected + i;
        if (xHover < soOVuong) {
            log("vi tri x%i: %i, %i", countX, ySelected, xSelected + i);
            if (arrCauHoi[ySelected][xSelected + i] != 100 && arrCauHoi[ySelected][xSelected + i] != 106) {
                
                //if (countX < 4) {
                    x[countX] = arrCauHoi[ySelected][xSelected + i];
                    viTriX[countX] = cocos2d::__String::createWithFormat("%i,%i", ySelected, xSelected + i)->getCString();
                    countX++;
                //}
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    
    
    //so sanh y
    for (int i = 1; i < 5; ++i) {
        yHover = ySelected - i;
        if (yHover >= 0) {
            log("vi tri y%i: %i, %i", countY, ySelected - i, xSelected);
            if (arrCauHoi[ySelected - i][xSelected] != 100 && arrCauHoi[ySelected - i][xSelected] != 106) {
                
                y[countY] = arrCauHoi[ySelected - i][xSelected];
                viTriY[countY] = cocos2d::__String::createWithFormat("%i,%i", ySelected - i, xSelected)->getCString();
                countY++;
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    for (int i = 1; i < 5; ++i) {
        yHover = ySelected + i;
        if (yHover < soOVuong) {
            log("vi tri y%i: %i, %i", countY, ySelected + i, xSelected);
            if (arrCauHoi[ySelected + i][xSelected] != 100 && arrCauHoi[ySelected + i][xSelected] != 106) {
                //if (countY < 4) {
                    y[countY] = arrCauHoi[ySelected + i][xSelected];
                    viTriY[countY] = cocos2d::__String::createWithFormat("%i,%i", ySelected + i, xSelected)->getCString();
                    countY++;
                //}
                
            } else {
                break;
            }
        }else{
            break;
        }
    }
    
    auto hoanThanhCauTraLoiY = true;
    for (int i = 0; i < 4; ++i) {
        log("y%i : %i", i, y[i]);
        if (y[i] == 33391) {
            hoanThanhCauTraLoiY = false;
            //break;
        }
    }
    log("cau tra loi : %i, dapan can so sanh: %i", std::stoi(me->getTitleText()), arrDapAn[ySelected][xSelected]);
    if (hoanThanhCauTraLoiY == false) {
        log("chua hoan thanh cau tra loi");
        //cai dat mau sac ve ban dau
        for (auto& btn : listButtonCauHoi) {
            if (btn->getName() == viTriX[0].getCString() || btn->getName() == viTriX[1].getCString() || btn->getName() == viTriX[2].getCString() || btn->getName() == viTriX[3].getCString()) {
                btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-normal%i.png", randomColor)->getCString());
                btn->setTitleColor(Color3B().BLACK);
            }

        }
    }
    auto hoanThanhCauTraLoiX = true;
    for (int i = 0; i < 4; ++i) {
        log("x%i : %i", i, x[i]);
        if (x[i] == 33391) {
            hoanThanhCauTraLoiX = false;
            //break;
        }
    }
    log("cau tra loi : %i, dapan can so sanh: %i", me->getTag(), arrDapAn[ySelected][xSelected]);
    if (hoanThanhCauTraLoiX == false) {
        log("chua hoan thanh cau tra loi");
        //cai dat mau sac ve ban dau
        for (auto& btn : listButtonCauHoi) {
            if (btn->getName() == viTriY[0].getCString() || btn->getName() == viTriY[1].getCString() || btn->getName() == viTriY[2].getCString() || btn->getName() == viTriY[3].getCString()) {
                btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-normal%i.png", randomColor)->getCString());
                btn->setTitleColor(Color3B().BLACK);
            }
        }
    }
}
std::string PlayGame1::getCauHoi(int xChon, int yChon, const char* vt1, const char* vt2, const char* vt3, const char* vt4, int cauTraLoi, bool direction) {
    log("ch: xChon %i, yChon %i, vt1 %s, vt2 %s, vt3 %s, vt4 %s", xChon, yChon, vt1, vt2, vt3, vt4);
    std::string ch = "";
    if (direction)
    {
        //theo truc Y
        int max = 0;
        //int x = getNumberOfString(vt1, true);
        
        max = getNumberOfString(vt1, true);
        if (max < getNumberOfString(vt2, true))
        {
            max = getNumberOfString(vt2, true);
        }
        if (max < getNumberOfString(vt3, true))
        {
            max = getNumberOfString(vt3, true);
        }
        if (max < getNumberOfString(vt4, true))
        {
            max = getNumberOfString(vt4, true);
        }
        if (max < yChon)
        {
            max = yChon;
        }
        log("max: %i", max);
        
        if (max != 100) {
            std::string tmp = "";
            
            bool changeToHoiCham = false;
            for (int i = max; i > max - 5; i--) {
                
                tmp = std::to_string(arrCauHoi[i][xChon]);
                log("TMP: %s", tmp.c_str());
                if (arrCauHoi[i][xChon] == cauTraLoi && changeToHoiCham == false) {
                    tmp = "?";
                    changeToHoiCham = true;
                }
                if (tmp == "101") {
                    tmp = "+";
                }
                if (tmp == "102") {
                    tmp = "-";
                }
                if (tmp == "103") {
                    tmp = "x";
                }
                if (tmp == "104") {
                    tmp = ":";
                }
                if (tmp == "105") {
                    tmp = "=";
                }
                if (tmp == "106") {
                    tmp = "?";
                }
                ch = ch + tmp;
            }
        }
        
    } else {
        //cau hoi hang ngang - theo truc X
//        if (getNumberOfString(vt1, false) == 100 || getNumberOfString(vt2, false) == 100 || getNumberOfString(vt3, false) == 100 || getNumberOfString(vt4, false) == 100) {
//            
//        } else {
            int min = 0;
            
            min = getNumberOfString(vt1, false);
            if (min > getNumberOfString(vt2, false))
            {
                min = getNumberOfString(vt2, false);
            }
            if (min > getNumberOfString(vt3, false))
            {
                min = getNumberOfString(vt3, false);
            }
            if (min > getNumberOfString(vt4, false))
            {
                min = getNumberOfString(vt4, false);
            }
            if (min > xChon)
            {
                min = xChon;
            }
            log("min: %i", min);
            
            std::string tmp = "";
            
            bool changeToHoiCham = false;
            for (int i = min; i < min + 5; i++) {
                tmp = std::to_string(arrCauHoi[yChon][i]);
                log("TMP: %s", tmp.c_str());
                if (arrCauHoi[yChon][i] == cauTraLoi && changeToHoiCham == false) {
                    tmp = "?";
                    changeToHoiCham = true;
                }
                if (tmp == "101") {
                    tmp = "+";
                }
                if (tmp == "102") {
                    tmp = "-";
                }
                if (tmp == "103") {
                    tmp = "x";
                }
                if (tmp == "104") {
                    tmp = ":";
                }
                if (tmp == "105") {
                    tmp = "=";
                }
                if (tmp == "106") {
                    tmp = "?";
                }
                ch = ch + tmp;
                
            }
        }
    //}
    return ch;
}
void PlayGame1::giamSoMang() {
    if (soMang == 3) {
        statusIcon->loadTextureNormal("status-mid.png");
    }
    if (soMang == 2) {
        statusIcon->loadTextureNormal("status-bad.png");
        
        float scale = statusIcon->getScale();
        float timePlayG = 0.4f;
        // Create a sequence and repeat it forever
        auto tiltSequenceG = Sequence::create(
                  ScaleTo::create(timePlayG, 1 * scale),
                  ScaleTo::create(timePlayG, 0.9 * scale),
                  nullptr);
        auto repeatTiltG = RepeatForever::create(tiltSequenceG);

        // Run the action on the parent button
        statusIcon->runAction(repeatTiltG);
    }
    soMang = soMang - 1;
    
    if (soMang == 0) {
        log("redirect to finish screen");
        DelayTime *pause = DelayTime::create(1);
        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(PlayGame1::moveSceneGameOver, this)), NULL);
        runAction(sqBOver);
    }
}
void PlayGame1::shuffleArray(std::vector<std::vector<int>> arr) {
    // Chuyển mảng 2D thành mảng 1D để dễ dàng random
    int temp[9];
    int idx = 0;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            temp[idx++] = arr[i][j];
        }
    }

    // Trộn mảng 1D
    srand(time(0));  // Khởi tạo seed cho random
    for (int i = 8; i > 0; --i) {
        int j = rand() % (i + 1);
        swap(temp[i], temp[j]);
    }

    // Đưa lại các giá trị vào mảng 2D
    idx = 0;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            arr[i][j] = temp[idx++];
        }
    }
}
void PlayGame1::kiemTraChienThang() {
    log("countThaoTac: %i", countThaoTac);
    soCauTraLoi++;
    if (countThaoTac >= 9) {
        log("redirect to man hinh chien thang");
        score = soDiem();
        int soVang = UserDefault::getInstance()->getIntegerForKey("sovang", 0);
        soVang = soVang + score;
        UserDefault::getInstance()->setIntegerForKey("sovang", soVang);
       
        
        int soVangdaily = UserDefault::getInstance()->getIntegerForKey("daily-sovang", 0);
        soVangdaily = soVangdaily + score;
        UserDefault::getInstance()->setIntegerForKey("daily-sovang", soVangdaily);
        
        if (HuyFunctions().inVietNam() == false) {
            GameCenterBridge::submitScore(soVang, "com.huy.mentalmath.Golds");
            GameCenterBridge::submitScore(soVangdaily, "com.huy.mentalmath.dailygold");
        }
        DelayTime *pause = DelayTime::create(1);
        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(PlayGame1::moveSceneGameOver, this)), NULL);
        runAction(sqBOver);
        
    }
}
void PlayGame1::createBg(float wScene, float hScene) {

}

void PlayGame1::createBgColor(float w, float h) {
    //create bg color
    Sprite* bgColor = Sprite::create("bg-game1.jpg");
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    if (isIpad)
    {
        //ytitle = 1.3 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    //bgColor->setPosition(Vec2(w / 2, ytitle));
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));

    this->addChild(bgColor, 0);
}

void PlayGame1::createEarth(float w, float h) {
    //create bg color
    Sprite* bgColor = Sprite::create("game1-earth.png");
    float ratiobgColor = 2.5;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    if (isIpad)
    {
        //ytitle = 1.3 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    //bgColor->setPosition(Vec2(w / 2, ytitle));
    bgColor->setAnchorPoint(Vec2(0.5, 0.23));
    bgColor->setPosition(Vec2(0, 0));

    this->addChild(bgColor, 1);
}
void PlayGame1::resumeButtonFullWith(float w, float h){
    pauseFullWidth = ui::Button::create("game1-play1.png"); // tao button
    float ratiopauseFullWidth = 1;
//    if (h / w <= 1.53)
//    {
//        ratiopauseFullWidth = 5;
//    }
    float scalepauseFullWidth = w / ratiopauseFullWidth / pauseFullWidth->getContentSize().width;
    pauseFullWidth->setScale(scalepauseFullWidth);
    //pauseFullWidth->setAnchorPoint(Vec2(0, 0));
    pauseFullWidth->setPosition(Vec2(w/2, h/2));
    pauseFullWidth->setVisible(false);
    //pauseFullWidth->setEnabled(true);
    pauseFullWidth->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                resumeClock();
                button->setVisible(false);
                pauseSmallButton->loadTextureNormal("game1pause.png");
                pauseSmallButton->setTag(0);
                for (auto& btn : listButtonCauHoi) {
                   
                    if (btn->getTag() != 106) {
                        if (isIpad) {
                            btn->setTitleFontSize(0.03 * wScenePlay);
                        }else {
                            btn->setTitleFontSize(0.06 * wScenePlay);
                        }
                        
                    }
                    
                  
                }
                
                for (auto& btn : listButtonTraLoi) {
                   
                    if (btn->getTag() != 106) {
                        if (isIpad) {
                            btn->setTitleFontSize(0.035 * wScenePlay);
                        }else {
                            btn->setTitleFontSize(0.07 * wScenePlay);
                        }
                        
                    }
                    
                  
                }
                break;
            default:
                break;
        }
    });
    this->addChild(pauseFullWidth, 100);
}
void PlayGame1::createMainActor(float w, float h){
    auto viTriNhanVat = UserDefault::getInstance()->getIntegerForKey("nhanvatdachon", 0) + 1;
    
    auto imageName = StringUtils::format("home-nv%d.png", viTriNhanVat);
//    if (h / w <= 1.53)
//    {
//        imageName = "bg-home-ipad2.png";
//    }
    auto mainActor = ui::Button::create(imageName); // tao button
    mainActor->setTouchEnabled(false);
    float ratiomainActor = 2.5;
    if (h / w <= 1.53)
    {
        ratiomainActor = 5;
    }
    float scalemainActor = w / ratiomainActor / mainActor->getContentSize().width;
    mainActor->setScale(scalemainActor);

    float ymainActor = 0.15 * h - (mainActor->getContentSize().height / 2 * scalemainActor);
    log("ti le man hinh: %f", h / w);
    
//    if (h / w <= 1.8)
//    {
//        ymainActor = 0.73 * h - (mainActor->getContentSize().height / 2 * scalemainActor);
//    }
    mainActor->setPosition(Vec2(w - mainActor->getContentSize().width * scalemainActor * 0.18, ymainActor));
    mainActor->setEnabled(true);
    
//    auto jump = JumpBy::create(2.4f, Vec2(0, 0), 30, 2);
//    auto scaleUp = ScaleTo::create(0.4f, 1.1f);
//    auto scaleDown = ScaleTo::create(0.4f, 0.9f);
//    auto scaleNormal = ScaleTo::create(0.4f, 1.0f);
//    auto bounceEffect = Sequence::create(scaleUp, scaleDown, scaleNormal, nullptr);
//
//    auto jumpWithEffect = Spawn::create(jump, bounceEffect, nullptr);
//    mainActor->runAction(RepeatForever::create(jumpWithEffect));

//    auto rotateLeft = RotateTo::create(0.1f, -10);
//    auto rotateRight = RotateTo::create(0.1f, 10);
//    auto rotateBack = RotateTo::create(0.1f, 0);
//    auto wagTail = Sequence::create(rotateLeft, rotateRight, rotateBack, nullptr);
//
//    auto repeatWag = RepeatForever::create(wagTail);
//    mainActor->runAction(repeatWag);

    
    this->addChild(mainActor);
}
void PlayGame1::createButtonUndoAndHint(float wScene, float hScene){
    backButton = ui::Button::create("game1back.png", "game1back.png"); // tao button
    float ratiobackButton = 10;
    if (isIpad)
    {
        ratiobackButton = 20;
    }
    
    float scalebackButton = wScene / ratiobackButton / backButton->getContentSize().width;
    backButton->setScale(scalebackButton);
    float ybackButton = hScene * 0.05 + backButton->getContentSize().height / 2 * scalebackButton;
//    if (hScene / wScene <= 1.8)
//    {
//        ybackButton = hScene * 0.05 + backButton->getContentSize().height / 2 * scalebackButton;
//    }
    backButton->setPosition(Vec2(wScene * 0.05 + backButton->getContentSize().width / 2 * scalebackButton, ybackButton));
    if (isIpad)
    {
        ybackButton = hScene * 0.05 + backButton->getContentSize().height / 2 * scalebackButton;
    }
    backButton->setTouchEnabled(false);
    backButton->setEnabled(false);
    backButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                backAction(button, wScene, hScene);
                
                break;
            default:
                break;
        }
    });
    this->addChild(backButton, 3);//add button vao scene

    //btn Hint
    hintButton = ui::Button::create("hint.png", "hint.png"); // tao button
    float ratiohintButton = 7;
    if (isIpad)
    {
        ratiohintButton = 14;

    }
    float scalehintButton = wScene / ratiohintButton / hintButton->getContentSize().width;
    hintButton->setScale(scalehintButton);

    //float xhintButton = wScene / 2 + buttonLearn->getContentSize().height / 2 * scaleButtonLearn + 30;
    hintButton->setPosition(Vec2(backButton->getPositionX(), backButton->getPositionY() + backButton->getContentSize().width * backButton->getScale() + hScene / 30));
    if (isIpad)
    {
        
        hintButton->setPosition(Vec2(backButton->getPositionX(), backButton->getPositionY() + backButton->getContentSize().width * backButton->getScale()  + hScene / 50));
    }
    hintButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                log("Get hint!");
                hintAction(wScene, hScene);
                button->setTouchEnabled(false);
                break;
            default:
                break;
        }
        
        
    });
    this->addChild(hintButton, 3);//add button vao scene
    
    //scoreString = cocos2d::__String::createWithFormat("%i", score);//score
    int hightScore = UserDefault::getInstance()->getIntegerForKey("diamond", 0);
    auto hightScoreString = cocos2d::__String::createWithFormat("%i", hightScore);
    
    hintLabel = Label::createWithTTF(hightScoreString->getCString(), "fonts/ComicNeue-Bold.ttf", 0.04 * wScene);
    if (isIpad)
    {
        hintLabel = Label::createWithTTF(hightScoreString->getCString(), "fonts/ComicNeue-Bold.ttf", 0.02 * wScene);
    }
    hintLabel->setColor(Color3B().WHITE);
    hintLabel->setPosition(Vec2(hintButton->getPositionX() + hintLabel->getContentSize().width / 2 - 2, hintButton->getPositionY() - hintButton->getContentSize().height * scalehintButton / 2 + 8));
    if (isIpad)
    {
        hintLabel->setPosition(Vec2(hintButton->getPositionX() + 2, hintButton->getPositionY() - hintButton->getContentSize().height * scalehintButton / 2 + 4.5));
    }
    
    addChild(hintLabel, 4);
}
void PlayGame1::backAction(cocos2d::ui::Button* buttonClicked, float w, float h) {
    if (countThaoTac <= 0) {
        return;
    }
    
    log("Undo for thao tac thu: %i, x: %f, y:%f, button: %f, x trong mang: %i, y trong mang: %i", countThaoTac, arrBack[countThaoTac - 1][0], arrBack[countThaoTac - 1][1], arrBack[countThaoTac - 1][2],(int)arrBack[countThaoTac][4], (int)arrBack[countThaoTac][3]);
    
    float timeAnimation = 0.4;
    float scale80 = 1.0;// squareSize / squareSizeTL;
    float scale100 = 1.0;
    countThaoTac--;
    
    if (countThaoTac <= 0) {
        backButton->setTouchEnabled(false);
        backButton->setEnabled(false);
    }

    int viTriTrongMangCauHoiX = (int)arrBack[countThaoTac][4];
    int viTriTrongMangCauHoiY = (int)arrBack[countThaoTac][3];
    
    ySelected = viTriTrongMangCauHoiX;
    xSelected = viTriTrongMangCauHoiY;
    
    arrCauHoi[viTriTrongMangCauHoiX][viTriTrongMangCauHoiY] = 106;
    
    for (auto& btn : listButtonCauHoi) {
        if (btn->getName() == cocos2d::__String::createWithFormat("%i,%i", viTriTrongMangCauHoiX, viTriTrongMangCauHoiY)->getCString()) {
           
            btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-empty_noselect%i.png", randomColor)->getCString());
        }
    }
    
    for (auto& btn : listButtonTraLoi) {
        if (btn->getTag() == (int)arrBack[countThaoTac][2]) {
            btn->setTouchEnabled(true);
            btn->loadTextureNormal(cocos2d::__String::createWithFormat("rec-answer%i.png", randomColor)->getCString());
            btn->setName("");
            
            backColorForCells(btn);
            
            btn->runAction(
                Sequence::create(
                      Spawn::create(
                          ScaleTo::create(timeAnimation, scale100),
                               MoveTo::create(timeAnimation, Vec2(arrBack[countThaoTac][0],  arrBack[countThaoTac][1])),
                          nullptr
                      ),
                    DelayTime::create(0.1),
                     Spawn::create(
                         ScaleTo::create(timeAnimation / 3, scale80),
                         nullptr
                     ),
                     CallFunc::create([this, btn, buttonClicked]() {
                         
                         if (countThaoTac <= 0) {
                             buttonClicked->setTouchEnabled(false);
                             buttonClicked->setEnabled(false);
                         }else {
                             buttonClicked->setTouchEnabled(true);
                             buttonClicked->setEnabled(true);
                         }
                     }),
                    nullptr
                )
            );
           
        }
    }
    
    
}
void PlayGame1::hintAction(float w, float h) {
    hintButton->stopAllActions();
    hintLabel->stopAllActions();
    hintLabel->setOpacity(255);
    hintButton->setOpacity(255);
    
    //kiem tra xem con kim cuong hay khong
    int hightScore = UserDefault::getInstance()->getIntegerForKey("diamond", 0);
    if (hightScore > 0) {
        if (sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
        }
        UserDefault::getInstance()->setIntegerForKey("diamond", hightScore - 1);
        auto hightScoreString = cocos2d::__String::createWithFormat("%i", hightScore - 1);
        hintLabel->setString(hightScoreString->getCString());
        
        float timeAnimation = 0.3;
        int soOVuong = 11;
        for (int row = 0; row < soOVuong; ++row)
        {
            for (int col = 0; col < soOVuong; ++col)
            {
                if (arrCauHoi[row][col] == 106) {
                    log("cau goi y la: %i. Voi vi tri la: x=%i, y=%i", arrDapAn[row][col], row, col);
                    //tim vi tri o trong va show animation an hien
                    for (auto& btn : listButtonCauHoi) {
                        if (btn->getName() == cocos2d::__String::createWithFormat("%i,%i", row, col)->getCString()) {
                            btn->runAction(
                                (RepeatForever::create(
                                   Sequence::create(
                                        ScaleTo::create(timeAnimation, 1.1 * btn->getScale()),
                                        ScaleTo::create(timeAnimation, btn->getScale() * 0.9),
                                        nullptr)
                                   ))
                           );
                        }
                    }
                    
                    //tim vi tri dap an tren man hinh va show animation an hien
                    for (auto& btn : listButtonTraLoi) {
                        if (std::stoi(btn->getTitleText()) == arrDapAn[row][col] and btn->getName() != "da-goi-y") {
                            btn->setName("da-goi-y");
                            btn->runAction(
                                (RepeatForever::create(
                                   Sequence::create(
                                        ScaleTo::create(timeAnimation, 1.1 * btn->getScale()),
                                        ScaleTo::create(timeAnimation, btn->getScale() * 0.9),
                                        nullptr)
                                   ))
                           );
                            break;
                            
                        }
                    }
                    return;
                }
            }
        }
    } else {
        //redirect man hinh mua them kim cuong
        //Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftDiamond::createScene(), Color3B().WHITE));
        if (sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buzz.mp3");
        }
    }
}
void PlayGame1::createPopupFinish(float w, float h) {
    //int bgIndex = cocos2d::RandomHelper::random_int(1, 4);
    //popupthanhCong = ui::Button::create(StringUtils::format("popup-thanh-cong-%d.png", bgIndex)); // tao button
    auto imgNameThemDiem = Variable().diemNgauNhienImg.at(indexThemDiem);
    popupthanhCong = ui::Button::create(imgNameThemDiem.c_str());
    popupthanhCong->setTouchEnabled(false);
    float ratiopopupthanhCong = 3;
    if (isIpad)
    {
        ratiopopupthanhCong = 7;
    }
    float scalepopupthanhCong = w / ratiopopupthanhCong / popupthanhCong->getContentSize().width;

    //log("ti le test: %f", scalepopupthanhCong);
    //log("ti le test theo w: %f", w / ratiopopupthanhCong / popupthanhCong->getContentSize().width);
    popupthanhCong->setScale(scalepopupthanhCong);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }

    //popupthanhCong->setPosition(Vec2(w / 2, ytitle));
    //popupthanhCong->setAnchorPoint(Vec2(0, 0));
    Vec2 positionPopupThanhCong = Vec2(w/2, h * 0.75);
    if (isIpad)
    {
        positionPopupThanhCong = Vec2(w * 3 / 4, h * 0.85);
    }
    popupthanhCong->setPosition(positionPopupThanhCong);

    popupthanhCong->setEnabled(true);
    this->addChild(popupthanhCong, 12);
    popupthanhCong->setOpacity(0);
    popupthanhCong->setScale(0.6);
    
    popupthatBai = ui::Button::create("popup-that-bai-1.png"); // tao button
    popupthatBai->setTouchEnabled(false);
   

    
    popupthatBai->setScale(scalepopupthanhCong);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    if (isIpad)
    {
        //ytitle = 1.3 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    //popupthanhCong->setPosition(Vec2(w / 2, ytitle));
    //popupthanhCong->setAnchorPoint(Vec2(0, 0));
    popupthatBai->setPosition(Vec2(w/2, h * 0.65));

    popupthatBai->setEnabled(true);
    this->addChild(popupthatBai, 12);
    popupthatBai->setOpacity(0);
    popupthatBai->setScale(0.6);
}
void PlayGame1::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathLevel::createScene(typeOfWGame1), Color3B().WHITE));
}

void PlayGame1::moveSceneGameOver()
{
    //kiem tra xem co show man hinh mua hang khong
    if (Variable().isProVer == false && score >= Variable().soDiemShowPro &&  UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) >= Variable().showProSauBaoNhieuLan) {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", 0);
        createBgPro(wScenePlay, hScenePlay);
    } else {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) + 1);
        finish();
    }
}
void PlayGame1::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (isIpad)
    {
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    if (Variable().isProduction == true) {
                        HuyFunctions().showAds();
                    }
                    if (fromChallengeG1) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(typeOfWGame1, levelOfWGame1), Color3B().WHITE));
                    } else {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(5, backTypePTGame1), Color3B().WHITE));
                    }
                    
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 2);//add button vao scene
    
    
    
}
void PlayGame1::status(float w, float h){
    statusIcon = ui::Button::create("status-good.png", "status-good.png"); // tao button
    float ratio = 5;
    if (isIpad)
    {
        ratio = 10;
    }
    auto statusIconHeight = statusIcon->getContentSize().height;
    auto statusIconWidth = statusIcon->getContentSize().width;

    float scale = w / ratio / statusIconWidth;
    statusIcon->setScale(scale);
    statusIcon->setPosition(Vec2((statusIconWidth / 2 * scale + 13), h - 30 - (statusIconHeight / 2 * scale + 13)));
    statusIcon->setTouchEnabled(false);
    addChild(statusIcon, 2);//add button vao scene
}

void PlayGame1::pauseButton(float w, float h){
    pauseSmallButton = ui::Button::create("game1pause.png", "game1pause.png"); // tao button
    float ratio = 4;
    if (isIpad)
    {
        ratio = 8;
    }
    auto pauseSmallButtonHeight = pauseSmallButton->getContentSize().height;
    auto pauseSmallButtonWidth = pauseSmallButton->getContentSize().width;

    float scale = w / ratio / pauseSmallButtonWidth;
    pauseSmallButton->setScale(scale);
    pauseSmallButton->setPosition(Vec2(w - (pauseSmallButtonWidth / 2 * scale + 13), h - 30 - (pauseSmallButtonHeight / 2 * scale + 13)));
    pauseSmallButton->setTag(0); //0 - playing : 1 - Pause
    //pauseSmallButton->setTouchEnabled(false);
    pauseSmallButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                log("click pause");
                if (button->getTag() == 0) {
                    //pause
                    button->setTag(1);
                    button->loadTextureNormal("game1resume.png");
                    pauseClock();
                    pauseFullWidth->setVisible(true);
                    for (auto& btn : listButtonCauHoi) {
                       
                        if (btn->getTag() != 106) {
                            btn->setTitleFontSize(0);
                        }
                    }
                    for (auto& btn : listButtonTraLoi) {
                        btn->setTitleFontSize(0);
                    }
                }else {
                    button->setTag(0);
                    button->loadTextureNormal("game1pause.png");
                    resumeClock();
                    pauseFullWidth->setVisible(false);
                    
                }
                
                if (Variable().isProduction == true) {
                    HuyFunctions().showAds();
                }
                
                break;
            default:
                break;
        }
    });
    addChild(pauseSmallButton, 2);//add button vao scene
    
    
    //scoreString = cocos2d::__String::createWithFormat("%i", score);//score
    lblScore = Label::createWithTTF("00:00", "fonts/ComicNeue-Bold.ttf", 0.05 * w);
    if (isIpad)
    {
        lblScore = Label::createWithTTF("00:00", "fonts/ComicNeue-Bold.ttf", 0.025 * w);
    }
    lblScore->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    
    lblScore->setPosition(Vec2(pauseSmallButton->getPositionX() - 10, pauseSmallButton->getPositionY() + 3));
    if (isIpad)
    {
        lblScore->setPosition(Vec2(pauseSmallButton->getPositionX() - 5, pauseSmallButton->getPositionY() + 1));
    }
    // add the label as a child to this layer
    addChild(lblScore, 3);
    resumeClock();
}
// Dừng cập nhật đồng hồ
void PlayGame1::pauseClock()
{
    this->unschedule("clock_update_key");  // Dừng lịch trình cập nhật
}

// Tiếp tục cập nhật đồng hồ
void PlayGame1::resumeClock()
{
    this->schedule([this](float dt) {
        updateClock(dt);
    }, 1.0f, "clock_update_key");  // Khởi tạo lại lịch trình
}
void PlayGame1::updateClock(float dt)
    {
        timeInSeconds++;  // Tăng thời gian mỗi giây
        timeInSecondsFor1PhepTinh++;

        // Chuyển đổi timeInSeconds thành phút và giây
        int minutes = timeInSeconds / 60;
        int seconds = timeInSeconds % 60;

        // Định dạng lại thành "MM:SS"
        std::string timeString = StringUtils::format("%02d:%02d", minutes, seconds);

        // Cập nhật label với thời gian mới
        lblScore->setString(timeString);
        if (timeInSecondsFor1PhepTinh == 5) {
//            auto scaleHint = hintButton->getScale();
//            auto scaleHintLabel = hintLabel->getScale();
            hintButton->runAction(
                RepeatForever::create(
                    Sequence::create(
                         
//                         ScaleTo::create(0.2, 1.05 * scaleHint),
//                         ScaleTo::create(0.2, scaleHint / 1.05),
                         DelayTime::create(0.2),
                         FadeTo::create(0.3, 80),
                         FadeIn::create(0.1),
                         nullptr)
                )
            );
            hintLabel->runAction(
                RepeatForever::create(
                    Sequence::create(
                         DelayTime::create(0.2),
                         FadeTo::create(0.3, 80),
                         FadeIn::create(0.1),
                         nullptr)
                )
            );
        }
    }
void PlayGame1::createBgPro(float wScene, float hScene) {
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    LanguageManager::getInstanceRestart();
    
    auto bgTexture = Director::getInstance()->getTextureCache()->addImage("bg-nen-tet.png");

    // Set texture parameters to repeat
    Texture2D::TexParams texParams = { GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_REPEAT };
    bgTexture->setTexParameters(texParams);

    // Create a sprite with repeated texture
    auto bgNenPro = Sprite::createWithTexture(bgTexture, Rect(0, 0, wScene, hScene));
    bgNenPro->setAnchorPoint(Vec2(0, 0)); // Align to bottom-left
    bgNenPro->setOpacity(245);
    //bgNenPro->setOpacity(0);
    this->addChild(bgNenPro, 100);
    
    //close
    auto btn = ui::Button::create("close-btn.png"); // tao button
    float ratio = 10;
    if (hScene/wScene <= 1.53)
    {
        ratio = 17;
    }
    //CCLOG("Debug: 2");
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                finish();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 101);//add button vao scene
    
    float fontSize = 0.1 * wScene;
    float fontSizePrice = 0.135 * wScene;
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
        fontSize = 0.07 * wScene;
    }
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.05 * wScene;
        fontSizePrice = 0.06 * wScene;
        if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
        {
           
            fontSize = 0.035 * wScene;
        }
    }
    //create title pro version
    std::string titleValue = LanguageManager::getInstance()->getStringForKey("TITLE_PRO").c_str();
    auto titlePro = Label::createWithTTF(titleValue, fontStyle, fontSize);
    titlePro->setColor(Color3B().WHITE);
    // position the label on the center of the
    auto btnHeightKey = titlePro->getContentSize().height;
    double ytitlePro = hScene * 0.9 - (btnHeightKey / 2 + 5);
    double xtitlePro = wScene / 2;// - (btnWidthKey / 2 + 5);
    titlePro->setPosition(Vec2(xtitlePro, ytitlePro));
    // add the label as a child to this layer
    addChild(titlePro, 101);
    
    auto bgVIP = Sprite::create("tv-ads.png");
    float ratiobgVIP = 2.4;

    float fixHeightIpad = 20;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        fixHeightIpad = 5;
    }
    
    if (hScene / wScene <= 1.53)
    {
        ratiobgVIP = 4.4;
    }
    
    float scalebgVIP = wScene / ratiobgVIP / bgVIP->getContentSize().width;
    bgVIP->setScale(scalebgVIP);
    bgVIP->setPosition(Vec2(wScene / 2, titlePro->getPositionY() - titlePro->getContentSize().height - 20 - bgVIP->getContentSize().height * scalebgVIP / 2)); // Đặt vị trí
    this->addChild(bgVIP, 101);
    
    
    //create desc pro version
    std::string descValue = LanguageManager::getInstance()->getStringForKey("REMOVE_ADS").c_str();
    auto descPro = Label::createWithTTF(descValue, fontStyle , fontSize * 0.8);
    descPro->setColor(Color3B().WHITE);
    // position the label on the center of the
    double ydescPro = bgVIP->getPositionY() - descPro->getContentSize().height /2 - 20 - bgVIP->getContentSize().height * scalebgVIP / 2;
    double xdescPro = wScene / 2;// - (btnWidthKey / 2 + 5);
    descPro->setPosition(Vec2(xdescPro, ydescPro));
    // add the label as a child to this layer
    addChild(descPro, 101);
    
    //create PRICE
    std::string priceValue = UserDefault::getInstance()->getStringForKey("gia", "");
    auto price = Label::createWithTTF(priceValue, "fonts/NunitoSans-Bold.ttf", fontSizePrice);
    price->setColor(Color3B(255, 195, 77));
    // position the label on the center of the
    double yprice = descPro->getPositionY() - descPro->getContentSize().height /2 - fixHeightIpad - price->getContentSize().height / 2;
    double xprice = wScene / 2;// - (btnWidthKey / 2 + 5);
    price->setPosition(Vec2(xprice, yprice));
    // add the label as a child to this layer
    addChild(price, 101);
    
    //create Underline
    auto underlineImg = Sprite::create("underline-pro.png");
    float ratiounderlineImg = 2;
    //float fixHeightNotiIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        ratiounderlineImg = 4;
        //fixHeightNotiIpad = 0.5;
    }
    
    float scaleunderlineImg = wScene / ratiounderlineImg / underlineImg->getContentSize().width;
    underlineImg->setScale(scaleunderlineImg);
    underlineImg->setPosition(Vec2(wScene / 2, price->getPositionY() - price->getContentSize().height / 2 - underlineImg->getContentSize().height * scaleunderlineImg * 0.15)); // Đặt vị trí
    this->addChild(underlineImg, 101);
    
    
    
    fontSize = 0.05 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.02 * wScene;
    }
    auto restorePurchaseBtn = ui::Button::create("empty.png");
    restorePurchaseBtn->setPressedActionEnabled(true);
    restorePurchaseBtn->setZoomScale(-0.1f);
    restorePurchaseBtn->setScale9Enabled(true);
    restorePurchaseBtn->setTitleText("Restore Purchase");
    if(appLang == "en" || appLang == "vi"){
        restorePurchaseBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    restorePurchaseBtn->setTitleColor(Color3B().WHITE);
    restorePurchaseBtn->setOpacity(200);
    restorePurchaseBtn->setTouchEnabled(true);
    float ratiotitle = 3;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 6;
        
    }
    auto scalerestoreBtn = wScene / ratiotitle / restorePurchaseBtn->getContentSize().width;
    restorePurchaseBtn->setScale(scalerestoreBtn);
    restorePurchaseBtn->setTitleFontSize(fontSize / scalerestoreBtn);
    if (appLang == "ja")
    {
        restorePurchaseBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        restorePurchaseBtn->setTitleFontSize(0.045 * wScene / scalerestoreBtn);
    }
    float ytitle = 40;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        
        ytitle = 20;
    }
    if (hScene / wScene <= 1.53)
    {
        
        if (appLang == "ja")
        {
            
            restorePurchaseBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
        }
    }
    restorePurchaseBtn->setPosition(Vec2(wScene / 2, ytitle));
    restorePurchaseBtn->setEnabled(true);
    restorePurchaseBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("restore purchasing");
                IAPManager::getInstance()->restorePurchases();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(restorePurchaseBtn, 101);
    
    float fontSize2 = 0.07 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize2 = 0.035 * wScene;
    }
    auto upProBtn = ui::Button::create("button-pro.png");
    upProBtn->setPressedActionEnabled(true);
    upProBtn->setZoomScale(-0.1f);
    upProBtn->setScale9Enabled(true);
    upProBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("PRO_BUY").c_str());
    if(appLang == "en" || appLang == "vi"){
        upProBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    upProBtn->setTitleColor(Color3B().WHITE);
    upProBtn->setTouchEnabled(true);
    ratiotitle = 1.5;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 3.4;
       
    }
    auto scaleUpProBtn = wScene / ratiotitle / upProBtn->getContentSize().width;
    upProBtn->setScale(scaleUpProBtn);
    upProBtn->setTitleFontSize(fontSize2 / scaleUpProBtn);
    if (appLang == "ja")
    {
        upProBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        upProBtn->setTitleFontSize(0.05 * wScene / scaleUpProBtn);
    }
    ytitle = ytitle + restorePurchaseBtn->getContentSize().height * scalerestoreBtn / 2 + upProBtn->getContentSize().height * scaleUpProBtn / 2 + 7;
    if (hScene / wScene <= 1.53)
    {
      
        if (appLang == "ja")
        {
            upProBtn->setTitleFontSize(0.025 * wScene / scaleUpProBtn);
        }
    }
    upProBtn->setPosition(Vec2(wScene / 2, ytitle));
    upProBtn->setEnabled(true);
    upProBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("up to pro");
                IAPManager::getInstance()->purchase(Variable().proProductionID);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(upProBtn, 101);
    
}

void PlayGame1::onEnter() {
    Layer::onEnter();

    // Đăng ký callback khi mua thành công
    IAPManager::getInstance()->setOnPurchaseSuccess([this](std::string productID) {
        log("🎉 Mua thành công - restore thanh cong: %s", productID.c_str());
        UserDefault::getInstance()->setBoolForKey("isProVer", true);
        //Variable().isProVer = true;
        UserDefault::getInstance()->flush();
        this->finish();
    });

    // Đăng ký callback khi mua thất bại
    IAPManager::getInstance()->setOnPurchaseFailed([this](std::string productID, std::string error) {
        log("❌ Mua thất bại: %s | Lỗi: %s", productID.c_str(), error.c_str());
        //this->finish();
        
        
    });
    
    // Đăng ký callback lấy giá
    IAPManager::getInstance()->setOnPriceRetrieved([this](std::string productID, std::string price) {
        log("📦 Giá của %s là: %s", productID.c_str(), price.c_str());
        // Gợi ý: update label nút mua
        //this->price->setString(price.c_str());
        UserDefault::getInstance()->setStringForKey("gia", price.c_str());
    });

    // Yêu cầu lấy giá từ App Store
    IAPManager::getInstance()->requestProductInfo(Variable().proProductionID);
}
void PlayGame1::finish() {
    if (Variable().isProduction == true) {
        HuyFunctions().showAds();
    }
    HuyFunctions().saveSoGame("g6");
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score, typeOfWGame1, levelOfWGame1, 5, fromChallengeG1), Color3B().WHITE));
}
