#ifndef __PARENT_SCREEN_H__
#define __PARENT_SCREEN_H__
#include "ui/CocosGUI.h"
#include "cocos2d.h"
#include <iostream>
#include <sstream>
class ParentScreen : public cocos2d::Layer
{
public:
    static cocos2d::Scene* createScene();
    virtual bool init();
    void createBg(float w, float h);
    void createTemplate(float w, float h);
    void createTwoButtonPlay(float w, float h);
    double createStar(float w, float h, float fixHeight, int position, cocos2d::ui::ScrollView *parent);
    double createLabel(std::string content, std::string fontName, float fontSize, float w, float h, float fixHeight, std::string position, cocos2d::Color3B myColor,int thuTu, cocos2d::ui::ScrollView *parent);
    double createDiemTungPhepTinh(std::string content, std::string type, float w, float h, float fixHeight,int thuTu, cocos2d::ui::ScrollView *parent);
    double createTongPhepTinh(std::string content, std::string type, float w, float h, float fixHeight,int thuTu, cocos2d::ui::ScrollView *parent);
    double createPhepTinhGanNhat(float w, float h, float fixHeight, std::string data, int thuTu, cocos2d::ui::ScrollView *parent);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
   
    CREATE_FUNC(ParentScreen);
};

#endif // __PARENT_SCREEN_H__
