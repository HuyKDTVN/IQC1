#include "FinishDual.h"
#include "playDual.h"
#include "buy.hpp"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <string>
#include <SimpleAudioEngine.h>
#include "HelloWorldScene.h"
#include "ParentScreen.h"
#include "giftDiamond.hpp"
#include "Huy_functions/HuyFunctions.hpp"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    #include "AdmobHelper.h"
#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    #include "NDKHelper.h"
#endif

using std::string;

USING_NS_CC;

int d_currentScore;
int d_currentScore2;
int d_cType;
int d_cLevel;
ui::Button* buttonNext;

cocos2d::__String *d_labelScore;
cocos2d::__String *d_labelHightScore;

ui::Button* d_titleGameOver;
ui::Button* d_titleGameOverDup;

Label* d_valueKey4;
float d_yValueKey4;
float d_xValueKey4;
float d_ratioManhinh;
int d_soundMathfinish;
float d_margin;
Scene* FinishDual::createScene(int score, int score2, int type, int level)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    d_currentScore = score;
    d_currentScore2 = score2;
    d_cType = type;
    d_cLevel = level;
    // 'layer' is an autorelease object
    auto layer = FinishDual::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool FinishDual::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    d_ratioManhinh = hScene / wScene;
    
    d_soundMathfinish = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
    //set bg
    createBg(wScene, hScene);
    //createButtonKey(wScene, hScene);
    


    //back
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    
    float ratio = 10;
    if(hScene / wScene <= 1.53) {
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(d_cType, d_cLevel), Color3B().WHITE));
                });

                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 3);//add button vao scene

    createScore(wScene, hScene);
    createButtonNextAndAddKey(wScene, hScene);
    
    if (UserDefault::getInstance()->getIntegerForKey("height-score", 0) < d_currentScore)
    {
        UserDefault::getInstance()->setIntegerForKey("height-score", d_currentScore);
        UserDefault::getInstance()->flush();
    }

    CCLOG("dien hien tai cua ban la: %i", d_currentScore);
    //this->setKeypadEnabled(true);
    
    //show popup rate app
    
    return true;
}
void FinishDual::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-app.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
}
void FinishDual::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel), Color3B().WHITE));
}

void FinishDual::createScore(float w, float h){
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    float fontSize = 0.085 * w;
    float fixIpad = 1;
    if (d_ratioManhinh <= 1.8)
    {
        fixIpad = 0.7;
    }
    if (d_ratioManhinh <= 1.53)
    {
        fontSize = 0.043 * w;
    }
    auto fontName = "fonts/comfortaa.ttf";
    if (appLang == "ja")
    {
        fontName = "fonts/KosugiMaru.ttf";
    }
    
    d_titleGameOver = ui::Button::create("empty.png");
    if (d_currentScore > d_currentScore2)
    {
        d_titleGameOver->setTitleText(LanguageManager::getInstance()->getStringForKey("YOUWIN").c_str());
    }else{
        d_titleGameOver->setTitleText(LanguageManager::getInstance()->getStringForKey("YOUFAIL").c_str());
    }
    if(appLang == "en" || appLang == "vi"){
        d_titleGameOver->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    
    d_titleGameOver->setTitleColor(Color3B().WHITE);
    d_titleGameOver->setTouchEnabled(false);
    float ratiotitleGameOver = 1.3;
    float scaletitleGameOver = w / ratiotitleGameOver / d_titleGameOver->getContentSize().width;
    d_titleGameOver->setScale(scaletitleGameOver);
    d_titleGameOver->setTitleFontSize(fontSize / scaletitleGameOver);
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {

        d_titleGameOver->setTitleFontName("fonts/KosugiMaru.ttf");
        d_titleGameOver->setTitleFontSize(0.1 * w / scaletitleGameOver);
    }
    
    d_titleGameOver->setAnchorPoint(Vec2({0.5, 1}));
    d_titleGameOver->setPosition(Vec2(w / 2, h * 0.42));
    d_titleGameOver->setEnabled(true);
    addChild(d_titleGameOver, 11);
    
    d_labelHightScore = cocos2d::__String::createWithFormat("%i", d_currentScore);
    auto score = HuyFunctions().creategGroupInfor(w, h, h/6 * fixIpad, "gold.png", "", "Score", d_labelHightScore->getCString());
    addChild(score);
    d_margin = score->getPositionX() - score->getContentSize().width / 2 * score->getScale();


    
    if (d_ratioManhinh <= 1.53)
    {
        d_titleGameOver->setPosition(Vec2(w / 2, h * 0.46));
        
    }
   

//    if (d_ratioManhinh <= 1.8)
//    {
//
//    }
//    if (d_ratioManhinh <= 1.65)
//    {
//        
//    }
    
    //create template Player 2
    d_titleGameOverDup = ui::Button::create("empty.png");
    if (d_currentScore < d_currentScore2)
    {
        d_titleGameOverDup->setTitleText(LanguageManager::getInstance()->getStringForKey("YOUWIN").c_str());
    }else{
        d_titleGameOverDup->setTitleText(LanguageManager::getInstance()->getStringForKey("YOUFAIL").c_str());
    }
    if(appLang == "en" || appLang == "vi"){
        d_titleGameOverDup->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    
    d_titleGameOverDup->setTitleColor(Color3B().WHITE);
    d_titleGameOverDup->setTouchEnabled(false);
    d_titleGameOverDup->setScale(scaletitleGameOver);
    d_titleGameOverDup->setTitleFontSize(fontSize / scaletitleGameOver);
    if (appLang == "ja")
    {
        d_titleGameOverDup->setTitleFontName("fonts/KosugiMaru.ttf");
        d_titleGameOverDup->setTitleFontSize(0.1 * w / scaletitleGameOver);
    }
    float ytitleGameOverDup = h * 0.68;
    if (d_ratioManhinh <= 1.8)
    {
        ytitleGameOverDup = h * 0.7;

    }
    if (d_ratioManhinh <= 1.53)
    {
        ytitleGameOverDup = h * 0.68;

    }

    
    d_titleGameOverDup->setAnchorPoint(Vec2({0.5, 0}));
    d_titleGameOverDup->setPosition(Vec2(w / 2, ytitleGameOverDup));
    d_titleGameOverDup->setEnabled(true);
    d_titleGameOverDup->runAction(RotateTo::create(0, 180.0f));
    addChild(d_titleGameOverDup, 11);
    
    d_labelHightScore = cocos2d::__String::createWithFormat("%i", d_currentScore2);
    auto scoreDup = HuyFunctions().creategGroupInfor(w, h, h - h/6 * fixIpad, "gold.png", "", "Score", d_labelHightScore->getCString());
    addChild(scoreDup);
    scoreDup->runAction(RotateTo::create(0, 180.0f));
    
    
    auto rateTimeDup = UserDefault::getInstance()->getIntegerForKey("ratetime", 0);
    
    if(d_currentScore > 2 && cocos2d::RandomHelper::random_int(1, 1 + (rateTimeDup * 6)) == 1){
        //show popup rate app
        #if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
            sendMessageWithParams("showPopUpReview", cocos2d::Value());
        #endif
        #if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
                AdmobHelper::showRating();
        #endif
        if(rateTimeDup < 5) {
            UserDefault::getInstance()->setIntegerForKey("ratetime", rateTimeDup + 1);
        }
    }
}
void FinishDual::createButtonNextAndAddKey(float w, float h){
    float fontSize = 0.05 * w;
    auto imageName = "bg-dual-finish2.png";
    if (h / w <= 1.53)
    {
        fontSize = 0.025 * w;
        imageName = "bg-finish-dual-ipad2.png";
    }
    //create bg color
    auto bgColor = ui::Button::create(imageName); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    bgColor->setScale(scalebgColor);
    bgColor->setPosition(Vec2(w / 2, h * 0.48));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    
    
    buttonNext = ui::Button::create("button-retry.png", "button-retry.png"); // tao button
    buttonNext->setTouchEnabled(true);
    float ratiobuttonNext = 4.5;
    if (h / w <= 1.53)
    {
        ratiobuttonNext = 9;
        
    }
    float scalebuttonNext = w / ratiobuttonNext / buttonNext->getContentSize().width;
    buttonNext->setScale(scalebuttonNext);
    buttonNext->setTitleFontSize(fontSize / scalebuttonNext);
    float ybuttonNext = h / 2 ;//50 + buttonNext->getContentSize().height / 2 * scalebuttonNext;
    buttonNext->setAnchorPoint(Vec2({0, 0.5}));
    buttonNext->setPosition(Vec2(d_margin, ybuttonNext));
    buttonNext->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (d_soundMathfinish == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(d_cType, d_cLevel), Color3B().WHITE));
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonNext);//add button vao
    
    auto buttonHome = ui::Button::create("button-home.png", "button-home.png"); // tao button
    buttonHome->setTouchEnabled(true);
   
    buttonHome->setScale(scalebuttonNext);
    
    buttonHome->setAnchorPoint(Vec2({0, 0.5}));
    buttonHome->setPosition(Vec2(w / 2 - buttonHome->getContentSize().width * scalebuttonNext / 2, ybuttonNext));
    buttonHome->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (d_soundMathfinish == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonHome);//add button vao
    
    auto buttonAddKey = ui::Button::create("icon-gift.png"); // tao button
//  buttonAddKey->setPressedActionEnabled(true);
//  buttonAddKey->setZoomScale(-0.1f);
//  buttonAddKey->setScale9Enabled(true);
    //buttonAddKey->setTitleText(LanguageManager::getInstance()->getStringForKey("ADDKEY").c_str());
    //buttonAddKey->setTitleFontName("fonts/comfortaa.ttf");
    buttonAddKey->setTitleFontSize(fontSize / scalebuttonNext);
    buttonAddKey->setTitleColor(Color3B().BLACK);
    buttonAddKey->setTouchEnabled(true);
    float ratiobuttonAddKey = 4.5;
    if (h / w <= 1.53)
    {
        ratiobuttonAddKey = 9;
        
        
    }
    float scalebuttonAddKey = w / ratiobuttonAddKey / buttonAddKey->getContentSize().width;
    buttonAddKey->setScale(scalebuttonAddKey);
    //float ybuttonAddKey = 50 + buttonAddKey->getContentSize().height / 2 * scalebuttonAddKey;

    buttonAddKey->setPosition(Vec2(w - d_margin, ybuttonNext));
    buttonAddKey->setAnchorPoint(Vec2({1, 0.5}));
    buttonAddKey->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (d_soundMathfinish == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                if (HuyFunctions().inVietNam()) {
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftDiamond::createScene(), Color3B().WHITE));
                    });
                }else {
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Buy::createScene(2), Color3B().WHITE));
                    });
                }
                
                //animation +3
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAddKey, 10);//add button vao scene

    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        buttonNext->setTitleFontName("fonts/KosugiMaru.ttf");
        buttonNext->setTitleFontSize(0.06 * w / scalebuttonAddKey);

        buttonAddKey->setTitleFontName("fonts/KosugiMaru.ttf");
        buttonAddKey->setTitleFontSize(0.06 * w / scalebuttonAddKey);
    }
}
void FinishDual::createValueKey(float w, float h){
    //valueKey
    
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    d_valueKey4 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * w);
    d_valueKey4->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = d_valueKey4->getContentSize().height;
    auto btnWidthKey = d_valueKey4->getContentSize().width;
    d_yValueKey4 = h - (btnHeightKey / 2 + 5);
    d_xValueKey4 = w - (btnWidthKey / 2 + 5);
    d_valueKey4->setPosition(Vec2(d_xValueKey4, d_yValueKey4));
    // add the label as a child to this layer
    addChild(d_valueKey4);
}
void FinishDual::createButtonKey(float w, float h){
    createValueKey(w, h);
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    auto btnWidth = btn->getContentSize().width;
    float scale = w / ratio / btnWidth;
    float xBtn = d_xValueKey4 - 7 - d_valueKey4->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, d_yValueKey4));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                //UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY") + 1);
                //restart valueKey Label
                //removeChild(valueKey4);
                createValueKey(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
