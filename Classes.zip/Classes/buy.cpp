//
//  buy.cpp
//  mentalmath-mobile
//
//  Created by Huy Le on 9/6/24.
//

#include "buy.hpp"
#include "HelloWorldScene.h"
#include "mathSelect.h"
#include "gift.h"
#include "giftHeart.hpp"
#include "giftDiamond.hpp"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "language.h"
#include <SimpleAudioEngine.h>
#include <ctime>
#include <iostream>
#include <string>
#include "Variable.hpp"
#include <SimpleAudioEngine.h>
#include "Huy_functions/HuyFunctions.hpp"
#include "GameCenterBridge.h"

USING_NS_CC;

float wSceneBuy;
float hSceneBuy;
float ratioScreenBuy;
int typeBuy;
Scene* Buy::createScene(int type)
{
    
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    typeBuy = type;
    // 'layer' is an autorelease object
    auto layer = Buy::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
    
}


// on "init" you need to initialize your instance
bool Buy::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }
    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();

    //khoi tao gia tri ban dau
    wSceneBuy = visibleSize.width;
    hSceneBuy = visibleSize.height;
    
    tongDiem = HuyFunctions().getSoVang();
    diemDiamond = UserDefault::getInstance()->getIntegerForKey("diamond", 0);
    diemHeart = UserDefault::getInstance()->getIntegerForKey("songay", 0);
    soundHello = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
    ratioScreenBuy = hSceneBuy / wSceneBuy;
    //set bg
    
    createBg();
    createInforDiemSo();
    createButtonBack();
    //log("nhan-vat-da-chon %d", (UserDefault::getInstance()->getIntegerForKey("nhanvatdachon", 0) + 1));
    viTriPhiThuyen = UserDefault::getInstance()->getIntegerForKey("phithuyendachon", 0) + 1;
    viTriNhanVat = UserDefault::getInstance()->getIntegerForKey("nhanvatdachon", 0) + 1;
    viTriTenLua = UserDefault::getInstance()->getIntegerForKey("tenluadachon", 0) + 1;
    
    if (viTriPhiThuyen < 1) {
        viTriPhiThuyen = 1;
    }
    if (viTriTenLua < 1) {
        viTriTenLua = 1;
    }
    if (viTriNhanVat < 1) {
        viTriNhanVat = 1;
    }
    switch (typeBuy) {
        case 1:
            createPhiThuyen(wSceneBuy, hSceneBuy, viTriPhiThuyen);
            createCard(viTriPhiThuyen);
            break;
        case 2:
            createNhanVat(wSceneBuy, hSceneBuy, viTriNhanVat);
            createCard(viTriNhanVat);
            break;
        case 3:
            createTenLua(wSceneBuy, hSceneBuy, viTriTenLua);
            createCard(viTriTenLua);
            break;
        default:
            createPhiThuyen(wSceneBuy, hSceneBuy, viTriPhiThuyen);
            createCard(viTriPhiThuyen);
            break;
    }
    createButton();
    
    //log("load type %i", typeBuy);
    
    return true;
}
void Buy::createCard(int viTriActive) {
    auto cardName = "icon-phi-thuyen-";
    auto markName1 = "";
    auto markName2 = "";
    auto markName3 = "";
    auto markName4 = "";
    std::string cardSelect = "1+N+N+N";
    std::vector<std::string> arrSelected = HuyFunctions().splitString(cardSelect, '+');
    int mucDiem = 0;
    
    switch (typeBuy) {
        case 1:
            mucDiem = Variable().arrPhiThuyen.at(0);
            if (mucDiem > tongDiem) {
                markName1 = "card-lock.png";
            }
            mucDiem = Variable().arrPhiThuyen.at(1);
            if (mucDiem > tongDiem) {
                markName2 = "card-lock.png";
            }
            mucDiem = Variable().arrPhiThuyen.at(2);
            if (mucDiem > tongDiem) {
                markName3 = "card-lock.png";
            }
            mucDiem = Variable().arrPhiThuyen.at(3);
            if (mucDiem > tongDiem) {
                markName4 = "card-lock.png";
            }
            
            cardSelect = UserDefault::getInstance()->getStringForKey("phithuyenselect", "1+N+N+N");
            
            arrSelected = HuyFunctions().splitString(cardSelect, '+');
            log("arrSelected %s", cardSelect.c_str());
            if( arrSelected[0].compare("N") == 0) {
                markName1 = "card-can-buy.png";
            } else if (arrSelected[0].compare("1") == 0) {
                markName1 = "";
            }
            if( arrSelected[1].compare("N") == 0) {
                markName2 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName2 = "";
            }
            if( arrSelected[2].compare("N") == 0) {
                markName3 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName3 = "";
            }
            if( arrSelected[3].compare("N") == 0) {
                markName4 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName4 = "";
            }
                
            
            cardName = "icon-phi-thuyen-";
            break;
        case 2:
            mucDiem = Variable().arrNhanVat.at(0);
            if (mucDiem > tongDiem) {
                markName1 = "card-lock.png";
            }
            mucDiem = Variable().arrNhanVat.at(1);
            if (mucDiem > tongDiem) {
                markName2 = "card-lock.png";
            }
            mucDiem = Variable().arrNhanVat.at(2);
            if (mucDiem > tongDiem) {
                markName3 = "card-lock.png";
            }
            mucDiem = Variable().arrNhanVat.at(3);
            if (mucDiem > tongDiem) {
                markName4 = "card-lock.png";
            }
            
            cardSelect = UserDefault::getInstance()->getStringForKey("nhanvatselect", "1+N+N+N");
            arrSelected = HuyFunctions().splitString(cardSelect, '+');

            if( arrSelected[0].compare("N") == 0) {
                markName1 = "card-can-buy.png";
            } else if (arrSelected[0].compare("1") == 0) {
                markName1 = "";
            }
            if( arrSelected[1].compare("N") == 0) {
                markName2 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName2 = "";
            }
            if( arrSelected[2].compare("N") == 0) {
                markName3 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName3 = "";
            }
            if( arrSelected[3].compare("N") == 0) {
                markName4 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName4 = "";
            }
             cardName =  "icon-animal-";
            
            break;
        case 3:
            mucDiem = Variable().arrTenLua.at(0);
            if (mucDiem > tongDiem) {
                markName1 = "card-lock.png";
            }
            mucDiem = Variable().arrTenLua.at(1);
            if (mucDiem > tongDiem) {
                markName2 = "card-lock.png";
            }
            mucDiem = Variable().arrTenLua.at(2);
            if (mucDiem > tongDiem) {
                markName3 = "card-lock.png";
            }
            mucDiem = Variable().arrTenLua.at(3);
            if (mucDiem > tongDiem) {
                markName4 = "card-lock.png";
            }
            cardSelect = UserDefault::getInstance()->getStringForKey("tenluaselect", "1+N+N+N");
            arrSelected = HuyFunctions().splitString(cardSelect, '+');

            if( arrSelected[0].compare("N") == 0) {
                markName1 = "card-can-buy.png";
            } else if (arrSelected[0].compare("1") == 0) {
                markName1 = "";
            }
            if( arrSelected[1].compare("N") == 0) {
                markName2 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName2 = "";
            }
            if( arrSelected[2].compare("N") == 0) {
                markName3 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName3 = "";
            }
            if( arrSelected[3].compare("N") == 0) {
                markName4 = "card-can-buy.png";
            }else if (arrSelected[0].compare("1") == 0) {
                markName4 = "";
            }
            cardName =  "icon-ten-lua-";
            
            break;
            
        default:
            cardSelect = UserDefault::getInstance()->getStringForKey("phithuyenselect", "1+N+N+N");
            break;
    }
    bool flagActive1 = false;
    bool flagActive2 = false;
    bool flagActive3 = false;
    bool flagActive4 = false;
    
    switch (viTriActive) {
        case 1:
            flagActive1 = true;
            markName1 = "card-selected.png";
            break;
        case 2:
            flagActive2 = true;
            markName2 = "card-selected.png";
            break;
        case 3:
            flagActive3 = true;
            markName3 = "card-selected.png";
            break;
        case 4:
            flagActive4 = true;
            markName4 = "card-selected.png";
            break;
            
        default:
            flagActive1 = true;
            markName1 = "card-selected.png";
            break;
    }
    
    log("test card: %s, type: %d", cardName, typeBuy);
    card1 = HuyFunctions().createGiftCard(wSceneBuy, hSceneBuy, hSceneBuy * 0.75,StringUtils::format("%s%d.png", cardName, 1), markName1, flagActive1);
    addChild(card1);
    float margin =  card1->getContentSize().height * card1->getScale() + 20;
    
    if (flagActive1 == true) {
        margin =  card1->getContentSize().height * card1->getScale() * 4.2 / 5 + 20;
        if (hSceneBuy / wSceneBuy <= 1.53)
        {
            margin =  card1->getContentSize().height * card1->getScale() * 8 / 10 + 15;
        }
    }
    card2 = HuyFunctions().createGiftCard(wSceneBuy, hSceneBuy, card1->getPositionY() - margin, StringUtils::format("%s%d.png", cardName, 2), markName2, flagActive2);
    addChild(card2);
    card3 = HuyFunctions().createGiftCard(wSceneBuy, hSceneBuy, card2->getPositionY() - margin, StringUtils::format("%s%d.png", cardName, 3), markName3, flagActive3);
    addChild(card3);
    card4 = HuyFunctions().createGiftCard(wSceneBuy, hSceneBuy, card3->getPositionY() - margin, StringUtils::format("%s%d.png", cardName, 4), markName4, flagActive4);
    addChild(card4);
//    card5 = HuyFunctions().createGiftCard(wSceneBuy, hSceneBuy, card4->getPositionY() - card1->getContentSize().height * card1->getScale() - 10, "icon-phi-thuyen-5.png");
//    addChild(card5);
    

    card1->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                animationCardClicked(button, 1);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    auto children = card1->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                auto button = static_cast<cocos2d::ui::Button*>(sender);
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        animationCardClicked(button, 1);
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
    card2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                animationCardClicked(button, 2);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
     children = card2->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                auto button = static_cast<cocos2d::ui::Button*>(sender);
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        animationCardClicked(button, 2);
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
    card3->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                animationCardClicked(button, 3);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
     children = card3->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                auto button = static_cast<cocos2d::ui::Button*>(sender);
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        animationCardClicked(button, 3);
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
    card4->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                animationCardClicked(button, 4);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
     children = card4->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                auto button = static_cast<cocos2d::ui::Button*>(sender);
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        animationCardClicked(button, 4);
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
//    card5->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
//        switch (type)
//        {
//            case cocos2d::ui::Widget::TouchEventType::BEGAN:
//                
//                animationCardClicked(5);
//                break;
//            case cocos2d::ui::Widget::TouchEventType::ENDED:
//                //CCLOG("Button 1 clicked");
//                break;
//            default:
//                break;
//        }
//    });
//    
//     children = card5->getChildren();
//    for (auto& child : children) {
//        auto childButton = dynamic_cast<ui::Button*>(child);
//        if (childButton) {
//            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
//            // Ví dụ: Thiết lập link cho button
//            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
//                switch (type)
//                {
//                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
//                        animationCardClicked(5);
//                        break;
//                    case cocos2d::ui::Widget::TouchEventType::ENDED:
//                        //CCLOG("Button 1 clicked");
//                        break;
//                    default:
//                        break;
//                }
//            });
//        }
//    }
//    
}
void Buy::createButton() {
    auto iconName1 = StringUtils::format("icon-phi-thuyen-%d.png", viTriPhiThuyen);
    auto iconName2 = StringUtils::format("icon-animal-%d.png", viTriNhanVat);
    auto iconName3 = StringUtils::format("icon-ten-lua-%d.png", viTriTenLua);
    
    button1 = HuyFunctions().createButtonGift(wSceneBuy, hSceneBuy, wSceneBuy / 2, iconName1);
    addChild(button1);
    button2 = HuyFunctions().createButtonGift(wSceneBuy, hSceneBuy, button1->getPositionX() - button1->getContentSize().width * button1->getScale() - 15, iconName2);
    addChild(button2);
    button3 = HuyFunctions().createButtonGift(wSceneBuy, hSceneBuy, button1->getPositionX() + button1->getContentSize().width * button1->getScale() + 15, iconName3);
    addChild(button3);
    switch (typeBuy) {
        case 1:
            button1->loadTextureNormal("bg-icon-gift-active.png");
            break;
        case 2:
            button2->loadTextureNormal("bg-icon-gift-active.png");
            break;
        case 3:
            button3->loadTextureNormal("bg-icon-gift-active.png");
            break;
            
        default:
            button1->loadTextureNormal("bg-icon-gift-active.png");
            break;
    }
    
    button1->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                Director::getInstance()->replaceScene(Buy::createScene(1));
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    auto children = button1->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        if (soundHello == 0)
                        {
                            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                        }
                        Director::getInstance()->replaceScene(Buy::createScene(1));
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
    
    button2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                Director::getInstance()->replaceScene(Buy::createScene(2));
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
     children = button2->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        if (soundHello == 0)
                        {
                            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                        }
                        Director::getInstance()->replaceScene(Buy::createScene(2));
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
    
    button3->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                Director::getInstance()->replaceScene(Buy::createScene(3));
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
     children = button3->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        if (soundHello == 0)
                        {
                            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                        }
                        Director::getInstance()->replaceScene(Buy::createScene(3));
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
}
void Buy::animationCardClicked(cocos2d::ui::Button* btn, int viTriClick) {
    
    if (soundHello == 0)
    {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
    }
    
    log("test click button add 200");
    float timeAnimation = 0.2;
    int opacityIndex = 150;
    
    if( arrSelected[viTriClick - 1].compare("1") == 0) {
        log("test click card to select nhanvat");
        
        auto typeName = "phithuyendachon";
        switch (typeBuy) {
            case 2:
                typeName = "nhanvatdachon";
                break;
            case 3:
                typeName = "tenluadachon";
                break;
                
            default:
                break;
        }
        int prevActive = UserDefault::getInstance()->getIntegerForKey(typeName, 0);
        UserDefault::getInstance()->setIntegerForKey(typeName, viTriClick - 1);
        //auto mark = card1->getChildByName<cocos2d::ui::Button*>("mark");
        //if (mark) {
            // Change the sprite texture
            //mark->loadTextureNormal("card-selected.png");
        //}
        
//        auto mark = ui::Button::create("card-selected.png", "card-selected.png");// tao button
//        float ratiomark = 14;
//        float scalemark = wSceneBuy / ratiomark / mark->getContentSize().width;
//        mark->setScale(scalemark);
//        mark->setName("mark");
//       // float ymark = y;
//        mark->setPosition(Vec2(btn->getContentSize().width * btn->getScale() / 2 + 5 - 0, 0));
//        btn->addChild(mark, 10);
//        log("prevActiveCard: %d", prevActive);
//        switch (prevActive) {
//            case 0:
//                
//                card1->removeChild(card1->getChildByName<cocos2d::ui::Button*>("mark"));
//                break;
//            case 1:
//                card2->removeChild(card2->getChildByName<cocos2d::ui::Button*>("mark"));
//                break;
//            case 2:
//                card3->removeChild(card3->getChildByName<cocos2d::ui::Button*>("mark"));
//                break;
//            case 3:
//                card4->removeChild(card4->getChildByName<cocos2d::ui::Button*>("mark"));
//                break;
//                
//            default:
//                break;
//        }
        Director::getInstance()->replaceScene(Buy::createScene(typeBuy));
    }
    
    if (viTriClick == 1 && card1->getTag() == 0) {
        
        
        
        card1->setTag(1);
        card1->runAction(
            Spawn::create(
                FadeIn::create(timeAnimation),
                ScaleTo::create(timeAnimation, 1 * card1->getScale() * 1.2),
                nullptr)
        );
        removeChild(phithuyenHienThi);
        
//        buttonAdd200Gold2->runAction(
//            Spawn::create(
//                FadeIn::create(timeAnimation),
//                ScaleTo::create(timeAnimation, 1 * buttonAdd200Gold2->getScale() * 1.2),
//                nullptr)
//        );
        removeChild(buttonAdd200Gold2);
        switch (typeBuy) {
            case 1:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 2:
                createNhanVat(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 3:
                createTenLua(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            default:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
        }
    }
    if (viTriClick == 2 && card2->getTag() == 0) {
        card2->setTag(1);
        card2->runAction(
            Spawn::create(
                FadeIn::create(timeAnimation),
                ScaleTo::create(timeAnimation, 1 * card2->getScale() * 1.2),
                nullptr)
        );
        removeChild(phithuyenHienThi);
//        buttonAdd200Gold2->runAction(
//            Spawn::create(
//                FadeIn::create(timeAnimation),
//                ScaleTo::create(timeAnimation, 1 * buttonAdd200Gold2->getScale() * 1.2),
//                nullptr)
//        );
        removeChild(buttonAdd200Gold2);
        switch (typeBuy) {
            case 1:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 2:
                createNhanVat(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 3:
                createTenLua(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            default:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
        }
    }
    if (viTriClick == 3 && card3->getTag() == 0) {
        card3->setTag(1);
        card3->runAction(
            Spawn::create(
                FadeIn::create(timeAnimation),
                ScaleTo::create(timeAnimation, 1 * card3->getScale() * 1.2),
                nullptr)
        );
        removeChild(phithuyenHienThi);
//        buttonAdd200Gold2->runAction(
//            Spawn::create(
//                FadeIn::create(timeAnimation),
//                ScaleTo::create(timeAnimation, 1 * buttonAdd200Gold2->getScale() * 1.2),
//                nullptr)
//        );
        removeChild(buttonAdd200Gold2);
        switch (typeBuy) {
            case 1:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 2:
                createNhanVat(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 3:
                createTenLua(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            default:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
        }
    }
    if (viTriClick == 4 && card4->getTag() == 0) {
        card4->setTag(1);
        card4->runAction(
            Spawn::create(
                FadeIn::create(timeAnimation),
                ScaleTo::create(timeAnimation, 1 * card4->getScale() * 1.2),
                nullptr)
        );
        removeChild(phithuyenHienThi);
//        buttonAdd200Gold2->runAction(
//            Spawn::create(
//                FadeIn::create(timeAnimation),
//                ScaleTo::create(timeAnimation, 1 * buttonAdd200Gold2->getScale() * 1.2),
//                nullptr)
//        );
        removeChild(buttonAdd200Gold2);
        switch (typeBuy) {
            case 1:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 2:
                createNhanVat(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            case 3:
                createTenLua(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
            default:
                createPhiThuyen(wSceneBuy, hSceneBuy, viTriClick);
                //createCard();
                break;
        }
    }
//    if (viTriClick == 5) {
//        card5->setTag(1);
//        card5->runAction(
//            Spawn::create(
//                FadeIn::create(timeAnimation),
//                ScaleTo::create(timeAnimation, 1 * card5->getScale() * 1.2),
//                nullptr)
//        );
//    }
    
    //reset
    if (card1->getTag() == 1 && viTriClick != 1) {
        card1->setTag(0);
        card1->runAction(
            Spawn::create(
                FadeTo::create(timeAnimation, opacityIndex),
                ScaleTo::create(timeAnimation, card1->getScale() / 1.2),
                nullptr)
        );
    }
    if (card2->getTag() == 1 && viTriClick != 2) {
        card2->setTag(0);
        card2->runAction(
            Spawn::create(
                FadeTo::create(timeAnimation, opacityIndex),
                ScaleTo::create(timeAnimation, card2->getScale() / 1.2),
                nullptr)
        );
    }
    
    if (card3->getTag() == 1 && viTriClick != 3) {
        card3->setTag(0);
        card3->runAction(
            Spawn::create(
                FadeTo::create(timeAnimation, opacityIndex),
                ScaleTo::create(timeAnimation, card3->getScale() / 1.2),
                nullptr)
        );
    }
    if (card4->getTag() == 1 && viTriClick != 4) {
        card4->setTag(0);
        card4->runAction(
            Spawn::create(
                FadeTo::create(timeAnimation, opacityIndex),
                ScaleTo::create(timeAnimation, card4->getScale() / 1.2),
                nullptr)
        );
    }
//    if (card5->getTag() == 1) {
//        card5->setTag(0);
//        card5->runAction(
//            Spawn::create(
//                FadeTo::create(timeAnimation, opacityIndex),
//                ScaleTo::create(timeAnimation, card5->getScale() / 1.2),
//                nullptr)
//        );
//    }
    
   
    
    
    
}
void Buy::createButtonBack(){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10.3;
    double heightPercent = 0.96;
    if (hSceneBuy / wSceneBuy > 2.168) {
        heightPercent = 0.945;
    }
    if (hSceneBuy/ wSceneBuy <= 1.8)
    {
        heightPercent = 0.992;
    }
    if (hSceneBuy/ wSceneBuy <= 1.53)
    {
        heightPercent = 0.99;
        ratio = 15;

    }
    auto btnWidth = btn->getContentSize().width;

    float scale = wSceneBuy / ratio / btnWidth;
    btn->setScale(scale);
    float xBtn = (btnWidth * scale / 2 + 8);
    btn->setPosition(Vec2(xBtn, hSceneBuy * heightPercent - (btnWidth * scale * 2 / 3)));
    
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("Button setting");
                //redirect to play
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    this->addChild(btn);//add button vao scene
}
void Buy::createBg() {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-gift.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hSceneBuy / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wSceneBuy / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wSceneBuy / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}
void Buy::createInforDiemSo () {
    float fontSize = 0.05 * wSceneBuy;
    float ratiomyImg = 14;
    log("test notch: %f", hSceneBuy / wSceneBuy);
    double heightPercent = 0.95;
    if (hSceneBuy / wSceneBuy > 2.168) {
        heightPercent = 0.935;
    }
    if (hSceneBuy/ wSceneBuy <= 1.8)
    {
        heightPercent = 0.98;
    }
    if (hSceneBuy/ wSceneBuy <= 1.53)
    {
        heightPercent = 0.98;
        fontSize = 0.03 * wSceneBuy;
        ratiomyImg = 20;

    }
    double topHeight = heightPercent * hSceneBuy;
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    
    //add giao dien cho thong tin diem cao nhat
    auto imageName = "diamond.png";
    auto myImg = ui::Button::create(imageName); // tao button
    //myImg->setTouchEnabled(false);
    
    float scalemyImg = wSceneBuy / ratiomyImg / myImg->getContentSize().width;
    myImg->setScale(scalemyImg);
    float ymyImg = topHeight - (myImg->getContentSize().height / 2 * scalemyImg);
    myImg->setPosition(Vec2(wSceneBuy * 3 / 8 - myImg->getContentSize().width / 2 * scalemyImg, ymyImg));
    myImg->setEnabled(true);
    if (Variable().isProduction) {
        myImg->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftDiamond::createScene(), Color3B().WHITE));
                                    });
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    

                    break;
                default:
                    break;
            }
                   
        });
    }
    this->addChild(myImg);
    
    
    auto labelHightScore = cocos2d::__String::createWithFormat("%i", diemDiamond);
    valueHeightScore = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize);
    valueHeightScore->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xValueScore = myImg->getPositionX() + myImg->getContentSize().width * scalemyImg / 2 + 2;
    float yValueScore = myImg->getPositionY() - 3;// - valueHeightScore->getContentSize().width;
//    if (h/ w <= 1.53)
//    {
//        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueHeightScore->getContentSize().width;
//
//    }
    valueHeightScore->setPosition(Vec2(xValueScore, yValueScore));
    valueHeightScore->setAnchorPoint({0, 0.5});
    valueHeightScore->setHorizontalAlignment(TextHAlignment::LEFT);
    addChild(valueHeightScore, 1);
    
    //add giao dien cho thong tin tong so diem
    
    auto labelTongDiem = cocos2d::__String::createWithFormat("%i", tongDiem);
    valueTongDiem = Label::createWithTTF(labelTongDiem->getCString(), fontStyle, fontSize);
    valueTongDiem->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    xValueScore = wSceneBuy - valueTongDiem->getContentSize().width - 8;
    //yValueScore = myImg->getPositionY() - 5;// - valueTongDiem->getContentSize().width;
//    if (h/ w <= 1.53)
//    {
//        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueTongDiem->getContentSize().width;
//
//    }
    valueTongDiem->setPosition(Vec2(xValueScore, yValueScore + 1));
    valueTongDiem->setAnchorPoint({0, 0.5});
    valueTongDiem->setHorizontalAlignment(TextHAlignment::RIGHT);
    addChild(valueTongDiem, 1);
    imageName = "gold.png";
    myImg = ui::Button::create(imageName, imageName); // tao button
    myImg->setPressedActionEnabled(false);
    //myImg->setTouchEnabled(false);
//    float ratiomyImg = 10;
//    float scalemyImg = wSceneBuy / ratiomyImg / myImg->getContentSize().width;
    myImg->setScale(scalemyImg);
    //float ymyImg = topHeight - (myImg->getContentSize().height / 2 * scalemyImg);
    myImg->setPosition(Vec2(valueTongDiem->getPositionX() - myImg->getContentSize().width * scalemyImg / 2 - 3, ymyImg));// - myImg->getContentSize().width / 2 * scalemyImg, ymyImg));
    myImg->setEnabled(true);
    if (Variable().isProduction) {
        myImg->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Gift::createScene(), Color3B().WHITE));
                                    });
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    

                    break;
                default:
                    break;
            }
                   
        });
    }
    this->addChild(myImg);
    
    //add giao dien cho thong tin tong so ngay da mo app
    imageName = "heart.png";
    auto myHeart = ui::Button::create(imageName); // tao button
    //myHeart->setTouchEnabled(false);
//    float ratiomyImg = 10;
//    float scalemyImg = wSceneBuy / ratiomyImg / myImg->getContentSize().width;
    myHeart->setScale(scalemyImg);
    //float ymyImg = topHeight - (myImg->getContentSize().height / 2 * scalemyImg);
    myHeart->setPosition(Vec2(wSceneBuy * 5 / 8 - myImg->getContentSize().width * scalemyImg / 2, ymyImg));// - myImg->getContentSize().width / 2 * scalemyImg, ymyImg));
    myHeart->setEnabled(true);
    if (Variable().isProduction) {
        myHeart->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftHeart::createScene(), Color3B().WHITE));
                                    });
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    

                    break;
                default:
                    break;
            }
                   
        });
    }
    this->addChild(myHeart);
   
    auto soNgayChoi = cocos2d::__String::createWithFormat("%i", diemHeart);
    valueSoNgayChoi = Label::createWithTTF(soNgayChoi->getCString(), fontStyle, fontSize);
    
  
    
    valueSoNgayChoi->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    xValueScore = myHeart->getPositionX() + myHeart->getContentSize().width * scalemyImg / 2 + 3;
    //yValueScore = myImg->getPositionY() - 5;// - valueTongDiem->getContentSize().width;
//    if (h/ w <= 1.53)
//    {
//        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueTongDiem->getContentSize().width;
//
//    }
    valueSoNgayChoi->setPosition(Vec2(xValueScore, yValueScore + 1));
    valueSoNgayChoi->setAnchorPoint({0, 0.5});
    valueSoNgayChoi->setHorizontalAlignment(TextHAlignment::LEFT);
    addChild(valueSoNgayChoi, 1);
    
    
}
void Buy::createPhiThuyen(float w, float h, int i) {
    
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    double fontSize = 0.09 * w;
    auto myColor = Color3B().WHITE;
    
    // create Phi thuyen
    auto sprite_cachePhiThuyen = SpriteFrameCache::getInstance();
    sprite_cachePhiThuyen->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d1.plist", i));
    Vector<SpriteFrame*> phiThuyen;
    phiThuyen.reserve(2);
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1a.png", i)));
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1b.png", i)));
    Animation* animationPhiThuyen = Animation::createWithSpriteFrames(phiThuyen, 0.4f, -1);
    Animate* animatePhiThuyen = Animate::create(animationPhiThuyen);

    phithuyenHienThi = Sprite::createWithSpriteFrame(phiThuyen.front());
    float ratioPhiThuyen = 2.5;
    if (h / w <= 1.53)
    {
        ratioPhiThuyen = 5;
    }
    float scalePhiThuyen = w / ratioPhiThuyen / phithuyenHienThi->getContentSize().width;
    phithuyenHienThi->setScale(scalePhiThuyen);

    //float ytitle = h * 0.9 - (earth->getContentSize().height / 2 * scalebgColor);
    float xtitlePhiThuyen = w * 0.5;// - (phithuyenHienThi->getContentSize().width / 2 * scalePhiThuyen);
    float ytitlePhiThuyen = h * 0.7;// - (phithuyenHienThi->getContentSize().height / 2 * scalePhiThuyen);
    
    phithuyenHienThi->setPosition(Vec2(xtitlePhiThuyen, ytitlePhiThuyen));
    phithuyenHienThi->runAction(animatePhiThuyen);
    this->addChild(phithuyenHienThi, 2);
    
    // Tạo hành động nghiêng sang trái
    auto tiltLeft = RotateBy::create(0.9f, -4);  // Xoay -2 độ
    // Tạo hành động nghiêng sang phải
    auto tiltRight = RotateBy::create(0.9f, 4);   // Xoay +2 độ
    // Lặp lại hành động
    auto tilting = RepeatForever::create(Sequence::create(tiltLeft, tiltRight, nullptr));
    // Chạy animation cho phi thuyền
    phithuyenHienThi->runAction(tilting);
    
    
    auto moveUp = MoveBy::create(0.9f, Vec2(0, 8));
    auto moveDown = MoveBy::create(0.9f, Vec2(0, -8));
    auto waveMotion = RepeatForever::create(Sequence::create(moveUp, moveDown, nullptr));

    phithuyenHienThi->runAction(waveMotion);
    
    phithuyenHienThi->setOpacity(0);
    phithuyenHienThi->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(0.5), nullptr));
  
    //animation for phi thuyen
    //auto actionMoveTo = MoveTo::create(100, Vec2( w, h));
    //phithuyenHienThi->runAction(actionMoveTo);
    //phithuyenHienThi->setOpacity(0);
    //phithuyenHienThi->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(0.5), nullptr));

    std::string cardSelect = UserDefault::getInstance()->getStringForKey("phithuyenselect", "1+N+N+N");
    //log("test cardSelect: %s", cardSelect.c_str());
    arrSelected = HuyFunctions().splitString(cardSelect, '+');
    //log("test i: %d", i);
    if( arrSelected[i - 1].compare("N") == 0) {
        buttonAdd200Gold2 = ui::Button::create("icon-buy-diamond.png"); // tao button
        buttonAdd200Gold2->setTouchEnabled(true);
        
        //auto labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (200));
        //buttonAdd200Gold2->setName(labelScoreAdd200->getCString());
        float ratiobuttonAdd200Gold2 = 2.5;
        float fixHeightIphone = h / 23;
        if (h / w <= 1.8)
        {
            //ratiobuttonAdd200Gold2 = 2;
            //fixHeightIphone = h / 40;
        }
        float fixWidthScale = 1;
        float fixHeightScale = 1;
        if (h / w <= 1.53)
        {
            ratiobuttonAdd200Gold2 = 5;
            fixHeightIphone = h / 23;
            fontSize = 0.09 * w;
            fixWidthScale = 2;
            fixHeightScale = 2;
        }
        
        
        float scalebuttonAdd200Gold2 = w / ratiobuttonAdd200Gold2 / buttonAdd200Gold2->getContentSize().width;
        buttonAdd200Gold2->setScale(scalebuttonAdd200Gold2);
        buttonAdd200Gold2->setAnchorPoint({0.5, 0});
        buttonAdd200Gold2->setTag(i - 1);
        int mucDiem = Variable().arrPhiThuyen.at(i - 1);
        buttonAdd200Gold2->setPosition(Vec2(w / 2,  phithuyenHienThi->getPositionY() - phithuyenHienThi->getContentSize().height * phithuyenHienThi->getScale() - 30));
        buttonAdd200Gold2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    clickBuy(button, 1);
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
            }
        });
        
        addChild(buttonAdd200Gold2);//add button vao scene
        
        
        
        auto desc = Label::createWithTTF(StringUtils::format("%d", mucDiem), fontStyle, fontSize);
        //desc->setTag(10);
        
        if (mucDiem > diemDiamond) {
            myColor = Color3B().RED;
        }
        desc->setColor(myColor);
        // position the label on the center of the screen
        if (h / w <= 1.53) {
            //desc->setPosition(Vec2(xValueScore * 2, yValueScore + 15));
        } else{
            //desc->setPosition(Vec2(xValueScore + 7, yValueScore));
        }
        //desc->setPosition(Vec2(w - (w - btn->getContentSize().width * scaleLang) / 2 - 10, btn->getContentSize().height * scaleLang / 2 + 7));
        desc->setPosition(Vec2(buttonAdd200Gold2->getContentSize().width * scalebuttonAdd200Gold2 * fixWidthScale - 15,  buttonAdd200Gold2->getContentSize().height * scalebuttonAdd200Gold2 / 2 * fixHeightScale + 20));
        desc->setAnchorPoint({0.5, 0.5});
        desc->setHorizontalAlignment(TextHAlignment::LEFT);
        buttonAdd200Gold2->addChild(desc);
        
        //buttonAdd200Gold2->runAction(Spawn::create(FadeOut::create(0), nullptr));
        //buttonAdd200Gold2->setEnabled(false);
    }
    
    
}
void Buy::clickBuy(cocos2d::ui::Button* button, int type ) {
    //type: 1 - phithuyendachon, 2- nhanvatdachon, 3 - tenluadachon
    int mucDiem = 0;
    auto typeName = "phithuyendachon";
    auto typeNameSelect = "phithuyenselect";
    switch (type) {
        case 1:
            
            mucDiem = Variable().arrPhiThuyen.at(button->getTag());
            if (mucDiem > diemDiamond) {
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftDiamond::createScene(), Color3B().WHITE));
                });
            }
            else {
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                }
                int viTri = button->getTag();
                log("tong diem %d", diemDiamond - mucDiem);
                UserDefault::getInstance()->setIntegerForKey("diamond", diemDiamond - mucDiem);
                
                UserDefault::getInstance()->setIntegerForKey(typeName, viTri);
                
                saveNhanVatSelected(typeNameSelect, viTri);
                valueHeightScore->setString(std::to_string(diemDiamond - mucDiem));
                
                auto timeAnimation = 0.1;
                auto valueHeightScoreSize = valueHeightScore->getScale();
                valueHeightScore->setScale(valueHeightScoreSize * 2);
                //valueHeightScore->setOpacity(0);
                valueHeightScore->runAction(
                    Spawn::create(
                        //FadeIn::create(timeAnimation * 2),
                        ScaleTo::create(timeAnimation * 2, valueHeightScoreSize),
                        nullptr)
                );
                
//                buttonAdd200Gold2->runAction(
//                    Spawn::create(
//                        FadeOut::create(timeAnimation * 2),
//                        ScaleTo::create(timeAnimation, 0 ),
//                        nullptr)
//                );
                auto pop = ScaleTo::create(0.15f, 1.3f);
                auto shrink = ScaleTo::create(0.15f, 1.0f);
                auto glow = FadeTo::create(0.15f, 200);

                auto combinedEffect = Spawn::create(
                    Sequence::create(pop, shrink, nullptr),  // Nảy lên
                    glow,  // Phát sáng nhẹ
                    nullptr
                );
                phithuyenHienThi->runAction(combinedEffect);
                HuyFunctions().animationClickedButtonWithDelay(button, 0.3f, [](){
                    Director::getInstance()->replaceScene(Buy::createScene(typeBuy));
                });
            }
            break;
        case 2:
            mucDiem = Variable().arrNhanVat.at(button->getTag());
            typeName = "nhanvatdachon";
            typeNameSelect = "nhanvatselect";
            
            if (mucDiem > tongDiem) {
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Gift::createScene(), Color3B().WHITE));
                });
            }
            else {
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                }
                int viTri = button->getTag();
                log("tong diem %d", tongDiem - mucDiem);
                UserDefault::getInstance()->setIntegerForKey("sovang", tongDiem - mucDiem);
                // Gửi điểm số
                GameCenterBridge::submitScore(tongDiem - mucDiem, "com.huy.mentalmath.Golds");
                UserDefault::getInstance()->setIntegerForKey(typeName, viTri);
                
                saveNhanVatSelected(typeNameSelect, viTri);
                valueTongDiem->setString(std::to_string(tongDiem - mucDiem));
                
                auto timeAnimation = 0.1;
                auto valueTongDiemSize = valueTongDiem->getScale();
                valueTongDiem->setScale(valueTongDiemSize * 2);
                //valueTongDiem->setOpacity(0);
                valueTongDiem->runAction(
                    Spawn::create(
                        //FadeIn::create(timeAnimation * 2),
                        ScaleTo::create(timeAnimation * 2, valueTongDiemSize ),
                        nullptr)
                );
//                buttonAdd200Gold2->runAction(
//                    Spawn::create(
//                        FadeOut::create(timeAnimation * 2),
//                        ScaleTo::create(timeAnimation, 0 ),
//                        nullptr)
//                );
                
                auto pop = ScaleTo::create(0.15f, 1.3f);
                auto shrink = ScaleTo::create(0.15f, 1.0f);
                auto glow = FadeTo::create(0.15f, 200);

                auto combinedEffect = Spawn::create(
                    Sequence::create(pop, shrink, nullptr),  // Nảy lên
                    glow,  // Phát sáng nhẹ
                    nullptr
                );
                phithuyenHienThi->runAction(combinedEffect);
                
                HuyFunctions().animationClickedButtonWithDelay(button, 0.5f, [](){
                    Director::getInstance()->replaceScene(Buy::createScene(typeBuy));
                });
            }
            
            break;
        case 3:
            
            mucDiem = Variable().arrTenLua.at(button->getTag());
            typeName = "tenluadachon";
            typeNameSelect = "tenluaselect";
            
            if (mucDiem > diemHeart) {
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftHeart::createScene(), Color3B().WHITE));
                });
            }
            else {
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                }
                int viTri = button->getTag();
                log("tong diem %d", diemHeart - mucDiem);
                UserDefault::getInstance()->setIntegerForKey("songay", diemHeart - mucDiem);
                
                UserDefault::getInstance()->setIntegerForKey(typeName, viTri);
                
                saveNhanVatSelected(typeNameSelect, viTri);
                valueSoNgayChoi->setString(std::to_string(diemDiamond - mucDiem));
                
                auto timeAnimation = 0.1;
                auto valueSoNgayChoiSize = valueSoNgayChoi->getScale();
                valueSoNgayChoi->setScale(valueSoNgayChoiSize * 2);
                //valueSoNgayChoi->setOpacity(0);
                valueSoNgayChoi->runAction(
                    Spawn::create(
                        //FadeIn::create(timeAnimation * 2),
                        ScaleTo::create(timeAnimation * 2, valueSoNgayChoiSize ),
                        nullptr)
                );
                
//                buttonAdd200Gold2->runAction(
//                    Spawn::create(
//                        FadeOut::create(timeAnimation * 2),
//                        ScaleTo::create(timeAnimation, 0 ),
//                        nullptr)
//                );
                
                auto pop = ScaleTo::create(0.15f, 1.3f);
                auto shrink = ScaleTo::create(0.15f, 1.0f);
                auto glow = FadeTo::create(0.15f, 200);

                auto combinedEffect = Spawn::create(
                    Sequence::create(pop, shrink, nullptr),  // Nảy lên
                    glow,  // Phát sáng nhẹ
                    nullptr
                );
                phithuyenHienThi->runAction(combinedEffect);
                HuyFunctions().animationClickedButtonWithDelay(button, 0.5f, [](){
                    Director::getInstance()->replaceScene(Buy::createScene(typeBuy));
                });
            }
            break;
            
        default:
            mucDiem = Variable().arrPhiThuyen.at(button->getTag());
            break;
    }
    //log("muc diem %d, tong diem %d", mucDiem, tongDiem);
    
    
  
    
}
void Buy::saveNhanVatSelected(std::string typeNameSelect, int viTri) {
    auto selected = UserDefault::getInstance()->getStringForKey(typeNameSelect.c_str(), "1+N+N+N");
    std::vector<std::string> arrSelectedNew = HuyFunctions().splitString(selected, '+');
    
    selected = "";
    for (size_t i = 0; i < arrSelectedNew.size(); ++i) {
        if (i != viTri) {
            if (i == 0) {
                selected = selected + arrSelectedNew[i].c_str();
            } else {
                selected = selected + "+" + arrSelectedNew[i].c_str();
            }
            
        } else {
            if (i == 0) {
                selected = selected + "1";
            } else {
                selected = selected + "+1";
            }
        }
        
            log("Index %zu: %s, vitri %d", i, arrSelectedNew[i].c_str(), viTri);
        }
    log("slected new %s", selected.c_str());
    UserDefault::getInstance()->setStringForKey(typeNameSelect.c_str(), selected);
}
void Buy::createTenLua(float w, float h, int i) {
    // create Phi thuyen
    auto sprite_cachePhiThuyen = SpriteFrameCache::getInstance();
    sprite_cachePhiThuyen->addSpriteFramesWithFile(StringUtils::format("tenlua0%d.plist", i));
    log("test ten lua: %d", i);
    Vector<SpriteFrame*> phiThuyen;
    phiThuyen.reserve(2);
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("tenlua0%da.png", i)));
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("tenlua0%db.png", i)));
    Animation* animationPhiThuyen = Animation::createWithSpriteFrames(phiThuyen, 0.2f, -1);
    Animate* animatePhiThuyen = Animate::create(animationPhiThuyen);

    phithuyenHienThi = Sprite::createWithSpriteFrame(phiThuyen.front());
    float ratioPhiThuyen = 2.5;
    if (h / w <= 1.53)
    {
        ratioPhiThuyen = 5;
    }
    float scalePhiThuyen = w / ratioPhiThuyen / phithuyenHienThi->getContentSize().width;
    phithuyenHienThi->setScale(scalePhiThuyen);

    //float ytitle = h * 0.9 - (earth->getContentSize().height / 2 * scalebgColor);
    float xtitlePhiThuyen = w * 0.5;// - (phithuyenHienThi->getContentSize().width / 2 * scalePhiThuyen);
    float ytitlePhiThuyen = h * 0.7;// - (phithuyenHienThi->getContentSize().height / 2 * scalePhiThuyen);
    
    phithuyenHienThi->setPosition(Vec2(xtitlePhiThuyen, ytitlePhiThuyen));
    phithuyenHienThi->runAction(animatePhiThuyen);
    phithuyenHienThi->setRotation(20);
    this->addChild(phithuyenHienThi, 2);
    
    auto moveUp = MoveBy::create(0.9f, Vec2(0, 15));
    auto moveDown = MoveBy::create(0.9f, Vec2(0, -15));
    auto waveMotion = RepeatForever::create(Sequence::create(moveUp, moveDown, nullptr));

    phithuyenHienThi->runAction(waveMotion);
  
    //animation for phi thuyen
    //auto actionMoveTo = MoveTo::create(100, Vec2( w, h));
    //phithuyenHienThi->runAction(actionMoveTo);
    //phithuyenHienThi->setOpacity(0);
    //phithuyenHienThi->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(0.5), nullptr));
    
    std::string cardSelect = UserDefault::getInstance()->getStringForKey("tenluaselect", "1+N+N+N");
    //log("test cardSelect: %s", cardSelect.c_str());
    arrSelected = HuyFunctions().splitString(cardSelect, '+');
    //log("test i: %d", i);
    if( arrSelected[i - 1].compare("N") == 0) {
        buttonAdd200Gold2 = ui::Button::create("icon-buy-heart.png"); // tao button
        buttonAdd200Gold2->setTouchEnabled(true);
        //auto tongDiem = HuyFunctions().getSoVang();
        //auto labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (200));
        //buttonAdd200Gold2->setName(labelScoreAdd200->getCString());
        float ratiobuttonAdd200Gold2 = 2.6;
        float fixHeightIphone = h / 23;
        if (h / w <= 1.8)
        {
            //ratiobuttonAdd200Gold2 = 2;
            //fixHeightIphone = h / 40;
        }
        float fixWidthScale = 1;
        float fixHeightScale = 1;
        if (h / w <= 1.53)
        {
            ratiobuttonAdd200Gold2 = 5;
            fixHeightIphone = h / 23;
          
            fixWidthScale = 2;
            fixHeightScale = 2;
        }
        float scalebuttonAdd200Gold2 = w / ratiobuttonAdd200Gold2 / buttonAdd200Gold2->getContentSize().width;
        buttonAdd200Gold2->setScale(scalebuttonAdd200Gold2);
        buttonAdd200Gold2->setAnchorPoint({0.5, 0});
        buttonAdd200Gold2->setTag(i - 1);
        buttonAdd200Gold2->setPosition(Vec2(w / 2,  phithuyenHienThi->getPositionY() - phithuyenHienThi->getContentSize().height * phithuyenHienThi->getScale() - 30));
        buttonAdd200Gold2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    
                    clickBuy(button, 3);
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
            }
        });
        
        addChild(buttonAdd200Gold2);//add button vao scene
        //buttonAdd200Gold2->runAction(Spawn::create(FadeOut::create(0), nullptr));
        //buttonAdd200Gold2->setEnabled(false);
        auto fontStyle = "fonts/BraahOne-Regular.ttf";
        double fontSize = 0.09 * w;
        auto myColor = Color3B().WHITE;
        int mucDiem = Variable().arrTenLua.at(i - 1);
        auto desc = Label::createWithTTF(StringUtils::format("%d", mucDiem), fontStyle, fontSize );
        //desc->setTag(10);
    
        if (mucDiem > diemHeart) {
            myColor = Color3B().RED;
        }
        desc->setColor(myColor);
        // position the label on the center of the screen
        if (h / w <= 1.53) {
            //desc->setPosition(Vec2(xValueScore * 2, yValueScore + 15));
        } else{
            //desc->setPosition(Vec2(xValueScore + 7, yValueScore));
        }
        //desc->setPosition(Vec2(w - (w - btn->getContentSize().width * scaleLang) / 2 - 10, btn->getContentSize().height * scaleLang / 2 + 7));
        desc->setPosition(Vec2(buttonAdd200Gold2->getContentSize().width * scalePhiThuyen / 2 * fixWidthScale + 14,  buttonAdd200Gold2->getContentSize().height * scalePhiThuyen / 2 * fixHeightScale - 3));
        desc->setAnchorPoint({0.5, 0.5});
        desc->setHorizontalAlignment(TextHAlignment::LEFT);
        buttonAdd200Gold2->addChild(desc);
    }
}
void Buy::createNhanVat(float w, float h, int i) {
    // create Phi thuyen
    
    auto sprite_cachePhiThuyen = SpriteFrameCache::getInstance();
    sprite_cachePhiThuyen->addSpriteFramesWithFile(StringUtils::format("nhanvat%d.plist", i));
    Vector<SpriteFrame*> phiThuyen;
    phiThuyen.reserve(2);
    
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("nhanvat%da.png", i)));
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("nhanvat%db.png", i)));
    Animation* animationPhiThuyen = Animation::createWithSpriteFrames(phiThuyen, 0.4f, -1);
    Animate* animatePhiThuyen = Animate::create(animationPhiThuyen);

    phithuyenHienThi = Sprite::createWithSpriteFrame(phiThuyen.front());
    float ratioPhiThuyen = 2.5;
    if (h / w <= 1.53)
    {
        ratioPhiThuyen = 5;
    }
    float scalePhiThuyen = w / ratioPhiThuyen / phithuyenHienThi->getContentSize().width;
    phithuyenHienThi->setScale(scalePhiThuyen);

    //float ytitle = h * 0.9 - (earth->getContentSize().height / 2 * scalebgColor);
    float xtitlePhiThuyen = w * 0.5;// - (phithuyenHienThi->getContentSize().width / 2 * scalePhiThuyen);
    float ytitlePhiThuyen = h * 0.7;// - (phithuyenHienThi->getContentSize().height / 2 * scalePhiThuyen);
    
    phithuyenHienThi->setPosition(Vec2(xtitlePhiThuyen, ytitlePhiThuyen));
    phithuyenHienThi->runAction(animatePhiThuyen);
    
    this->addChild(phithuyenHienThi, 2);
    
    float timePlay = 1.5f;
    auto rotateLeft = RotateBy::create(timePlay, -3.0f); // Rotate left by 10 degrees
    auto rotateRight = RotateBy::create(timePlay, 6.0f); // Rotate right by 20 degrees (to 10 degrees right)
    auto rotateBack = RotateBy::create(timePlay, -3.0f); // Rotate back to center

    // Create a sequence and repeat it forever
    auto tiltSequence = Sequence::create(rotateLeft, rotateRight, rotateBack, nullptr);
    auto repeatTilt = RepeatForever::create(tiltSequence);

     //Run the action on the parent button
    phithuyenHienThi->runAction(repeatTilt);
    
//    auto jump = JumpBy::create(2.4f, Vec2(0, 0), 30, 2);
//    auto scaleUp = ScaleTo::create(0.4f, 1.1f);
//    auto scaleDown = ScaleTo::create(0.4f, 0.9f);
//    auto scaleNormal = ScaleTo::create(0.4f, 1.0f);
//    auto bounceEffect = Sequence::create(scaleUp, scaleDown, scaleNormal, nullptr);
//
//    auto jumpWithEffect = Spawn::create(jump, bounceEffect, nullptr);
//    phithuyenHienThi->runAction(RepeatForever::create(jumpWithEffect));

//    auto rotateLeft2 = RotateTo::create(0.1f, -5);
//            auto rotateRight2 = RotateTo::create(0.1f, 5);
//            auto rotateBack2 = RotateTo::create(0.1f, 0);
//            auto shake = Sequence::create(rotateLeft2, rotateRight2, rotateBack2, nullptr);
//            
//            auto tint = TintTo::create(0.2f, 255, 200, 200); // Chuyển màu hồng nhẹ
//            auto normalTint = TintTo::create(0.2f, 255, 255, 255);
//            auto happyEffect = Spawn::create(shake, tint, normalTint, nullptr);
            
    //phithuyenHienThi->runAction(happyEffect);



    
    std::string cardSelect = UserDefault::getInstance()->getStringForKey("nhanvatselect", "1+N+N+N");
    //log("test cardSelect: %s", cardSelect.c_str());
    arrSelected = HuyFunctions().splitString(cardSelect, '+');
    //log("test i: %d", i);
    if( arrSelected[i - 1].compare("N") == 0) {
        buttonAdd200Gold2 = ui::Button::create("icon-gold.png"); // tao button
        buttonAdd200Gold2->setTouchEnabled(true);
        //auto tongDiem = tongDiem;
        //auto labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (200));
        //buttonAdd200Gold2->setName(labelScoreAdd200->getCString());
        float ratiobuttonAdd200Gold2 = 2.6;
        float fixHeightIphone = h / 23;
        if (h / w <= 1.8)
        {
            //ratiobuttonAdd200Gold2 = 2;
            //fixHeightIphone = h / 40;
        }
        float fixWidthScale = 1;
        float fixHeightScale = 1;
        if (h / w <= 1.53)
        {
            ratiobuttonAdd200Gold2 = 5;
            fixHeightIphone = h / 23;
            fixWidthScale = 2;
            fixHeightScale = 2;
        }
        float scalebuttonAdd200Gold2 = w / ratiobuttonAdd200Gold2 / buttonAdd200Gold2->getContentSize().width;
        buttonAdd200Gold2->setScale(scalebuttonAdd200Gold2);
        buttonAdd200Gold2->setAnchorPoint({0.5, 0});
        buttonAdd200Gold2->setTag(i - 1);
        buttonAdd200Gold2->setPosition(Vec2(w / 2,  phithuyenHienThi->getPositionY() - phithuyenHienThi->getContentSize().height * phithuyenHienThi->getScale() - 30));
        buttonAdd200Gold2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    
                    clickBuy(button, 2);
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
            }
        });
        
        addChild(buttonAdd200Gold2);//add button vao scene
        //buttonAdd200Gold2->runAction(Spawn::create(FadeOut::create(0), nullptr));
        //buttonAdd200Gold2->setEnabled(false);
        auto fontStyle = "fonts/BraahOne-Regular.ttf";
        double fontSize = 0.09 * w;
        auto myColor = Color3B().WHITE;
        int mucDiem = Variable().arrNhanVat.at(i - 1);
        auto desc = Label::createWithTTF(StringUtils::format("%d", mucDiem), fontStyle, fontSize );
        //desc->setTag(10);
        
        if (mucDiem > tongDiem) {
            myColor = Color3B().RED;
        }
        desc->setColor(myColor);
        // position the label on the center of the screen
        if (h / w <= 1.53) {
            //desc->setPosition(Vec2(xValueScore * 2, yValueScore + 15));
        } else{
            //desc->setPosition(Vec2(xValueScore + 7, yValueScore));
        }
        //desc->setPosition(Vec2(w - (w - btn->getContentSize().width * scaleLang) / 2 - 10, btn->getContentSize().height * scaleLang / 2 + 7));
        desc->setPosition(Vec2(buttonAdd200Gold2->getContentSize().width * scalePhiThuyen / 2 * fixWidthScale + 14,  buttonAdd200Gold2->getContentSize().height * scalePhiThuyen / 2 * fixHeightScale - 3));
        desc->setAnchorPoint({0.5, 0.5});
        desc->setHorizontalAlignment(TextHAlignment::LEFT);
        buttonAdd200Gold2->addChild(desc);
    }
}
