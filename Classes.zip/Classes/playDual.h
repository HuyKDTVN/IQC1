#ifndef __PLAYDUAL_H__
#define __PLAYDUAL_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class PlayDual : public cocos2d::Layer
{
public:
    cocos2d::__String *ImageNamDapAnX;
    cocos2d::__String *ImageNamDapAnV;
    float phepTinhSoSanh1 = false;
    cocos2d::__String *loaiPhepTinh;
    
    bool dualModel = true;
    const char *D_HIGH_SCORE = "height-score";

    int d_realType;
    int d_answer1;
    int d_answer2;
    int d_answer3;
    int d_answer4;

    int d_wScenePlay;
    int d_hScenePlay;

    int d_correctAnswer;

    int d_score;
    int d_scoreDup;
    int d_maxDoiSo;

    int allPlayerChoised;
    bool player1Choised;
    bool player2Choised;
    int numQuestion;
    int MaxNumberQuestion;

    float d_timeMax;

    cocos2d::__String *ImageNamDapAn;
    
    cocos2d::__String *d_phepToan;
    cocos2d::__String *d_scoreString;
    cocos2d::__String *d_scoreStringDup;

    cocos2d::Label* d_lblPhepToan;
    cocos2d::Label* d_lblScore;
    cocos2d::ui::Button* d_scoreIcon;
    cocos2d::ui::Button* d_scoreIconDup;
    cocos2d::ui::Button* bgColor;
    cocos2d::Label* d_lblPhepToanDup;
    cocos2d::Label* d_lblScoreDup;

    

    cocos2d::ui::Button* d_buttonAnswer1;
    cocos2d::ui::Button* d_buttonAnswer2;
    cocos2d::ui::Button* d_buttonAnswer3;
    cocos2d::ui::Button* d_buttonAnswer4;
    cocos2d::ui::Button* d_buttonAnswer1Dup;
    cocos2d::ui::Button* d_buttonAnswer2Dup;
    cocos2d::ui::Button* d_buttonAnswer3Dup;
    cocos2d::ui::Button* d_buttonAnswer4Dup;
    cocos2d::ui::Button* d_buttonPause;

    float d_scaleButtonAnswer1;

    float d_timeRemaining;
    cocos2d::ui::LoadingBar* d_loadingBar;
    cocos2d::ui::LoadingBar* d_loadingBarWrap;
    float d_hLoadingBar;
    float d_ratioLoadingBar;
    bool d_isPause = false;

    cocos2d::Label* d_valueKey3;
    float d_yValueKey3;
    float d_xValueKey3;

    int d_sound;
    int d_prevA = 2;
    int d_prevB = 2;

    float ratioScreenPlay;

    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int type, int level, bool fromChallenge = false);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void update(float dt);
    void coundownTimer(float w, float h);
    void back(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void createButtonKey(float w, float h);
    void createValueKey(float w, float h);
    void createBg(float w, float h);
    void createScore(float w, float h);
    void createMainTemplate(float w, float h);
    
    void createBg();
    void createAnswer(float w, float h);
    void animationShowAnswer(cocos2d::ui::Button* button, float time, float scale);
    void handlerClickAnswer(int v, bool buttonSide);
    //void handlerClickAnswer(int v, cocos2d::ui::Button* button);

    void moveSceneGameOver();
    void nextPlay();

    void createBgPro(float w, float h);
    void finish();
    virtual void onEnter() override;
    void showMedal(float w, float h, std::string medal);
    
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(PlayDual);
};

#endif // __PLAYDUAL_H__
