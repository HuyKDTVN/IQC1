
#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include <ctime>
#include <iostream>
#include "ui/CocosGUI.h"

class HelloWorld : public cocos2d::Scene
{
public:
    bool inVN;
    bool ngayChoiMoi;
    int tongDiem;
    int perCent;
    int loaiPhanThuong;
    int giftNumber;
    int challengeIndex;
    cocos2d::Sprite* iconGift;
    cocos2d::ui::LoadingBar* loadingBar;
    
    bool showDailyReward;
    cocos2d::ui::Button* bgReward;
    cocos2d::ui::Button* bgReward2;
    cocos2d::Label* labelNguoiChoi;
    cocos2d::Label* labelTitleNguoiChoi;
    cocos2d::Label* labelErr;
    cocos2d::Node* node;
    cocos2d::ui::EditBox* nameEditBox;
    
    cocos2d::ui::Button* pictureHeader;
    cocos2d::ui::Button* cards;
    cocos2d::ui::Button* claimButton;
    cocos2d::ui::Button* closeButton;
    
    
    
    cocos2d::ui::Button* okButton;
    cocos2d::ui::Button* closeButton2;
    
    cocos2d::Vector<cocos2d::Label*> listCardsLabel;
    cocos2d::Vector<cocos2d::ui::Button*> listCardsButton;
    int dailyRewardDay;
    int dailyRewardWeek;
    cocos2d::ui::Button* myHeart;
    cocos2d::ui::Button* myGold;
    cocos2d::ui::Button* myImg;
    cocos2d::Label* valueTongDiem;
    cocos2d::Label* valueHeightScore;
    cocos2d::Label* valueDiamond;
    
    cocos2d::ui::Button* handButton;
    cocos2d::ui::Button* lock;
    cocos2d::ui::Button* lock2;
    cocos2d::ui::Button* mainActor;
    cocos2d::ui::Button* mainActorMiror;
    
    cocos2d::ui::Button* buttonCricleRed;
    cocos2d::Label* achievementLabel;
    float mainActorScale;
    
    int levelChallenge;
    int loaiPhepTinh;
    
	
    
	static cocos2d::Scene* createScene();
	std::string formatDate(const std::time_t& time);
    void createBg();
	void createButtonLearnPlayRateGift();
	void createButtonLearn();
	void createButtonSetting();
    void createInforDiemSo();
	void createButtonKey();
	void createValueKey();
    void createTemplateDailyReward(float w, float h);
    void createTemplateInputTen(float w, float h);
    void createTemplateChallenge();
    void claimHandle(float w, float h);
    void inputTenHandle(float w, float h);
    void animationChallenge();
    
    
	void createMainActor(float w, float h);
    void createMainActorMiror(float w, float h);
	// Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
	virtual bool init();

	// a selector callback
	void menuCloseCallback(cocos2d::Ref* pSender);

	// implement the "static create()" method manually
    CREATE_FUNC(HelloWorld);
};

#endif // __HELLOWORLD_SCENE_H__
