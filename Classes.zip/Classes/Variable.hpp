//
//  Variable.hpp
//  mentalmath-mobile
//
//  Created by Huy Le on 06/03/2024.
//

#ifndef Variable_hpp
#define Variable_hpp
#include <ctime>
#include <iostream>
#include <stdio.h>
#include <vector>
class Variable {
public:
    Variable(); // Constructor
    ~Variable(); // Destructor
   
private:
    
public:
    int soDiemShowPro;
    int showProSauBaoNhieuLan;
    bool isProVer;
    bool isProduction;
    bool hasTet;
    bool hasLePhucSinh;
    bool hasHaloween;
    int soGame;
    int diemVang;
    int diemXanh;
    int diemDo;
    int diemTim;
    int diemXanhDam;
    std::string languageTest;
    int soCauHoiDualModeTest;
    int showSoPhepTinhParentScreen;
    int soDiemMoKhoaGame4;
    int soDiemMoKhoaGame3;
    int soDiemMoKhoaGame2;
    const std::string soPhepTinhdungLienTiepString = "SO_PHEP_TINH_DUNG_LIEN_TIEP";
    const std::string soPhepTinhDungMoiNgayString = "SO_PHEP_TINH_DUNG_MOI_NGAY";
    
    static const int soPheptinhdungDatMedal1 = 1;//10
    static const int soPheptinhdungDatMedal2 = 2;//20
    static const int soPheptinhdungDatMedal3 = 3;
    static const int soPheptinhdungDatMedal4 = 4;
    static const int soPheptinhdungDatMedal5 = 5;
    std::string proProductionID;
    
    std::vector<std::string> emojiStart;
    std::vector<std::string> emojiEnd;
    
    std::vector<std::string> diemNgauNhienImg;
    std::vector<int> diemNgauNhien;
    std::vector<std::string> diemNgauNhienPhepTinh;
    
    std::vector<std::string> diemMayManImg;
    std::vector<int> diemMayMan;
    std::vector<std::string> diemMayManPhepTinh;
    
    std::vector<int> arrNhanVat;
    std::vector<int> arrPhiThuyen;
    std::vector<int> arrTenLua;
    
    float timeBasic;
    float timeHard;
    float timeVeryHard;
    
    float timeBasicNhan;
    float timeHardNhan;
    float timeVeryHardNhan;
    
    //cai dat cho play4
    int batDauHienCandyTuCauHoi;
    int batDauHienSaoChoiTuCauHoi;
    int batDauHienHoDenTuCauHoi;
    int batDauHienVirusTuCauHoi;
    int batDauTangChuyenDongVirusTuCauHoi;
    
    std::vector<int> arrDailyRewardType;
    std::vector<std::vector<int>> arrDailyRewardValue;
    std::vector<std::vector<int>> arrChallenge;
};
#endif /* Variable_hpp */
