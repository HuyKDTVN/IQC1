#include "play3.h"
#include "mathLevel.h"
#include "mathSelect.h"
#include "finish.h"
#include "SelectGame.hpp"
#include "ui/CocosGUI.h"
#include <SimpleAudioEngine.h>
#include <iostream>
#include <string>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "Huy_functions/CreatePhepToan.hpp"
#include "LanguageManager.h"
#include "IAPManager.h"

using namespace std;
USING_NS_CC;

int typeOfW3;
int levelOfW3;
int isMulti3 = false;
int backTypePT3 = 0;
bool fromChallenge3;
Scene* Play3::createScene(int type, int level, int backTypePhepTinh, bool fromChallenge)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    typeOfW3 = type;
    if(typeOfW3 == 1){
        isMulti3 = true;
    }
    levelOfW3 = level;
    fromChallenge3 = fromChallenge;
    // 'layer' is an autorelease object
    backTypePT3 = backTypePhepTinh;
    auto layer = Play3::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
// on "init" you need to initialize your instance
bool Play3::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }
    score = 0;
    if (UserDefault::getInstance()->getIntegerForKey("height-score", 99999) == 99999)
    {
        UserDefault::getInstance()->setIntegerForKey(HIGH_SCORE, 0);
        UserDefault::getInstance()->flush();
    }

    
    auto mLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    maxDoiSo = HuyFunctions().SoLonNhat(mLang);
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    wScenePlay = wScene;
    hScenePlay = hScene;
    ratioScreen = hScene / wScene;
    //log("test man SE: %i, %i, %.2f", hScenePlay, wScenePlay, double(hScenePlay / wScenePlay));

    hasGuide = false;
    //set bg
    //createBg(wScene, hScene);

    //countdown timer + loading bar
    //coundownTimer(wScene, hScene);
    //end: countdown timer + loading bar

    realType = typeOfW3;

    back(wScene, hScene);
    //createButtonKey(wScene, hScene);

    auto arr = CreatePhepToan().createAnswerQuestions(typeOfW3, levelOfW3, prevA, prevB, maxDoiSo);
    
    auto arrNoti = CreatePhepToan().createAnswerQuestions(typeOfW3, levelOfW3, prevA, prevB, maxDoiSo);
    UserDefault::getInstance()->setStringForKey("noti-title1", HuyFunctions().createPhepToanWithEmoji(arrNoti.at(2).c_str()));
    
    log("test improve function");
    //    0 - prevA
    //    1 - prevB
    //    2 - phepToan
    //    3 - correctAnswer
    //    4 - answer1
    //    5 - answer2
    //    6 - answer3
    //    7 - answer4
    prevA = std::stoi(arr.at(0));
    prevB = std::stoi(arr.at(1));
    phepToan = cocos2d::__String::createWithFormat("%s", arr.at(2).c_str());
    correctAnswer = std::stoi(arr.at(3));
    answer1 = std::stoi(arr.at(4));
    answer2 = std::stoi(arr.at(5));
    answer3 = std::stoi(arr.at(6));
    answer4 = std::stoi(arr.at(7));
    soA = std::stoi( arr.at(0) );
    soB = std::stoi ( arr.at(1));
    
    phepTinhSmallA = arr.at(9);
    phepTinhSmallB = arr.at(10);
    
    log("cau hoi: %s",  arr.at(2).c_str());
    log("4 dap an: %i, %i, %i, %i",  std::stoi(arr.at(4)), std::stoi(arr.at(5)), std::stoi(arr.at(6)), std::stoi(arr.at(7)));
    log("dap dung: %i",  std::stoi(arr.at(3)));
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", arr.at(8).c_str());
    
    //indexThemDiem = HuyFunctions().getRandomForThemDiem();
    
    createScore(wScene, hScene);
    createMainTemplate(wScene, hScene);
    createAnswer(wScene, hScene);

    //log("HUY ----- type: %i, level: %i", typeOfW3, levelOfW3);

    createBgColor(wScene, hScene);
    createLuckySpin(wScene, hScene);
    createPopupFinish(wScene, hScene);
    
    //log("hLoadingBar: %f", hLoadingBar);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(3);
    }
    lblPhepToan->setScale(0);
    buttonAnswer1->setScale(0);
    buttonAnswer2->setScale(0);
    buttonAnswer3->setScale(0);
    buttonAnswer4->setScale(0);
    
    if (sound == 0) {
        
        CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
        CocosDenshion::SimpleAudioEngine::getInstance()->unloadEffect("sound/lucky.wav");
        CocosDenshion::SimpleAudioEngine::getInstance()->unloadEffect("sound/lucky-done.wav");
        
        CocosDenshion::SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(0); // Đặt âm lượng cho âm thanh nền
        CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("sound/lucky.wav");
        CocosDenshion::SimpleAudioEngine::getInstance()->preloadBackgroundMusic("sound/lucky-done.wav");
        
    }
    
    rotateLuckySpin();
    //this->setKeypadEnabled(true);
    
    if (levelOfW3 == 1) {
        createTemplateGuideLevel1(wScene, hScene);
    } else {
        createTemplateGuideLevel2(wScene, hScene);
    }
    
    return true;
}
void Play3::createTemplateGuideLevel1(float w, float h) {
    if ( typeOfW3 == 4 or typeOfW3 == 5 or typeOfW3 == 6) {
        hasGuide = true;
    }
}

void Play3::createTemplateGuideLevel2(float w, float h) {
    if ( typeOfW3 == 4 or typeOfW3 == 5 or typeOfW3 == 6) {
        hasGuide = true;
    }
    
}
void Play3::createTemplateGuideLevel1Cong(float w, float h) {
    
    auto viTriTenLua = UserDefault::getInstance()->getIntegerForKey("tenluadachon", 0) + 1;
    auto iconTenLua = StringUtils::format("icon-ten-lua-%d.png", viTriTenLua);
    
    float wLuoi = w / 10;
    int step = 1;
    for (int i = 1; i <= soA; i++) {
        auto iconSoA = Sprite::create(iconTenLua.c_str());
        iconSoA->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * 0.65));
        float ratioiconSoA = 12;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoA = w / ratioiconSoA / iconSoA->getContentSize().width;
        iconSoA->setScale(scaleiconSoA);
        this->addChild(iconSoA, 2);
        listIcon.pushBack(iconSoA);
        
        float ratiobgNumber = 12;
        float fixIpad = 1;
        if (h / w <= 1.53) {
            ratiobgNumber = 20;
            fixIpad = 0.8;
        }
        
        auto bgNumber = ui::Button::create("bgNumber 2.png");
        bgNumber->setPosition(Vec2(iconSoA->getPositionX(), iconSoA->getPositionY() + iconSoA->getContentSize().height * scaleiconSoA * 1.2 * fixIpad)); // Đặt vị trí
        
        float scalebgNumber = w / ratiobgNumber / bgNumber->getContentSize().width;
        bgNumber->setScale(scalebgNumber);
        bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", i)->getCString());
        bgNumber->setTitleFontName("Arial-BoldMT");
        bgNumber->setTitleColor(Color3B().WHITE);
        bgNumber->setTitleFontSize(0.12 * w * fixIpad);
        this->addChild(bgNumber, 2);
        listBgNumber.pushBack(bgNumber);
        step++;
    }
    
    float ratiobgNumber = 12;
    float fixIpad = 1;
    float fixHeightIpad = 0.55;
    if (h / w < 1.8 && h / w > 1.53) {
        fixHeightIpad = 0.52;
    }
    if (h / w <= 1.53) {
        ratiobgNumber = 20;
        fixIpad = 0.8;
        fixHeightIpad = 0.52;
    }
    
    for (int i = 1; i <= soB + 1; i++) {
        auto iconSoB = Sprite::create(iconTenLua.c_str());
        iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * fixHeightIpad));
        if (i == soB + 1) {
            iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (soB - 1) * wLuoi, h * fixHeightIpad));
        }
        float ratioiconSoB = 12;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoB = w / ratioiconSoB / iconSoB->getContentSize().width;
        iconSoB->setScale(scaleiconSoB);
        this->addChild(iconSoB, 2);
        listIcon.pushBack(iconSoB);
        
        auto bgNumber = ui::Button::create("bgNumber 2.png");
        bgNumber->setPosition(Vec2(iconSoB->getPositionX(), iconSoB->getPositionY() + iconSoB->getContentSize().height * scaleiconSoB * 1.2 * fixIpad)); // Đặt vị trí
       
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scalebgNumber = w / ratiobgNumber / bgNumber->getContentSize().width;
        bgNumber->setScale(scalebgNumber);
        bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", step)->getCString());
        if (i == soB + 1) {
            
            iconSoB->setTag(100);
            bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", soB + soA)->getCString());
            bgNumber->setTag(100);
        }
        bgNumber->setTitleFontName("Arial-BoldMT");
        bgNumber->setTitleColor(Color3B().WHITE);
        bgNumber->setTitleFontSize(0.12 * w * fixIpad);
        this->addChild(bgNumber, 2);
        listBgNumber.pushBack(bgNumber);
        step++;
    }
    
    int step1 = 0;
    float scale;
    for (auto icon : listIcon) {
        if(icon) {
            if (step1 == 0) {
                scale = icon->getScale();
            }
            if (step1 < soA + soB) {
                icon->setScale(0);
                icon->runAction(Sequence::create(DelayTime::create(1.5 + step1 * 0.6), ScaleTo::create(0.3, scale), NULL));
            } else{
                icon->setScale(0);
            }
            
            step1++;
        }
    }
    int step2 = 0;
    for (auto button : listBgNumber) {
        if(button) {
            if (step2 == 0) {
                scale = button->getScale();
            }
            if (step2 < soA + soB) {
                button->setScale(0);
                button->runAction(Sequence::create(DelayTime::create(1.5 + step2 * 0.6 ), ScaleTo::create(0.3, scale), NULL));//(1.5 + step1 * 0.6 + step2 * 0.5)
            } else{
                button->setScale(0);
                auto moveToDapAn = CallFunc::create([button, this]() {
                    button->runAction(
                            Sequence::create(
                                Spawn::create(
                                    ScaleTo::create(0.6, button->getScale() * 1.5),
                                    MoveTo::create(0.6, Vec2(lblPhepToan->getPositionX() + lblPhepToan->getContentSize().width * lblPhepToan->getScale() / 2, lblPhepToan->getPositionY())),
                                    nullptr),
                                FadeOut::create(0.2),
                            NULL)
                        );
                });
                button->runAction(Sequence::create(DelayTime::create(1.5 + step2 * 0.6), ScaleTo::create(0, scale), moveToDapAn, NULL)); //1.5 + step1 * 0.6 + step2 * 0.5
                
            }
            step2++;
        }
    }
    
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                    }
                    
                    lblPhepToan->runAction(
                        Sequence::create(
                             FadeOut::create(0.3),
                             CallFunc::create([this]() {
                                lblPhepToan->setString(cocos2d::__String::createWithFormat("%d + %d = ?", soA, soB)->getCString());
                                // Thêm câu lệnh khác nếu cần
                             }),
                             FadeIn::create(0.2), NULL));
                    if (hasGuide) {
                        createTemplateGuideLevel1Cong(wScenePlay, hScenePlay);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    
    float timeFinish = 1.5 + step1 * 0.6; //1.5 + step1 * 0.6 + step2 * 0.5
    buttonOK->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(timeFinish), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2
    
    buttonRetry->setScale(0);
    
    lblPhepToan->runAction(
        Sequence::create(
             DelayTime::create(timeFinish + 0.2),
             FadeOut::create(0.1),
             ScaleTo::create(0, 2),
             CallFunc::create([this]() {
                lblPhepToan->setString(cocos2d::__String::createWithFormat("%d + %d = %d", soA, soB, soA + soB)->getCString());
                 if (sound == 0)
                 {
                     CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                 }
                // Thêm câu lệnh khác nếu cần
             }),
             Spawn::create(FadeIn::create(0.2), ScaleTo::create(0.2, 1), nullptr), NULL));

    buttonRetry->runAction(Sequence::create(DelayTime::create(timeFinish + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
    
}

void Play3::createTemplateGuideLevel2Cong(float w, float h) {
    
    int congDonVi = HuyFunctions().getSoHangDonVi(soA) + HuyFunctions().getSoHangDonVi(soB);
    
    lblPhepToan->runAction(FadeOut::create(0.1));
    lblPhepToan->setPosition(Vec2(w/2, h/2));
    auto fontStyle = "fonts/DeliusSwashCaps.ttf";
    float fontSize = 0.18 * w;
    if (h / w > 1.53 && h / w <= 1.8){
        fontSize = 0.15 * w;
    }
    if (h / w <= 1.53)
    {
        fontSize = 0.09 * w;
    }

    float time = 0.2;
    float width = 50.0f;
    float fixWithIpad = 1.0f;
    if (h / w <= 1.53)
    {
        fixWithIpad = 0.5f;
    }
    if (levelOfW3 > 1) {
        width = 70.0f;
    }
    float height = 3.0f * fixWithIpad;
    width = width * fixWithIpad;
    cocos2d::Vec2 origin(w / 2 - width / 2 - 16 * fixWithIpad, lblPhepToan->getPositionY() + lblPhepToan->getContentSize().height / 2);
    gachChan = HuyFunctions().createChuNhatBoGoc(width, height, origin);
    this->addChild(gachChan, 2);
    
    lblB = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soB))->getCString(), fontStyle, fontSize);
    float xLblB = w / 2;
    lblB->setPosition(Vec2(xLblB, lblPhepToan->getPositionY() + lblPhepToan->getContentSize().height * 1.2));
    addChild(lblB, 2);
    lblB->setAlignment(TextHAlignment:: CENTER);
    lblB->setOpacity(0);
    lblB->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    if (soB > 9) {
        lblBHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soB))->getCString(), fontStyle, fontSize);
        
        lblBHangChuc->setPosition(Vec2(lblB->getPositionX() - lblB->getContentSize().height * 0.51, lblB->getPositionY()));
        addChild(lblBHangChuc, 2);
        lblBHangChuc->setAlignment(TextHAlignment:: CENTER);
        lblBHangChuc->setOpacity(0);
        lblBHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    }
    
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", "+");
    
    lblLoaiPhepTinh = Label::createWithTTF(loaiPhepTinh->getCString(), fontStyle, fontSize);
    lblLoaiPhepTinh->setPosition(Vec2(w/2 - lblB->getContentSize().height * 0.82, lblB->getPositionY() + lblB->getContentSize().height / 2));
    addChild(lblLoaiPhepTinh, 2);
    lblLoaiPhepTinh->setOpacity(0);
    lblLoaiPhepTinh->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblA = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA))->getCString(), fontStyle, fontSize);
    lblA->setPosition(Vec2(w / 2, lblLoaiPhepTinh->getPositionY() + lblLoaiPhepTinh->getContentSize().height / 2));
    addChild(lblA, 2);
    lblA->setAlignment(TextHAlignment:: CENTER);
    lblA->setOpacity(0);
    lblA->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblAHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA))->getCString(), fontStyle, fontSize);
    lblAHangChuc->setPosition(Vec2(lblA->getPositionX() - lblA->getContentSize().height * 0.51, lblA->getPositionY()));
    addChild(lblAHangChuc, 2);
    lblAHangChuc->setOpacity(0);
    lblAHangChuc->setAlignment(TextHAlignment:: CENTER);
    lblAHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA + soB))->getCString(), fontStyle, fontSize);
    lblDapAnHangDV->setPosition(Vec2(w / 2, lblB->getPositionY() - lblB->getContentSize().height * 1.1));
    addChild(lblDapAnHangDV, 2);
    lblDapAnHangDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnHangDV->setOpacity(0);
    //lblDapAnHangDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA + soB))->getCString(), fontStyle, fontSize);
    if (congDonVi > 9) {
        lblDapAnHangChuc->setString(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA + soB) - 1)->getCString());
    }
    lblDapAnHangChuc->setPosition(Vec2(lblAHangChuc->getPositionX(), lblDapAnHangDV->getPositionY()));
    addChild(lblDapAnHangChuc, 2);
    lblDapAnHangChuc->setOpacity(0);
    lblDapAnHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    
    
    lblDapAnPhanNhoDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(congDonVi))->getCString(), fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoDV->setPosition(Vec2(w * 0.8, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoDV, 2);
    lblDapAnPhanNhoDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnPhanNhoDV->setOpacity(0);
    //lblDapAnPhanNhoDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnPhanNhoHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(congDonVi))->getCString(), fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoHangChuc->setPosition(Vec2(lblDapAnPhanNhoDV->getPositionX() - lblDapAnPhanNhoDV->getContentSize().height * 0.51, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoHangChuc, 2);
    lblDapAnPhanNhoHangChuc->setOpacity(0);
    lblDapAnPhanNhoHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnPhanNhoHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    
    if (flagB1ChuSo) {
        xLblB = w / 2 + (lblA->getContentSize().width - lblB->getContentSize().width) / 2;
        lblB->setPosition(Vec2(xLblB, lblB->getPositionY()));
    }
    //animation cho hang don vi - phong to
    float timeAnimate = 0.2;
    float delayTime = 2;
    float fixTimeCoNho = 0;
    if (congDonVi > 9) {
        fixTimeCoNho = 2;
    }
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    
    log("cong don vi: %i", congDonVi);
    auto playSound = CallFunc::create([this]() {
        if (sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
    });
    
    auto congCaPhanNho = CallFunc::create([this]() {
        if (sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
        lblDapAnHangChuc->setString(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA + soB))->getCString());
    });
    
    if (congDonVi > 9) { // co nho
        lblDapAnPhanNhoDV->runAction(
            Sequence::create(
                DelayTime::create(delayTime + 0.5),
                Spawn::create(
                           FadeIn::create(timeAnimate),
                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                           TintTo::create(timeAnimate, Color3B::YELLOW),
                           //move to lblDapAnHangDV
                           
                           nullptr),
                 DelayTime::create(2),
                 MoveTo::create(timeAnimate * 3, Vec2(lblDapAnHangDV->getPositionX(), lblDapAnHangDV->getPositionY())),
                 FadeOut::create(timeAnimate)
                , NULL)
            );
            lblDapAnPhanNhoHangChuc->runAction(
                Sequence::create(
                    DelayTime::create(delayTime + 0.5),
                         Spawn::create(
                               FadeIn::create(timeAnimate),
                               ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                               TintTo::create(timeAnimate, Color3B::YELLOW),
                               
                               nullptr),
                     DelayTime::create(5.5),
                     MoveTo::create(timeAnimate * 3, Vec2(lblDapAnHangChuc->getPositionX(), lblDapAnHangChuc->getPositionY())),
                     //DelayTime::create(1),
                     FadeOut::create(timeAnimate)
                                 
                    , NULL)
                );
    }
    lblDapAnHangDV->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 0.5),
                 Spawn::create(
                       FadeIn::create(timeAnimate),
                       ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                        playSound,
                       TintTo::create(timeAnimate, Color3B::GREEN),
                       nullptr)
            , NULL)
        );
    
    //hang don vi - thu nho va hien dap an don vi
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    
    
    lblDapAnHangDV->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(
                    ScaleTo::create(timeAnimate, lblB->getScale()),
                    
                    TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    if (congDonVi > 9) {
        lblDapAnHangChuc->runAction(
            Sequence::create(
                             DelayTime::create(delayTime + fixTimeCoNho * 1.3 + 3),
                     Spawn::create(
                           FadeIn::create(timeAnimate),
                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                            playSound,
                           TintTo::create(timeAnimate, Color3B::GREEN),
                           
                           nullptr),
                             DelayTime::create(1),
                             congCaPhanNho
                , NULL)
            );
    } else {
        lblDapAnHangChuc->runAction(
            Sequence::create(
                             DelayTime::create(delayTime + fixTimeCoNho * 1.3 + 3),
                     Spawn::create(
                           FadeIn::create(timeAnimate),
                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                            playSound,
                           TintTo::create(timeAnimate, Color3B::GREEN),
                           nullptr)
                , NULL)
            );
    }
    
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                DelayTime::create(delayTime + fixTimeCoNho + 2.5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
        
    }
    
    lblAHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2.5),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    
    lblDapAnHangChuc->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 3),
                 Spawn::create(
                       FadeIn::create(timeAnimate),
                       ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                        playSound,
                       TintTo::create(timeAnimate, Color3B::GREEN),
                       nullptr)
            , NULL)
        );
    //hang chuc thu nho
    
    lblAHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()),
            TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                DelayTime::create(delayTime + fixTimeCoNho + 5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()),
                TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
                , NULL)
            );
    }
    
    lblDapAnHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho* 1.5 + 5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()),
            TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    //2 button retry va OK
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    //float fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                        removeChild(lblA);
                        removeChild(lblAHangChuc);
                        removeChild(lblB);
                        removeChild(lblBHangChuc);
                        removeChild(gachChan);
                        removeChild(lblDapAnHangDV);
                        removeChild(lblDapAnHangChuc);
                        removeChild(lblDapAnPhanNhoDV);
                        removeChild(lblDapAnPhanNhoHangChuc);
                    }
                    
                    if (hasGuide) {
                        createTemplateGuideLevel2Cong(wScenePlay, hScenePlay);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    buttonOK->setScale(0);
    buttonRetry->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 5), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2

    buttonRetry->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 5 + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
}
void Play3::createTemplateGuideLevel2Tru(float w, float h) {
    bool flagCoNho = false;
    int congDonVi = 0;
    float fixWithCoNho = 1;
    if ( HuyFunctions().getSoHangDonVi(soA) - HuyFunctions().getSoHangDonVi(soB) < 0) {
        congDonVi = 10 + HuyFunctions().getSoHangDonVi(soA) - HuyFunctions().getSoHangDonVi(soB);
        flagCoNho = true;
        fixWithCoNho = 1.25;
    } else {
        congDonVi = HuyFunctions().getSoHangDonVi(soA) - HuyFunctions().getSoHangDonVi(soB);
    }
    
    
    lblPhepToan->runAction(FadeOut::create(0.1));
    lblPhepToan->setPosition(Vec2(w/2, h/2));
    auto fontStyle = "fonts/DeliusSwashCaps.ttf";
    float fontSize = 0.18 * w;
    if (h / w > 1.53 && h / w <= 1.8){
        fontSize = 0.15 * w;
        fixWithCoNho = 1.4;
    }
    if (h / w <= 1.53)
    {
        fontSize = 0.09 * w;
    }

    float time = 0.2;
    float width = 50.0f;
    float fixWithIpad = 1.0f;
    if (h / w <= 1.53)
    {
        fixWithIpad = 0.5f;
    }
    if (levelOfW3 > 1) {
        width = 70.0f;
    }
    float height = 3.0f * fixWithIpad;
    width = width * fixWithIpad;
    cocos2d::Vec2 origin(w / 2 - width / 2 - 16 * fixWithIpad, lblPhepToan->getPositionY() + lblPhepToan->getContentSize().height / 2);
    gachChan = HuyFunctions().createChuNhatBoGoc(width, height, origin);
    this->addChild(gachChan, 2);
    
    lblB = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soB))->getCString(), fontStyle, fontSize);
    float xLblB = w / 2;
    lblB->setPosition(Vec2(xLblB, lblPhepToan->getPositionY() + lblPhepToan->getContentSize().height * 1.2));
    addChild(lblB, 2);
    lblB->setAlignment(TextHAlignment:: CENTER);
    lblB->setOpacity(0);
    lblB->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    if (soB > 9) {
        lblBHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soB))->getCString(), fontStyle, fontSize);
        
        lblBHangChuc->setPosition(Vec2(lblB->getPositionX() - lblB->getContentSize().height * 0.51 * fixWithCoNho, lblB->getPositionY()));
        addChild(lblBHangChuc, 2);
        lblBHangChuc->setAlignment(TextHAlignment:: CENTER);
        lblBHangChuc->setOpacity(0);
        lblBHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    }
    
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", "-");
    
    lblLoaiPhepTinh = Label::createWithTTF(loaiPhepTinh->getCString(), fontStyle, fontSize);
    lblLoaiPhepTinh->setPosition(Vec2(w/2 - lblB->getContentSize().height * 0.82 * fixWithCoNho, lblB->getPositionY() + lblB->getContentSize().height * 0.55));
    addChild(lblLoaiPhepTinh, 2);
    lblLoaiPhepTinh->setOpacity(0);
    lblLoaiPhepTinh->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblA = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA))->getCString(), fontStyle, fontSize);
    lblA->setPosition(Vec2(w / 2, lblLoaiPhepTinh->getPositionY() + lblLoaiPhepTinh->getContentSize().height * 0.4));
    addChild(lblA, 2);
    lblA->setAlignment(TextHAlignment:: CENTER);
    lblA->setOpacity(0);
    lblA->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblAHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA))->getCString(), fontStyle, fontSize);
    lblAHangChuc->setPosition(Vec2(lblA->getPositionX() - lblA->getContentSize().height * 0.51 * fixWithCoNho, lblA->getPositionY()));
    addChild(lblAHangChuc, 2);
    lblAHangChuc->setOpacity(0);
    lblAHangChuc->setAlignment(TextHAlignment:: CENTER);
    lblAHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA - soB))->getCString(), fontStyle, fontSize);
    lblDapAnHangDV->setPosition(Vec2(w / 2, lblB->getPositionY() - lblB->getContentSize().height * 1.1 * fixWithCoNho * 0.9));
    addChild(lblDapAnHangDV, 2);
    lblDapAnHangDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnHangDV->setOpacity(0);
    //lblDapAnHangDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA - soB))->getCString(), fontStyle, fontSize);
    lblDapAnHangChuc->setPosition(Vec2(lblAHangChuc->getPositionX(), lblDapAnHangDV->getPositionY()));
    addChild(lblDapAnHangChuc, 2);
    lblDapAnHangChuc->setOpacity(0);
    lblDapAnHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    
    lblDapAnPhanNhoDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(congDonVi))->getCString(), fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoDV->setPosition(Vec2(w * 0.8, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoDV, 2);
    lblDapAnPhanNhoDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnPhanNhoDV->setOpacity(0);
    //lblDapAnPhanNhoDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnPhanNhoHangChuc = Label::createWithTTF("1", fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoHangChuc->setPosition(Vec2(lblDapAnPhanNhoDV->getPositionX() - lblDapAnPhanNhoDV->getContentSize().height * 0.51, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoHangChuc, 2);
    lblDapAnPhanNhoHangChuc->setOpacity(0);
    lblDapAnPhanNhoHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnPhanNhoHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    auto playSound = CallFunc::create([this]() {
        if (sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
    });
    
    if (flagB1ChuSo) {
        xLblB = w / 2 + (lblA->getContentSize().width - lblB->getContentSize().width) / 2;
        lblB->setPosition(Vec2(xLblB, lblB->getPositionY()));
    }
    //animation cho hang don vi - phong to
    float timeAnimate = 0.2;
    float delayTime = 2;
    float fixTimeCoNho = 0;
    if (flagCoNho) {
        fixTimeCoNho = 2;
    }
    if (flagCoNho) {
        float timePlay = 0.07f;
        auto rotateLeft = RotateBy::create(timePlay, -5.0f); // Rotate left by 10 degrees
        auto rotateRight = RotateBy::create(timePlay, 10.0f); // Rotate right by 20 degrees (to 10 degrees right)
        auto rotateBack = RotateBy::create(timePlay, -5.0f); // Rotate back to center

        // Create a sequence and repeat it forever
        auto tiltSequence = Sequence::create( rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack, nullptr);
       
        lblB->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(
                              ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                              TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
                DelayTime::create(1),
                tiltSequence,
                NULL)

            );
        rotateLeft = RotateBy::create(timePlay * 0.9, -5.0f); // Rotate left by 10 degrees
        rotateRight = RotateBy::create(timePlay * 0.9, 10.0f); // Rotate right by 20 degrees (to 10 degrees right)
        rotateBack = RotateBy::create(timePlay * 0.9, -5.0f); // Rotate back to center

        // Create a sequence and repeat it forever
        tiltSequence = Sequence::create( rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack, nullptr);
        
        lblA->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
                             DelayTime::create(1),
                             tiltSequence
                , NULL)
            );
    } else {
        lblB->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
        lblA->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
    }
    
    
    log("cong don vi: %i", congDonVi);
    
    if (flagCoNho) { // co nho
//        lblDapAnPhanNhoDV->runAction(
//            Sequence::create(
//                DelayTime::create(delayTime + 0.5),
//                Spawn::create(
//                           FadeIn::create(timeAnimate),
//                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.2),
//                           TintTo::create(timeAnimate, Color3B::YELLOW),
//                           //move to lblDapAnHangDV
//
//                           nullptr),
//                 DelayTime::create(2),
//                 MoveTo::create(timeAnimate * 3, Vec2(lblDapAnHangDV->getPositionX(), lblDapAnHangDV->getPositionY())),
//                 FadeOut::create(timeAnimate)
//                , NULL)
//            );
        auto positionPhanNho = Vec2(lblDapAnPhanNhoHangChuc->getPosition());
        
        auto changeText = CallFunc::create([this]() {
            lblDapAnPhanNhoHangChuc->setString("-1");
        });
        
        lblDapAnPhanNhoHangChuc->setPosition(Vec2(lblA->getPositionX() - lblA->getContentSize().width * 0.8, lblA->getPositionY())); // - lblA->getContentSize().width / 2)
            lblDapAnPhanNhoHangChuc->runAction(
                Sequence::create(
                    DelayTime::create(delayTime + 1.5 + 0.5),
                         Spawn::create(
                               FadeIn::create(timeAnimate),
                               ScaleTo::create(timeAnimate, lblB->getScale() * 0.7),
                                TintTo::create(timeAnimate, Color3B::GREEN),
                               nullptr),
                     DelayTime::create(2.5),
                     MoveTo::create(timeAnimate, positionPhanNho),
                     
                     DelayTime::create(2),
                                 Spawn::create(
                                        MoveTo::create(timeAnimate * 2, Vec2(lblDapAnHangChuc->getPositionX(), lblDapAnHangChuc->getPositionY() + lblDapAnHangChuc->getContentSize().height / 2)),
                                    changeText,
                                       nullptr),
                                 
                     DelayTime::create(2),
                     FadeOut::create(timeAnimate)
                    , NULL)
                );
    }
    lblDapAnHangDV->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 1.2 + 1),
                 Spawn::create(
                       FadeIn::create(timeAnimate),
                       ScaleTo::create(timeAnimate, lblB->getScale() * 1.2),
                        playSound,
                       TintTo::create(timeAnimate, Color3B::GREEN),
                       nullptr)
            , NULL)
        );
    
    //hang don vi - thu nho va hien dap an don vi
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    lblDapAnHangDV->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
//    lblB->runAction(
//        Sequence::create(
//            DelayTime::create(delayTime),
//            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
//            , NULL)
//        );
    lblAHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho * 1.8 + 2.5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2),
                          
                          TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                             DelayTime::create(delayTime + fixTimeCoNho * 1.8 + 2.5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
    }
    
    lblDapAnHangChuc->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 2 + 4),
                 Spawn::create(
                       FadeIn::create(timeAnimate),
                       ScaleTo::create(timeAnimate, lblB->getScale() * 1.2),
                        playSound,
                       TintTo::create(timeAnimate, Color3B::GREEN),
                       nullptr)
            , NULL)
        );
    
    
    //hang chuc thu nho
    
    lblAHangChuc->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
                , NULL)
            );
    }
    
    lblDapAnHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 6),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    //2 button retry va OK
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    float fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                        removeChild(lblA);
                        removeChild(lblAHangChuc);
                        removeChild(lblB);
                        removeChild(lblBHangChuc);
                        removeChild(gachChan);
                        removeChild(lblDapAnHangDV);
                        removeChild(lblDapAnHangChuc);
                        removeChild(lblDapAnPhanNhoDV);
                        removeChild(lblDapAnPhanNhoHangChuc);
                    }
                    
                    if (hasGuide) {
                        createTemplateGuideLevel2Tru(wScenePlay, hScenePlay);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    buttonOK->setScale(0);
    buttonRetry->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 6), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2

    buttonRetry->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 6 + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
}
void Play3::createTemplateGuideLevel1Tru(float w, float h) {
    auto viTriTenLua = UserDefault::getInstance()->getIntegerForKey("tenluadachon", 0) + 1;
    auto iconTenLua = StringUtils::format("icon-ten-lua-%d.png", viTriTenLua);
    float wLuoi = w / 10;
    int step = 1;
    for (int i = 1; i <= soA + 1; i++) {
        // create Phi thuyen
        auto viTriPhiThuyen = UserDefault::getInstance()->getIntegerForKey("phithuyendachon", 0) + 1;
        auto sprite_cachePhiThuyen = SpriteFrameCache::getInstance();
        sprite_cachePhiThuyen->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d1.plist", viTriPhiThuyen));
        Vector<SpriteFrame*> phiThuyen;
        phiThuyen.reserve(2);
        phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1a.png", viTriPhiThuyen)));
        phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1b.png", viTriPhiThuyen)));
        Animation* animationPhiThuyen = Animation::createWithSpriteFrames(phiThuyen, 0.2f, -1);
        Animate* animatePhiThuyen = Animate::create(animationPhiThuyen);

        auto iconSoA = Sprite::createWithSpriteFrame(phiThuyen.front());
        iconSoA->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * 0.65));
        if (i == soA + 1) {
            iconSoA->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 2) * wLuoi, h * 0.65));
        }
        float ratioiconSoA = 12;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoA = w / ratioiconSoA / iconSoA->getContentSize().width;
        iconSoA->setScale(scaleiconSoA);
        this->addChild(iconSoA, 2);
        iconSoA->runAction(animatePhiThuyen);
        iconSoA->setTag(i);
        listIcon.pushBack(iconSoA);
        
        float ratiobgNumber = 12;
        float fixIpad = 1;
        if (h / w <= 1.53) {
            ratiobgNumber = 20;
            fixIpad = 0.8;
        }
        
        if (i <= soA + 1 && i > soB) {
            auto bgNumber = ui::Button::create("bgNumber 2.png");
            bgNumber->setPosition(Vec2(iconSoA->getPositionX(), iconSoA->getPositionY() + iconSoA->getContentSize().height * scaleiconSoA * 1.2 * fixIpad)); // Đặt vị trí
            
            float scalebgNumber = w / ratiobgNumber / bgNumber->getContentSize().width;
            bgNumber->setScale(scalebgNumber);
            bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", i - soB)->getCString());
            if (i == soA + 1) {
                
             
                bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", i - 1 - soB )->getCString());
        
            }
            bgNumber->setTitleFontName("Arial-BoldMT");
            bgNumber->setTitleColor(Color3B().WHITE);
            bgNumber->setTitleFontSize(0.12 * w * fixIpad);
            this->addChild(bgNumber, 2);
            listBgNumber.pushBack(bgNumber);
        }

        step++;
    }
    float ratiobgNumber = 12;
    float fixIpad = 1;
    float fixHeightIpad = 0.55;
    if (h / w < 1.8 && h / w > 1.53) {
        fixHeightIpad = 0.52;
    }
    if (h / w <= 1.53) {
        ratiobgNumber = 20;
        fixIpad = 0.8;
        fixHeightIpad = 0.52;
    }
    for (int i = 1; i <= soB; i++) {
        auto iconSoB = Sprite::create(iconTenLua.c_str());
        iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * fixHeightIpad));
        if (i == soB + 1) {
            iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (soB - 1) * wLuoi, h * fixHeightIpad));
        }
        float ratioiconSoB = 18;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoB = w / ratioiconSoB / iconSoB->getContentSize().width;
        iconSoB->setScale(scaleiconSoB);
        iconSoB->setRotation(-45);
        iconSoB->setTag(i);
        this->addChild(iconSoB, 2);
        listIconTru.pushBack(iconSoB);
        
        step++;
    }
    
    float time = 0;
    int step1 = 0;
    float scale;
    for (auto icon : listIcon) {
        if(icon) {
            if (step1 == 0) {
                scale = icon->getScale();
            }
            icon->setScale(0);
            time = 1.5 + step1 * 0.25;
            icon->runAction(Sequence::create(DelayTime::create(time), ScaleTo::create(0.3, scale), NULL));
            
            step1++;
        }
    }
    
    step1 = 0;
    for (auto icon : listIconTru) {
        if(icon) {
            if (step1 == 0) {
                scale = icon->getScale();
            }
            icon->setScale(0);
            time = time + 0.1;
            icon->runAction(Sequence::create(DelayTime::create(time), ScaleTo::create(0.3, scale), NULL));
            step1++;
        }
    }
    step1 = 0;
    
    time = time + 0.8;
    for (auto icon : listIconTru) {
        if (icon) {
            time = time + 0.3f;
            
            cocos2d::Vec2 position = Vec2(icon->getPositionX(), h * 0.65f);
            // Tạo hiệu ứng di chuyển và mờ dần
            auto moveAction = MoveTo::create(0.4f, position);
            auto fadeOut = FadeTo::create(0.2f, 0);
            // Callback để xử lý hành động sau khi icon biến mất
            auto callback = CallFunc::create([this, icon, position]() {
                for (auto phithuyen : listIcon) {
                    if (phithuyen && phithuyen->getTag() == icon->getTag()) {
                        phithuyen->runAction(Sequence::create(
                                //DelayTime::create(0.4),
                                FadeOut::create(0.2f), NULL)
                        );
                        //createGuideBom(scale, position);
                    }
                
                }
                

            });

            // Chạy hành động với easing
            icon->runAction(
                //EaseExponentialIn::create(
                    Sequence::create(
                        DelayTime::create(time),
                        moveAction,
                        callback,
                        fadeOut,
                        nullptr
                    )
                //)
            );

            step1++;
        }
    }

    int step2 = 0;
    for (auto button : listBgNumber) {
        if(button) {
            if (step2 == 0) {
                scale = button->getScale();
            }
            if (step2 < soA - soB) {
                button->setScale(0);
                button->runAction(Sequence::create(DelayTime::create(time + 1 + step2 * 0.6 ), ScaleTo::create(0.3, scale), NULL));//(1.5 + step1 * 0.6 + step2 * 0.5)
            } else{
                button->setScale(0);
                auto moveToDapAn = CallFunc::create([button, this]() {
                    button->runAction(
                            Sequence::create(
                                Spawn::create(
                                    ScaleTo::create(0.6, button->getScale() * 1.5),
                                    MoveTo::create(0.6, Vec2(lblPhepToan->getPositionX() + lblPhepToan->getContentSize().width * lblPhepToan->getScale() / 2, lblPhepToan->getPositionY())),
                                    nullptr),
                                FadeOut::create(0.2),
                            NULL)
                        );
                });
                button->runAction(Sequence::create(DelayTime::create(time + 1 + step2 * 0.6), ScaleTo::create(0, scale), moveToDapAn, NULL)); //1.5 + step1 * 0.6 + step2 * 0.5
                time = time + 1 + step2 * 0.6;
                
            }
            step2++;
        }
    }
    
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    listIconTru.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                    }
                    
                    lblPhepToan->runAction(
                        Sequence::create(
                             FadeOut::create(0.3),
                             CallFunc::create([this]() {
                                lblPhepToan->setString(cocos2d::__String::createWithFormat("%d - %d = ?", soA, soB)->getCString());
                                // Thêm câu lệnh khác nếu cần
                             }),
                             FadeIn::create(0.2), NULL));
                    if (hasGuide) {
                        createTemplateGuideLevel1Tru(wScenePlay, hScenePlay);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    
    float timeFinish = time + 0.6;
    buttonOK->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(timeFinish), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2
    
    buttonRetry->setScale(0);
    
    lblPhepToan->runAction(
        Sequence::create(
             DelayTime::create(timeFinish + 0.2),
             FadeOut::create(0.1),
             ScaleTo::create(0, 2),
             CallFunc::create([this]() {
                lblPhepToan->setString(cocos2d::__String::createWithFormat("%d - %d = %d", soA, soB, soA - soB)->getCString());
                 if (sound == 0)
                 {
                     CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                 }
                // Thêm câu lệnh khác nếu cần
             }),
             Spawn::create(FadeIn::create(0.2), ScaleTo::create(0.2, 1), nullptr), NULL));

    buttonRetry->runAction(Sequence::create(DelayTime::create(timeFinish + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
    
}
void Play3::createBg(float wScene, float hScene) {
//    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
//    auto imageName = "bg-kid-top-3.png";
//    if (hScene / wScene <= 1.53)
//    {
//        imageName = "bg-top-ipad.png";
//
//    }
//    auto bgTopKid = ui::Button::create(imageName); // tao button
//    float ratioButtonkidTop = 1;
//    float scaleButtonKidTop = wScene / ratioButtonkidTop / bgTopKid->getContentSize().width;
//    bgTopKid->setScale(scaleButtonKidTop);
//    float yButtonKidTop = hScene - bgTopKid->getContentSize().height / 2 * scaleButtonKidTop;
//    float xButtonKidTop = bgTopKid->getContentSize().width / 2 * scaleButtonKidTop;
//    bgTopKid->setPosition(Vec2(xButtonKidTop, yButtonKidTop));
//    bgTopKid->setEnabled(false);
//    this->addChild(bgTopKid);//add button vao scene
//
//    auto imageNameBottom = "bg-kid.png";
//    if (hScene / wScene <= 1.53)
//    {
//        imageNameBottom = "bg-bottom-ipad.png";
//
//    }
//
//    auto bgKid = ui::Button::create(imageNameBottom); // tao button
//    float ratioButtonkid = 1;
//    float scaleButtonKid = wScene / ratioButtonkid / bgKid->getContentSize().width;
//    bgKid->setScale(scaleButtonKid);
//    float yButtonKid = 0 + bgKid->getContentSize().height / 2 * scaleButtonKid;
//    float xButtonKid = 0 + bgKid->getContentSize().width / 2 * scaleButtonKid;
//    bgKid->setPosition(Vec2(xButtonKid, yButtonKid));
//    bgKid->setEnabled(false);
//    this->addChild(bgKid);//add button vao scene
}

void Play3::createBgColor(float w, float h) {
    //create bg color
    auto bgColor = ui::Button::create("bg-oceanjpg.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    if (ratioScreen <= 1.8)
    {
        //ytitle = 1.06 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    if (ratioScreen <= 1.53)
    {
        //ytitle = 1.3 * h - (bgColor->getContentSize().height / 2 * scalebgColor);
    }
    //bgColor->setPosition(Vec2(w / 2, ytitle));
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));

    bgColor->setEnabled(true);
    this->addChild(bgColor, 1);
    
    
}
void Play3::createPopupFinish(float w, float h) {
    //int bgIndex = cocos2d::RandomHelper::random_int(1, 4);
    //popupthanhCong = ui::Button::create(StringUtils::format("popup-thanh-cong-%d.png", bgIndex)); // tao button
    auto imgNameThemDiem = "+2.png";
    popupthanhCong = ui::Button::create(imgNameThemDiem);
    popupthanhCong->setTouchEnabled(false);
    float ratiopopupthanhCong = 3.5;
    if (ratioScreen <= 1.53)
    {
        ratiopopupthanhCong = 15;
    }
    float scalepopupthanhCong = w / ratiopopupthanhCong / popupthanhCong->getContentSize().width;
    

    //log("ti le test: %f", scalepopupthanhCong);
    //log("ti le test theo w: %f", w / ratiopopupthanhCong / popupthanhCong->getContentSize().width);
    popupthanhCong->setScale(scalepopupthanhCong);
    if (ratioScreen <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    if (ratioScreen <= 1.53)
    {
        //ytitle = 1.3 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    //popupthanhCong->setPosition(Vec2(w / 2, ytitle));
    //popupthanhCong->setAnchorPoint(Vec2(0, 0));
    popupthanhCong->setPosition(Vec2(w/2, luckySpin->getPositionY() + luckySpin->getContentSize().height * luckySpin->getScale() / 2 * 0.60));

    popupthanhCong->setEnabled(true);
    this->addChild(popupthanhCong, 12);
    popupthanhCong->setOpacity(0);
    popupthanhCong->setScale(0.4);
    
    popupthatBai = ui::Button::create("popup-that-bai-1.png"); // tao button
    popupthatBai->setTouchEnabled(false);
   

    
    popupthatBai->setScale(scalepopupthanhCong);
    if (ratioScreen <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    if (ratioScreen <= 1.53)
    {
        //ytitle = 1.3 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    //popupthanhCong->setPosition(Vec2(w / 2, ytitle));
    //popupthanhCong->setAnchorPoint(Vec2(0, 0));
    popupthatBai->setPosition(Vec2(w/2, h * 0.8));

    popupthatBai->setEnabled(true);
    this->addChild(popupthatBai, 12);
    popupthatBai->setOpacity(0);
    popupthatBai->setScale(0.6);
}
void Play3::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathLevel::createScene(typeOfW3), Color3B().WHITE));
}
void Play3::coundownTimer(float w, float h){
    switch (levelOfW3)
    {
        case 1:
            timeRemaining = Variable().timeBasic;
            timeMax = Variable().timeBasic;
            if (typeOfW3 == 3 || typeOfW3 == 2) {
                timeRemaining = Variable().timeBasicNhan;
                timeMax = Variable().timeBasicNhan;
            }
            break;
        case 2:
            timeRemaining = Variable().timeHard;
            timeMax = Variable().timeHard;
            if (typeOfW3 == 3 || typeOfW3 == 2) {
                timeRemaining = Variable().timeHardNhan;
                timeMax = Variable().timeHardNhan;
            }
            break;
        case 3:
            timeRemaining = Variable().timeVeryHard;
            timeMax = Variable().timeVeryHard;
            if (typeOfW3 == 3 || typeOfW3 == 2) {
                timeRemaining = Variable().timeVeryHardNhan;
                timeMax = Variable().timeVeryHardNhan;
            }
            break;
        default:
            timeRemaining = 20.f;
            timeMax = 20.f;
            break;
    }

    ratioLoadingBar = 100 / timeRemaining;
    
    loadingBar = ui::LoadingBar::create("loadingbar2.png");
    float heightLoadingBar = 0.92 * h;
    
    float scaleLoading = w / 2.5  / loadingBar->getContentSize().width;
    if (ratioScreen <= 2.168)
    {
        heightLoadingBar = 0.93 * h;
    }
    if (ratioScreen <= 1.8)
    {
        heightLoadingBar = 0.96 * h;
    }
    if (ratioScreen <= 1.53)
    {
        scaleLoading = w / 5  / loadingBar->getContentSize().width;
    }
    loadingBar->setPosition(Vec2(w / 2, heightLoadingBar));
    loadingBar->setScale(scaleLoading);
    loadingBar->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBar->setPercent(0);
    this->addChild(loadingBar, 2);
    hLoadingBar = loadingBar->getContentSize().height * scaleLoading - 5;

    loadingBarWrap = ui::LoadingBar::create("loadingbar-wrap2.png");
    loadingBarWrap->setPosition(Vec2(w / 2, heightLoadingBar));

    loadingBarWrap->setScale(scaleLoading);
    loadingBarWrap->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBarWrap->setPercent(100);
    this->addChild(loadingBarWrap, 10);
    log("add loading bar");
    this->scheduleUpdate();
}
void Play3::update(float dt) {
    // make sure game is still running
    //log("time remain: %f", timeRemaining);
    if (timeRemaining > 0.f) {
        timeRemaining -= dt;
        if (isPause == true)
        {
            //log("da pause");
        }
        else{
            if (loadingBar != nullptr) {
                loadingBar->setPercent(timeRemaining * ratioLoadingBar);
            }
            
        }
        // update the label or whatever displays the time here. if displaying the number, use ceilf to round
        // up the time remaining so that you don't display lots of numbers after the decimal point

        // check if time ran out
        if (timeRemaining <= 0.f && isPause == false) {
            // timer ran out; react here

            handlerClickAnswer(0, buttonAnswer1);
            log("Het gio");
        }
    }
}
void Play3::rotateLuckySpin() {
    indexThemDiem = cocos2d::RandomHelper::random_int(0, 11);

    //tranh truong hop tru diem khi diem > 200
    if ((indexThemDiem == 4 or indexThemDiem == 7) && score < 10) {
        indexThemDiem = cocos2d::RandomHelper::random_int(0, 11);
    }
    
    //tranh truong hop X2 khi diem > 40 or diem = 0
    if (indexThemDiem == 2 && (score > 40 or score == 0)) {
        indexThemDiem = 1;
    }
    
    int randomAngle = 30 * (indexThemDiem);
    //int intTime1 = cocos2d::RandomHelper::random_int(25, 40); yeah
    
    //float time1 = static_cast<float>(intTime1 / 100.0f);
    float time1 = 0.4f; //tong thoi gian = 0.4 * 6 = 2.4s
    float angle = 1080.f + randomAngle;
    //float timeRadom = time1 * 6 * 0.5 * angle / 1440.f;
    float timeRadom = time1 * 6 * 0.5;
    
    auto imgNameThemDiem = Variable().diemMayManImg.at(indexThemDiem);
    popupthanhCong->loadTextureNormal(imgNameThemDiem);
    
    log("press Spin Button");
    log("indexThemDiem: %i, imgNameThemDiem: %s, random angle: %i, angle: %f, score: %i", indexThemDiem, imgNameThemDiem.c_str(), randomAngle, angle, score);
    
    if (sound == 0) {
        CocosDenshion::SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(1.0); // Đặt âm lượng cho âm thanh nền
        CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/lucky.wav", false);
    }
    
    luckySpin->runAction(
      Sequence::create(
            RotateBy::create(time1 / 2, 90.f),
            RotateBy::create(timeRadom, angle),
            RotateBy::create(time1 / 2, 90.f),
            RotateBy::create(time1 / 2  * 0.75, 45.f),
            RotateBy::create(time1 / 2 * 1.75, 45.f),
            RotateBy::create(time1 / 2  * 2.5, 45.f),
            RotateBy::create(time1 / 2  * 3, 45.f),
                       
            DelayTime::create(0.3),
            CallFunc::create(CC_CALLBACK_0(Play3::showItemsAfterSpin, this)),
            NULL)
    );
    
//    if (UserDefault::getInstance()->getIntegerForKey("hide-hand-guide", 0) == 0) {
//        handButton->runAction(Spawn::create(FadeOut::create(0.3), nullptr));
//        UserDefault::getInstance()->setIntegerForKey("hide-hand-guide", 1);
//    }
}
void Play3::createLuckySpin(float w, float h) {
    luckySpin = ui::Button::create("lucky-spin.png"); // tao button
    luckySpin->setTouchEnabled(false);
    float ratioluckySpin = 1;
    if (ratioScreen <= 1.53)
    {
        ratioluckySpin = 2;
    }
    
    float scaleluckySpin = w / ratioluckySpin / luckySpin->getContentSize().width;
    luckySpin->setScale(scaleluckySpin);
    float yluckySpin = h * 0.58;

    luckySpin->setPosition(Vec2(w/2, yluckySpin));
    if (ratioScreen <= 1.53)
    {
        //luckySpin->setPosition(Vec2(w / 2.5 - 10, yluckySpin));
    }
    addChild(luckySpin, 2);//add button vao scene
    
    luckySpinShadow = ui::Button::create("lucky-spin-shadow.png"); // tao button
    luckySpinShadow->setTouchEnabled(false);
    luckySpinShadow->setScale(scaleluckySpin);
    luckySpinShadow->setPosition(Vec2(luckySpin->getPosition()));
    addChild(luckySpinShadow, 1);//add button vao scene

    luckyStick = ui::Button::create("lucky-stick.png"); // tao button
    luckyStick->setTouchEnabled(false);
    float ratioluckyStick = 14;
    if (ratioScreen <= 1.53)
    {
        ratioluckyStick = 28;
    }
    
    float scaleluckyStick = w / ratioluckyStick / luckyStick->getContentSize().width;
    luckyStick->setScale(scaleluckyStick);
    float yluckyStick = luckySpin->getPositionY() + luckySpin->getContentSize().height * scaleluckySpin / 2 - luckyStick->getContentSize().height * scaleluckyStick * 0.85;

    luckyStick->setPosition(Vec2(w/2, yluckyStick));
    if (ratioScreen <= 1.53)
    {
        //luckyStick->setPosition(Vec2(w / 2.5 - 10, yluckyStick));
    }
    addChild(luckyStick, 2);//add button vao scene
    
    spinButton = ui::Button::create("button-spin.png"); // tao button
    spinButton->setTouchEnabled(true);
    float ratiospinButton = 6;
    if (ratioScreen <= 1.53)
    {
        ratiospinButton = 12;
        //fontSize = 0.04 * w;
    }
    
    float scalespinButton = w / ratiospinButton / spinButton->getContentSize().width;
    spinButton->setScale(scalespinButton);
    //spinButton->setTitleFontSize(fontSize / scalespinButton);
    spinButton->setPosition(Vec2(luckySpin->getPositionX(), luckySpin->getPositionY()));
    if (ratioScreen <= 1.53)
    {
        //spinButton->setPosition(Vec2(w / 2.5 - 10, yspinButton));
    }
//    spinButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
//        switch (type)
//        {
//            case cocos2d::ui::Widget::TouchEventType::BEGAN:
//                spinButton->setTouchEnabled(false);
//                
//                rotateLuckySpin();
//                break;
//            case cocos2d::ui::Widget::TouchEventType::ENDED:
//                //log("Button 1 clicked");
//                break;
//            default:
//                break;
//        }
//    });
    addChild(spinButton, 10);//add button vao scene
    
    
    
//    handButton = ui::Button::create("hand.png"); // tao button
//    handButton->setTouchEnabled(false);
//    float ratiohandButton = 6;
//    if (ratioScreen <= 1.53)
//    {
//        ratiohandButton = 12;
//        //fontSize = 0.04 * w;
//    }
//    
//    if (UserDefault::getInstance()->getIntegerForKey("hide-hand-guide", 0) == 0) {
//        float scalehandButton = w / ratiospinButton / spinButton->getContentSize().width;
//        handButton->setScale(scalespinButton);
//        //handButton->setTitleFontSize(fontSize / scalehandButton);
//        handButton->setPosition(Vec2(luckySpin->getPositionX() + handButton->getContentSize().width * scalehandButton * 0.5, luckySpin->getPositionY() - handButton->getContentSize().height * scalehandButton * 0.75));
//        if (ratioScreen <= 1.53)
//        {
//            //handButton->setPosition(Vec2(w / 2.5 - 10, yhandButton));
//        }
//        addChild(handButton, 10);//add button vao scene
//        float timeAnimationHand = 0.2;
//        handButton->runAction(
//             RepeatForever::create(
//                Sequence::create(
//                     ScaleTo::create(timeAnimationHand / 1.1, 1.1 * scalehandButton),
//                     DelayTime::create(0.5),
//                     ScaleTo::create(timeAnimationHand  / 1.2, scalehandButton * 0.9),
//                     nullptr)
//              )
//        );
//    }
    
    
    float timeAnimation = 0.5;
    auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.1 * scalespinButton);
    auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.2, scalespinButton * 0.9);
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    spinButton->runAction((RepeatForever::create(sq3)));
    
    
    float time = 0.1;
    HuyFunctions().animationZoomToShowForButton(luckySpin, 0, time, 1.2);
    HuyFunctions().animationZoomToShowForButton(luckySpinShadow, 0, time, 1.2);
    HuyFunctions().animationZoomToShowForButton(spinButton, 0, time, 1.2);
    HuyFunctions().animationZoomToShowForButton(luckyStick, 0, time, 1.2);
    
    
    
}
void Play3::showItemsAfterSpin() {
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float w;
    float h;

    //khoi tao gia tri ban dau
    w = visibleSize.width;
    h = visibleSize.height;
    coundownTimer(w, h);
    
    float valScale = 1.4;
    float time = 0.2;
    
    animationShowAnswer(buttonAnswer1, time, valScale);
    animationShowAnswer(buttonAnswer2, time, valScale);
    animationShowAnswer(buttonAnswer3, time, valScale);
    animationShowAnswer(buttonAnswer4, time, valScale);

    auto opButton1 = FadeOut::create(0);
    lblPhepToan->setOpacity(0);
    auto scaleButton1 = ScaleTo::create(0, 1.4);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, 1);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    auto sq = Sequence::create(sqButton1, sqB, nullptr);
    lblPhepToan->runAction(sq);
    
    spinButton->stopAllActions();
    
    spinButton->runAction(
      Sequence::create(
            ScaleTo::create(0.2, 0),
            NULL)
    );
    
    double scalePopup = 0.6;
    if (ratioScreen <= 1.53) {
        scalePopup = 0.3;
    }
    popupthanhCong->runAction(
      Sequence::create(
           DelayTime::create(0.05),
           Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr),
           NULL)
    );
    
    if (sound == 0) {
        CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
        CocosDenshion::SimpleAudioEngine::getInstance()->unloadEffect("sound/lucky.wav");
        CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/lucky-done.wav", false);
    }
    
}
void Play3::createScore(float w, float h){
    scoreString = cocos2d::__String::createWithFormat("%i", score);//score
    lblScore = Label::createWithTTF(scoreString->getCString(), "fonts/ComicNeue-Bold.ttf", 0.08 * w);
    if (ratioScreen <= 1.53)
    {
        lblScore = Label::createWithTTF(scoreString->getCString(), "fonts/ComicNeue-Bold.ttf", 0.05 * w);

        
        
    }
    lblScore->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xScore = w - (lblScore->getContentSize().width / 2 + 14);
    lblScore->setPosition(Vec2(xScore, h - 6 - (lblScore->getContentSize().height / 2)));
    // add the label as a child to this layer
    addChild(lblScore, 11);
    
    //create scoreIcon
    scoreIcon = ui::Button::create("gold.png"); // tao button
    scoreIcon->setTouchEnabled(false);
    float ratioscoreIcon = 10;
    float scaleI = 1;
    if (ratioScreen <= 1.53)
    {
        ratioscoreIcon = 20;
        scaleI = 0.55;
        
    }
    float scalescoreIcon = w / ratioscoreIcon / scoreIcon->getContentSize().width;
    scoreIcon->setScale(scalescoreIcon);
    scoreIcon->setAnchorPoint(Vec2({1, 0.5}));
    scoreIcon->setPosition(Vec2(lblScore->getPositionX() - 3 - lblScore->getContentSize().width / 2, h - 6 - (lblScore->getContentSize().height / 2)));
    scoreIcon->setEnabled(true);
    this->addChild(scoreIcon, 11);
    
    //show lblscore with animation
    lblScore->setOpacity(0);
    
    //create scoreIconEffect
//    auto scoreIconEffect = ui::Button::create("score.png"); // tao button
//    scoreIconEffect->setTouchEnabled(false);
//    float ratioscoreIconEffect = 12;
//    float scalescoreIconEffect = w / ratioscoreIconEffect / scoreIconEffect->getContentSize().width;
//    scoreIconEffect->setScale(scalescoreIconEffect);
//    scoreIconEffect->setAnchorPoint(Vec2({1, 0.5}));
//    scoreIconEffect->setPosition(Vec2(w / 2, h * 0.825));
//    scoreIconEffect->setEnabled(true);
//    this->addChild(scoreIconEffect, 11);
//
//    scoreIconEffect->setOpacity(0);
    
    float valScale = 1.4;
    float time = 0.1;
    lblScore->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, valScale), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, 1), FadeIn::create(time), nullptr), nullptr));

    
    
    scoreIcon->setOpacity(0);
    scoreIcon->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, 1), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, scaleI), FadeIn::create(time), nullptr), nullptr));
    
//    scoreIconEffect->runAction(Sequence::create(
//
//        Spawn::create(
//            ScaleTo::create(0, 0),
//            FadeOut::create(0), nullptr),
//
//            Spawn::create(
//                ScaleTo::create(0.3, 0.65),
//                FadeIn::create(0.3), nullptr),
//
//                Spawn::create(
//                  DelayTime::create(0.2),
//                  MoveTo::create(0.6, Vec2(lblScore->getPositionX() - 12, h - 6 - (lblScore->getContentSize().height / 2))),
//                        FadeOut::create(0.6), nullptr),
//
//            nullptr
//        )
//
//    );
    
}
void Play3::createAnswer(float w, float h){

    float fontSize = 0.09 * w;

    buttonAnswer1 = ui::Button::create("button-bubble.png"); // tao button
    buttonAnswer1->setPressedActionEnabled(true);
    buttonAnswer1->setZoomScale(0);
    buttonAnswer1->setScale9Enabled(true);
    buttonAnswer1->setTitleText(HuyFunctions().NumberToString(answer1));
    if (answer1 == correctAnswer)
    {
        buttonAnswer1->setTag(1);
    }
    else
    {
        buttonAnswer1->setTag(0);
    }
    buttonAnswer1->setTitleFontName("fonts/ComicNeue-Bold.ttf");

    buttonAnswer1->setTitleColor(Color3B(41, 107, 170));
    buttonAnswer1->setTouchEnabled(true);
    float ratioButtonAnswer1 = 3.4;
    if (ratioScreen <= 1.8)
    {
        ratioButtonAnswer1 = 4.2;
        fontSize = 0.08 * w;
        
        
    }
    if (ratioScreen <= 1.53)
    {
        ratioButtonAnswer1 = 7.2;
        fontSize = 0.04 * w;
    }
    
    int fixHeightAnswer = 25;
    int fixWidthAnswer = -5;
    if (ratioScreen <= 1.8 and ratioScreen > 1.53) {
        fixHeightAnswer = 10;
        fixWidthAnswer = 10;
    }
    if (ratioScreen <= 1.53)
    {
        fixWidthAnswer = w / 15;
    }
    scaleButtonAnswer1 = w / ratioButtonAnswer1 / buttonAnswer1->getContentSize().width;
    buttonAnswer1->setScale(scaleButtonAnswer1);
    buttonAnswer1->setTitleFontSize(fontSize / scaleButtonAnswer1);
    float yButtonAnswer1 = fixHeightAnswer + buttonAnswer1->getContentSize().height / 2 * scaleButtonAnswer1;

    buttonAnswer1->setPosition(Vec2(w / 3 + fixWidthAnswer, yButtonAnswer1));
    
    buttonAnswer1->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (answer1 != correctAnswer)
                {
                    buttonAnswer1->loadTextureNormal("button-bubble-wrong.png");
                    buttonAnswer1->setTitleColor(Color3B(160, 0, 0));
                }
                handlerClickAnswer(answer1, buttonAnswer1);

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer1, 10);//add button vao scene
    

    buttonAnswer2 = ui::Button::create("button-bubble.png"); // tao button
    buttonAnswer2->setPressedActionEnabled(true);
    buttonAnswer2->setZoomScale(0);
    buttonAnswer2->setScale9Enabled(true);
    buttonAnswer2->setTitleText(HuyFunctions().NumberToString(answer2));
    if (answer2 == correctAnswer)
    {
        buttonAnswer2->setTag(1);
    }
    else
    {
        buttonAnswer2->setTag(0);
    }
    buttonAnswer2->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    buttonAnswer2->setTitleFontSize(fontSize / scaleButtonAnswer1);
    buttonAnswer2->setTitleColor(Color3B(41, 107, 170));
    buttonAnswer2->setTouchEnabled(true);
    float scaleButtonAnswer2 = w / ratioButtonAnswer1 / buttonAnswer2->getContentSize().width;
    buttonAnswer2->setScale(scaleButtonAnswer2);
    //float yButtonAnswer2 = 50 + buttonAnswer2->getContentSize().height / 2 * scaleButtonAnswer2;

    buttonAnswer2->setPosition(Vec2(w * 4 / 6 - fixWidthAnswer, yButtonAnswer1));
   
    buttonAnswer2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (answer2 != correctAnswer)
                {
                    buttonAnswer2->loadTextureNormal("button-bubble-wrong.png");
                    buttonAnswer2->setTitleColor(Color3B(160, 0, 0));
                }
                handlerClickAnswer(answer2,buttonAnswer2);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                buttonAnswer2->loadTextureNormal("button-bubble-wrong.png");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer2, 10);//add button vao scene

    buttonAnswer3 = ui::Button::create("button-bubble.png"); // tao button
    buttonAnswer3->setPressedActionEnabled(true);
    buttonAnswer3->setZoomScale(0);
    buttonAnswer3->setScale9Enabled(true);
    buttonAnswer3->setTitleText(HuyFunctions().NumberToString(answer3));
    if (answer3 == correctAnswer)
    {
        buttonAnswer3->setTag(1);
    }
    else
    {
        buttonAnswer3->setTag(0);
    }
    buttonAnswer3->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    buttonAnswer3->setTitleFontSize(fontSize / scaleButtonAnswer1);
    buttonAnswer3->setTitleColor(Color3B(41, 107, 170));
    buttonAnswer3->setTouchEnabled(true);
    float scaleButtonAnswer3 = w / ratioButtonAnswer1 / buttonAnswer3->getContentSize().width;
    buttonAnswer3->setScale(scaleButtonAnswer3);
    float yButtonAnswer3 = yButtonAnswer1 + buttonAnswer3->getContentSize().height * scaleButtonAnswer3 + 15;

    buttonAnswer3->setPosition(Vec2(w / 3 + fixWidthAnswer, yButtonAnswer3));
    buttonAnswer3->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (answer3 != correctAnswer)
                {
                    buttonAnswer3->loadTextureNormal("button-bubble-wrong.png");
                    buttonAnswer3->setTitleColor(Color3B(160, 0, 0));
                }
                handlerClickAnswer(answer3, buttonAnswer3);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer3, 10);//add button vao scene

    buttonAnswer4 = ui::Button::create("button-bubble.png"); // tao button
    buttonAnswer4->setPressedActionEnabled(true);
    buttonAnswer4->setZoomScale(0);
    buttonAnswer4->setScale9Enabled(true);
    buttonAnswer4->setTitleText(HuyFunctions().NumberToString(answer4));
    if (answer4 == correctAnswer)
    {
        buttonAnswer4->setTag(1);
    }
    else
    {
        buttonAnswer4->setTag(0);
    }
    buttonAnswer4->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    buttonAnswer4->setTitleFontSize(fontSize / scaleButtonAnswer1);
    buttonAnswer4->setTitleColor(Color3B(41, 107, 170));
    buttonAnswer4->setTouchEnabled(true);
    float scaleButtonAnswer4 = w / ratioButtonAnswer1 / buttonAnswer4->getContentSize().width;
    buttonAnswer4->setScale(scaleButtonAnswer4);


    buttonAnswer4->setPosition(Vec2(w * 4 / 6 - fixWidthAnswer, yButtonAnswer3));
    buttonAnswer4->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (answer4 != correctAnswer)
                {
                    buttonAnswer4->loadTextureNormal("button-bubble-wrong.png");
                    buttonAnswer4->setTitleColor(Color3B(160, 0, 0));
                }
                handlerClickAnswer((answer4), buttonAnswer4);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer4, 10);//add button vao scene
    if (strcmp(loaiPhepTinh->getCString(), "ss") == 0) {
        phepTinhSoSanh1 = true;
        
        if (buttonAnswer1->getTitleText() == "1") {
            
            buttonAnswer1->loadTextureNormal("button-bubble-v.png");
            buttonAnswer2->loadTextureNormal("button-bubble-x.png");
        }else{
            buttonAnswer1->loadTextureNormal("button-bubble-x.png");
            buttonAnswer2->loadTextureNormal("button-bubble-v.png");
        }
        buttonAnswer1->setTitleText("");
        buttonAnswer2->setTitleText("");
        buttonAnswer3->setVisible(false);
        buttonAnswer4->setVisible(false);
        //log("ban dang lam bai so sanh");
    }
    
}
void Play3::animationShowAnswer(cocos2d::ui::Button* button, float time, float scale){
    auto opButton1 = FadeOut::create(0);
    button->setOpacity(0);

    auto scaleButton1 = ScaleTo::create(0, scaleButtonAnswer1 * scale);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, scaleButtonAnswer1);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    auto sq = Sequence::create(sqButton1, sqB, nullptr);
    button->runAction(sq);
}

void Play3::handlerClickAnswer(int v, cocos2d::ui::Button* buttonclicked){
    
    this->unscheduleUpdate();
    
    double scalePopup = 1;
    log("test man SE: %f", double(hScenePlay / wScenePlay));
    
    if (hScenePlay / wScenePlay <= 1.53)
    {
        scalePopup = 0.4;
    }
    //luu ket qua phep tinh vao DB
    int myTime = timeMax - timeRemaining;
    int isCorrect = 0;
    if(v == correctAnswer) {
        isCorrect = 1;
    }
    std::string ph = lblPhepToan->getString().c_str();
    
    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);

    buttonAnswer1->setTouchEnabled(false);
    buttonAnswer2->setTouchEnabled(false);
    buttonAnswer3->setTouchEnabled(false);
    buttonAnswer4->setTouchEnabled(false);

    auto pop = ScaleTo::create(0.15f, 1.3 * scaleButtonAnswer1);
    auto shrink = ScaleTo::create(0.15f, scaleButtonAnswer1);
    auto glow = FadeTo::create(0.15f, 200);

    auto combinedEffect = Spawn::create(
        Sequence::create(pop, shrink, nullptr),  // Nảy lên
        glow,  // Phát sáng nhẹ
        nullptr
    );

    if (buttonAnswer1->getTag() == 1)
    {
        buttonAnswer1->loadTextureNormal("button-bubble-correct.png");
        buttonAnswer1->runAction(combinedEffect);
    }
    if (buttonAnswer2->getTag() == 1)
    {
        buttonAnswer2->loadTextureNormal("button-bubble-correct.png");
        buttonAnswer2->setTitleColor(Color3B(41, 107, 170));

        buttonAnswer2->runAction(combinedEffect);
    }
    if (buttonAnswer3->getTag() == 1)
    {
        buttonAnswer3->loadTextureNormal("button-bubble-correct.png");
        buttonAnswer3->setTitleColor(Color3B(41, 107, 170));
        
        buttonAnswer3->runAction(combinedEffect);
    }
    if (buttonAnswer4->getTag() == 1)
    {
        buttonAnswer4->loadTextureNormal("button-bubble-correct.png");
        buttonAnswer4->setTitleColor(Color3B(41, 107, 170));
        buttonAnswer4->runAction(combinedEffect);
    }

    //hide pheptoan
    
    float time = 0.2;
    float valScale = 1.4;
    
    if (v == correctAnswer || hasGuide == false)
    {
        auto scaleTitle = ScaleTo::create(time, valScale);
        auto opaA = FadeOut::create(time);
        //auto moveA = MoveBy::create(time, Vec2(lblPhepToan->getContentSize().width, 0));
        auto sqA = Spawn::create(scaleTitle, opaA, nullptr);
        lblPhepToan->runAction(sqA);
    }
    
    

    //hide LoadingBar
    auto opaLoadingBar = FadeOut::create(time);
    auto sqLoadingBar = Spawn::create(opaLoadingBar, nullptr);
    loadingBar->runAction(sqLoadingBar);

    auto opaLoadingBarW = FadeOut::create(time);
    auto sqLoadingBarW = Spawn::create(opaLoadingBarW, nullptr);
    loadingBarWrap->runAction(sqLoadingBarW);
    
    //hide score
    lblScore->runAction(Sequence::create(DelayTime::create(0.9), FadeOut::create(time), NULL));
    scoreIcon->runAction(Sequence::create(DelayTime::create(1.0), FadeOut::create(time), NULL));
    
    /*
    //hide pause
    auto opaPause = FadeOut::create(time);
    auto sqPause = Spawn::create(opaPause, nullptr);
    buttonPause->runAction(sqPause);
    */

    //hide 4 answer
    double timeHide = 0.3;
    if (v != correctAnswer and hasGuide == true) //&&
    {
        
        if (levelOfW3 == 1) {
            if (typeOfW3 == 4) {
                createTemplateGuideLevel1Cong(wScenePlay, hScenePlay);
            } else if (typeOfW3 == 5) {
                createTemplateGuideLevel1Tru(wScenePlay, hScenePlay);
            } else if (typeOfW3 == 6) {
                hasGuide = false;
            }
        }else {
            if (typeOfW3 == 4) {
                createTemplateGuideLevel2Cong(wScenePlay, hScenePlay);
            }else if (typeOfW3 == 5) {
                createTemplateGuideLevel2Tru(wScenePlay, hScenePlay);
            } else if (typeOfW3 == 6) {
                createTemplateGuideLevel2SoSanh(wScenePlay, hScenePlay);
            }
        }
        timeHide = 0.9;
    }
    
    
    if (v != correctAnswer)
    {
        auto shake = Sequence::create(
            MoveBy::create(0.05f, Vec2(-10, 0)),
            MoveBy::create(0.05f, Vec2(10, 0)),
            MoveBy::create(0.05f, Vec2(-10, 0)),
            MoveBy::create(0.05f, Vec2(10, 0)),
            nullptr
        );

        auto flashRed = Sequence::create(
            TintTo::create(0.2f, 255, 0, 0),
            TintTo::create(0.2f, 255, 255, 255),
            nullptr
        );

        auto shrink = ScaleTo::create(0.2f, 0.97 * scaleButtonAnswer1);  // Co lại một chút

        auto failEffect = Spawn::create(shake, flashRed, shrink, nullptr);
        buttonclicked->runAction(failEffect);

        timeHide = 0.9;
    }
    DelayTime *pauseButtonAnswer = DelayTime::create(timeHide);
    auto opaAnswer1 = FadeOut::create(time);
    auto sqAnswer1 = Sequence::create(pauseButtonAnswer, opaAnswer1, nullptr);
    buttonAnswer1->runAction(sqAnswer1);

    auto opaAnswer2 = FadeOut::create(time);
    auto sqAnswer2 = Sequence::create(pauseButtonAnswer, opaAnswer2, nullptr);
    buttonAnswer2->runAction(sqAnswer2);

    auto opaAnswer3 = FadeOut::create(time);
    auto sqAnswer3 = Sequence::create(pauseButtonAnswer, opaAnswer3, nullptr);
    buttonAnswer3->runAction(sqAnswer3);

    auto opaAnswer4 = FadeOut::create(time);
    auto sqAnswer4 = Sequence::create(pauseButtonAnswer, opaAnswer4, nullptr);
    buttonAnswer4->runAction(sqAnswer4);
    
    if (v == correctAnswer)
    {
        //auto dungLienTiep = HuyFunctions().saveSoPhepTinhDungLienTiep(true);
        auto dungMoiNgay = HuyFunctions().saveSoPhepTinhDungMoiNgay(true);
//        if (dungLienTiep != "") {
//            showMedal(wScenePlay, hScenePlay, dungLienTiep);
//        }
        if (dungMoiNgay != "") {
            showMedal(wScenePlay, hScenePlay, dungMoiNgay);
        }
        //tra loi dung
        timeRemaining = timeRemaining + 1;
        
        luckySpinShadow->runAction(Sequence::create(DelayTime::create(0.6), FadeOut::create(0.2), NULL));
        luckySpin->runAction(Sequence::create(DelayTime::create(0.6), FadeOut::create(0.3), NULL));
        spinButton->runAction(Sequence::create(DelayTime::create(0.6), FadeOut::create(0.3), NULL));
        luckyStick->runAction(Sequence::create(DelayTime::create(0.6), FadeOut::create(0.3), NULL));
        popupthanhCong->runAction(
          Sequence::create(
               DelayTime::create(0.05),
               Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup * 0.6), nullptr),
               ScaleTo::create(0.03, 0.94 * scalePopup * 0.6),DelayTime::create(0.05),
               Spawn::create(
                     MoveTo::create(0.9, Vec2(scoreIcon->getPositionX() + scoreIcon->getScale() * scoreIcon->getContentSize().width, scoreIcon->getPositionY())),
                     ScaleTo::create(0.9, scalePopup / 1.5),
                     nullptr),
               FadeTo::create(0.1, 0), NULL)
        );
        
    }else{
        //tra loi sai
        luckySpinShadow->runAction(Sequence::create(FadeOut::create(0.2), NULL));
        luckySpin->runAction(Sequence::create(FadeOut::create(0.3), NULL));
        spinButton->runAction(Sequence::create(FadeOut::create(0.3), NULL));
        luckyStick->runAction(Sequence::create(FadeOut::create(0.3), NULL));
        popupthanhCong->runAction(Sequence::create(FadeOut::create(0.3), NULL));
        popupthatBai->runAction(Sequence::create(DelayTime::create(0.3), Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr), ScaleTo::create(0.03, 0.94 * scalePopup),DelayTime::create(0.6), FadeTo::create(0.1, 0), NULL));

    }
    DelayTime *pause = DelayTime::create(1);


    if (v == correctAnswer)
    {
        score = HuyFunctions().getKetQuaDiemSoNgauNhien(score, Variable().diemMayManPhepTinh.at(indexThemDiem), Variable().diemMayMan.at(indexThemDiem));
        
        if (sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }

        log("ban da tra loi dung");
        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(Play3::nextPlay, this)), NULL);
        runAction(sqBOver);
        
    }
    else{
        
        log("ban da tra loi sai");
        if (sound == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/bom-no-cham.mp3");
            
            //runAction(Sequence::create(DelayTime::create(0.3), CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/bom-no.mp3"), NULL));
        }

        if (hasGuide) {
            pause = DelayTime::create(20000);
        }
        //isPause = false;
        //auto opaB = FadeOut::create(v);
        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(Play3::moveSceneGameOver, this)), NULL);
        runAction(sqBOver);

        //::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score, typeOfW3, levelOfW3), Color3B().WHITE));
    }
    
    
    
    if(phepTinhSoSanh1){
    //if (strcmp(loaiPhepTinh->getCString(), "ss") == 0) {
        if (v == correctAnswer) {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 9999, myTime, levelOfW3, score);
        } else {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 2222, myTime, levelOfW3, score);
        }
    }else {
        HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, v, myTime, levelOfW3, score);
    }
    
}
void Play3::nextPlay()
{
    if (realType == 1)
    {
        typeOfW3 = cocos2d::RandomHelper::random_int(2, 5);
    }
    removeChild(lblPhepToan);
    removeChild(popupthanhCong);
    removeChild(popupthatBai);
    removeChild(lblScore);
    removeChild(buttonAnswer1);
    removeChild(buttonAnswer2);
    removeChild(buttonAnswer3);
    removeChild(buttonAnswer4);
    removeChild(spinButton);
    removeChild(luckyStick);
    removeChild(luckySpin);
    removeChild(luckySpinShadow);
    removeChild(handButton);
    
    //removeChild(loadingBar);
    
    //coundownTimer(wScenePlay, hScenePlay);
    createScore(wScenePlay, hScenePlay);
    
    auto arr = CreatePhepToan().createAnswerQuestions(typeOfW3, levelOfW3, prevA, prevB, maxDoiSo);
    log("test improve function");
    //    0 - prevA
    //    1 - prevB
    //    2 - phepToan
    //    3 - correctAnswer
    //    4 - answer1
    //    5 - answer2
    //    6 - answer3
    //    7 - answer4
    prevA = std::stoi(arr.at(0));
    prevB = std::stoi(arr.at(1));
    phepToan = cocos2d::__String::createWithFormat("%s", arr.at(2).c_str());
    correctAnswer = std::stoi(arr.at(3));
    answer1 = std::stoi(arr.at(4));
    answer2 = std::stoi(arr.at(5));
    answer3 = std::stoi(arr.at(6));
    answer4 = std::stoi(arr.at(7));
    soA = std::stoi( arr.at(0) );
    soB = std::stoi ( arr.at(1));
    phepTinhSmallA = arr.at(9);
    phepTinhSmallB = arr.at(10);
    
    log("cau hoi: %s",  arr.at(2).c_str());
    log("4 dap an: %i, %i, %i, %i",  std::stoi(arr.at(4)), std::stoi(arr.at(5)), std::stoi(arr.at(6)), std::stoi(arr.at(7)));
    log("dap dung: %i",  std::stoi(arr.at(3)));
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", arr.at(8).c_str());
    //indexThemDiem = HuyFunctions().getRandomForThemDiem(score);
    createMainTemplate(wScenePlay, hScenePlay);
    createLuckySpin(wScenePlay, hScenePlay);
    createPopupFinish(wScenePlay, hScenePlay);
    createAnswer(wScenePlay, hScenePlay);
    
    lblPhepToan->setScale(0);
    buttonAnswer1->setScale(0);
    buttonAnswer2->setScale(0);
    buttonAnswer3->setScale(0);
    buttonAnswer4->setScale(0);
    rotateLuckySpin();
    
    
}
void Play3::showMedal(float wScene, float hScene, std::string medal){
    auto fixIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        fixIpad = 2;
    }

    auto iconMedal = Sprite::create(medal);

    float ratioMedal = 6 * fixIpad;
    float scaleiconMedal = wScene / ratioMedal / iconMedal->getContentSize().width;

    // Vị trí giữa màn hình
    iconMedal->setPosition(Vec2(wScene / 2, hScene * 0.7));

    // Bắt đầu từ 0
    iconMedal->setScale(0.0f);
    iconMedal->setOpacity(0);

    this->addChild(iconMedal, 15);

    /// ===== ANIMATION =====

    // Move lên khi xuất hiện (30px)
    auto moveUp = MoveBy::create(0.2f, Vec2(0, 30 / fixIpad));

    // Scale từ 0 -> x1.3
    auto scaleUp = ScaleTo::create(0.2f, scaleiconMedal * 1.3);

    // Fade in
    auto fadeIn = FadeTo::create(0.2f, 255);

    // Scale + Fade + Move lên cùng lúc
    auto spawnIn = Spawn::create(scaleUp, fadeIn, moveUp, nullptr);

    // Giữ 1 chút
    auto delay = DelayTime::create(0.4f);

    // Move xuống nhẹ khi hide
    auto moveDown = MoveBy::create(0.6f, Vec2(0, -15 / fixIpad));

    // Fade out
    auto fadeOut = FadeOut::create(0.6f);

    // Fade + Move xuống cùng lúc khi hide
    auto spawnOut = Spawn::create(fadeOut, moveDown, nullptr);

    // Xóa sprite sau khi xong
    auto remove = RemoveSelf::create();

    // Chạy sequence
    iconMedal->runAction(
        Sequence::create(
            spawnIn,
            delay,
            spawnOut,
            remove,
            nullptr
        )
    );
}
void Play3::createTemplateGuideLevel2SoSanh(float w, float h) {
    lblPhepToan->runAction(FadeOut::create(0.1));
    auto fontStyle = "fonts/DeliusSwashCaps.ttf";
    float fontSize = 0.18 * w;
    if (h / w > 1.53 && h / w <= 1.8){
        fontSize = 0.15 * w;
    }
    if (h / w <= 1.53)
    {
        fontSize = 0.09 * w;
    }

    float time = 0.2;
    float width = 50.0f;
    float xLblA = w / 4;
    float xLblB = 3 * w / 4;
    if (h / w <= 1.53)
    {
        xLblA = 3 * w / 8;
        xLblB = 5 * w / 8;
    }
    float delayTime = 2;
    float fixTimeCoNho = 0;
    
    lblA = Label::createWithTTF(phepTinhSmallA.c_str(), fontStyle, fontSize);
    
    lblA->setPosition(Vec2(xLblA, lblPhepToan->getPositionY() - lblPhepToan->getContentSize().height));
    addChild(lblA, 2);
    lblA->setAlignment(TextHAlignment:: CENTER);
    //lblA->setOpacity(0);
    lblA->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblB = Label::createWithTTF(phepTinhSmallB.c_str(), fontStyle, fontSize);
    
    lblB->setPosition(Vec2(xLblB, lblA->getPositionY()));
    addChild(lblB, 2);
    lblB->setAlignment(TextHAlignment:: CENTER);
    //lblB->setOpacity(0);
    lblB->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblAKetQua = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", soA)->getCString(), fontStyle, fontSize * 0.8);
    lblAKetQua->setPosition(Vec2(xLblA, lblA->getPositionY() - lblA->getContentSize().height));
    addChild(lblAKetQua, 2);
    lblAKetQua->setColor(Color3B::GREEN);
    lblAKetQua->setAlignment(TextHAlignment:: CENTER);
    lblAKetQua->setOpacity(0);
    lblAKetQua->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblBKetQua = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", soB)->getCString(), fontStyle, fontSize * 0.8);
    lblBKetQua->setPosition(Vec2(xLblB, lblAKetQua->getPositionY()));
    addChild(lblBKetQua, 2);
    lblBKetQua->setAlignment(TextHAlignment:: CENTER);
    lblBKetQua->setOpacity(0);
    lblBKetQua->setColor(Color3B::GREEN);
    lblBKetQua->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));

    auto ketQuaSoSanh = ">";
    if (soA < soB) {
        ketQuaSoSanh = "<";
    }else if ( soA == soB) {
        ketQuaSoSanh = "=";
    }
    lblPhepSoSanh1 = Label::createWithTTF(ketQuaSoSanh, fontStyle, fontSize * 0.8);
    lblPhepSoSanh1->setPosition(Vec2(w / 2, lblAKetQua->getPositionY()));
    addChild(lblPhepSoSanh1, 2);
    lblPhepSoSanh1->setAlignment(TextHAlignment:: CENTER);
    lblPhepSoSanh1->setColor(Color3B::YELLOW);
    lblPhepSoSanh1->setOpacity(0);
    lblPhepSoSanh1->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
        
    //animation cho hang don vi - phong to
    float timeAnimate = 0.2;

    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()),
                         TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
    );
    lblAKetQua->runAction(
        Sequence::create(
            ScaleTo::create(0, 0),
            DelayTime::create(delayTime + 1 + timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1 - timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 0.8), nullptr)
            , NULL)
    );
    
    delayTime = delayTime + timeAnimate * 2 + 2;
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale()),
                         TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
    );
    lblBKetQua->runAction(
        Sequence::create(
            ScaleTo::create(0, 0),
            DelayTime::create(delayTime + 1 +  timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1 - timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 0.8), nullptr)
            , NULL)
    );
    
    delayTime = delayTime + timeAnimate * 3 + 2;
    lblPhepSoSanh1->runAction(
        Sequence::create(
            ScaleTo::create(0, 0),
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 0.8), TintTo::create(timeAnimate, Color3B::YELLOW), nullptr),
            DelayTime::create(1 - timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale()), MoveTo::create(timeAnimate, Vec2(w / 2, lblA->getPositionY())), nullptr)
            , NULL)
    );

    //2 button retry va OK
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    //float fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                        removeChild(lblA);
                        removeChild(lblAKetQua);
                        removeChild(lblB);
                        removeChild(lblBKetQua);
                        removeChild(lblPhepSoSanh1);
                    }
                    
                    if (hasGuide) {
                        createTemplateGuideLevel2SoSanh(wScenePlay, hScenePlay);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    buttonOK->setScale(0);
    buttonRetry->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(delayTime + 1), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2

    buttonRetry->runAction(Sequence::create(DelayTime::create(delayTime + 1), ScaleTo::create(0.3, scalebuttonRetry), NULL));
}
void Play3::moveSceneGameOver()
{
    //kiem tra xem co show man hinh mua hang khong
    if (Variable().isProVer == false && score >= Variable().soDiemShowPro &&  UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) >= Variable().showProSauBaoNhieuLan) {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", 0);
        createBgPro(wScenePlay, hScenePlay);
    } else {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) + 1);
        finish();
    }
}
void Play3::createMainTemplate(float w, float h){
    lblPhepToan = Label::createWithTTF(phepToan->getCString(), "fonts/DeliusSwashCaps.ttf", 0.14 * w);
    if (ratioScreen <= 1.53)
    {
        lblPhepToan = Label::createWithTTF(phepToan->getCString(), "fonts/DeliusSwashCaps.ttf", 0.07 * w);
    }
    lblPhepToan->setColor(Color3B().WHITE);//Color3B().BLACK
    // position the label on the center of the screen
    
    lblPhepToan->setPosition(Vec2(w / 2, h * 0.87));
    if (ratioScreen > 1.53 && ratioScreen <= 1.8){
        lblPhepToan->setPosition(Vec2(w / 2, h * 0.9));
    }
    if (ratioScreen <= 1.53)
    {
        lblPhepToan->setPosition(Vec2(w / 2, h * 0.9));
    }
    // add the label as a child to this layer
    addChild(lblPhepToan, 2);

    auto opaA = FadeOut::create(0);
    lblPhepToan->setOpacity(0);
    //int valScale = 4;
    //auto scaleTitle = ScaleTo::create(0, valScale);
    //auto sqA = Spawn::create(scaleTitle, nullptr);
    //lblPhepToan->runAction(sqA);



    float time = 0.2;
    auto opaB = FadeIn::create(time);
    //auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    //DelayTime *pause2 = DelayTime::create(0.2);

    auto sq = Sequence::create(opaA, opaB, nullptr);
    lblPhepToan->runAction(sq);

}
void Play3::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (ratioScreen <= 1.53)
    {
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                
                CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
                CocosDenshion::SimpleAudioEngine::getInstance()->unloadEffect("sound/lucky.wav");
                CocosDenshion::SimpleAudioEngine::getInstance()->unloadEffect("sound/lucky-done.wav");
                
                HuyFunctions().animationClickedButton(button, [](){
                    if (Variable().isProduction == true) {
                        HuyFunctions().showAds();
                    }
                    
                    if (fromChallenge3) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(typeOfW3, levelOfW3), Color3B().WHITE));
                    } else {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(3, backTypePT3), Color3B().WHITE));
                    }
                });

                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 2);//add button vao scene
}
void Play3::createValueKey(float w, float h){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    valueKey3 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * w);
    valueKey3->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = valueKey3->getContentSize().height;
    auto btnWidthKey = valueKey3->getContentSize().width;
    yValueKey3 = h - (btnHeightKey / 2 + 5);
    xValueKey3 = w - (btnWidthKey / 2 + 5);
    valueKey3->setPosition(Vec2(xValueKey3, yValueKey3));
    // add the label as a child to this layer
    addChild(valueKey3);
}
void Play3::createButtonKey(float w, float h){
    createValueKey(w, h);
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    auto btnWidth = btn->getContentSize().width;
    float scale = w / ratio / btnWidth;
    float xBtn = xValueKey3 - 7 - valueKey3->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, yValueKey3));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                //restart valueKey Label
                removeChild(valueKey3);
                createValueKey(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
void Play3::createBgPro(float wScene, float hScene) {
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    LanguageManager::getInstanceRestart();
    
    auto bgTexture = Director::getInstance()->getTextureCache()->addImage("bg-nen-tet.png");

    // Set texture parameters to repeat
    Texture2D::TexParams texParams = { GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_REPEAT };
    bgTexture->setTexParameters(texParams);

    // Create a sprite with repeated texture
    auto bgNenPro = Sprite::createWithTexture(bgTexture, Rect(0, 0, wScene, hScene));
    bgNenPro->setAnchorPoint(Vec2(0, 0)); // Align to bottom-left
    bgNenPro->setOpacity(245);
    //bgNenPro->setOpacity(0);
    this->addChild(bgNenPro, 100);
    
    //close
    auto btn = ui::Button::create("close-btn.png"); // tao button
    float ratio = 10;
    if (hScene/wScene <= 1.53)
    {
        ratio = 17;
    }
    //CCLOG("Debug: 2");
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                finish();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 101);//add button vao scene
    
    float fontSize = 0.1 * wScene;
    float fontSizePrice = 0.135 * wScene;
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
        fontSize = 0.07 * wScene;
    }
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.05 * wScene;
        fontSizePrice = 0.06 * wScene;
        if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
        {
           
            fontSize = 0.035 * wScene;
        }
    }
    //create title pro version
    std::string titleValue = LanguageManager::getInstance()->getStringForKey("TITLE_PRO").c_str();
    auto titlePro = Label::createWithTTF(titleValue, fontStyle, fontSize);
    titlePro->setColor(Color3B().WHITE);
    // position the label on the center of the
    auto btnHeightKey = titlePro->getContentSize().height;
    double ytitlePro = hScene * 0.9 - (btnHeightKey / 2 + 5);
    double xtitlePro = wScene / 2;// - (btnWidthKey / 2 + 5);
    titlePro->setPosition(Vec2(xtitlePro, ytitlePro));
    // add the label as a child to this layer
    addChild(titlePro, 101);
    
    auto bgVIP = Sprite::create("tv-ads.png");
    float ratiobgVIP = 2.4;

    float fixHeightIpad = 20;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        fixHeightIpad = 5;
    }
    
    if (hScene / wScene <= 1.53)
    {
        ratiobgVIP = 4.4;
    }
    
    float scalebgVIP = wScene / ratiobgVIP / bgVIP->getContentSize().width;
    bgVIP->setScale(scalebgVIP);
    bgVIP->setPosition(Vec2(wScene / 2, titlePro->getPositionY() - titlePro->getContentSize().height - 20 - bgVIP->getContentSize().height * scalebgVIP / 2)); // Đặt vị trí
    this->addChild(bgVIP, 101);
    
    
    //create desc pro version
    std::string descValue = LanguageManager::getInstance()->getStringForKey("REMOVE_ADS").c_str();
    auto descPro = Label::createWithTTF(descValue, fontStyle , fontSize * 0.8);
    descPro->setColor(Color3B().WHITE);
    // position the label on the center of the
    double ydescPro = bgVIP->getPositionY() - descPro->getContentSize().height /2 - 20 - bgVIP->getContentSize().height * scalebgVIP / 2;
    double xdescPro = wScene / 2;// - (btnWidthKey / 2 + 5);
    descPro->setPosition(Vec2(xdescPro, ydescPro));
    // add the label as a child to this layer
    addChild(descPro, 101);
    
    //create PRICE
    std::string priceValue = UserDefault::getInstance()->getStringForKey("gia", "");
    auto price = Label::createWithTTF(priceValue, "fonts/NunitoSans-Bold.ttf", fontSizePrice);
    price->setColor(Color3B(255, 195, 77));
    // position the label on the center of the
    double yprice = descPro->getPositionY() - descPro->getContentSize().height /2 - fixHeightIpad - price->getContentSize().height / 2;
    double xprice = wScene / 2;// - (btnWidthKey / 2 + 5);
    price->setPosition(Vec2(xprice, yprice));
    // add the label as a child to this layer
    addChild(price, 101);
    
    //create Underline
    auto underlineImg = Sprite::create("underline-pro.png");
    float ratiounderlineImg = 2;
    //float fixHeightNotiIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        ratiounderlineImg = 4;
        //fixHeightNotiIpad = 0.5;
    }
    
    float scaleunderlineImg = wScene / ratiounderlineImg / underlineImg->getContentSize().width;
    underlineImg->setScale(scaleunderlineImg);
    underlineImg->setPosition(Vec2(wScene / 2, price->getPositionY() - price->getContentSize().height / 2 - underlineImg->getContentSize().height * scaleunderlineImg * 0.15)); // Đặt vị trí
    this->addChild(underlineImg, 101);
    
    
    
    fontSize = 0.05 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.02 * wScene;
    }
    auto restorePurchaseBtn = ui::Button::create("empty.png");
    restorePurchaseBtn->setPressedActionEnabled(true);
    restorePurchaseBtn->setZoomScale(-0.1f);
    restorePurchaseBtn->setScale9Enabled(true);
    restorePurchaseBtn->setTitleText("Restore Purchase");
    if(appLang == "en" || appLang == "vi"){
        restorePurchaseBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    restorePurchaseBtn->setTitleColor(Color3B().WHITE);
    restorePurchaseBtn->setOpacity(200);
    restorePurchaseBtn->setTouchEnabled(true);
    float ratiotitle = 3;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 6;
        
    }
    auto scalerestoreBtn = wScene / ratiotitle / restorePurchaseBtn->getContentSize().width;
    restorePurchaseBtn->setScale(scalerestoreBtn);
    restorePurchaseBtn->setTitleFontSize(fontSize / scalerestoreBtn);
    if (appLang == "ja")
    {
        restorePurchaseBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        restorePurchaseBtn->setTitleFontSize(0.045 * wScene / scalerestoreBtn);
    }
    float ytitle = 40;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        
        ytitle = 20;
    }
    if (hScene / wScene <= 1.53)
    {
        
        if (appLang == "ja")
        {
            
            restorePurchaseBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
        }
    }
    restorePurchaseBtn->setPosition(Vec2(wScene / 2, ytitle));
    restorePurchaseBtn->setEnabled(true);
    restorePurchaseBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("restore purchasing");
                IAPManager::getInstance()->restorePurchases();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(restorePurchaseBtn, 101);
    
    float fontSize2 = 0.07 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize2 = 0.035 * wScene;
    }
    auto upProBtn = ui::Button::create("button-pro.png");
    upProBtn->setPressedActionEnabled(true);
    upProBtn->setZoomScale(-0.1f);
    upProBtn->setScale9Enabled(true);
    upProBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("PRO_BUY").c_str());
    if(appLang == "en" || appLang == "vi"){
        upProBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    upProBtn->setTitleColor(Color3B().WHITE);
    upProBtn->setTouchEnabled(true);
    ratiotitle = 1.5;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 3.4;
       
    }
    auto scaleUpProBtn = wScene / ratiotitle / upProBtn->getContentSize().width;
    upProBtn->setScale(scaleUpProBtn);
    upProBtn->setTitleFontSize(fontSize2 / scaleUpProBtn);
    if (appLang == "ja")
    {
        upProBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        upProBtn->setTitleFontSize(0.05 * wScene / scaleUpProBtn);
    }
    ytitle = ytitle + restorePurchaseBtn->getContentSize().height * scalerestoreBtn / 2 + upProBtn->getContentSize().height * scaleUpProBtn / 2 + 7;
    if (hScene / wScene <= 1.53)
    {
      
        if (appLang == "ja")
        {
            upProBtn->setTitleFontSize(0.025 * wScene / scaleUpProBtn);
        }
    }
    upProBtn->setPosition(Vec2(wScene / 2, ytitle));
    upProBtn->setEnabled(true);
    upProBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("up to pro");
                IAPManager::getInstance()->purchase(Variable().proProductionID);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(upProBtn, 101);
    
}

void Play3::onEnter() {
    Layer::onEnter();

    // Đăng ký callback khi mua thành công
    IAPManager::getInstance()->setOnPurchaseSuccess([this](std::string productID) {
        log("🎉 Mua thành công - restore thanh cong: %s", productID.c_str());
        UserDefault::getInstance()->setBoolForKey("isProVer", true);
        //Variable().isProVer = true;
        UserDefault::getInstance()->flush();
        this->finish();
    });

    // Đăng ký callback khi mua thất bại
    IAPManager::getInstance()->setOnPurchaseFailed([this](std::string productID, std::string error) {
        log("❌ Mua thất bại: %s | Lỗi: %s", productID.c_str(), error.c_str());
        //this->finish();
        
        
    });
    
    // Đăng ký callback lấy giá
    IAPManager::getInstance()->setOnPriceRetrieved([this](std::string productID, std::string price) {
        log("📦 Giá của %s là: %s", productID.c_str(), price.c_str());
        // Gợi ý: update label nút mua
        //this->price->setString(price.c_str());
        UserDefault::getInstance()->setStringForKey("gia", price.c_str());
    });

    // Yêu cầu lấy giá từ App Store
    IAPManager::getInstance()->requestProductInfo(Variable().proProductionID);
}
void Play3::finish() {
    if (Variable().isProduction == true) {
        HuyFunctions().showAds();
    }
    
    HuyFunctions().saveSoGame("g4");
    
    if(isMulti3 == true){
        typeOfW3 = 1;
    }
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score, typeOfW3, levelOfW3, 3, fromChallenge3), Color3B().WHITE));
}
