#ifndef __FINISHDUAL_H__
#define __FINISHDUAL_H__

#include "cocos2d.h"



class FinishDual : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int score, int score2, int type, int level);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
	void createScore(float w, float h);
	void createButtonKey(float w, float h);
    void createBg(float w, float h);
	void createValueKey(float w, float h);
	void createButtonNextAndAddKey(float w, float h);
	void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);

    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
	CREATE_FUNC(FinishDual);
};

#endif // __FINISHDUAL_H__
