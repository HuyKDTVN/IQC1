//
//  Sticker.hpp
//  mentalmath
//
//  Created by Huy Le on 19/11/25.
//

#ifndef __STICKER_H__
#define __STICKER_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class Sticker : public cocos2d::Layer
{
public:
    float wScene;
    float hScene;
    float ratioScreen;
    cocos2d::Label* labelTitleNguoiChoi;
    cocos2d::ui::EditBox* nameEditBox;
    cocos2d::Label* labelErr;
    cocos2d::ui::Button* okButton;
    cocos2d::Node* node;
    int sound;
    
    
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void createBg(float w, float h);
    void back(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void createTemplate(float w, float h);
    void inputTenHandle(float w, float h);

    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(Sticker);
};

#endif // !__STICKER_H__
