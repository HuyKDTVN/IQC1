//
//  SelectGame.hpp
//  mentalmath
//
//  Created by Huy Le on 22/2/25.
//

#ifndef __SELECTGAME_H__
#define __SELECTGAME_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class SelectGame : public cocos2d::Layer
{
public:
    float wScene;
    float hScene;
    float ratioScreen;
    
    int soundSelectGame;
    
    std::vector<std::string> arrImage;
    std::vector<int> arrLink;
    
    cocos2d::ui::Button* handButton;
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int typePhepTinh = 100, int level = 100);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void createBg(float w, float h);
    void back(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void createTemplate(float w, float h);
    void requestAds();
    void showAds();

    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(SelectGame);
};

#endif // __SELECTGAME_H__
