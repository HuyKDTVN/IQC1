#include "setting.h"
#include "HelloWorldScene.h"
#include "language.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "ChangeName.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include <iostream>
#include <string>
USING_NS_CC;
const char *SOUND = "sound";

ui::Button* title;

float scaletitle;


Scene* Setting::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = Setting::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Setting::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }
    //this->setKeypadEnabled(false);
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;

    //set bg
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));

    CCLOG("ngon ngu: %s", UserDefault::getInstance()->getStringForKey("LANGUAGE", "en").c_str());

    back(wScene, hScene);
    createTite(wScene, hScene);
    createCheckBoxAudioMusic(wScene, hScene);
    return true;
}
void Setting::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void Setting::createTite(float w, float h){
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-app.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    LanguageManager::getInstanceRestart();
    float fontSize = 0.12 * w;
    if (h / w <= 1.53)
    {
        fontSize = 0.06 * w;
    }
    title = ui::Button::create("bg-title.png");
    title->setPressedActionEnabled(true);
    title->setZoomScale(-0.1f);
    title->setScale9Enabled(true);
    title->setTitleText(LanguageManager::getInstance()->getStringForKey("SETTING").c_str());
    if(appLang == "en" || appLang == "vi"){
        title->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    title->setTitleColor(Color3B().WHITE);
    title->setTouchEnabled(false);
    float ratiotitle = 1;
    scaletitle = w / ratiotitle / title->getContentSize().width;
    title->setScale(scaletitle);
    title->setTitleFontSize(fontSize / scaletitle);
    if (appLang == "ja")
    {
        title->setTitleFontName("fonts/KosugiMaru.ttf");
        title->setTitleFontSize(0.09 * w / scaletitle);
    }
    float ytitle = h - (title->getContentSize().height / 2 * scaletitle);
    if (h / w <= 1.53)
    {
        ytitle = h * 1.1 - (title->getContentSize().height / 2 * scaletitle);
        if (appLang == "ja")
        {
            
            title->setTitleFontSize(0.05 * w / scaletitle);
        }
    }
    title->setPosition(Vec2(w / 2, ytitle));
    title->setEnabled(true);
    addChild(title);
    
    
    auto label = dynamic_cast<Label*>(title->getTitleRenderer());
    if (label) {
        std::string fontName = label->getSystemFontName();
        log("font-mac dinh: %s", fontName.c_str());
        // Bây giờ bạn có thể sử dụng 'fontName' cho mục đích của mình
    } else {
        // Nếu không tìm thấy đối tượng nhãn trong button
        log("Không thể lấy đối tượng nhãn từ button!");
    }
}
void Setting::createCheckBoxAudioMusic(float w, float h){
    float fontSize = 0.05 * w;
    if (h / w <= 1.53)
    {
        fontSize = 0.025 * w;
    }
    //int sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");

   
    fontSize = 0.05 * w;
    cocos2d::ui::Button* btn = ui::Button::create("bg-infor.png", "bg-infor.png");// tao button
    btn->setPressedActionEnabled(false);
    btn->setZoomScale(-0.1f);
    btn->setScale9Enabled(false);
    btn->setTouchEnabled(true);
    float ratioLang = 1.2;
    if (h / w <= 1.53)
    {
        ratioLang = 2.7;
        fontSize = 0.04 * w;
    }
    float scaleLang = w / ratioLang / btn->getContentSize().width;
    btn->setScale(scaleLang);
    btn->setPosition(Vec2(w / 2, h - title->getContentSize().height * scaletitle - h / 8));
    
    auto icon = ui::Button::create("sound3.png", "sound3.png");// tao button;
    if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 1)
    {
        icon->loadTextureNormal("unsound3.png");
       
    }
    
    icon->setPressedActionEnabled(false);
    icon->setZoomScale(-0.1f);
    icon->setScale9Enabled(false);
    icon->setTouchEnabled(true);
    icon->setTag(1);
    float ratioIcon = 10;
    if (h / w <= 1.53)
    {
        //ratioLang = 3;
        //fontSize = 0.035 * w;
    }
    float scaleIcon = w / ratioIcon / icon->getContentSize().height;
    icon->setScale(scaleIcon);
   // float yicon = y;
    icon->setPosition(Vec2(20 + icon->getContentSize().width * scaleIcon / 2, icon->getContentSize().height * scaleIcon + 5));
    
   
    auto myColor = Color3B().WHITE;
  
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
    }
    auto title = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("AUDIO").c_str(), fontStyle, fontSize);
    title->setColor(myColor);
    // position the label on the center of the screen
    if (h / w <= 1.53) {
        //title->setPosition(Vec2(xValueScore * 2, yValueScore + 15));
    } else{
        //title->setPosition(Vec2(xValueScore + 7, yValueScore));
    }
    title->setPosition(Vec2(icon->getPositionX() + icon->getContentSize().width * scaleIcon / 2 + 12, icon->getPositionY()));
    title->setAnchorPoint({0, 0.5});
    title->setHorizontalAlignment(TextHAlignment::CENTER);
    btn->addChild(title);
    btn->addChild(icon);
    this->addChild(btn, 2);
    
    icon->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0)
                {
                    UserDefault::getInstance()->setIntegerForKey("sound", 1);
                    UserDefault::getInstance()->flush();
                    buttonIcon->loadTextureNormal("unsound3.png");
                   
                }
                else
                {
                    UserDefault::getInstance()->setIntegerForKey("sound", 0);
                    UserDefault::getInstance()->flush();
                    buttonIcon->loadTextureNormal("sound3.png");
                }
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        
        auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
      
        for (const auto& child : buttonIcon->getChildren())
            {
                // Kiểm tra xem child có phải là một button không
                auto button = dynamic_cast<ui::Button*>(child);
                
                if (button)
                {
                    switch (type)
                    {
                        case cocos2d::ui::Widget::TouchEventType::BEGAN:
                            
                            if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0)
                            {
                                
                                UserDefault::getInstance()->setIntegerForKey("sound", 1);
                                UserDefault::getInstance()->flush();
                                button->loadTextureNormal("unsound3.png");
                            }
                            else
                            {
                                UserDefault::getInstance()->setIntegerForKey("sound", 0);
                                UserDefault::getInstance()->flush();
                                button->loadTextureNormal("sound3.png");
                                
                            }
                            break;
                        case cocos2d::ui::Widget::TouchEventType::ENDED:
                            //CCLOG("Button 1 clicked");
                            break;
                        default:
                            break;
                    }
                }
            }
        
    });

    auto bgLang = HuyFunctions().creategGroupInfor(w, h, btn->getPositionY() - btn->getContentSize().height * btn->getScale() * 1.2, "language2.png", "", LanguageManager::getInstance()->getStringForKey("LANG").c_str(), "");
    addChild(bgLang);
    bgLang->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, Language::createScene(), Color3B().WHITE));
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    auto children = bgLang->getChildren();
    for (auto& child : children) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                        UserDefault::getInstance()->setStringForKey("LANGUAGE", "en");
                        UserDefault::getInstance()->flush();
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Language::createScene(), Color3B().WHITE));
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
    auto bgName = HuyFunctions().creategGroupInfor(w, h, bgLang->getPositionY() - bgLang->getContentSize().height * btn->getScale() * 1.2, "user.png", "", LanguageManager::getInstance()->getStringForKey("CHANGE_NAME").c_str(), "");
    addChild(bgName);
    bgName->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, ChangeName::createScene(), Color3B().WHITE));
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    auto children2 = bgName->getChildren();
    for (auto& child : children2) {
        auto childButton = dynamic_cast<ui::Button*>(child);
        if (childButton) {
            // Đây là một đối tượng Button, bạn có thể thực hiện các thao tác với nó ở đây
            // Ví dụ: Thiết lập link cho button
            childButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type) {
                switch (type)
                {
                    case cocos2d::ui::Widget::TouchEventType::BEGAN:
                       
                        break;
                    case cocos2d::ui::Widget::TouchEventType::ENDED:
                        //CCLOG("Button 1 clicked");
                        break;
                    default:
                        break;
                }
            });
        }
    }
}
void Setting::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 2);//add button vao scene
}
