//
//  CreatePhepToan.hpp
//  mentalmath-mobile
//
//  Created by Huy Le on 9/3/24.
//

#ifndef CreatePhepToan_hpp
#define CreatePhepToan_hpp
#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include <stdio.h>
#include <vector>

class CreatePhepToan {
public:
    CreatePhepToan(); // Constructor
    ~CreatePhepToan(); // Destructor
    std::string generateRandomExpression(int tong);
    
    std::vector<std::string> createAnswerQuestions(int loai, int doKho, int prevA, int prevB, int soLonNhat);
    void randomNhan1();
    void randomNhan2();
    void randomNhan3();

    void randomCong1();
    void randomCong2();
    void randomCong3();
    
    void randomSoSanh1();
    void randomSoSanh2();
    void randomSoSanh3();

    void randomTru1();
    void randomTru2();
    void randomTru3();

    void randomChia1();
    void randomChia2();
    void randomChia3();

    void random4AnswerNhan1(int a, int b);
    void random4AnswerNhan2(int a, int b);
    void random4AnswerNhan3(int a, int b);

    void random4AnswerCong1(int a, int b);
    void random4AnswerCong2(int a, int b);
    void random4AnswerCong3(int a, int b);

    void random4AnswerTru1(int a, int b);
    void random4AnswerTru2(int a, int b);
    void random4AnswerTru3(int a, int b);

    void random4AnswerChia1(int a, int b);
    void random4AnswerChia2(int a, int b);
    void random4AnswerChia3(int a, int b);
    void generateCloseNumbers(int A, int range);
    bool needPhepTinhTheoChieuDoc(std::string loaiPhepTinh, int level);
    
private:
    int typeOfW;
    int levelOfW;
    int prevA;
    int prevB;
    int maxDoiSo;
    
    int correctAnswer;
    cocos2d::__String *phepToan;
    int answer1;
    int answer2;
    int answer3;
    int answer4;
    std::string phepTinhA;
    std::string phepTinhB;
    
public:
    
};
#endif /* CreatePhepToan_hpp */
