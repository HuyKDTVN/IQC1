//
//  HuyFunctions.hpp
//  mentalmath-mobile
//
//  Created by Huy Le on 07/03/2024.
//

#ifndef HuyFunctions_hpp
#define HuyFunctions_hpp

#include <stdio.h>
#include <vector>
#include "ui/CocosGUI.h"

class HuyFunctions {
public:
    HuyFunctions(); // Constructor
    ~HuyFunctions(); // Destructor
    std::vector<int> generateRandomNumbers();
    void requestATTAds();
    void requestAds(int type);
    void showAds();
    
    void requestRewardedAd1();
    void requestRewardedAd2();
    void requestRewardedAdDiamond();
    void requestRewardedAdHeart();
    void showRewardedAd1();
    void showRewardedAd2();
    void showRewardedAdDiamond();
    void showRewardedAdHeart();
    
    std::string NumberToString(int pNumber);
    
    std::string createPhepToanWithEmoji(std::string phepToan);
    
    std::string ReplaceString(std::string str, const std::string& from, const std::string& to);
    int SoLonNhat(std::string myLanguage);
    bool checkAddDayOrNot();
    int getDayOfYear();
    void savePhepTinhToDataBase(int isCorrect, std::string phepTinh, int cauTraLoi, int myTime, int level, int soVangMoiThem = 1, bool dualMode = false, bool yesNoMode = false, int viTriCauTraLoi = 1);
    int tongDiemPhepCong();
    int tongDiemPhepTru();
    int tongDiemPhepNhan();
    int tongDiemPhepChia();
    int tongDiemPhepSoSanh();
    std::string getCurrentLang();
    int getthanhTich(int soDiem);
    cocos2d::ui::Button* createButtonPhepTinh(double w, double h, int modeGame, double y, int viTri, int loaiPhepTinh);
    cocos2d::ui::Button* creategGroupInfor(double w, double h, double y, std::string iconName, std::string iconDesc, std::string myTitle, std::string mydesc, std::string colorText = "", double delayAnimationDesc = 0);
    cocos2d::ui::Button* createArrow(double w, double h, double x, double y);
    
    cocos2d::ui::Button* createCheckBox(double w, double h, double y, std::string icon, std::string iconSelected, std::string myTitle);
    int getKetQuaDiemSoNgauNhien(int dienHienTai, std::string loaiPhepTinh, int soDiemNgauNhien);
    
    int getRandomForThemDiem(int score = 0);
    
    int getSoVang();
    void animationZoomToShowForButton(cocos2d::ui::Button* button, float timeDelay, float timeAnimation, float scaleTo);
    void animationClickedButton(cocos2d::ui::Button* button, const std::function<void()>& callback);
    void animationClickedButtonWithDelay(cocos2d::ui::Button* button, float delayTime, const std::function<void()>& callback);
    cocos2d::ui::Button* createGiftCard(double w, double h, double y, std::string iconName, std::string markName, bool isActive = false);
    cocos2d::ui::Button* createButtonGift(double w, double h, double x, std::string iconName);
    std::vector<std::string> splitString(const std::string &input, char delimiter);
    void saveTungLoaiPhepTinhToDBAndGameCenterAchievement(std::string loaiPhepTinh, std::string achiemvementID);
    
    void saveDiamondToDBAndGameCenterAchievement(int add = 0);
    void saveHeartToDBAndGameCenterAchievement(bool add = true);
    void saveSoGame(std::string loaiGame);
    std::string getCountry();
    bool inVietNam();
    bool hasTet();
    void submitAllowNoti();
    cocos2d::DrawNode* createChuNhatBoGoc(float width, float height, cocos2d::Vec2 origin);
    int getSoHangDonVi(int num);
    int getSoHangChuc(int num);
    int perCentChallenge(int index);
    int chuyenGiaTriPhepTinh(int loaiPhepTinhCu);
    int tinhTongSoStickerBangKhen();
    void drawSolidRoundedRect(cocos2d::DrawNode* node, const cocos2d::Vec2& origin, const cocos2d::Size& size, float radius, const cocos2d::Color4F& color);
    void drawSolidRoundedRect2(cocos2d::DrawNode* node, const cocos2d::Vec2& origin, const cocos2d::Size& size, float radius, const cocos2d::Color4F& color);
    std::string trim(const std::string &s);
    std::string ltrim(const std::string &s); 
    std::string rtrim(const std::string &s);
    std::string saveSoPhepTinhDungLienTiep(bool isCorrect);
    std::string saveSoPhepTinhDungMoiNgay(bool isCorrect);
    
private:
    
    
public:
    
};
#endif /* HuyFunctions_hpp */
