//
//  PhepToanOChu.hpp
//  mentalmath
//
//  Created by Huy Le on 29/12/24.
//


#ifndef PhepToanOChu_hpp
#define PhepToanOChu_hpp
#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include <stdio.h>
#include <vector>

class PhepToanOChu {
public:
    PhepToanOChu(); // Constructor
    ~PhepToanOChu(); // Destructor
    
    std::vector<std::vector<std::vector<std::vector<std::vector<int>>>>> arrCauHoiTong;
    std::vector<std::vector<std::vector<std::vector<std::vector<int>>>>> arrDapAnTong;
    std::vector<std::vector<std::vector<std::vector<std::vector<int>>>>> arrTraloiTong;
    
private:
    
    
public:
    
};
#endif /* PhepToanOChu_hpp */
