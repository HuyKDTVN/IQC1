//
//  HuyFunctions.cpp
//  mentalmath-mobile
//
//  Created by Huy Le on 07/03/2024.
//
#include <iostream>
#include <sstream>
#include <string>
#include "ui/CocosGUI.h"
#include "HuyFunctions.hpp"
#include <vector>
#include <ctime>
#include "play.h"
#include "playDual.h"
#include "play2.h"
#include "play3.h"
#include "Variable.hpp"
#include <SimpleAudioEngine.h>
#include "mathSelect.h"
#include "LanguageManager.h"
#include <CoreFoundation/CoreFoundation.h>
#include "GameCenterBridge.h"
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "AdmobHelper.h"
#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
#include "NDKHelper.h"
#endif
using namespace std;
USING_NS_CC;
HuyFunctions::HuyFunctions() {
   
}

HuyFunctions::~HuyFunctions() {
    // Destructor
}
std::vector<int> HuyFunctions::generateRandomNumbers() {
    std::vector<int> numbers;
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(2, 7);

    while (numbers.size() < 4) {
        int num = dis(gen);
        if (std::find(numbers.begin(), numbers.end(), num) == numbers.end()) {
            numbers.push_back(num);
        }
    }

    return numbers;
}
void HuyFunctions::showAds()
{
    if (!Variable().isProVer) {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("showIntertistitalAds", cocos2d::Value());
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    AdmobHelper::showAds();
    AdmobHelper::loadAds();
#endif
    }
}
std::string HuyFunctions::saveSoPhepTinhDungLienTiep(bool isCorrect) {
    auto result = "";
    int soPhepTinhDungLienTiep = 0;
    
    if (isCorrect) {
        soPhepTinhDungLienTiep = UserDefault::getInstance()->getIntegerForKey(Variable().soPhepTinhdungLienTiepString.c_str(), 0) + 1;
        UserDefault::getInstance()->setIntegerForKey(Variable().soPhepTinhdungLienTiepString.c_str(), soPhepTinhDungLienTiep);
    } else {
        UserDefault::getInstance()->setIntegerForKey(Variable().soPhepTinhdungLienTiepString.c_str(), 0);
    }
    switch (soPhepTinhDungLienTiep) {
        case Variable::soPheptinhdungDatMedal2:
            result = "medal2.png";
            UserDefault::getInstance()->setIntegerForKey("medal2", UserDefault::getInstance()->getIntegerForKey("medal2", 0) + 1);
            break;
        case Variable::soPheptinhdungDatMedal3:
            result = "medal3.png";
            UserDefault::getInstance()->setIntegerForKey("medal3", UserDefault::getInstance()->getIntegerForKey("medal3", 0) + 1);
            break;
        case Variable::soPheptinhdungDatMedal4:
            result = "medal4.png";
            UserDefault::getInstance()->setIntegerForKey("medal4", UserDefault::getInstance()->getIntegerForKey("medal4", 0) + 1);
            break;
        case Variable::soPheptinhdungDatMedal5:
            result = "medal5.png";
            UserDefault::getInstance()->setIntegerForKey("medal5", UserDefault::getInstance()->getIntegerForKey("medal5", 0) + 1);
            break;
            
        default:
            break;
    }
    
    log("soPhepTinhdungLienTiepString: %d", UserDefault::getInstance()->getIntegerForKey(Variable().soPhepTinhdungLienTiepString.c_str(), 0));
    
    return result;
}

std::string HuyFunctions::saveSoPhepTinhDungMoiNgay(bool isCorrect) {
    auto result = "";
    int soPhepTinhDungMoiNgay = 0;
    if (isCorrect) {
        if (!checkAddDayOrNot()) {
            soPhepTinhDungMoiNgay = UserDefault::getInstance()->getIntegerForKey(Variable().soPhepTinhDungMoiNgayString.c_str(), 0) + 1;
            UserDefault::getInstance()->setIntegerForKey(Variable().soPhepTinhDungMoiNgayString.c_str(), soPhepTinhDungMoiNgay);
        }else{
            UserDefault::getInstance()->setIntegerForKey(Variable().soPhepTinhDungMoiNgayString.c_str(), 0);
        }
    }
    
    switch (soPhepTinhDungMoiNgay) {
        case Variable::soPheptinhdungDatMedal1:
            result = "medal1.png";
            UserDefault::getInstance()->setIntegerForKey("medal1", UserDefault::getInstance()->getIntegerForKey("medal1", 0) + 1);
            break;
        case Variable::soPheptinhdungDatMedal2:
            result = "medal2.png";
            UserDefault::getInstance()->setIntegerForKey("medal2", UserDefault::getInstance()->getIntegerForKey("medal2", 0) + 1);
            break;
        case Variable::soPheptinhdungDatMedal3:
            result = "medal3.png";
            UserDefault::getInstance()->setIntegerForKey("medal3", UserDefault::getInstance()->getIntegerForKey("medal3", 0) + 1);
            break;
        case Variable::soPheptinhdungDatMedal4:
            result = "medal4.png";
            UserDefault::getInstance()->setIntegerForKey("medal4", UserDefault::getInstance()->getIntegerForKey("medal4", 0) + 1);
            break;
        case Variable::soPheptinhdungDatMedal5:
            result = "medal5.png";
            UserDefault::getInstance()->setIntegerForKey("medal5", UserDefault::getInstance()->getIntegerForKey("medal5", 0) + 1);
            break;
            
        default:
            break;
    }
    
    log("soPhepTinhDungMoiNgayString: %d", UserDefault::getInstance()->getIntegerForKey(Variable().soPhepTinhDungMoiNgayString.c_str(), 0));
    return result;
}
int HuyFunctions::tinhTongSoStickerBangKhen() {
    int sticker = UserDefault::getInstance()->getIntegerForKey("medal1", 0) + UserDefault::getInstance()->getIntegerForKey("medal2", 0) + UserDefault::getInstance()->getIntegerForKey("medal3", 0) + UserDefault::getInstance()->getIntegerForKey("medal4", 0) + UserDefault::getInstance()->getIntegerForKey("medal5", 0);
    return sticker;
}
std::string HuyFunctions::trim(const std::string &s) {
    return ltrim(rtrim(s));
}
std::string HuyFunctions::ltrim(const std::string &s) {
    std::string result = s;
    result.erase(result.begin(), std::find_if(result.begin(), result.end(),
        [](unsigned char ch){ return !std::isspace(ch); }));
    return result;
}

// trim từ cuối (right)
std::string HuyFunctions::rtrim(const std::string &s) {
    std::string result = s;
    result.erase(std::find_if(result.rbegin(), result.rend(),
        [](unsigned char ch){ return !std::isspace(ch); }).base(), result.end());
    return result;
}
void HuyFunctions::drawSolidRoundedRect(cocos2d::DrawNode* node, const cocos2d::Vec2& origin, const cocos2d::Size& size, float radius, const cocos2d::Color4F& color){
    // Middle rectangle
    node->drawSolidRect(
        Vec2(origin.x + radius, origin.y),
        Vec2(origin.x + size.width - radius, origin.y + size.height),
        color
    );

    // Left + right rectangles
    node->drawSolidRect(
        Vec2(origin.x, origin.y + radius),
        Vec2(origin.x + radius, origin.y + size.height - radius),
        color
    );

    node->drawSolidRect(
        Vec2(origin.x + size.width - radius, origin.y + radius),
        Vec2(origin.x + size.width, origin.y + size.height - radius),
        color
    );

    // 4 rounded corners (solid circle sectors)
    node->drawSolidCircle(Vec2(origin.x + radius, origin.y + radius), radius, 0,     32, color);
    node->drawSolidCircle(Vec2(origin.x + size.width - radius, origin.y + radius), radius, 0,     32, color);
    node->drawSolidCircle(Vec2(origin.x + size.width - radius, origin.y + size.height - radius), radius, 0, 32, color);
    node->drawSolidCircle(Vec2(origin.x + radius, origin.y + size.height - radius), radius, 0,     32, color);
}
void HuyFunctions::drawSolidRoundedRect2(cocos2d::DrawNode* node, const cocos2d::Vec2& origin, const cocos2d::Size& size, float radius, const cocos2d::Color4F& color){
    const int SEGMENTS = 24;

        // 1. Rect đáy (vuông)
        node->drawSolidRect(
            origin,
            Vec2(origin.x + size.width, origin.y + size.height - radius),
            color
        );

        // 2. Rect trên giữa
        node->drawSolidRect(
            Vec2(origin.x + radius, origin.y + size.height - radius),
            Vec2(origin.x + size.width - radius, origin.y + size.height),
            color
        );

        // ===== Góc trên trái =====
        std::vector<Vec2> vertsTL;
        vertsTL.push_back(Vec2(origin.x + radius, origin.y + size.height - radius));

        for (int i = 0; i <= SEGMENTS; ++i)
        {
            float angle = M_PI + (M_PI_2 * i / SEGMENTS);
            vertsTL.push_back(Vec2(
                origin.x + radius + cosf(angle) * radius,
                origin.y + size.height - radius + sinf(angle) * radius
            ));
        }

        node->drawSolidPoly(vertsTL.data(), vertsTL.size(), color);

        // ===== Góc trên phải =====
        std::vector<Vec2> vertsTR;
        vertsTR.push_back(Vec2(origin.x + size.width - radius, origin.y + size.height - radius));

        for (int i = 0; i <= SEGMENTS; ++i)
        {
            float angle = -M_PI_2 + (M_PI_2 * i / SEGMENTS);
            vertsTR.push_back(Vec2(
                origin.x + size.width - radius + cosf(angle) * radius,
                origin.y + size.height - radius + sinf(angle) * radius
            ));
        }

        node->drawSolidPoly(vertsTR.data(), vertsTR.size(), color);
}
void HuyFunctions::requestATTAds()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("requestATT", cocos2d::Value());
#endif
}
void HuyFunctions::requestAds(int type)
{
    if (!Variable().isProVer) {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    if (type == 1) {
        sendMessageWithParams("requestIntertistialAdsPlay1", cocos2d::Value());
    }else if (type == 2) {
        sendMessageWithParams("requestIntertistialAdsPlay2", cocos2d::Value());
    }else if (type == 3) {
        sendMessageWithParams("requestIntertistialAdsPlay3", cocos2d::Value());
    }else if (type == 4) {
        sendMessageWithParams("requestIntertistialAdsPlay4", cocos2d::Value());
    }else if (type == 5) {
        sendMessageWithParams("requestIntertistialAdsPlay5", cocos2d::Value());
    }
    else if (type == 6) {
        sendMessageWithParams("requestIntertistialAdsHome", cocos2d::Value());
    }
    else{
        sendMessageWithParams("requestIntertistialAds", cocos2d::Value());
    }
    
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    AdmobHelper::loadAds();
#endif
    }
}

void HuyFunctions::showRewardedAd1()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("showRewardedAd", cocos2d::Value());
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::showAds();
    //AdmobHelper::loadAds();
#endif
}
void HuyFunctions::showRewardedAd2()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("showRewardedAdGifScreen", cocos2d::Value());
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::showAds();
    //AdmobHelper::loadAds();
#endif
}
void HuyFunctions::requestRewardedAd1()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("requestRewardedAd", cocos2d::Value());
    
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::loadAds();
#endif
}
void HuyFunctions::requestRewardedAd2()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("requestRewardedAdGifScreen", cocos2d::Value());
    
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::loadAds();
#endif
}
void HuyFunctions::submitAllowNoti()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("submitAllowNoti", cocos2d::Value());
    
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::loadAds();
#endif
}

void HuyFunctions::requestRewardedAdDiamond()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("requestRewardedAdDiamond", cocos2d::Value());
    
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::loadAds();
#endif
}
void HuyFunctions::showRewardedAdDiamond()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("showRewardedAdDiamond", cocos2d::Value());
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::showAds();
    //AdmobHelper::loadAds();
#endif
}

void HuyFunctions::requestRewardedAdHeart()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("requestRewardedAdHeart", cocos2d::Value());
    
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::loadAds();
#endif
}
void HuyFunctions::showRewardedAdHeart()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    sendMessageWithParams("showRewardedAdHeart", cocos2d::Value());
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    //AdmobHelper::showAds();
    //AdmobHelper::loadAds();
#endif
}

std::string HuyFunctions::NumberToString(int pNumber)
{
    std::ostringstream oOStrStream;
    oOStrStream.clear();
    oOStrStream << pNumber;
    return oOStrStream.str();
}
std::string HuyFunctions::ReplaceString(std::string str, const std::string& from, const std::string& to) {
    size_t start_pos = str.find(from);
    if(start_pos == std::string::npos)
        return "";
    str.replace(start_pos, from.length(), to);
    return str;
}
void HuyFunctions::animationClickedButton(cocos2d::ui::Button* button, const std::function<void()>& callback)  {
    float scaleButton = button->getScale();
    button->runAction(
        Sequence::create(
             ScaleTo::create(0.09, 0.85 * scaleButton),
             DelayTime::create(0.04),
             ScaleTo::create(0.04, 1.08 * scaleButton),
             //ScaleTo::create(0.03, 0.98 * scaleButton),
             ScaleTo::create(0.02, scaleButton),
             cocos2d::CallFunc::create([callback]() {
                             if (callback) {
                                 callback();
                             }
                         }),
            nullptr)
    );
}
void HuyFunctions::animationClickedButtonWithDelay(cocos2d::ui::Button* button, float delayTime, const std::function<void()>& callback)  {
    float scaleButton = button->getScale();
    button->runAction(
        Sequence::create(
             ScaleTo::create(0.09, 0.85 * scaleButton),
             DelayTime::create(0.04),
             ScaleTo::create(0.04, 1.08 * scaleButton),
             ScaleTo::create(0.02, scaleButton),
             DelayTime::create(delayTime),
             cocos2d::CallFunc::create([callback]() {
                             if (callback) {
                                 callback();
                             }
                         }),
            nullptr)
    );
}
int HuyFunctions::SoLonNhat(std::string myLanguage) {
    int maxDoiSo2 = 9;
    
    if (myLanguage == "en"
        || myLanguage == "ja"
        || myLanguage == "de"
        || myLanguage == "ko"
        || myLanguage == "th"
        || myLanguage == "fr"
        || myLanguage == "sp"
        || myLanguage == "ma"
        || myLanguage == "da")
    {
        maxDoiSo2 = 12;
    }
    return maxDoiSo2;
}
bool HuyFunctions::checkAddDayOrNot() {
    bool result = false;
    int currentDay = this->getDayOfYear();

    if(currentDay != UserDefault::getInstance()->getIntegerForKey("dayOfYear", 0)) {
        UserDefault::getInstance()->setIntegerForKey("dayOfYear", currentDay);
        
        UserDefault::getInstance()->setIntegerForKey("daily-sovang", 0);
        saveHeartToDBAndGameCenterAchievement();
        result = true;
    }
    UserDefault::getInstance()->flush();

    log("test so ngay");
    log("so ngay mo app: %i", UserDefault::getInstance()->getIntegerForKey("songay", 0));
    return result;
}
void HuyFunctions::saveSoGame(std::string loaiGame) {
    int loaiGameValue = UserDefault::getInstance()->getIntegerForKey(loaiGame.c_str(), 0);
    if (loaiGameValue == 0) {
        //xac nhan ban da choi thanh cong game nao
        UserDefault::getInstance()->setIntegerForKey(loaiGame.c_str(), 1);
        
        int soGameDaChoi = 0;
        for (int i = 1; i <= Variable().soGame; i++) {
            std::string key = StringUtils::format("g%d", i);
            soGameDaChoi = soGameDaChoi + UserDefault::getInstance()->getIntegerForKey(key.c_str(), 0);
        }
        UserDefault::getInstance()->setIntegerForKey("so-game-da-choi", soGameDaChoi);
        
        float percent = float(soGameDaChoi * 100 / 5);
        if (percent > 100) {
            percent = 100.0f;
        }
        if (inVietNam() == false) {
            GameCenterBridge::reportAchievement("com.huy.mentalmath.playfivegame", percent);
        }
    }
}
int HuyFunctions::getDayOfYear() {
    time_t time = std::time(nullptr);
    tm* timeinfo = localtime(&time);
    return timeinfo->tm_yday;
}
int HuyFunctions::getSoVang() {
    int soVang = UserDefault::getInstance()->getIntegerForKey("sovang", 0);
    if (soVang == 0) {
        soVang = tongDiemPhepCong() + tongDiemPhepTru() + tongDiemPhepNhan() + tongDiemPhepChia();
    }
    return soVang;
}

std::vector<std::string> HuyFunctions::splitString(const std::string &input, char delimiter) {
    std::vector<std::string> result;
    std::stringstream ss(input);
    std::string item;
    
    while (std::getline(ss, item, delimiter)) {
        result.push_back(item);
    }
    
    return result;
}

std::string HuyFunctions::createPhepToanWithEmoji(std::string phepToan) {
    log("phep toan so sanh: %s", phepToan.c_str());
    std::string phepToan2 = ReplaceString(phepToan, "?", "❓");
    if (phepToan2 == "") {
        phepToan = phepToan + " 🤔❓";
    }else {
        log("phep toan so sanh: %s", phepToan2.c_str());
        int random1 = cocos2d::RandomHelper::random_int(0, 7);
        int random2 = cocos2d::RandomHelper::random_int(0, 7);
        phepToan = Variable().emojiStart.at(random1) + phepToan2  + Variable().emojiEnd.at(random2);
    }
    
    
    log("phep toan so sanh: %s", phepToan.c_str());
    return phepToan;
}
int HuyFunctions::getSoHangChuc(int num) {
    int hangDonVi = num % 10;
    int result = (num - hangDonVi) / 10;
    return result;
}
int HuyFunctions::getSoHangDonVi(int num) {
    int a0 = num % 10;
    return a0;
}
void HuyFunctions::savePhepTinhToDataBase(int isCorrect, std::string phepTinh, int cauTraLoi, int myTime, int level, int soVangMoiThem, bool dualMode, bool yesNoMode, int viTriCauTraLoi) {
    
    bool isSoSanh = false;
    
    if (cauTraLoi == 9999 or cauTraLoi == 2222) {
        isSoSanh = true;
    }
    
    bool inVN = inVietNam();
    
    if (yesNoMode == true) {
        if (viTriCauTraLoi == 1) {
            cauTraLoi = 9999;
        } else {
            cauTraLoi = 2222;
        }
    }
    
    cocos2d::__String *saveData = cocos2d::__String::createWithFormat("%s_%i_%i_%iAA%s", phepTinh.c_str(), cauTraLoi, isCorrect, myTime, UserDefault::getInstance()->getStringForKey("data-math", "").c_str());
    //log("pheptoan: %s, v: %i, correctAnswer: %i, time-remain: %i", lblPhepToan->getString().c_str(), v, correctAnswer, myTime);
    log("save data: %s", saveData->getCString());
    log("so vang moi them: %i", soVangMoiThem);
    log("Cap do 1-co ban, 2-kho, 3 -rat kho: %i", level);
    UserDefault::getInstance()->setStringForKey("data-math", saveData->getCString());

    int soPhepTinh = UserDefault::getInstance()->getIntegerForKey("phep-cong", 0) + UserDefault::getInstance()->getIntegerForKey("phep-tru", 0) + UserDefault::getInstance()->getIntegerForKey("phep-nhan", 0) + UserDefault::getInstance()->getIntegerForKey("phep-chia", 0) + UserDefault::getInstance()->getIntegerForKey("phep-cong-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-tru-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-nhan-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-chia-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-cong-ratkho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-tru-ratkho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-nhan-ratkho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-chia-ratkho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-so-sanh", 0) + UserDefault::getInstance()->getIntegerForKey("phep-so-sanh-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-so-sanh-ratkho", 0);
    float tocDo = (UserDefault::getInstance()->getFloatForKey("toc-do", 0) * soPhepTinh + myTime) / (soPhepTinh + 1);
    float percentCorrect;
    if(isCorrect == 1) {
        percentCorrect = (UserDefault::getInstance()->getFloatForKey("phan-tram-dung", 0) * soPhepTinh + 1) / (soPhepTinh + 1);
    }else{
        percentCorrect = (UserDefault::getInstance()->getFloatForKey("phan-tram-dung", 0) * soPhepTinh) / (soPhepTinh + 1);
    }
    if(isCorrect == 1) {
        if (dualMode == true) {
            int soVang = UserDefault::getInstance()->getIntegerForKey("sovang", 0);
            int soVangDaily = UserDefault::getInstance()->getIntegerForKey("daily-sovang", 0);
            soVang = soVang + 1;
            soVangDaily = soVangDaily + 1;
            UserDefault::getInstance()->setIntegerForKey("sovang", soVang);
            UserDefault::getInstance()->setIntegerForKey("daily-sovang", soVangDaily);
            
            if (inVN == false) {
                GameCenterBridge::submitScore(soVang, "com.huy.mentalmath.Golds");
                GameCenterBridge::submitScore(soVangDaily, "com.huy.mentalmath.dailygold");
            }
            
        }
        log("level: %i, phep tinh: %s", level, phepTinh.c_str());
        switch (level) {
            case 1:
                if (isSoSanh) {
                    saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-so-sanh", "com.huy.mentalmath.sosanhlevel1");
                } else {
                    if(phepTinh.find("+") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong", "com.huy.mentalmath.conglevel1");
                    }else if(phepTinh.find("-") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-tru", "com.huy.mentalmath.sublevel1");
                    } else if(phepTinh.find("x") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-nhan", "com.huy.mentalmath.multilevel1");
                    } else if(phepTinh.find(":") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-chia", "com.huy.mentalmath.divisionlevel1");
                    } else{
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong", "com.huy.mentalmath.conglevel1");
                    }
                }
                break;
            case 2:
                if (isSoSanh) {
                    saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-so-sanh-kho", "com.huy.mentalmath.sosanhlevel2");
                } else {
                    if(phepTinh.find("+") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong-kho", "com.huy.mentalmath.conglevel2");
                        
                    } else if(phepTinh.find("-") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-tru-kho", "com.huy.mentalmath.sublevel2");
                        
                    } else if(phepTinh.find("x") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-nhan-kho", "com.huy.mentalmath.multilevel2");
                        
                    } else if(phepTinh.find(":") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-chia-kho", "com.huy.mentalmath.divisionlevel2");
                    } else {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong-kho", "com.huy.mentalmath.conglevel2");
                    }
                }
                
                break;
            case 3:
                if (isSoSanh) {
                    saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-so-sanh-ratkho", "com.huy.mentalmath.sosanhlevel3");
                } else {
                    if(phepTinh.find("+") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong-ratkho", "com.huy.mentalmath.conglevel3");
                    } else if(phepTinh.find("-") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-tru-ratkho", "com.huy.mentalmath.sublevel3");
                    } else if(phepTinh.find("x") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-nhan-ratkho", "com.huy.mentalmath.multilevel3");
                    } else if(phepTinh.find(":") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-chia-ratkho", "com.huy.mentalmath.divisionlevel3");
                    } else {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong-ratkho", "com.huy.mentalmath.conglevel3");
                    }
                }
                break;
                
            default:
                if (isSoSanh) {
                    saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-so-sanh", "com.huy.mentalmath.sosanhlevel1");
                } else {
                    if(phepTinh.find("+") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong", "com.huy.mentalmath.conglevel1");
                    }else if(phepTinh.find("-") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-tru", "com.huy.mentalmath.sublevel1");
                    } else if(phepTinh.find("x") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-nhan", "com.huy.mentalmath.multilevel1");
                    } else if(phepTinh.find(":") != string::npos) {
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-chia", "com.huy.mentalmath.divisionlevel1");
                    } else{
                        saveTungLoaiPhepTinhToDBAndGameCenterAchievement("phep-cong", "com.huy.mentalmath.conglevel1");
                    }
                }
                break;
        }
        
        UserDefault::getInstance()->setFloatForKey("toc-do", tocDo);
    }else{
        if (dualMode == false) {
            int soVang = UserDefault::getInstance()->getIntegerForKey("sovang", 0);
            int soVangDaily = UserDefault::getInstance()->getIntegerForKey("daily-sovang", 0);
            
            if (soVangMoiThem > 0) {
                soVang = soVang + soVangMoiThem;
                UserDefault::getInstance()->setIntegerForKey("sovang", soVang);

                soVangDaily = soVangDaily + soVangMoiThem;
                UserDefault::getInstance()->setIntegerForKey("daily-sovang", soVangDaily);
                
                if (inVN == false) {
                    // Gửi điểm số
                    GameCenterBridge::submitScore(soVang, "com.huy.mentalmath.Golds");
                    // Gửi điểm số
                    GameCenterBridge::submitScore(soVangDaily, "com.huy.mentalmath.dailygold");
                }
            }
        }
    }
    
    UserDefault::getInstance()->setFloatForKey("phan-tram-dung", percentCorrect);
    log("Diem so cap do co ban");
    log("phep cong: %i, phep tru: %i, phep nhan: %i, phep chia: %i, tong: %i, toc do: %f", UserDefault::getInstance()->getIntegerForKey("phep-cong", 0), UserDefault::getInstance()->getIntegerForKey("phep-tru", 0), UserDefault::getInstance()->getIntegerForKey("phep-nhan", 0), UserDefault::getInstance()->getIntegerForKey("phep-chia", 0),  soPhepTinh, tocDo);
    log("Diem so cap do Kho");
    log("phep cong: %i, phep tru: %i, phep nhan: %i, phep chia: %i", UserDefault::getInstance()->getIntegerForKey("phep-cong-kho", 0), UserDefault::getInstance()->getIntegerForKey("phep-tru-kho", 0), UserDefault::getInstance()->getIntegerForKey("phep-nhan-kho", 0), UserDefault::getInstance()->getIntegerForKey("phep-chia-kho", 0));
    log("Diem so cap do Rat Kho");
    log("phep cong: %i, phep tru: %i, phep nhan: %i, phep chia: %i", UserDefault::getInstance()->getIntegerForKey("phep-cong-ratkho", 0), UserDefault::getInstance()->getIntegerForKey("phep-tru-ratkho", 0), UserDefault::getInstance()->getIntegerForKey("phep-nhan-ratkho", 0), UserDefault::getInstance()->getIntegerForKey("phep-chia-ratkho", 0));
    
    
    //save tong so phep tinh => hien thi notification ve ket qua hoc tap
    auto ketQua = cocos2d::__String::createWithFormat(": %i %s (>=< %i, + %i, - %i, x %i, : %i)", tongDiemPhepCong() + tongDiemPhepTru() + tongDiemPhepNhan() + tongDiemPhepChia() + tongDiemPhepSoSanh(), LanguageManager::getInstance()->getStringForKey("PHEPTINH").c_str(),tongDiemPhepSoSanh(), tongDiemPhepCong(), tongDiemPhepTru(), tongDiemPhepNhan(), tongDiemPhepChia());
    
    std::string desc = LanguageManager::getInstance()->getStringForKey("TOTAL").c_str();
    desc.append(ketQua->getCString());
    
    UserDefault::getInstance()->setStringForKey("noti-title2", LanguageManager::getInstance()->getStringForKey("YOURARCHIVE_TITLE").c_str());
    UserDefault::getInstance()->setStringForKey("noti-desc2", desc.c_str());
}
cocos2d::DrawNode* HuyFunctions::createChuNhatBoGoc(float width, float height, cocos2d::Vec2 origin) {
    // Tạo một DrawNode để vẽ
    auto drawNode = cocos2d::DrawNode::create();
    cocos2d::Color4F color(1.0f, 1.0f, 1.0f, 1.0f);

    float radius = height / 2;
    // Vẽ hình chữ nhật bo góc
    drawNode->drawSolidRect(cocos2d::Vec2(origin.x + radius, origin.y),
                           cocos2d::Vec2(origin.x + width - radius, origin.y + height),
                           color);
    // Vẽ bốn góc bo tròn
    drawNode->drawSolidCircle(cocos2d::Vec2(origin.x + radius, origin.y + radius), radius, 0, 50, 1, 1, color); // Góc trên trái
    drawNode->drawSolidCircle(cocos2d::Vec2(origin.x + width - radius, origin.y + radius), radius, 0, 50, 1, 1, color); // Góc trên phải
    drawNode->drawSolidCircle(cocos2d::Vec2(origin.x + radius, origin.y + height - radius), radius, 0, 50, 1, 1, color); // Góc dưới trái
    drawNode->drawSolidCircle(cocos2d::Vec2(origin.x + width - radius, origin.y + height - radius), radius, 0, 50, 1, 1, color); // Góc dưới phải
    return  drawNode;
}int HuyFunctions::perCentChallenge(int index) {
    int result = 0;
    int soPhepTinhMucTieu = Variable().arrChallenge.at(1).at(index);
    int loaiPhepTinh = Variable().arrChallenge.at(0).at(index);
    int level = Variable().arrChallenge.at(2).at(index);
    auto loaiPhepTinhString = "phep-cong";
    switch (loaiPhepTinh) {
        case 0: // type:: +:0, -:1, x:2, :3 <>=4
            switch (level) { //level: 1 - de, 2 - vua, 3 - kho
                case 1:
                    loaiPhepTinhString = "phep-cong";
                    break;
                case 2:
                    loaiPhepTinhString = "phep-cong-kho";
                    break;
                case 3:
                    loaiPhepTinhString = "phep-cong-ratkho";
                    break;
            
                default:
                    loaiPhepTinhString = "phep-cong";
                    break;
            }
            break;
            
        case 1: // type:: +:0, -:1, x:2, :3
            switch (level) { //level: 1 - de, 2 - vua, 3 - kho
                case 1:
                    loaiPhepTinhString = "phep-tru";
                    break;
                case 2:
                    loaiPhepTinhString = "phep-tru-kho";
                    break;
                case 3:
                    loaiPhepTinhString = "phep-tru-ratkho";
                    break;
                default:
                    loaiPhepTinhString = "phep-tru";
                    break;
            }
            break;
        case 2: // type:: +:0, -:1, x:2, :3
            switch (level) { //level: 1 - de, 2 - vua, 3 - kho
                case 1:
                    loaiPhepTinhString = "phep-nhan";
                    break;
                case 2:
                    loaiPhepTinhString = "phep-nhan-kho";
                    break;
                case 3:
                    loaiPhepTinhString = "phep-nhan-ratkho";
                    break;
                default:
                    loaiPhepTinhString = "phep-nhan";
                    break;
            }
            break;
        case 3: // type:: +:0, -:1, x:2, :3
            switch (level) { //level: 1 - de, 2 - vua, 3 - kho
                case 1:
                    loaiPhepTinhString = "phep-chia";
                    break;
                case 2:
                    loaiPhepTinhString = "phep-chia-kho";
                    break;
                case 3:
                    loaiPhepTinhString = "phep-chia-ratkho";
                    break;
                default:
                    loaiPhepTinhString = "phep-chia";
                    break;
            }
            break;
        case 4: // type:: +:0, -:1, x:2, :3
            switch (level) { //level: 1 - de, 2 - vua, 3 - kho
                case 1:
                    loaiPhepTinhString = "phep-so-sanh";
                    break;
                case 2:
                    loaiPhepTinhString = "phep-so-sanh-kho";
                    break;
                case 3:
                    loaiPhepTinhString = "phep-so-sanh-ratkho";
                    break;
                default:
                    loaiPhepTinhString = "phep-so-sanh";
                    break;
            }
            break;
            
        default:
            break;
    }
    
    int soPhepTinh = UserDefault::getInstance()->getIntegerForKey(loaiPhepTinhString, 0);
    
    int batDauThuThachMoi = UserDefault::getInstance()->getIntegerForKey("bat-dau-thu-thach-moi", 0);
    if (batDauThuThachMoi == 0) {
        result = 0;
        UserDefault::getInstance()->setIntegerForKey("so-phep-tinh-tt-truoc", soPhepTinh);
    } else {
        int soPhepTinhThuThachTruoc = UserDefault::getInstance()->getIntegerForKey("so-phep-tinh-tt-truoc", 0);
        
        if (soPhepTinhThuThachTruoc > soPhepTinh) {
            UserDefault::getInstance()->setIntegerForKey(loaiPhepTinhString, soPhepTinhThuThachTruoc);
            soPhepTinh = UserDefault::getInstance()->getIntegerForKey(loaiPhepTinhString, 0);
        }
        
        result = int( ( soPhepTinh - soPhepTinhThuThachTruoc) * 100 / soPhepTinhMucTieu);
        if (result > 100) {
            result = 100;
        }
        log("percent thu thach: %i | %i | %i | %i", result, soPhepTinh, soPhepTinhThuThachTruoc, soPhepTinhMucTieu);
    }
    
    return result;
}
void HuyFunctions::saveTungLoaiPhepTinhToDBAndGameCenterAchievement(std::string loaiPhepTinh, std::string achiemvementID) {
    log("chuan bi luu diem so vao DB");
    int soPhepTinh = UserDefault::getInstance()->getIntegerForKey(loaiPhepTinh.c_str(), 0) + 1;
    UserDefault::getInstance()->setIntegerForKey(loaiPhepTinh.c_str(), soPhepTinh);
    float percentPhepTinh = float(soPhepTinh);
    if (soPhepTinh > 100) {
        percentPhepTinh = 100.0f;
    }
    if (inVietNam() == false) {
        GameCenterBridge::reportAchievement(achiemvementID.c_str(), percentPhepTinh);
    }
}
void HuyFunctions::saveDiamondToDBAndGameCenterAchievement(int add) {
    int diamond = UserDefault::getInstance()->getIntegerForKey("diamond", 0);
    if (add > 0) {
        diamond = diamond + add;
    }
    UserDefault::getInstance()->setIntegerForKey("diamond", diamond);
    float percentLevel1 = float(diamond * 2);
    if (percentLevel1 > 100) {
        percentLevel1 = 100.0f;
    }
    
    
    float percentLevel2 = float(diamond * 0.2);
    if (percentLevel2 > 100) {
        percentLevel2 = 100.0f;
    }
    
    if (inVietNam() == false) {
        GameCenterBridge::reportAchievement("com.huy.mentalmath.50diamonds", percentLevel1);
        GameCenterBridge::reportAchievement("com.huy.mentalmath.500diamonds", percentLevel2);
    }
}

void HuyFunctions::saveHeartToDBAndGameCenterAchievement(bool add) {
    int heart = UserDefault::getInstance()->getIntegerForKey("songay", 0);
    if (add) {
        heart = heart + 1;
    }
    UserDefault::getInstance()->setIntegerForKey("songay", heart);
    float percentLevel1 = float(heart * 100 / 30);
    if (percentLevel1 > 100) {
        percentLevel1 = 100.0f;
    }
 
    float percentLevel2 = float(heart * 100 / 200);
    if (percentLevel2 > 100) {
        percentLevel2 = 100.0f;
    }
    if (inVietNam() == false) {
        GameCenterBridge::reportAchievement("com.huy.mentalmath.30hearts", percentLevel1);
        GameCenterBridge::reportAchievement("com.huy.mentalmath.200hearts", percentLevel2);
    }
}
int HuyFunctions::tongDiemPhepCong() {
    return UserDefault::getInstance()->getIntegerForKey("phep-cong", 0) + UserDefault::getInstance()->getIntegerForKey("phep-cong-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-cong-ratkho", 0);
}
int HuyFunctions::tongDiemPhepTru() {
    return UserDefault::getInstance()->getIntegerForKey("phep-tru", 0) + UserDefault::getInstance()->getIntegerForKey("phep-tru-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-tru-ratkho", 0);
}
int HuyFunctions::tongDiemPhepNhan() {
    return UserDefault::getInstance()->getIntegerForKey("phep-nhan", 0) + UserDefault::getInstance()->getIntegerForKey("phep-nhan-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-nhan-ratkho", 0);
}
int HuyFunctions::tongDiemPhepChia() {
    return UserDefault::getInstance()->getIntegerForKey("phep-chia", 0) + UserDefault::getInstance()->getIntegerForKey("phep-chia-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-chia-ratkho", 0);
}
int HuyFunctions::tongDiemPhepSoSanh() {
    return UserDefault::getInstance()->getIntegerForKey("phep-so-sanh", 0) + UserDefault::getInstance()->getIntegerForKey("phep-so-sanh-kho", 0) + UserDefault::getInstance()->getIntegerForKey("phep-so-sanh-ratkho", 0);
}
std::string HuyFunctions::getCurrentLang() {
    auto languageC = Application::getInstance()->getCurrentLanguageCode();
    auto *currentLanguage = "en";
    if(strcmp(languageC,"vi") == 0) {
        currentLanguage = "vi";
    }
    if(strcmp(languageC,"ja") == 0) {
        currentLanguage = "ja";
    }
    if(strcmp(languageC,"fr") == 0) {
        currentLanguage = "fr";
    }
    if(strcmp(languageC,"de") == 0) {
        currentLanguage = "de";
    }
    if(strcmp(languageC,"ko") == 0) {
        currentLanguage = "ko";
    }
    if(strcmp(languageC,"th") == 0) {
        currentLanguage = "th";
    }
    if(strcmp(languageC,"ru") == 0) {
        currentLanguage = "ru";
    }
    if(strcmp(languageC,"zh") == 0) {
        currentLanguage = "zh";
    }
    if(strcmp(languageC,"pt") == 0) {
        currentLanguage = "pt";
    }
//        if(strcmp(languageC,"ar") == 0) {
//            currentLanguage = "ar";
//        }
    if(strcmp(languageC,"it") == 0) {
        currentLanguage = "it";
    }
    if(strcmp(languageC,"id") == 0) {
        currentLanguage = "id";
    }
    if(strcmp(languageC,"tr") == 0) {
        currentLanguage = "tr";
    }
    if(strcmp(languageC,"ca") == 0) {
        currentLanguage = "ca";
    }
    if(strcmp(languageC,"cr") == 0) {
        currentLanguage = "cr";
    }
    if(strcmp(languageC,"cz") == 0) {
        currentLanguage = "cz";
    }
    if(strcmp(languageC,"da") == 0) {
        currentLanguage = "da";
    }
    if(strcmp(languageC,"du") == 0) {
        currentLanguage = "du";
    }
    if(strcmp(languageC,"fi") == 0) {
        currentLanguage = "fi";
    }
    if(strcmp(languageC,"gr") == 0) {
        currentLanguage = "gr";
    }
    if(strcmp(languageC,"hi") == 0) {
        currentLanguage = "hi";
    }
    if(strcmp(languageC,"hu") == 0) {
        currentLanguage = "hu";
    }
    if(strcmp(languageC,"ma") == 0) {
        currentLanguage = "ma";
    }
    if(strcmp(languageC,"no") == 0) {
        currentLanguage = "no";
    }
    if(strcmp(languageC,"po") == 0) {
        currentLanguage = "po";
    }
    if(strcmp(languageC,"ro") == 0) {
        currentLanguage = "ro";
    }
    if(strcmp(languageC,"sk") == 0) {
        currentLanguage = "sk";
    }
    if(strcmp(languageC,"sp") == 0) {
        currentLanguage = "sp";
    }
    if(strcmp(languageC,"sw") == 0) {
        currentLanguage = "sw";
    }
    if(strcmp(languageC,"uk") == 0) {
        currentLanguage = "uk";
    }
    
    return currentLanguage;
}
int HuyFunctions::getthanhTich(int soDiem) {
    
    int result = 1;
    if (soDiem > 0 && soDiem < Variable().diemTim) {
        result = 2;
    } else if (soDiem >= Variable().diemTim  && soDiem < Variable().diemDo){
        result = 3;
    }
    else if (soDiem >= Variable().diemDo && soDiem < Variable().diemXanh){
        result = 4;
    }
    else if (soDiem >= Variable().diemXanh && soDiem < Variable().diemVang){
        result = 5;
    }else if (soDiem >= Variable().diemVang){
        result = 6;
    }
    return result;
}
int HuyFunctions::chuyenGiaTriPhepTinh(int loaiPhepTinhCu) {
    int result = 4;
    
    //loai cu
    //typePhepTinh = 0 - +
    //typePhepTinh = 1 - -
    //typePhepTinh = 2 - x
    //typePhepTinh = 3 - :
    //typePhepTinh = 4 - >=<
    //can chuyen sang loai moi
    //2 - nhan; 3 - chia; 4 - cong; 5 - tru; 1 - multi
    switch (loaiPhepTinhCu) {
        case 0:
            result = 4;
            break;
        case 1:
            result = 5;
            break;
        case 2:
            result = 2;
            break;
        case 3:
            result = 3;
        case 4:
            result = 6;
            break;
        default:
            break;
    }
    return  result;
}
cocos2d::ui::Button* HuyFunctions::createButtonPhepTinh(double w, double h, int modeGame, double y, int viTri, int loaiPhepTinh) {
    auto imageType = "cong%d.png";
    auto diemType = "phep-cong";
    auto prefix = "";
    switch (loaiPhepTinh) {
        case 2:
            imageType = "tru%d.png";
            diemType = "phep-tru";
            break;
        case 3:
            imageType = "nhan%d.png";
            diemType = "phep-nhan";
            break;
        case 4:
            imageType = "chia%d.png";
            diemType = "phep-chia";
            break;
        case 5:
            imageType = "button-all2.png";
            diemType = "";
            break;
        case 6:
            imageType = "sosanh%d.png";
            diemType = "phep-so-sanh";
            break;
        default:
            imageType = "cong%d.png";
            diemType = "phep-cong";
            break;
    }
    if (viTri == 2) {
        prefix = "-kho";
    }
    if (viTri == 3) {
        prefix = "-ratkho";
    }
    
    double ratioScreen = h/w;
    //button cong
    auto dataFieldName = cocos2d::__String::createWithFormat("%s%s", diemType, prefix);
    
    
    int diemInt = UserDefault::getInstance()->getIntegerForKey(dataFieldName->getCString(), 0);
    log("loai phep tinh: %s - %i diem", dataFieldName->getCString(), diemInt);
    int thanhTich = HuyFunctions().getthanhTich(diemInt);
    auto imgName = StringUtils::format(imageType, thanhTich);
    auto buttonCong = ui::Button::create(imgName, imgName); // tao button
    float ratioButtonCong = 5.5;
    if (ratioScreen <= 1.53)
    {
        ratioButtonCong = 9;
    }
    float scaleButtonCong = w / ratioButtonCong / buttonCong->getContentSize().width;
    buttonCong->setScale(scaleButtonCong);
    float yButton = y - buttonCong->getContentSize().height * scaleButtonCong / 2 - 0.05 * h;
    float xButton = w / 6;
    if (viTri == 2) {
        xButton =  w / 2;
    }else if (viTri == 3) {
        xButton = 5 * w / 6;
    }
    
    buttonCong->setPosition(Vec2(xButton, yButton));
    //this->addChild(buttonCong);//add button vao scene
    if (diemInt != 0 and diemType != "") {
        auto fontSize = 0.06 * w;
        auto fontStyle = "fonts/BraahOne-Regular.ttf";
        
        auto diemString = cocos2d::__String::createWithFormat("%i", diemInt);
        auto diemLabel = Label::createWithTTF(diemString->getCString(), fontStyle, fontSize);
        diemLabel->setColor(Color3B().WHITE);
        // position the label on the center of the screen
        float xValueScore = buttonCong->getContentSize().width * scaleButtonCong / 2;
        float yValueScore = buttonCong->getContentSize().height * scaleButtonCong / 2 - 10;
        if (h / w <= 1.53) {
            diemLabel->setPosition(Vec2(xValueScore * 2, yValueScore + 15));
        } else{
            diemLabel->setPosition(Vec2(xValueScore + 7, yValueScore));
        }
        diemLabel->setAnchorPoint({0.5, 0.5});
        diemLabel->setHorizontalAlignment(TextHAlignment::CENTER);
        buttonCong->addChild(diemLabel, 1);
        if (thanhTich == 6) {
            diemLabel->setColor(Color3B().BLACK);
        }
    }
    if (thanhTich == 6) {
        auto vuongMien = Sprite::create("vuong-mien.png");
        float ratiovuongMien = 7;
//        if (ratioScreen <= 1.53)
//        {
//            ratiovuongMien = 7;
//        }
        float scalevuongMien = w / ratiovuongMien / vuongMien->getContentSize().width;
        vuongMien->setScale(scalevuongMien);
        vuongMien->setPosition(Vec2(buttonCong->getContentSize().width / 2, buttonCong->getContentSize().height + vuongMien->getContentSize().height * 0.4));
        buttonCong->addChild(vuongMien);
    }

    return  buttonCong;
}
cocos2d::ui::Button* HuyFunctions::createArrow(double w, double h, double x, double y) {
    auto btn = ui::Button::create("arrow-dut.png", "arrow-dut.png");// tao button
    float ratioLang = 10;
    float fixIpad = 0;
    if (h / w <= 1.53)
    {
        ratioLang = 16;
        fixIpad = w / 20;
    }
    float scaleLang = w / ratioLang / btn->getContentSize().width;
    btn->setScale(scaleLang);
    
    btn->setPosition(Vec2(x + btn->getContentSize().width * scaleLang /2 + 3 + fixIpad, y));
    return  btn;
}
cocos2d::ui::Button* HuyFunctions::creategGroupInfor(double w, double h, double y, std::string iconName, std::string iconDesc, std::string myTitle, std::string mydesc, std::string colorText, double delayAnimationDesc) {
    double fontSize = 0.05 * w;
    auto btn = ui::Button::create("bg-infor.png", "bg-infor.png");// tao button
    //btn->setPressedActionEnabled(true);
    //btn->setZoomScale(-0.1f);
    //btn->setScale9Enabled(true);
    //btn->setTouchEnabled(true);
    float ratioLang = 1.2;
    if (h / w <= 1.53)
    {
        ratioLang = 2.7;
        //fontSize = 0.045 * w;
    }
    float scaleLang = w / ratioLang / btn->getContentSize().width;
    btn->setScale(scaleLang);
    btn->setPosition(Vec2(w / 2, y));
    
    auto icon = ui::Button::create(iconName, iconName);// tao button
    float ratioIcon = 10;
    float scaleIcon = w / ratioIcon / icon->getContentSize().height;
    icon->setScale(scaleIcon);
    icon->setTag(11);
   // float yicon = y;
    icon->setPosition(Vec2(20 + icon->getContentSize().width * scaleIcon / 2, icon->getContentSize().height * scaleIcon + 5));
    btn->addChild(icon);
    if (iconDesc != "") {
        icon->setName(iconDesc);
    }
    
    auto myColor = Color3B().WHITE;
    if (colorText == "xanh") {
        myColor = Color3B(125, 218, 255);
    }
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
    }
    if (myTitle != "") {
        auto title = Label::createWithTTF(myTitle, fontStyle, fontSize);
        title->setColor(myColor);
        // position the label on the center of the screen
       
        title->setPosition(Vec2(icon->getPositionX() + icon->getContentSize().width * scaleIcon / 2 + 12, icon->getPositionY() ));
        title->setAnchorPoint({0, 0.5});
        title->setHorizontalAlignment(TextHAlignment::CENTER);
        btn->addChild(title);
    }
    
    if (mydesc != "") {
        fontStyle = "fonts/BraahOne-Regular.ttf";
        auto desc = Label::createWithTTF(mydesc, fontStyle, fontSize * 1.6);
        desc->setTag(10);
        desc->setColor(myColor);
        // position the label on the center of the screen
        if (h / w <= 1.53) {
            //desc->setPosition(Vec2(xValueScore * 2, yValueScore + 15));
        } else{
            //desc->setPosition(Vec2(xValueScore + 7, yValueScore));
        }
        //desc->setPosition(Vec2(w - (w - btn->getContentSize().width * scaleLang) / 2 - 10, btn->getContentSize().height * scaleLang / 2 + 7));
        desc->setPosition(Vec2(btn->getContentSize().width * 0.92, icon->getPositionY()));
        desc->setAnchorPoint({1, 0.5});
        desc->setHorizontalAlignment(TextHAlignment::RIGHT);
        btn->addChild(desc);
        
        if (delayAnimationDesc > 0) {
            
            desc->setScale(2);
            desc->setOpacity(0);
            
            if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0)
            {
                desc->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");; })));
            }
            float timeAnimation = 0.3;
            auto sq3 = Sequence::create(
                            DelayTime::create(delayAnimationDesc),
                            Spawn::create(
                                ScaleTo::create(timeAnimation  / 1.2, 0.8),
                                FadeIn::create(timeAnimation  / 1.2), nullptr),
                            DelayTime::create(0.1),
                            ScaleTo::create(timeAnimation  / 1, 1),
                            nullptr);
            desc->runAction(sq3);
        }
    }
    return btn;
}
bool HuyFunctions::hasTet() {
    bool result = false;
    auto quocGia = HuyFunctions().getCountry();
    auto lang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "ii");
    log("current code lang: %s", lang.c_str());
    if (quocGia == "VN" || quocGia == "KR" || quocGia == "TH" || quocGia == "JP" || quocGia == "SG" || quocGia == "MY" || quocGia == "TW" || quocGia == "ID" || lang == "vi" || lang == "ko" || lang == "th" || lang == "ja" || lang == "ma" || lang == "id") {
        //        Việt Nam
        //        Hàn Quốc
        //        Thái Lan
        //        Nhật Bản
        //        Singapore
        //        Malaysia
        //        Đài Loan
        //        Indonesia
        result = true;
    }
    return result;
}
bool HuyFunctions::inVietNam() {
    bool result = false;
    auto quocGia = HuyFunctions().getCountry();
    //auto lang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "ii");
    if (Variable().isProduction == true) {
        if (quocGia == "VN" ) { //|| lang == "vi"
            result = true;
        }
    }
    return result;
}
std::string HuyFunctions::getCountry()
{
    CFLocaleRef locale = CFLocaleCopyCurrent();
    CFStringRef country = (CFStringRef)CFLocaleGetValue(locale, kCFLocaleCountryCode);
    char buffer[256];
    CFStringGetCString(country, buffer, sizeof(buffer), kCFStringEncodingUTF8);
    CFRelease(locale);
    return std::string(buffer);
}
cocos2d::ui::Button* HuyFunctions::createGiftCard(double w, double h, double y, std::string iconName, std::string markName, bool isActive) {
    auto btn = ui::Button::create("bg-gift-card.png", "bg-gift-card.png");// tao button
    //btn->setPressedActionEnabled(true);
    //btn->setZoomScale(-0.1f);
    //btn->setScale9Enabled(true);
    //btn->setTouchEnabled(true);
    float ratioLang = 5;
    int fixWidth = 10;
    int fixWidthxIcon = 0;
    int fixWidthMark = 0;
    
    float fixWidthScale = 1;
    float fixHeightScale = 1;
    if (isActive) {
        ratioLang = 4.2;
        fixWidth = 5;
        fixWidthxIcon = 5;
        fixWidthMark = 5;
        btn->setTag(1);
    }
    if (h / w <= 1.53)
    {
        ratioLang = 10;
        fixWidthScale = 2;
        fixHeightScale = 2;
        if (isActive) {
            ratioLang = 8;
        }
    }
    float scaleLang = w / ratioLang / btn->getContentSize().width;
    btn->setScale(scaleLang);
    if (isActive == false) {
        btn->setOpacity(150);
        btn->setTag(0);
    }
    btn->setPosition(Vec2(w - btn->getContentSize().width * scaleLang / 2 - fixWidth, y));
    
    auto icon = ui::Button::create(iconName, iconName);// tao button
    float ratioIcon = 6;
    float scaleIcon = w / ratioIcon / icon->getContentSize().width;
    
    icon->setScale(scaleIcon);
   // float yicon = y;
    icon->setPosition(Vec2(btn->getContentSize().width * scaleLang / 2 * fixWidthScale + 5 - fixWidthxIcon * fixWidthScale, btn->getContentSize().height * scaleLang / 2 * fixHeightScale + 5 - fixWidthxIcon));
    btn->addChild(icon);
    
    if (markName != "") {
        auto mark = ui::Button::create(markName, markName);// tao button
        float ratiomark = 14;
        float scalemark = w / ratiomark / mark->getContentSize().width;
        mark->setScale(scalemark);
        mark->setName("mark");
       // float ymark = y;
        mark->setPosition(Vec2(btn->getContentSize().width * scaleLang / 2 * fixWidthScale + 5 - fixWidthMark, 0));
        btn->addChild(mark, 10);
    }
    
    return btn;
}
cocos2d::ui::Button* HuyFunctions::createButtonGift(double w, double h, double x, std::string iconName) {
    auto btn = ui::Button::create("bg-icon-gift.png", "bg-icon-gift.png");// tao button
    //btn->setPressedActionEnabled(true);
    //btn->setZoomScale(-0.1f);
    //btn->setScale9Enabled(true);
    //btn->setTouchEnabled(true);
    float ratioLang = 5;
    float fixWithScale = 1;
    float fixHeightScale = 1;
    if (h / w <= 1.53)
    {
        ratioLang = 10;
        fixWithScale = 2.1;
        fixHeightScale = 2;
    }
    float scaleLang = w / ratioLang / btn->getContentSize().width;
    btn->setScale(scaleLang);
    btn->setPosition(Vec2(x, h * 0.1));
    
    auto icon = ui::Button::create(iconName, iconName);// tao button
    float ratioIcon = 6;
    float scaleIcon = w / ratioIcon / icon->getContentSize().width;
    
    icon->setScale(scaleIcon);
   // float yicon = y;
    icon->setPosition(Vec2(btn->getContentSize().width * scaleLang * 2/ 3 * fixWithScale, btn->getContentSize().height * scaleLang * 2 / 3 * fixHeightScale));
    btn->addChild(icon);
    
    
    
    return btn;
}
cocos2d::ui::Button* HuyFunctions::createCheckBox(double w, double h, double y, std::string iconName, std::string iconSelectedName, std::string myTitle) {
   
    double fontSize = 0.05 * w;
    auto btn = ui::Button::create("bg-infor.png", "bg-infor.png");// tao button
    float ratioLang = 1.2;
    if (h / w <= 1.53)
    {
        ratioLang = 3;
        fontSize = 0.035 * w;
    }
    float scaleLang = w / ratioLang / btn->getContentSize().width;
    btn->setScale(scaleLang);
    btn->setPosition(Vec2(w / 2, y));
    auto icon = ui::Button::create(iconName, iconName);// tao button;
    if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 1)
    {
        icon->loadTextureNormal(iconSelectedName);
       
    }
    float ratioIcon = 10;
    float scaleIcon = w / ratioIcon / icon->getContentSize().height;
    icon->setScale(scaleIcon);
   // float yicon = y;
    icon->setPosition(Vec2(20 + icon->getContentSize().width * scaleIcon / 2, icon->getContentSize().height * scaleIcon + 5));
    btn->addChild(icon);
   
    auto myColor = Color3B().WHITE;
  
    auto fontStyle = "fonts/comfortaa.ttf";
    if (myTitle != "") {
        auto title = Label::createWithTTF(myTitle, fontStyle, fontSize);
        title->setColor(myColor);
        title->setPosition(Vec2(icon->getPositionX() + icon->getContentSize().width * scaleIcon / 2 + 12, btn->getContentSize().height * scaleLang / 2 + 5));
        title->setAnchorPoint({0, 0.5});
        title->setHorizontalAlignment(TextHAlignment::CENTER);
        btn->addChild(title);
    }
    
    icon->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        
        auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0)
                {
                    UserDefault::getInstance()->setIntegerForKey("sound", 1);
                    UserDefault::getInstance()->flush();
                    buttonIcon->loadTextureNormal(iconSelectedName);
                   
                }
                else
                {
                    UserDefault::getInstance()->setIntegerForKey("sound", 0);
                    UserDefault::getInstance()->flush();
                    buttonIcon->loadTextureNormal(iconName);
                }
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    return btn;
}
int HuyFunctions::getKetQuaDiemSoNgauNhien(int diemHienTai, std::string loaiPhepTinh, int soDiemNgauNhien) {
    int diemTuongLai = diemHienTai;
    
    if (loaiPhepTinh == "+") {
        diemTuongLai = diemHienTai + soDiemNgauNhien;
    } else if (loaiPhepTinh == "*") {
        diemTuongLai = diemHienTai * soDiemNgauNhien;
    }else{
        diemTuongLai = diemHienTai - soDiemNgauNhien;
    }
    if (diemTuongLai < 0) {
        diemTuongLai = 0;
    }
    
    return diemTuongLai;
}

int HuyFunctions::getRandomForThemDiem(int score) {
    int doDaiMang = static_cast<int>(Variable().diemNgauNhienImg.size());
    //log("score hien tai: %i", score);
    if (score > 20) {
        doDaiMang = doDaiMang - 1;
    }
    if (score > 40) {
        doDaiMang = doDaiMang - 1;
    }
    if (score == 0) {
        return cocos2d::RandomHelper::random_int(0, doDaiMang - 2);
    } else {
        return cocos2d::RandomHelper::random_int(0, doDaiMang - 1);
    }
    
    
}
void HuyFunctions::animationZoomToShowForButton(cocos2d::ui::Button* button, float timeDelay, float timeAnimation, float scaleTo) {
    button->setOpacity(0);
    button->runAction(
         Sequence::create(
            DelayTime::create(timeDelay),
            Spawn::create(
                        ScaleTo::create(0, button->getScale() * scaleTo),
                        FadeOut::create(0),
                        nullptr),
            Spawn::create(
                        ScaleTo::create(timeAnimation, button->getScale()),
                        FadeIn::create(timeAnimation),
                        nullptr),
            nullptr)
    );
}
