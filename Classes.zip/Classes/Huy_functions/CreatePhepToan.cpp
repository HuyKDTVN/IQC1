//
//  CreatePhepToan.cpp
//  mentalmath-mobile
//
//  Created by Huy Le on 9/3/24.
//
#include <iostream>
#include <string>
#include "CreatePhepToan.hpp"
#include "Variable.hpp"
#include "HuyFunctions.hpp"
#include <vector>
#include <unordered_set>
using namespace std;
USING_NS_CC;
CreatePhepToan::CreatePhepToan() {
   
}
CreatePhepToan::~CreatePhepToan() {
    // Destructor
}
std::vector<std::string> CreatePhepToan::createAnswerQuestions(int typeOfW_input, int levelOfW_input, int prevA_input, int prevB_input, int soLonNhat_input) {
    typeOfW = typeOfW_input;
    levelOfW = levelOfW_input;
    prevA = prevA_input;
    prevB = prevB_input;
    maxDoiSo = soLonNhat_input;
    auto loaiPhepTinh = "+";
    if (typeOfW == 1)
    {
        typeOfW = cocos2d::RandomHelper::random_int(2, 5);
    }
    switch (typeOfW)
    {
        //2 - nhan; 3 - chia; 4 - cong; 5 - tru; 6 - so sanh; 1 - multi
        case 2:
            loaiPhepTinh = "x";
            switch (levelOfW)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomNhan1();
                    break;
                case 2:
                    randomNhan2();
                    break;
                case 3:
                    randomNhan3();
                    break;
                default:
                    randomNhan1();
                    break;
            }
            break;
        case 3:
            loaiPhepTinh = ":";
            switch (levelOfW)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomChia1();
                    break;
                case 2:
                    randomChia2();
                    break;
                case 3:
                    randomChia3();
                    break;
                default:
                    randomChia1();
                    break;
            }
            break;
        case 4:
            loaiPhepTinh = "+";
            switch (levelOfW)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomCong1();
                    break;
                case 2:
                    randomCong2();
                    break;
                case 3:
                    randomCong3();
                    break;
                default:
                    randomCong1();
                    break;
            }
            break;
        case 5:
            loaiPhepTinh = "-";
            switch (levelOfW)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomTru1();
                    break;
                case 2:
                    randomTru2();
                    break;
                case 3:
                    randomTru3();
                    break;
                default:
                    randomTru1();
                    break;
            }
            break;
        case 6:
            loaiPhepTinh = "ss";
            //huy33391
            switch (levelOfW)
                //1 - binh thuong; 2 - kho; 3 - cuc kho
            {
                case 1:
                    randomSoSanh1();
                    break;
                case 2:
                    randomSoSanh2();
                    break;
                case 3:
                    randomSoSanh3();
                    break;
                default:
                    randomSoSanh1();
                    break;
            }
            break;
        default:
            randomNhan1();
            break;
    }
    std::vector<std::string> stringArray;
    //    0 - prevA
    //    1 - prevB
    //    2 - phepToan
    //    3 - correctAnswer
    //    4 - answer1
    //    5 - answer2
    //    6 - answer3
    //    7 - answer4
    //    8 - loai phep tinh, VD: "+"
    //    9 - phep tinh A: trong phep tinh so sanh vi du A = 6, A duoc tach thanh 5+1=> phep tinh A: 5+1
    //   10 - phep tinh B: trong phep tinh so sanh vi du B = 6, B duoc tach thanh 5+1=> phep tinh B: 5+1
    int soDau = prevA;
    int soCuoi = prevB;
    if (typeOfW == 5) { // phep tru
        soDau = prevA + prevB;
       
    }
    if (typeOfW == 3) { // phep chia
        soDau = prevA * prevB;
        
    }
    stringArray.push_back(std::to_string(soDau));
    stringArray.push_back(std::to_string(soCuoi));
    stringArray.push_back(phepToan->getCString());
    stringArray.push_back(std::to_string(correctAnswer));
    stringArray.push_back(std::to_string(answer1));
    stringArray.push_back(std::to_string(answer2));
    stringArray.push_back(std::to_string(answer3));
    stringArray.push_back(std::to_string(answer4));
    stringArray.push_back(loaiPhepTinh);
    if (phepTinhA == "") {
        phepTinhA = std::to_string(soDau);
    }
    if (phepTinhB == "") {
        phepTinhB = std::to_string(soCuoi);
    }
    stringArray.push_back(phepTinhA);
    stringArray.push_back(phepTinhB);
    return stringArray;
}
void CreatePhepToan::randomNhan1() {
    int myMinA = 2;
    int myMaxA = maxDoiSo;
    
    int myMinB = 2;
    int myMaxB = maxDoiSo;
    
    
    int scoreNhan = HuyFunctions().tongDiemPhepNhan();
    log("test score nhan: %i", scoreNhan);
    
    if (scoreNhan < 15) {
        myMaxA = 5;
        
        myMinB = 1;
        myMaxB = 1;
    }
    
    if (scoreNhan > 14 && scoreNhan < 31) {
        myMaxA = maxDoiSo;
        myMinB = 1;
        myMaxB = 2;
    }
    
    if (scoreNhan > 30 && scoreNhan < 41) {
        myMinB = 1;
        myMaxB = 3;
    }
    if (scoreNhan > 40 && scoreNhan < 51) {
        myMinB = 1;
        myMaxB = 5;
    }
    if (scoreNhan > 50) {
        myMinB = 2;
        myMaxB = maxDoiSo;
    }
    
    int a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
    int b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    
   
    if ((a == prevA && b == prevB) or (b == prevA && a == prevB))
    {
        if (a > 2) {
            a = a - 1;
        }
        if (b > 1) {
            b = b - 1;
        }
    }
    prevA = a;
    prevB = b;

    correctAnswer = a * b;
    
    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " x ", b, " = ?");

    log("test score nhan lan 2: %i", scoreNhan);
    
    log("random:: a : %i, b : %i, correctAnswer: %i", a, b, correctAnswer);
    
    //4 answer
    //random4AnswerNhan1(a, b);
    generateCloseNumbers(correctAnswer, 10);
    log("random:: a : %i, b : %i, correctAnswer: %i, phepToan: %s", a, b, correctAnswer, phepToan);
    log("random:: answer1 : %i, answer1 : %i, answer3: %i, answer4: %i", answer1, answer2, answer3, answer4);
}
void CreatePhepToan::randomNhan2() {
    int a = cocos2d::RandomHelper::random_int(5, maxDoiSo);
    int b = cocos2d::RandomHelper::random_int(4, maxDoiSo);
    if ((a == prevA && b == prevB) or (b == prevA && a == prevB))
    {
        a = cocos2d::RandomHelper::random_int(5, maxDoiSo);
        b = cocos2d::RandomHelper::random_int(4, maxDoiSo);
    }
    prevA = a;
    prevB = b;
    //int tmpResult = a * b;
    correctAnswer = a * b;

    //question
    //phepToan = cocos2d::__String::createWithFormat("%i%s%i", a, " x ? = ", tmpResult);

    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " x ", b, " = ?");
    
    //4 answer
    //random4AnswerNhan1(a, b);
    generateCloseNumbers(correctAnswer, 10);
    
    //log("random:: a : %i, b : %i, correctAnswer: %i, phepToan: %s", a, b, correctAnswer, phepToan);
    //log("random:: answer1 : %i, answer1 : %i, answer3: %i, answer4: %i", answer1, answer2, answer3, answer4);
}
void CreatePhepToan::randomNhan3() {
    int a = cocos2d::RandomHelper::random_int(7, 12);
    int b = cocos2d::RandomHelper::random_int(5, 10);
    if ((a == prevA && b == prevB) or (b == prevA && a == prevB))
    {
        a = cocos2d::RandomHelper::random_int(7, 12);
        b = cocos2d::RandomHelper::random_int(5, 10);
    }
    prevA = a;
    prevB = b;
    
    if(cocos2d::RandomHelper::random_int(0, 1) == 1) {
        int tmp1 = a;
        a = b;
        b = tmp1;
    }
    correctAnswer = a * b;
    
    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " x ", b, " = ?");

    //4 answer
    //random4AnswerNhan1(a, b);
    generateCloseNumbers(correctAnswer, 10);

    //log("random:: a : %i, b : %i, correctAnswer: %i, phepToan: %s", a, b, correctAnswer, phepToan);
    //log("random:: answer1 : %i, answer1 : %i, answer3: %i, answer4: %i", answer1, answer2, answer3, answer4);
}
void CreatePhepToan::randomSoSanh1(){
    int myMinA = 1;
    int myMaxA = 9;
    
    int myMinB = 1;
    int myMaxB = 9;
    
    int scoreSoSanh = UserDefault::getInstance()->getIntegerForKey("phep-so-sanh", 0);
    log("test score so sanh: %i", scoreSoSanh);
    if (scoreSoSanh < 11) {
        myMaxA = 5;
        
        myMinB = 0;
        myMaxB = 1;
    }
    if (scoreSoSanh > 10 && scoreSoSanh < 21) {
        myMaxA = 9;
        myMinB = 0;
        myMaxB = 3;
    }
    if (scoreSoSanh > 20 && scoreSoSanh < 31) {
        myMinB = 1;
        myMaxB = 4;
    }
    if (scoreSoSanh > 30) {
        myMaxB = 9;
    }
    
    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a + b > 10 || a == prevA || a == prevB || b == prevA || b == prevB);
    
    string loaiPhepToan = ">"; // < - 0, <  - 1, =  - 2
    
    string loaiPhepTinhSai = "<";
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        loaiPhepTinhSai = "=";
    }
    if (a == b) {
        loaiPhepToan = "=";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "<";
        }
    }
    if (a < b) {
        loaiPhepToan = "<";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "=";
        }
    }
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        correctAnswer = 1; //dap an dung
    } else{
        correctAnswer = 2; // dap an sai
        loaiPhepToan = loaiPhepTinhSai;
    }

    prevA = a;
    prevB = b;

    //question
    phepToan = cocos2d::__String::createWithFormat("%i %s %i", a, loaiPhepToan.c_str(), b);

//    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
//    {
//        phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " + ", b, " = ?");
//    }
//    else
//    {
//        phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", b, " + ", a, " = ?");
//    }

    //4 answer
    answer3 = 0; // 0 - an dap an, 1 - dap an dung, 2 - dap an sai
    answer4 = 0;
    answer1 = 1;
    answer2 = 2;
    
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        answer1 = 2;
        answer2 = 1;
    }
}

void CreatePhepToan::randomSoSanh2(){
    int myMinA = 3;
    int myMaxA = 9;
    
    int myMinB = 3;
    int myMaxB = 9;

    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a == prevA || a == prevB || b == prevA || b == prevB);
    
    string loaiPhepToan = ">"; // < - 0, <  - 1, =  - 2
    
    string loaiPhepTinhSai = "<";
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        loaiPhepTinhSai = "=";
    }
    if (a == b) {
        loaiPhepToan = "=";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "<";
        }
    }
    if (a < b) {
        loaiPhepToan = "<";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "=";
        }
    }
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        correctAnswer = 1; //dap an dung
    } else{
        correctAnswer = 2; // dap an sai
        loaiPhepToan = loaiPhepTinhSai;
    }

    prevA = a;
    prevB = b;

    //question
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        phepTinhB = generateRandomExpression(b);
        phepToan = cocos2d::__String::createWithFormat("%i %s %s", a, loaiPhepToan.c_str(), phepTinhB.c_str());
    } else{
        phepTinhA = generateRandomExpression(a);
        phepToan = cocos2d::__String::createWithFormat("%s %s %i", phepTinhA.c_str(), loaiPhepToan.c_str(), b);
    }
    
    //4 answer
    answer3 = 0; // 0 - an dap an, 1 - dap an dung, 2 - dap an sai
    answer4 = 0;
    answer1 = 1;
    answer2 = 2;
    
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        answer1 = 2;
        answer2 = 1;
    }
    
}
void CreatePhepToan::randomSoSanh3(){
    int myMinA = 5;
    int myMaxA = 9;
    
    int myMinB = 3;
    int myMaxB = 9;

    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a == prevA || a == prevB || b == prevA || b == prevB);
    
    string loaiPhepToan = ">"; // < - 0, <  - 1, =  - 2
    
    string loaiPhepTinhSai = "<";
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        loaiPhepTinhSai = "=";
    }
    if (a == b) {
        loaiPhepToan = "=";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "<";
        }
    }
    if (a < b) {
        loaiPhepToan = "<";
        loaiPhepTinhSai = ">";
        if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
            loaiPhepTinhSai = "=";
        }
    }
    if (cocos2d::RandomHelper::random_int(0, 1) == 0) {
        correctAnswer = 1; //dap an dung
    } else{
        correctAnswer = 2; // dap an sai
        loaiPhepToan = loaiPhepTinhSai;
    }

    prevA = a;
    prevB = b;

    //question
    phepTinhA = generateRandomExpression(a);
    phepTinhB = generateRandomExpression(b);
    phepToan = cocos2d::__String::createWithFormat("%s %s %s", phepTinhA.c_str(), loaiPhepToan.c_str(), phepTinhB.c_str());
    
    //4 answer
    answer3 = 0; // 0 - an dap an, 1 - dap an dung, 2 - dap an sai
    answer4 = 0;
    answer1 = 1;
    answer2 = 2;
    
    if (cocos2d::RandomHelper::random_int(0, 1) == 1) {
        answer1 = 2;
        answer2 = 1;
    }
    
}

void CreatePhepToan::randomCong1(){
    int myMinA = 1;
    int myMaxA = 9;
    
    int myMinB = 1;
    int myMaxB = 9;
    
    int scoreCong = UserDefault::getInstance()->getIntegerForKey("phep-cong", 0);
    log("test score cong: %i", scoreCong);
    if (scoreCong < 11) {
        myMaxA = 5;
        
        myMinB = 0;
        myMaxB = 1;
    }
    if (scoreCong > 10 && scoreCong < 21) {
        myMaxA = 9;
        myMinB = 0;
        myMaxB = 3;
    }
    if (scoreCong > 20 && scoreCong < 31) {
        myMinB = 1;
        myMaxB = 4;
    }
    if (scoreCong > 30) {
        myMaxB = 9;
    }
    
    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a + b > 10 || a == prevA || a == prevB || b == prevA || b == prevB);
    
    
    correctAnswer = a + b;
    if (b > a) {
        int tmp = a;
        a = b;
        b = tmp;
    }
    prevA = a;
    prevB = b;

    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " + ", b, " = ?");

//    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
//    {
//        phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " + ", b, " = ?");
//    }
//    else
//    {
//        phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", b, " + ", a, " = ?");
//    }

    //4 answer
    //random4AnswerCong1(a, b);
    generateCloseNumbers(correctAnswer, 10);

    //log("random:: a : %i, b : %i, correctAnswer: %i, phepToan: %s", a, b, correctAnswer, phepToan);
    //log("random:: answer1 : %i, answer1 : %i, answer3: %i, answer4: %i", answer1, answer2, answer3, answer4);
}
void CreatePhepToan::randomCong2(){
    int scoreCong = UserDefault::getInstance()->getIntegerForKey("phep-cong-kho", 0);
    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(10, 49);
        
        b = cocos2d::RandomHelper::random_int(3, 9);
        if (scoreCong > 20) {
            b = cocos2d::RandomHelper::random_int(3, 49);
        }
        
    } while (a == prevA || a == prevB || b == prevB || b == prevA || (a % 10 + b % 10 >= 10));  // Nếu A trùng với C thì tạo lại
    
 
    prevA = a;
    prevB = b;
    //int tmpResult = a + b;
    correctAnswer = a + b;

    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " + ", b, " = ?");
    //phepToan = cocos2d::__String::createWithFormat("%i%s%i", a, " + ? = ", tmpResult);


    //4 answer
    //random4AnswerCong2(a, b);
    generateCloseNumbers(correctAnswer, 10);
}
std::string CreatePhepToan::generateRandomExpression(int tong) {
    int c = std::rand() % (tong + 1); // c thuộc [0, a]
    int b = tong - c;
    return std::to_string(c) + "+" + std::to_string(b);
}

void CreatePhepToan::randomCong3(){
    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(10, 49);
        
        b = cocos2d::RandomHelper::random_int(10, 49);
        
    } while (a == prevA || a == prevB || b == prevB || b == prevA || (a % 10 + b % 10 < 10));  // Nếu A trùng với C thì tạo lại
    
    if (a + b > 99) {
        a = a - 6;
        b = b - 6;
    }
    prevA = a;
    prevB = b;
    //int tmpResult = a + b;
    correctAnswer = a + b;

    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", a, " + ", b, " = ?");
//    if (cocos2d::RandomHelper::random_int(0, 1) == 0)
//    {
//        phepToan = cocos2d::__String::createWithFormat("%i%s%i", a, " + ? = ", tmpResult);
//    }
//    else
//    {
//        phepToan = cocos2d::__String::createWithFormat("%s%i%s%i", "? + ", a, " = ", tmpResult);
//    }

    //4 answer
    //random4AnswerCong2(a, b);
    generateCloseNumbers(correctAnswer, 10);

    //log("random:: a : %i, b : %i, correctAnswer: %i, phepToan: %s", a, b, correctAnswer, phepToan);
    //log("random:: answer1 : %i, answer1 : %i, answer3: %i, answer4: %i", answer1, answer2, answer3, answer4);
}
void CreatePhepToan::randomTru1(){
    int myMinA = 1;
    int myMaxA = 9;
    
    int myMinB = 1;
    int myMaxB = 9;
    
    int scoreTru = HuyFunctions().tongDiemPhepTru();
    log("test score tru: %i", scoreTru);
    if (scoreTru < 15) {
        myMaxA = 5;
        
        myMinB = 0;
        myMaxB = 1;
    }
    
    if (scoreTru > 14 && scoreTru < 31) {
        myMaxA = 9;
        myMinB = 0;
        myMaxB = 3;
    }
    
    if (scoreTru > 30 && scoreTru < 41) {
        myMinB = 1;
        myMaxB = 3;
    }
    if (scoreTru > 40 && scoreTru < 51) {
        myMinB = 1;
        myMaxB = 5;
    }
    if (scoreTru > 50) {
        myMaxB = 9;
    }
    
    int a, b;
    do {
        a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
        b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    }
    while (a + b > 10 || a == prevA || a == prevB || b == prevA || b == prevB);
    
    prevA = a;
    prevB = b;
    int tmpTong = a + b;
    correctAnswer = a;

    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", tmpTong, " - ", b, " = ?");

    //4 answer
    //random4AnswerTru1(b, tmpTong);
    generateCloseNumbers(a, 10);
}
void CreatePhepToan::randomTru2(){
    int scoreCong = UserDefault::getInstance()->getIntegerForKey("phep-cong-kho", 0);
    int a, b;
    
    do {
        a = cocos2d::RandomHelper::random_int(10, 49);
        
        b = cocos2d::RandomHelper::random_int(3, 9);
        if (scoreCong > 20) {
            b = cocos2d::RandomHelper::random_int(3, 49);
        }
        
    } while (a == prevA || a == prevB || b == prevB || b == prevA || (a % 10 + b % 10 >= 10));  // Nếu A trùng với C thì tạo lại
    
    prevA = a;
    prevB = b;
    int tmpTong = a + b;
    correctAnswer = a;

    //question
    
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", tmpTong, " - ", b, " = ?");

    //4 answer
    //random4AnswerTru2(b, tmpTong);
    generateCloseNumbers(a, 10);
}
void CreatePhepToan::generateCloseNumbers(int A, int range) {
    int count = 3; // Số lượng số cần tạo (không tính đáp án đúng)
    std::unordered_set<int> uniqueNumbers;
    std::srand(std::time(nullptr));

    // Tạo 3 số khác nhau và khác A
    while (uniqueNumbers.size() < count) {
        int randomNum = A + (std::rand() % (2 * range + 1)) - range; // Random trong khoảng [A - range, A + range]
        if (randomNum != A && randomNum >= 0) { // Đảm bảo khác A và >= 0
            uniqueNumbers.insert(randomNum);
        }
    }

    // Chuyển set thành vector để dễ truy cập
    std::vector<int> numbers(uniqueNumbers.begin(), uniqueNumbers.end());

    // Chọn vị trí ngẫu nhiên cho đáp án đúng
    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);

    switch (positionOfCorrectAnswer) {
        case 1:
            answer1 = correctAnswer;
            answer2 = numbers[0];
            answer3 = numbers[1];
            answer4 = numbers[2];
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = numbers[0];
            answer3 = numbers[1];
            answer4 = numbers[2];
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = numbers[0];
            answer1 = numbers[1];
            answer4 = numbers[2];
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = numbers[0];
            answer3 = numbers[1];
            answer1 = numbers[2];
            break;
        default:
            answer1 = correctAnswer;
            answer2 = numbers[0];
            answer3 = numbers[1];
            answer4 = numbers[2];
            break;
    }
}
void CreatePhepToan::randomTru3(){
    int a = cocos2d::RandomHelper::random_int(9, 49);
    int b = cocos2d::RandomHelper::random_int(9, 49);
    
    do {
        a = cocos2d::RandomHelper::random_int(9, 49);
        
        b = cocos2d::RandomHelper::random_int(9, 49);
        
    } while (a == prevA || a == prevB || b == prevB || b == prevA || (a % 10 + b % 10 < 10));  // Nếu A trùng với C thì tạo lại
    
    if (a + b > 99) {
        a = a - 6;
        b = b - 6;
    }
    
    prevA = a;
    prevB = b;
    int tmpTong = a + b;
    correctAnswer = a;

    //question
    //phepToan = cocos2d::__String::createWithFormat("%s%i%s%i", "? - ", a, " = ", b);
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", tmpTong, " - ", b, " = ?");
    //4 answer
    //random4AnswerTru3(a, tmpTong);
    generateCloseNumbers(a, 10);
}
void CreatePhepToan::randomChia1(){
    int myMinA = 2;
    int myMaxA = maxDoiSo;
    
    int myMinB = 2;
    int myMaxB = maxDoiSo;
    
    int scoreChia = HuyFunctions().tongDiemPhepChia();
    log("test score chia: %i", scoreChia);
    if (scoreChia < 15) {
        myMaxA = 5;
        
        myMinB = 1;
        myMaxB = 1;
    }
    
    if (scoreChia > 14 && scoreChia < 31) {
        myMaxA = maxDoiSo;
        myMinB = 1;
        myMaxB = 2;
    }
    if (scoreChia > 30 && scoreChia < 41) {
        myMinB = 1;
        myMaxB = 4;
    }
    if (scoreChia > 40 && scoreChia < 51) {
        myMinB = 1;
        myMaxB = 6;
    }
    if (scoreChia > 50) {
        myMinB = 2;
        myMaxB = maxDoiSo;
    }
    
    int a = cocos2d::RandomHelper::random_int(myMinA, myMaxA);
    int b = cocos2d::RandomHelper::random_int(myMinB, myMaxB);
    if ((a == prevA && b == prevB) or (b == prevA && a == prevB))
    {
        if (a > 2) {
            a = a - 1;
        }
        if (b > 1) {
            b = b - 1;
        }
    }
    
    prevA = a;
    prevB = b;
    int tmpResult = a * b;
    correctAnswer = a;

    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", tmpResult, " : ", b, " = ?");

    //4 answer
    //random4AnswerChia1(b , tmpResult);
    generateCloseNumbers(correctAnswer, 10);
}
bool CreatePhepToan::needPhepTinhTheoChieuDoc(std::string loaiPhepTinh, int level) {
    bool result = false;
    //2 - nhan; 3 - chia; 4 - cong; 5 - tru; 1 - multi
    //1 - binh thuong; 2 - kho; 3 - cuc kho
    if ( (loaiPhepTinh == "+" or loaiPhepTinh == "-") and (level > 1) ) {
        result = true;
    }
    return result;
}
void CreatePhepToan::randomChia2(){
    int a = cocos2d::RandomHelper::random_int(5, maxDoiSo);
    int b = cocos2d::RandomHelper::random_int(4, maxDoiSo);
    if ((a == prevA && b == prevB) or (b == prevA && a == prevB))
    {
        a = cocos2d::RandomHelper::random_int(5, maxDoiSo);
        b = cocos2d::RandomHelper::random_int(4, maxDoiSo);
    }
    prevA = a;
    prevB = b;
    int tmpResult = a * b;
    correctAnswer = a;

    //question
    //phepToan = cocos2d::__String::createWithFormat("%s%i%s%i", "? : ", a, " = ", b);
    //question
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", tmpResult, " : ", b, " = ?");

    //4 answer
    //random4AnswerChia1(b, tmpResult);
    generateCloseNumbers(correctAnswer, 10);
}
void CreatePhepToan::randomChia3(){
    int a = cocos2d::RandomHelper::random_int(7, 12);
    int b = cocos2d::RandomHelper::random_int(5, 10);
    if ((a == prevA && b == prevB) or (b == prevA && a == prevB))
    {
        a = cocos2d::RandomHelper::random_int(7, 12);
        b = cocos2d::RandomHelper::random_int(5, 10);
    }
    prevA = a;
    prevB = b;
    
    if(cocos2d::RandomHelper::random_int(0, 1) == 1) {
        int tmp1 = a;
        a = b;
        b = tmp1;
    }
    int tmpResult = a * b;
    correctAnswer = a;

    //question
    //phepToan = cocos2d::__String::createWithFormat("%i%s%i", tmpResult, " : ? = ", b);
    phepToan = cocos2d::__String::createWithFormat("%i%s%i%s", tmpResult, " : ", b, " = ?");

    //4 answer
    //random4AnswerChia1(b, tmpResult);
    generateCloseNumbers(correctAnswer, 10);
}
void CreatePhepToan::random4AnswerChia1(int a, int b){
    //chua check truong hop co dap an trung nhau

    std::vector<int> arr2;
    for (int i = 2; i <= maxDoiSo; i++)
    {
        if (i != correctAnswer)
        {
            arr2.push_back(i);
        }
    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
void CreatePhepToan::random4AnswerChia2(int a, int b){

}
void CreatePhepToan::random4AnswerChia3(int a, int b){

}


void CreatePhepToan::random4AnswerTru1(int a, int b){
    std::vector<int> arr2;
    for (int i = a + 2; i <= a + 10; i++)
    {
        if (i != correctAnswer)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
void CreatePhepToan::random4AnswerTru2(int a, int b){
    std::vector<int> arr2;
    for (int i = a + 2; i <= a + 10; i++)
    {
        if (i != correctAnswer)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
void CreatePhepToan::random4AnswerTru3(int a, int b){
    std::vector<int> arr2;
    for (int i = a + 1; i <= a + b + 7; i++)
    {
        if (i != correctAnswer)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
void CreatePhepToan::random4AnswerCong1(int a, int b){
    std::vector<int> arr2;
    for (int i = a + 1; i <= a + b + 7; i++)
    {
        if (i != correctAnswer)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
void CreatePhepToan::random4AnswerCong2(int a, int b){
    //chua check truong hop co dap an trung nhau
    std::vector<int> arr2;
    for (int i = 9; i <= 49; i++)
    {
        if (i != correctAnswer)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
void CreatePhepToan::random4AnswerCong3(int a, int b){

}
void CreatePhepToan::random4AnswerNhan1(int a, int b){

    //chua check truong hop co dap an trung nhau
    int result1 = a + b;
    if(a >= b){
        if(a > 2){
            result1 = (a - 1) * b;
        }
    }else{
        if(b > 2){
            result1 = (b - 1) * a;
        }
    }

    if (result1 == correctAnswer){
        result1 = (a + b) * 2;
    }

    std::vector<int> arr2;
    
    for (int i = (a * b + 2) ; i <= a * b + 6; i++)
    {
        if (i != correctAnswer && i != result1)
        {
            arr2.push_back(i);
        }
    }

    std::random_shuffle(arr2.begin(), arr2.end());
    int result2 = arr2.at(0);

    std::vector<int> arr3;
    for (int i = result2 + 1; i <= result2 + 7; i++)
    {
        if (i != correctAnswer && i != result1)
        {
            arr3.push_back(i);
            log("dap an: %i", i);
        }

    }
    std::random_shuffle(arr3.begin(), arr3.end());
    int result3 = arr3.at(0);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
void CreatePhepToan::random4AnswerNhan2(int a, int b){
    //chua check truong hop co dap an trung nhau
    std::vector<int> arr2;
    for (int i = 4; i <= maxDoiSo; i++)
    {
        if (i != correctAnswer)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result1 = arr2.at(0);
    int result2 = arr2.at(1);
    int result3 = arr2.at(2);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}

void CreatePhepToan::random4AnswerNhan3(int a, int b){
    int tich = b;
    //chua check truong hop co dap an trung nhau
    int result1 = tich - a;
    if (result1 == correctAnswer){
        result1 = tich - a + 2;
    }

    std::vector<int> arr2;
    for (int i = a + 2; i <= a + 6; i++)
    {
        if (i != correctAnswer && i != result1)
        {
            arr2.push_back(i);
        }

    }
    std::random_shuffle(arr2.begin(), arr2.end());
    int result2 = arr2.at(0);

    std::vector<int> arr3;
    for (int i = result2 + 1; i <= result2 + 7; i++)
    {
        if (i != correctAnswer && i != result1)
        {
            arr3.push_back(i);
        }

    }
    std::random_shuffle(arr3.begin(), arr3.end());
    int result3 = arr3.at(0);

    int positionOfCorrectAnswer = cocos2d::RandomHelper::random_int(1, 4);
    switch (positionOfCorrectAnswer)
    {
        case 1:
            answer1 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 2:
            answer2 = correctAnswer;
            answer1 = result1;
            answer3 = result2;
            answer4 = result3;
            break;
        case 3:
            answer3 = correctAnswer;
            answer2 = result1;
            answer1 = result2;
            answer4 = result3;
            break;
        case 4:
            answer4 = correctAnswer;
            answer2 = result1;
            answer3 = result2;
            answer1 = result3;
            break;
        default:
            break;
    }
}
