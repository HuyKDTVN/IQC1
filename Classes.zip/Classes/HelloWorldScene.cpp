#include "HelloWorldScene.h"
#include "learnSelect.h"
#include "mathSelect.h"
#include "setting.h"
#include "BuyPro.hpp"
#include "buy.hpp"
#include "gift.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "language.h"
#include "gift.h"
#include "giftDiamond.hpp"
#include "giftHeart.hpp"
#include "ParentScreen.h"
#include <SimpleAudioEngine.h>
#include <ctime>
#include <iostream>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "GameCenterBridge.h"
#include "SelectGame.hpp"
#include "AllowNoti.hpp"
#include "play.h"
#include "IAPManager.h"
#include "ui/UITextField.h"
#include "ui/UIScale9Sprite.h"
#include "Sticker.hpp"
#include "Medal.hpp"
#include "ChangeName.hpp"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    #include "AdmobHelper.h"
    #include "platform/android/jni/JniHelper.h"
#endif


USING_NS_CC;

float wScene;
float hScene;

Label* valueKey;
float yValueKey;
float xValueKey;

int soundHello;
float ratioScreenHello;

std::string lang;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}


// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }
    
//    this->scheduleOnce([](float) {
//        auto scene = AllowNoti::createScene();
//        Director::getInstance()->replaceScene(scene);
//       }, 0.2f, "auto_change_scene");
//    
    if(Variable().isProduction == true) {
        log("This version ready to publish!");
    }else {
        log("This is test version. Please change to Produciton mode before to submit!");
    }
    
    if (UserDefault::getInstance()->getStringForKey("ten-nguoi-choi") == "") {
        //showDailyReward = true;
        //createTemplateInputTen(wScene, hScene);
        this->runAction(Sequence::create(
            DelayTime::create(0),
            CallFunc::create([=]() {
                Director::getInstance()->replaceScene(
                    TransitionFade::create(
                        0.5f,
                        ChangeName::createScene(),
                        Color3B::WHITE));
            }),
            nullptr));

    }
    
    showDailyReward = false;
    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    
    
    //test redirect to play1
//    this->scheduleOnce([=](float dt) {
//        Director::getInstance()->replaceScene(TransitionFade::create(0, Play::createScene(1, 4, 1), Color3B().WHITE));
//    }, 0.1f, "call_ABC_key");  // Đặt độ trễ 1 giây
//    
    
    ratioScreenHello = hScene / wScene;
    
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(6);
    }
    
    inVN = HuyFunctions().inVietNam();
//    if (inVN == false) {
//        // Đăng nhập Game Center
//        GameCenterBridge::authenticatePlayer();
//    }
    //log("wSence: %f", wScene);
    //log("hScene: %f", hScene);
    log("ratio: %f", hScene / wScene);
    //lang = AdmobHelper::getPhoneLanguage();

    log("currentLang: %s", Application::getInstance()->getCurrentLanguageCode());
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "ii") == "ii")
    {
        UserDefault::getInstance()->setStringForKey("LANGUAGE", HuyFunctions().getCurrentLang());
        UserDefault::getInstance()->flush();
    }
    if (Variable().isProduction == false) {
        UserDefault::getInstance()->setStringForKey("LANGUAGE", Variable().languageTest);
    }

    if (UserDefault::getInstance()->getIntegerForKey("sound", 2) == 2){
        UserDefault::getInstance()->setIntegerForKey("sound", 0);//0: enable - 1: unsound
        UserDefault::getInstance()->flush();
    }

    if (UserDefault::getInstance()->getIntegerForKey("KEY", 99999) == 99999)
    {
        UserDefault::getInstance()->setIntegerForKey("KEY", 3);
        UserDefault::getInstance()->flush();
    }
    
    if(UserDefault::getInstance()->getStringForKey("noti-title1", "") == "") {
        UserDefault::getInstance()->setStringForKey("noti-title1", "🚀4 + 2 = ?💥");
    }
    
    if(UserDefault::getInstance()->getStringForKey("noti-title2", "") == "") {
        UserDefault::getInstance()->setStringForKey("noti-title2", LanguageManager::getInstance()->getStringForKey("PARENT_TITLE").c_str());
        UserDefault::getInstance()->setStringForKey("noti-desc2", LanguageManager::getInstance()->getStringForKey("PARENT_SUB_TITLE_MOI_BAT_DAU").c_str());
    }
    
    log("Noti: %s", UserDefault::getInstance()->getStringForKey("noti-title1", "").c_str());
    
    soundHello = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
    dailyRewardDay = UserDefault::getInstance()->getIntegerForKey("daily-reward", 0);
    dailyRewardWeek = UserDefault::getInstance()->getIntegerForKey("daily-reward-sotuan", 0);
    if (dailyRewardWeek > 5) {
        dailyRewardWeek = 5;
    }
    
    //set bg
    createBg();

    //save install date
    if(UserDefault::getInstance()->getStringForKey("install-date", "") == "") {
        // get current time
        std::time_t now = std::time(nullptr);
        UserDefault::getInstance()->setStringForKey("install-date", formatDate(now));
    }

    //delete vao lan cap nhat sau
//    if (UserDefault::getInstance()->getIntegerForKey("diamond", 33391) == 33391) {
//        UserDefault::getInstance()->setIntegerForKey("diamond", UserDefault::getInstance()->getIntegerForKey("height-score", 0));
//    }

    tongDiem = HuyFunctions().getSoVang();
//    createMainActor(wScene, hScene);
//    createMainActorMiror(wScene, hScene);
    //createMainActor(wScene, hScene);
    createButtonLearnPlayRateGift();
    createButtonSetting();
    createInforDiemSo();
    challengeIndex = UserDefault::getInstance()->getIntegerForKey("challenge-index", 0);
    
    //UserDefault::getInstance()->setIntegerForKey("phep-so-sanh-ratkho", 10);
    //UserDefault::getInstance()->setIntegerForKey("daily-sovang", 319);
    
    //log("so thu thach: %i", Variable().arrChallenge.at(0).size());
    if (challengeIndex < Variable().arrChallenge.at(0).size()) {
        createTemplateChallenge();
    }
    
    if (soundHello == 0)
    {
        CocosDenshion::SimpleAudioEngine::getInstance()->preloadEffect("sound/click.wav");
        CocosDenshion::SimpleAudioEngine::getInstance()->preloadEffect("sound/chucmung.wav");
    }

//    UserDefault::getInstance()->setIntegerForKey("phep-nhan", 0);
//    UserDefault::getInstance()->setIntegerForKey("phep-nhan-kho", 0);
//    UserDefault::getInstance()->setIntegerForKey("phep-nhan-ratkho", 0);
//    UserDefault::getInstance()->setIntegerForKey("diamond", 50);
//    UserDefault::getInstance()->setIntegerForKey("songay", 33);
//
    
//     f
    return true;
}


std::string HelloWorld::formatDate(const std::time_t& time)
{
    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%d/%m/%Y", std::localtime(&time));
    return std::string(buffer);
}
void HelloWorld::createBg() {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg-blurr.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    if (Variable().hasHaloween) {
        auto conRoi = Sprite::create("con-roi.png");
        float ratioconRoi = 7;
        if (ratioScreenHello <= 1.53)
        {
            ratioconRoi = 14;
        }
        float scaleconRoi = wScene / ratioconRoi / conRoi->getContentSize().width;
        conRoi->setScale(scaleconRoi);
        conRoi->setPosition(Vec2(wScene * 1.3, hScene * 0.8));
        this->addChild(conRoi);
        
        auto conRo2 = Sprite::create("con-roi.png");
        float ratioconRo2 = 9;
        if (ratioScreenHello <= 1.53)
        {
            ratioconRo2 = 18;
        }
        float scaleconRo2 = wScene / ratioconRo2 / conRo2->getContentSize().width;
        conRo2->setScale(scaleconRo2);
        conRo2->setRotation(45);
        conRo2->setPosition(Vec2(-wScene / 5, hScene * 0.72));
        this->addChild(conRo2);
        
        
        // Tạo hành động bay từ phai sang trai
        auto moveRight2 = MoveTo::create(8.0f, Vec2(- wScene * 0.2, conRoi->getPositionY() + hScene / 8));
        // Khi bay xong, đưa về vị trí ban đầu
        auto resetPosition2 = CallFunc::create([=]() {
            conRoi->setPosition(Vec2(wScene * 1.3, hScene * 0.8));
        });

        // Lặp lại mãi mãi
        auto sequence2 = Sequence::create(moveRight2, resetPosition2, nullptr);
        auto repeat2 = RepeatForever::create(sequence2);
        conRoi->runAction(repeat2);
        
        // Tạo hành động bay từ trái sang phải
        auto moveRight = MoveTo::create(10.0f, Vec2(wScene * 1.5, conRo2->getPositionY() + hScene / 8));
        // Khi bay xong, đưa về vị trí ban đầu
        auto resetPosition = CallFunc::create([=]() {
            conRo2->setPosition(Vec2(-wScene / 5, hScene * 0.72));
        });

        // Lặp lại mãi mãi
        auto sequence = Sequence::create(moveRight, resetPosition, nullptr);
        auto repeat = RepeatForever::create(sequence);
        conRo2->runAction(repeat);

    }
}
void HelloWorld::createInforDiemSo () {
    float fontSize = 0.05 * wScene;
    float ratiomyImg = 14;
    log("test notch: %f", hScene / wScene);
    double heightPercent = 0.95;
    if (hScene / wScene > 2.168) {
        heightPercent = 0.935;
    }
    if (hScene/ wScene <= 1.8)
    {
        heightPercent = 0.98;
    }
    if (hScene/ wScene <= 1.53)
    {
        heightPercent = 0.98;
        fontSize = 0.03 * wScene;
        ratiomyImg = 20;

    }
    double topHeight = heightPercent * hScene;
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    
    //add giao dien cho thong tin diem cao nhat
    auto imageName = "diamond.png";
    myImg = ui::Button::create(imageName); // tao button
    //myImg->setTouchEnabled(false);
    
    float scalemyImg = wScene / ratiomyImg / myImg->getContentSize().width;
    myImg->setScale(scalemyImg);
    float ymyImg = topHeight - (myImg->getContentSize().height / 2 * scalemyImg);
    myImg->setPosition(Vec2(wScene * 3 / 8 - myImg->getContentSize().width / 2 * scalemyImg, ymyImg));
    myImg->setEnabled(true);
    if (Variable().isProduction) {
        myImg->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    log("Button 1 touch");
                    //redirect to play
                    
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftDiamond::createScene(), Color3B().WHITE));
                                    });

                    break;
                default:
                    break;
            }
                   
        });
    }
    this->addChild(myImg, 11);
    myImg->runAction(
        RepeatForever::create(
            Sequence::create(
                 DelayTime::create(0.17),
                 ScaleTo::create(0.15, 1.1 * scalemyImg),
                 ScaleTo::create(0.15, scalemyImg / 1.1),
                 nullptr)
        )
    );
    int iHighScore = UserDefault::getInstance()->getIntegerForKey("diamond", 0);
    auto labelHightScore = cocos2d::__String::createWithFormat("%i", iHighScore);
    valueDiamond = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize);
    valueDiamond->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xValueScore = myImg->getPositionX() + myImg->getContentSize().width * scalemyImg / 2 + 2;
    float yValueScore = myImg->getPositionY() - 3;// - valueDiamond->getContentSize().width;
//    if (h/ w <= 1.53)
//    {
//        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueDiamond->getContentSize().width;
//
//    }
    valueDiamond->setPosition(Vec2(xValueScore, yValueScore));
    valueDiamond->setAnchorPoint({0, 0.5});
    valueDiamond->setHorizontalAlignment(TextHAlignment::LEFT);
    addChild(valueDiamond, 11);
    
    //add giao dien cho thong tin tong so diem
    
    auto labelTongDiem = cocos2d::__String::createWithFormat("%i", tongDiem);
    valueTongDiem = Label::createWithTTF(labelTongDiem->getCString(), fontStyle, fontSize);
    valueTongDiem->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    xValueScore = wScene - valueTongDiem->getContentSize().width - 8;
    //yValueScore = myImg->getPositionY() - 5;// - valueTongDiem->getContentSize().width;
//    if (h/ w <= 1.53)
//    {
//        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueTongDiem->getContentSize().width;
//
//    }
    valueTongDiem->setPosition(Vec2(xValueScore, yValueScore + 1));
    valueTongDiem->setAnchorPoint({0, 0.5});
    valueTongDiem->setHorizontalAlignment(TextHAlignment::RIGHT);
    addChild(valueTongDiem, 11);
    imageName = "gold.png";
    myGold = ui::Button::create(imageName, imageName); // tao button
    myGold->setPressedActionEnabled(false);
    //myImg->setTouchEnabled(false);
//    float ratiomyImg = 10;
//    float scalemyImg = wScene / ratiomyImg / myImg->getContentSize().width;
    myGold->setScale(scalemyImg);
    //float ymyImg = topHeight - (myGold->getContentSize().height / 2 * scalemyImg);
    myGold->setPosition(Vec2(valueTongDiem->getPositionX() - myGold->getContentSize().width * scalemyImg / 2 - 3, ymyImg));// - myGold->getContentSize().width / 2 * scalemyImg, ymyImg));
    myGold->setEnabled(true);
    if (Variable().isProduction) {
        myGold->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    log("Button 1 touch");
                    //redirect to play
                    
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Gift::createScene(), Color3B().WHITE));
                                    });

                    break;
                default:
                    break;
            }
                   
        });
    }
    
    this->addChild(myGold, 11);
    myGold->runAction(
        RepeatForever::create(
            Sequence::create(
                 DelayTime::create(0.1),
                 ScaleTo::create(0.15, 1.1 * scalemyImg),
                 ScaleTo::create(0.15, scalemyImg / 1.1),
                 nullptr)
        )
    );
    
    //add giao dien cho thong tin tong so ngay da mo app
    imageName = "heart.png";
    myHeart = ui::Button::create(imageName); // tao button
    //myHeart->setTouchEnabled(false);
//    float ratiomyImg = 10;
//    float scalemyImg = wScene / ratiomyImg / myImg->getContentSize().width;
    myHeart->setScale(scalemyImg);
    //float ymyImg = topHeight - (myImg->getContentSize().height / 2 * scalemyImg);
    myHeart->setPosition(Vec2(wScene * 5 / 8 - myImg->getContentSize().width * scalemyImg / 2, ymyImg));// - myImg->getContentSize().width / 2 * scalemyImg, ymyImg));
    myHeart->setEnabled(true);
    if (Variable().isProduction) {
        myHeart->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = static_cast<cocos2d::ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    log("Button 1 touch");
                    //redirect to play
                    
                    HuyFunctions().animationClickedButton(button, [](){
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, GiftHeart::createScene(), Color3B().WHITE));
                                    });

                    break;
                default:
                    break;
            }
                   
        });
    }
    this->addChild(myHeart, 11);
    myHeart->runAction(
        RepeatForever::create(
            Sequence::create(
                 DelayTime::create(0.4),
                 ScaleTo::create(0.14, 1.1 * scalemyImg),
                 ScaleTo::create(0.15, scalemyImg / 1.1),
                 nullptr)
        )
    );
    
    int soNgayChoiInt = UserDefault::getInstance()->getIntegerForKey("songay", 0);
    ngayChoiMoi = HuyFunctions().checkAddDayOrNot();
    auto soNgayChoi = cocos2d::__String::createWithFormat("%i", soNgayChoiInt);
    auto valueSoNgayChoi = Label::createWithTTF(soNgayChoi->getCString(), fontStyle, fontSize);
    
    if (ngayChoiMoi == true || (UserDefault::getInstance()->getIntegerForKey("daily-reward", 0) == 0 and UserDefault::getInstance()->getIntegerForKey("daily-reward-sotuan", 0) == 0)) {
        //if(1==1){
//        soNgayChoiInt = soNgayChoiInt + 1;
//        soNgayChoi = cocos2d::__String::createWithFormat("%i", soNgayChoiInt);
        showDailyReward = true;
        createTemplateDailyReward(wScene, hScene);
    }
    
    
    valueSoNgayChoi->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    xValueScore = myHeart->getPositionX() + myHeart->getContentSize().width * scalemyImg / 2 + 3;
    //yValueScore = myImg->getPositionY() - 5;// - valueTongDiem->getContentSize().width;
//    if (h/ w <= 1.53)
//    {
//        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueTongDiem->getContentSize().width;
//
//    }
    valueSoNgayChoi->setPosition(Vec2(xValueScore, yValueScore + 1));
    valueSoNgayChoi->setAnchorPoint({0, 0.5});
    valueSoNgayChoi->setHorizontalAlignment(TextHAlignment::LEFT);
    addChild(valueSoNgayChoi, 11);
    
//    //add giao dien cho thong tin tong so diem phep cong
//    imageName = "home-cong.png";
//    auto myImgDiemSo = ui::Button::create(imageName, imageName); // tao button
//    myImgDiemSo->setPressedActionEnabled(false);
//    myImgDiemSo->setTouchEnabled(true);
//    ratiomyImg = 5;
//    float fixFontSize = 1.1;
//    if (hScene/ wScene <= 1.53)
//    {
//        ratiomyImg = 10;
//        fixFontSize = 1;
//    }
//    auto scalemyImgDiemSo = wScene / ratiomyImg / myImgDiemSo->getContentSize().width;
//    myImgDiemSo->setScale(scalemyImgDiemSo);
//    
//    int fixResponsive = 0;
//    if (hScene/ wScene <= 1.8)
//    {
//        fixResponsive = 10;
//
//    }
//    ymyImg = myImg->getPositionY() - myImg->getContentSize().height * scalemyImg - myImgDiemSo->getContentSize().height * scalemyImg * 0.75 + fixResponsive;
//    myImgDiemSo->setPosition(Vec2(wScene / 8 , ymyImg));
//    myImgDiemSo->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
//        auto button = static_cast<cocos2d::ui::Button*>(sender);
//        switch (type)
//        {
//            case cocos2d::ui::Widget::TouchEventType::BEGAN:
//                                break;
//            case cocos2d::ui::Widget::TouchEventType::ENDED:
//                //log("Button 1 clicked");
//                if (soundHello == 0)
//                {
//                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
//                }
//                log("Button 1 touch");
//                //redirect to play
//                
//                HuyFunctions().animationClickedButton(button, [](){
//                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(), Color3B().WHITE));
//                    if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
//                        HuyFunctions().showAds();
//                    }
//                });
//                
//
//                break;
//            default:
//                break;
//        }
//               
//    });
//    this->addChild(myImgDiemSo);
//    int diemSo = HuyFunctions().tongDiemPhepCong();
//    labelHightScore = cocos2d::__String::createWithFormat("%i", diemSo);
//    valueHeightScore = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize * fixFontSize);
//    valueHeightScore->setColor(Color3B().WHITE);
//    // position the label on the center of the screen
//    xValueScore = myImgDiemSo->getPositionX();
//    yValueScore = myImgDiemSo->getPositionY() - valueHeightScore->getContentSize().height * 0.3;
////    if (h/ w <= 1.53)
////    {
////        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueHeightScore->getContentSize().width;
////
////    }
//    valueHeightScore->setPosition(Vec2(xValueScore, yValueScore));
//    valueHeightScore->setAnchorPoint({0.5, 0.5});
//    valueHeightScore->setHorizontalAlignment(TextHAlignment::CENTER);
//    addChild(valueHeightScore, 1);
//    
//    //add giao dien cho thong tin tong so diem phep tru
//    imageName = "home-tru.png";
//    myImgDiemSo = ui::Button::create(imageName, imageName); // tao button
//    scalemyImgDiemSo = wScene / ratiomyImg / myImgDiemSo->getContentSize().width;
//    myImgDiemSo->setScale(scalemyImgDiemSo);
//    myImgDiemSo->setPosition(Vec2(wScene * 3 / 8, ymyImg - 10));
//    myImgDiemSo->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
//        auto button = static_cast<cocos2d::ui::Button*>(sender);
//        switch (type)
//        {
//            case cocos2d::ui::Widget::TouchEventType::BEGAN:
//                                break;
//            case cocos2d::ui::Widget::TouchEventType::ENDED:
//                //log("Button 1 clicked");
//                if (soundHello == 0)
//                {
//                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
//                }
//                log("Button 1 touch");
//                //redirect to play
//                HuyFunctions().animationClickedButton(button, [](){
//                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(), Color3B().WHITE));
//                    if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
//                        HuyFunctions().showAds();
//                    }
//                });
//                    
//                
//
//                break;
//            default:
//                break;
//        }
//               
//    });
//    this->addChild(myImgDiemSo);
//    diemSo = HuyFunctions().tongDiemPhepTru();
//    labelHightScore = cocos2d::__String::createWithFormat("%i", diemSo);
//    valueHeightScore = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize * fixFontSize);
//    valueHeightScore->setColor(Color3B().WHITE);
//    // position the label on the center of the screen
//    xValueScore = myImgDiemSo->getPositionX();
//    yValueScore = myImgDiemSo->getPositionY() - valueHeightScore->getContentSize().height * 0.3;
////    if (h/ w <= 1.53)
////    {
////        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueHeightScore->getContentSize().width;
////
////    }
//    valueHeightScore->setPosition(Vec2(xValueScore, yValueScore));
//    valueHeightScore->setAnchorPoint({0.5, 0.5});
//    valueHeightScore->setHorizontalAlignment(TextHAlignment::CENTER);
//    addChild(valueHeightScore, 1);
//    
//    //add giao dien cho thong tin tong so diem phep nhan
//    imageName = "home-nhan.png";
//    myImgDiemSo = ui::Button::create(imageName, imageName); // tao button
//    
//  
//    scalemyImgDiemSo = wScene / ratiomyImg / myImgDiemSo->getContentSize().width;
//    myImgDiemSo->setScale(scalemyImgDiemSo);
//    myImgDiemSo->setPosition(Vec2(wScene * 5 / 8, ymyImg - 8));
//    myImgDiemSo->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
//        auto button = static_cast<cocos2d::ui::Button*>(sender);
//        switch (type)
//        {
//            case cocos2d::ui::Widget::TouchEventType::BEGAN:
//                                break;
//            case cocos2d::ui::Widget::TouchEventType::ENDED:
//                //log("Button 1 clicked");
//                if (soundHello == 0)
//                {
//                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
//                }
//                log("Button 1 touch");
//                //redirect to play
//                HuyFunctions().animationClickedButton(button, [](){
//                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(), Color3B().WHITE));
//                    if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
//                        HuyFunctions().showAds();
//                    }
//                });
//
//                break;
//            default:
//                break;
//        }
//               
//    });
//    this->addChild(myImgDiemSo);
//    diemSo = HuyFunctions().tongDiemPhepNhan();
//    labelHightScore = cocos2d::__String::createWithFormat("%i", diemSo);
//    valueHeightScore = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize * fixFontSize);
//    valueHeightScore->setColor(Color3B().WHITE);
//    // position the label on the center of the screen
//    xValueScore = myImgDiemSo->getPositionX();
//    yValueScore = myImgDiemSo->getPositionY() - valueHeightScore->getContentSize().height * 0.3;
////    if (h/ w <= 1.53)
////    {
////        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueHeightScore->getContentSize().width;
////
////    }
//    valueHeightScore->setPosition(Vec2(xValueScore, yValueScore));
//    valueHeightScore->setAnchorPoint({0.5, 0.5});
//    valueHeightScore->setHorizontalAlignment(TextHAlignment::CENTER);
//    addChild(valueHeightScore, 1);
//    
//    //add giao dien cho thong tin tong so diem phep chia
//    imageName = "home-chia.png";
//    myImgDiemSo = ui::Button::create(imageName, imageName); // tao button
//    
//
//    scalemyImgDiemSo = wScene / ratiomyImg / myImgDiemSo->getContentSize().width;
//    myImgDiemSo->setScale(scalemyImgDiemSo);
//    myImgDiemSo->setPosition(Vec2(wScene * 7 / 8, ymyImg - 3));
//    myImgDiemSo->setEnabled(true);
//    myImgDiemSo->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
//        auto button = static_cast<cocos2d::ui::Button*>(sender);
//        switch (type)
//        {
//            case cocos2d::ui::Widget::TouchEventType::BEGAN:
//                                break;
//            case cocos2d::ui::Widget::TouchEventType::ENDED:
//                //log("Button 1 clicked");
//                if (soundHello == 0)
//                {
//                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
//                }
//                log("Button 1 touch");
//                //redirect to play
//                
//                HuyFunctions().animationClickedButton(button, [](){
//                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(), Color3B().WHITE));
//                    if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
//                        HuyFunctions().showAds();
//                    }
//                });
//                break;
//            default:
//                break;
//        }
//               
//    });
//    this->addChild(myImgDiemSo);
//    diemSo = HuyFunctions().tongDiemPhepChia();
//    labelHightScore = cocos2d::__String::createWithFormat("%i", diemSo);
//    valueHeightScore = Label::createWithTTF(labelHightScore->getCString(), fontStyle, fontSize * fixFontSize);
//    valueHeightScore->setColor(Color3B().WHITE);
//    // position the label on the center of the screen
//    xValueScore = myImgDiemSo->getPositionX();
//    yValueScore = myImgDiemSo->getPositionY() - valueHeightScore->getContentSize().height * 0.3;
////    if (h/ w <= 1.53)
////    {
////        xValueScore = w - bgScore->getPosition().x + bgScore->getContentSize().width * 0.44 * scalebgScore - valueHeightScore->getContentSize().width;
////
////    }
//    valueHeightScore->setPosition(Vec2(xValueScore, yValueScore));
//    valueHeightScore->setAnchorPoint({0.5, 0.5});
//    valueHeightScore->setHorizontalAlignment(TextHAlignment::CENTER);
//    addChild(valueHeightScore, 1);
    
    
//    if (ngayChoiMoi == true) {
//    //if (1==1){
//    //create animation for add played day
//        //add giao dien cho thong tin tong so ngay da mo app
//        imageName = "heart.png";
//        auto bigImg = ui::Button::create(imageName); // tao button
//        bigImg->setTouchEnabled(false);
//        float ratiobigImg = 10/4;
//        float scale120 = 1.2;
//        float scale100 = 1.0;
//        if (hScene/ wScene <= 1.53)
//        {
//            scale100 = 0.6;
//            scale120 = 0.7;
//
//        }
//        float scalebigImg = wScene / ratiobigImg / bigImg->getContentSize().width;
//        bigImg->setScale(scalebigImg);
//        float ybigImg = hScene * 0.6;
//        bigImg->setPosition(Vec2(wScene * 0.5, ybigImg));// - bigImg->getContentSize().width / 2 * scalebigImg, ybigImg));
//        bigImg->setEnabled(true);
//        this->addChild(bigImg);
//        
//        bigImg->setScale(0);
//        float timeAnimation = 0.8;
//        bigImg->runAction(
//            Sequence::create(
//                DelayTime::create(0.5),
////                Spawn::create(
////                    ScaleTo::create(timeAnimation, 2),
////                    MoveTo::create(timeAnimation, Vec2(wScene / 2.2,  hScene * 0.7)),
////                    nullptr
////                ),
////                 DelayTime::create(0.2),
//                  Spawn::create(
//                      ScaleTo::create(timeAnimation, scale120),
//                      MoveTo::create(timeAnimation, Vec2(myHeart->getPositionX(),  myHeart->getPositionY())),
//                      nullptr
//                  ),
//                DelayTime::create(0.2),
//                 Spawn::create(
//                     ScaleTo::create(timeAnimation / 3, scale100),
//                     //MoveTo::create(timeAnimation, Vec2(myHeart->getPositionX(),  myHeart->getPositionY())),
//                     nullptr
//                 ),
//                nullptr
//            )
//        );
//        this->runAction(Sequence::createWithTwoActions(DelayTime::create(0.5), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/chucmung.wav", false); })));
//        valueSoNgayChoi->runAction(
//                                   Sequence::create(
//                                           DelayTime::create(timeAnimation * 2),
//                                           ScaleTo::create(timeAnimation / 3, 1.3),
//                                           CallFunc::create([=]() {
//                                               valueSoNgayChoi->setString(cocos2d::__String::createWithFormat("%i", soNgayChoiInt)->getCString());
//                                           }),
//                                           DelayTime::create(0.2),
//                                           ScaleTo::create(timeAnimation / 4, 1),
//                                           nullptr
//                                       )
//        );
//        
////        this->scheduleOnce([=](float dt) {
////            log("soNgayChoi %i", soNgayChoiInt);
////            valueSoNgayChoi->setString(cocos2d::__String::createWithFormat("%i", soNgayChoiInt)->getCString());
////            }, 2.0f, "updateScoreDelay");
//        
//        //valueSoNgayChoi->runAction(Sequence::createWithTwoActions(DelayTime::create(timeAnimation * 7 / 3), CallFunc::create([=](){ valueSoNgayChoi->setString(soNgayChoi->getCString()); })));
//        
//        
//    } //if (ngayChoiMoi == true) {
    
    
    
   
    int rand = cocos2d::RandomHelper::random_int(1, 13);
    auto titleDay3 = cocos2d::__String::createWithFormat("COMEBACK_TITLE%i", rand);
    auto descDay3 = cocos2d::__String::createWithFormat("COMEBACK_DESC%i", rand);
    
    UserDefault::getInstance()->setStringForKey("noti-day3-title", LanguageManager::getInstance()->getStringForKey(titleDay3->getCString()).c_str());
    UserDefault::getInstance()->setStringForKey("noti-day3-desc", LanguageManager::getInstance()->getStringForKey(descDay3->getCString()).c_str());
    
    rand = cocos2d::RandomHelper::random_int(1, 13);
    auto titleDay7 = cocos2d::__String::createWithFormat("COMEBACK_TITLE%i", rand);
    auto descDay7 = cocos2d::__String::createWithFormat("COMEBACK_DESC%i", rand);
    
    UserDefault::getInstance()->setStringForKey("noti-day7-title", LanguageManager::getInstance()->getStringForKey(titleDay7->getCString()).c_str());
    UserDefault::getInstance()->setStringForKey("noti-day7-desc", LanguageManager::getInstance()->getStringForKey(descDay7->getCString()).c_str());
    
    rand = cocos2d::RandomHelper::random_int(1, 13);
    auto titleDay10 = cocos2d::__String::createWithFormat("COMEBACK_TITLE%i", rand);
    auto descDay10 = cocos2d::__String::createWithFormat("COMEBACK_DESC%i", rand);
    
    UserDefault::getInstance()->setStringForKey("noti-day10-title", LanguageManager::getInstance()->getStringForKey(titleDay10->getCString()).c_str());
    UserDefault::getInstance()->setStringForKey("noti-day10-desc", LanguageManager::getInstance()->getStringForKey(descDay10->getCString()).c_str());
    
    rand = cocos2d::RandomHelper::random_int(1, 13);
    auto titleDay14 = cocos2d::__String::createWithFormat("COMEBACK_TITLE%i", rand);
    auto descDay14 = cocos2d::__String::createWithFormat("COMEBACK_DESC%i", rand);
    
    UserDefault::getInstance()->setStringForKey("noti-day14-title", LanguageManager::getInstance()->getStringForKey(titleDay14->getCString()).c_str());
    UserDefault::getInstance()->setStringForKey("noti-day14-desc", LanguageManager::getInstance()->getStringForKey(descDay14->getCString()).c_str());
    log("day3: %s. %s", titleDay3->getCString(), descDay3->getCString());
    log("day7: %s. %s", titleDay7->getCString(), descDay7->getCString());
    log("day10: %s. %s", titleDay10->getCString(), descDay10->getCString());
    log("day14: %s. %s", titleDay14->getCString(), descDay14->getCString());
}
void HelloWorld::createTemplateChallenge() {
    log("challengeIndex %i", challengeIndex);
    perCent = HuyFunctions().perCentChallenge(challengeIndex);
    
    levelChallenge = Variable().arrChallenge.at(2).at(challengeIndex);
    loaiPhepTinh = HuyFunctions().chuyenGiaTriPhepTinh(Variable().arrChallenge.at(0).at(challengeIndex));
    //2 - nhan; 3 - chia; 4 - cong; 5 - tru; 1 - multi
    //create bg
    auto bgChallenge = ui::Button::create("bg-challege.png"); // tao button
    bgChallenge->setTouchEnabled(false);
    float ratiobgChallenge = 1.05;
    //float fixWidth = wScene / 20;
    //float fixHeight = hScene * 0.53;
    if (hScene / wScene <= 1.53)
    {
        ratiobgChallenge = 2.1;
    }
    float scalebgChallenge = wScene / ratiobgChallenge / bgChallenge->getContentSize().width;
    bgChallenge->setScale(scalebgChallenge);
    bgChallenge->setPosition(Vec2(wScene/2, hScene * 0.6));
    bgChallenge->setEnabled(true);
    this->addChild(bgChallenge);
    
    //them con cho
    auto viTriNhanVat = UserDefault::getInstance()->getIntegerForKey("nhanvatdachon", 0) + 1;
    
    auto imageName = StringUtils::format("home-nv%d.png", viTriNhanVat);
//    if (h / w <= 1.53)
//    {
//        imageName = "bg-home-ipad2.png";
//    }
    mainActor = ui::Button::create(imageName); // tao button
    mainActor->setTouchEnabled(false);
    float ratiomainActor = 3.2;
    if (hScene / wScene <= 1.53)
    {
        ratiomainActor = 6.4;
    }
    float scalemainActor = wScene / ratiomainActor / mainActor->getContentSize().width;
    mainActor->setScale(scalemainActor);

    float ymainActor = 0.73 * hScene - (mainActor->getContentSize().height / 2 * scalemainActor);
    log("ti le man hinh: %f", hScene / wScene);
    
  
    auto fontOfName = 0.04 * wScene;
    float paddingX = 40 , paddingY = 10;
    if (hScene / wScene <= 1.53)
    {
        paddingX = 20;
        paddingY = 5;
        fontOfName = 0.023 * wScene;
        ymainActor = 0.73 * hScene - (mainActor->getContentSize().height / 2 * scalemainActor);
    }
    mainActor->setPosition(Vec2(wScene / 2 + mainActor->getContentSize().width * scalemainActor / 2, bgChallenge->getPositionY() + bgChallenge->getContentSize().height * scalebgChallenge * 0.57));
    mainActor->setEnabled(true);
    mainActor->setRotation(50);
    this->addChild(mainActor, 6);
    
    auto fontStyle = "fonts/NunitoSans-Bold.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
    }
    //thêm tên cho người chơi
    auto tenNguoiChoi = UserDefault::getInstance()->getStringForKey("ten-nguoi-choi");
    auto xinChao = LanguageManager::getInstance()->getStringForKey("HELLO");
    if (tenNguoiChoi != "") {
        auto hienThiTenNguoiChoi = cocos2d::__String::createWithFormat("%s\n%s", xinChao.c_str(), tenNguoiChoi.c_str());
        labelNguoiChoi = Label::createWithTTF(hienThiTenNguoiChoi->getCString(), fontStyle, fontOfName);
        labelNguoiChoi->setHorizontalAlignment(TextHAlignment::CENTER);
        
        
        Size bgSize(labelNguoiChoi->getContentSize().width + paddingX,
                    labelNguoiChoi->getContentSize().height + paddingY);
        auto bg = DrawNode::create();
        HuyFunctions().drawSolidRoundedRect(bg, Vec2::ZERO, bgSize, bgSize.height / 2, Color4F(0.1176f, 0.0275f, 0.3373f, 1.0f));
        auto node = Node::create();
        node->addChild(bg);
        node->addChild(labelNguoiChoi);
        labelNguoiChoi->setPosition(Vec2(bgSize.width * 0.5f, bgSize.height * 0.5f));
        this->addChild(node, 5);
        node->setRotation(-2);
        node->setPosition(mainActor->getPositionX() -  bgSize.width - mainActor->getContentSize().width * mainActor->getScale() / 4, mainActor->getPositionY());
        
    }
    //thêm tên cho người chơi --- kết thúc
    
    //them nut bam cho challenge
    auto buttonPlayDual = ui::Button::create("button-challenge.png", "button-challenge.png"); // tao button
    float ratioButtonPlayDual = 2.9;
    if (ratioScreenHello <= 1.53)
    {
        ratioButtonPlayDual = 5.8;
    }
    float scaleButtonPlayDual = wScene / ratioButtonPlayDual / buttonPlayDual->getContentSize().width;
    buttonPlayDual->setScale(scaleButtonPlayDual);
    float yButtonPlayDual = bgChallenge->getPositionY() - bgChallenge->getContentSize().height * scalebgChallenge / 2;// +  buttonPlayDual->getContentSize().height * scaleButtonPlayDual * 0.5;

    float xButtonPlayDual = wScene * 0.3;
    if (ratioScreenHello <= 1.53)
    {
        xButtonPlayDual = wScene * 0.4;
    }
    buttonPlayDual->setPosition(Vec2(xButtonPlayDual, yButtonPlayDual));

    buttonPlayDual->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button 1 clicked");
                //HuyFunctions().animationClickedButton(button);
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                log("Button 1 touch");
                
                //bat dau 1 thu thach moi
                UserDefault::getInstance()->setIntegerForKey("bat-dau-thu-thach-moi", 1);
                
                
                //redirect to play
                HuyFunctions().animationClickedButton(button, [this](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(loaiPhepTinh, levelChallenge), Color3B().WHITE));
//                    if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
//                        HuyFunctions().showAds();
//                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
            }
        });
    addChild(buttonPlayDual);//add button vao scene
    
    // Nén dọc (chiều Y nhỏ lại, chiều X giữ nguyên)
    auto squash = ScaleTo::create(0.5f, 1.1f * scaleButtonPlayDual, 0.9f * scaleButtonPlayDual);
    // Trở lại bình thường
    auto stretch = ScaleTo::create(0.5f, 1.0f * scaleButtonPlayDual, 1.0f * scaleButtonPlayDual);

    // Chạy lặp lại
    auto sequence = Sequence::create(squash, stretch, nullptr);
    buttonPlayDual->runAction(RepeatForever::create(sequence));
    
    //them icon cong tru nhan chia
    auto iconPhepTinh = Sprite::create(StringUtils::format("challenge-type%i.png", Variable().arrChallenge.at(0).at(challengeIndex)));
    log(StringUtils::format("challenge-type%i.png", Variable().arrChallenge.at(0).at(challengeIndex)).c_str());
    
    float ratioiconPhepTinh = 9;
    float fontSizeNoti = 0.04 * wScene;
    
    if (ratioScreenHello <= 1.53)
    {
        ratioiconPhepTinh = 18;
      
    }
    float scaleiconPhepTinh = wScene / ratioiconPhepTinh / iconPhepTinh->getContentSize().width;
    iconPhepTinh->setScale(scaleiconPhepTinh);
    iconPhepTinh->setPosition(Vec2(bgChallenge->getPositionX() + iconPhepTinh->getContentSize().width * scaleiconPhepTinh / 2 - bgChallenge->getContentSize().width * scalebgChallenge * 0.4, bgChallenge->getPositionY())); // Đặt vị trí
    this->addChild(iconPhepTinh);
    float fixWidthIpad = 1;
    if (ratioScreenHello <= 1.53) {
        fixWidthIpad = 0.5;
    }
    //them so phep tinh cua thu thach
    auto soPhepTinhString = StringUtils::format("%i", Variable().arrChallenge.at(1).at(challengeIndex));
    auto soPhepTinh = Label::createWithTTF(soPhepTinhString, "fonts/NunitoSans-Bold.ttf", 0.045 * wScene * fixWidthIpad);
    soPhepTinh->setColor(Color3B().WHITE);
    auto ysoPhepTinh = iconPhepTinh->getPositionY();
    auto xsoPhepTinh = iconPhepTinh->getPositionX() + iconPhepTinh->getContentSize().width * scaleiconPhepTinh * 0.65 + soPhepTinh->getContentSize().width / 2;
    soPhepTinh->setPosition(Vec2(xsoPhepTinh, ysoPhepTinh));
    addChild(soPhepTinh);
    
    
    // Thêm slider
    loadingBar = ui::LoadingBar::create(StringUtils::format("challenge-loading%i.png", Variable().arrChallenge.at(0).at(challengeIndex)));
    float heightLoadingBar = 0.92 * hScene;
    float scaleLoading = wScene / 2.5  / loadingBar->getContentSize().width;
    if (ratioScreenHello <= 1.53) {
        scaleLoading = wScene / 5  / loadingBar->getContentSize().width;
    }
    loadingBar->setPosition(Vec2(iconPhepTinh->getPositionX() + loadingBar->getContentSize().width * scaleLoading / 2 - iconPhepTinh->getContentSize().width * scaleiconPhepTinh / 2, bgChallenge->getPositionY() + bgChallenge->getContentSize().height * scalebgChallenge * 0.25));
    loadingBar->setScale(scaleLoading);
    loadingBar->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBar->setPercent(0); // Bắt đầu từ 0%
    this->addChild(loadingBar, 2);

    auto hLoadingBar = loadingBar->getContentSize().height * scaleLoading - 5;

    // Tạo một loading bar wrap (bao quanh)
    auto loadingBarWrap = ui::LoadingBar::create("loadingbar-wrap2.png");
    loadingBarWrap->setPosition(loadingBar->getPosition());
    loadingBarWrap->setScale(scaleLoading);
    loadingBarWrap->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBarWrap->setPercent(100);
    this->addChild(loadingBarWrap);

    
    //them icon level
    auto iconLevel = Sprite::create(StringUtils::format("challenge-%i%i.png", Variable().arrChallenge.at(0).at(challengeIndex), Variable().arrChallenge.at(2).at(challengeIndex)));
    float ratioiconLevel = 11;
    if (ratioScreenHello <= 1.53)
    {
        ratioiconLevel = 22;
    }
    float scaleiconLevel = wScene / ratioiconLevel / iconLevel->getContentSize().width;
    iconLevel->setScale(scaleiconLevel);
    iconLevel->setPosition(Vec2(loadingBar->getPositionX() + loadingBar->getContentSize().width * scaleLoading / 2  - iconLevel->getContentSize().width * scaleiconLevel / 2, iconPhepTinh->getPositionY()));
    this->addChild(iconLevel);
    
    //them bg cho gift thu thach
    auto bgGiftChallenge = Sprite::create(StringUtils::format("bg-gift%i-challenge.png", Variable().arrChallenge.at(3).at(challengeIndex)));
    float ratiobgGiftChallenge = 3.2;
    if (ratioScreenHello <= 1.53)
    {
        ratiobgGiftChallenge = 6.4;
      
    }
    float scalebgGiftChallenge = wScene / ratiobgGiftChallenge / bgGiftChallenge->getContentSize().width;
    bgGiftChallenge->setScale(scalebgGiftChallenge);
    bgGiftChallenge->setPosition(Vec2(bgChallenge->getPositionX() + bgChallenge->getContentSize().width * scalebgChallenge / 2 - bgGiftChallenge->getContentSize().width * scalebgGiftChallenge * 0.75, iconPhepTinh->getPositionY()));
    this->addChild(bgGiftChallenge);
    //them icon gift
    loaiPhanThuong = Variable().arrChallenge.at(3).at(challengeIndex);
    auto imgGiftName = "gold-daily-reward.png";
    if (Variable().arrChallenge.at(3).at(challengeIndex) == 2) {
        imgGiftName = "diamod-daily-reward.png";
    }
    auto iconGift0 = Sprite::create(imgGiftName);
    float ratioiconGift = 7;
    if (ratioScreenHello <= 1.53)
    {
        ratioiconGift = 14;
    }
    float scaleiconGift = wScene / ratioiconGift / iconGift0->getContentSize().width;
    
    iconGift0->setScale(scaleiconGift);
    iconGift0->setPosition(Vec2(bgGiftChallenge->getPositionX() - iconGift0->getContentSize().width * scaleiconGift * 0.4 , bgGiftChallenge->getPositionY() - bgGiftChallenge->getContentSize().height * scalebgChallenge * 0.15));
    this->addChild(iconGift0);
    iconGift = Sprite::create(imgGiftName);
    iconGift->setScale(scaleiconGift);
    iconGift->setPosition(iconGift0->getPosition());
    this->addChild(iconGift);
    
    
    //them text cho Gift
    giftNumber = Variable().arrChallenge.at(4).at(challengeIndex);
    auto labelGiftValueColor = Color4B(13, 113, 154, 255);
    auto giftValueString = cocos2d::__String::createWithFormat("+%i", giftNumber);
    auto giftValue = Label::createWithTTF(giftValueString->getCString(), "fonts/NunitoSans-Bold.ttf", 0.045 * wScene * fixWidthIpad);
    giftValue->setTextColor(labelGiftValueColor);
    giftValue->enableOutline(cocos2d::Color4B::WHITE, 1);
    auto ygiftValue = iconGift->getPositionY();
    auto xgiftValue = iconGift->getPositionX() + iconGift->getContentSize().width * scaleiconGift * 0.55 + giftValue->getContentSize().width / 2;
    giftValue->setPosition(Vec2(xgiftValue, ygiftValue));
    addChild(giftValue);
    if (showDailyReward == false) {
        animationChallenge();
    }
}
void HelloWorld::createTemplateDailyReward(float w, float h) {
    //create bg
    bgReward = ui::Button::create("bg-daily-reward.png"); // tao button
    bgReward->setTouchEnabled(false);
    float ratiobgReward = 1;
    float scalebgReward = h / ratiobgReward / bgReward->getContentSize().height;
    if(scalebgReward < w / ratiobgReward / bgReward->getContentSize().width) {
        scalebgReward = w / ratiobgReward / bgReward->getContentSize().width;
    }
    //log("ti le test: %f", scalebgReward);
    //log("ti le test theo w: %f", w / ratiobgReward / bgReward->getContentSize().width);
    bgReward->setScale(scalebgReward);
    bgReward->setAnchorPoint(Vec2(0, 0));
    bgReward->setPosition(Vec2(0, 0));
    bgReward->setEnabled(true);
    this->addChild(bgReward, 10);
    
    //create top-header
    pictureHeader = ui::Button::create("header-daily-reward.png"); // tao button
    pictureHeader->setTouchEnabled(false);
    float ratiopictureHeader = 1.8;
    float fixWidth = w / 20;
    float fixHeight = h * 0.53;
    if (h / w <= 1.53)
    {
        ratiopictureHeader = 3.6;
        fixWidth = w / 4;
        fixHeight = h * 0.58;
    }
    float scalepictureHeader = w / ratiopictureHeader / pictureHeader->getContentSize().width;
    pictureHeader->setScale(scalepictureHeader);
    pictureHeader->setPosition(Vec2(w/2, h * 0.75));
    pictureHeader->setEnabled(true);
    this->addChild(pictureHeader, 10);
    
    int positionX = 0;
    int isRow2 = 0;
    auto labelGiftValueColor = Color4B(13, 113, 154, 255);
    float heightCard = 0;
    float widthCardBefore = 0;
    float positionCardBefore = 0;
    //create day 1 - day 4
    for (int i = 0; i < 7; i++) {
        if (positionX > 3) {
            positionX = 0;
            isRow2 = 1;
        }
        auto cardBgName = "card-small-gold-2.png";
        if (i < 5) {
            if (Variable().arrDailyRewardType.at(i) == 1) {
                labelGiftValueColor = Color4B(224, 89, 0, 255);
                int randBg = cocos2d::RandomHelper::random_int(1, 2);
                if (randBg == 1) {
                    cardBgName = "card-small-gold-1.png";
                }else {
                    cardBgName = "card-small-gold-2.png";
                }
            } else {
                labelGiftValueColor = Color4B(13, 113, 154, 255);
                cardBgName = "card-small-diamond-1.png";
            }
        }else if (i == 5) {
            cardBgName = "card-m-gold-1.png";
            labelGiftValueColor = Color4B(224, 89, 0, 255);
        }else if (i == 6) {
            cardBgName = "card-big-diamond-1.png";
            labelGiftValueColor = Color4B(13, 113, 154, 255);
        }
        
        cards = ui::Button::create(cardBgName); // tao button
        cards->setTouchEnabled(false);
        float ratiocards = 4.6;
        if (h / w <= 1.53)
        {
            ratiocards = 9.2;
        }
        float scalecards = w / ratiocards / cards->getContentSize().width;
        if (i > 4) {
            log("height cards: %f", heightCard);
            ratiocards = h / heightCard;
            scalecards = h / ratiocards / cards->getContentSize().height;
            
        }
        cards->setScale(scalecards);
        cards->setAnchorPoint(Vec2(0, 0));
        cards->setPosition(Vec2(fixWidth + (w/70 + cards->getContentSize().width * scalecards) * positionX, fixHeight - (cards->getContentSize().height * scalecards * 1.1) * isRow2));
        if (i > 4) {
            cards->setPosition(Vec2(positionCardBefore + widthCardBefore + w/70 , fixHeight - (cards->getContentSize().height * scalecards * 1.1) * isRow2));
        }
        widthCardBefore = cards->getContentSize().width * cards->getScale();
        positionCardBefore = cards->getPositionX();
        cards->setEnabled(true);
        listCardsButton.pushBack(cards);
        this->addChild(cards, 10);
        if (i == 0) {
            heightCard = cards->getContentSize().height * scalecards;
        }
        auto cardWrapper = cocos2d::ui::Button::create(cardBgName); // tao button
        cardWrapper->setTouchEnabled(false);
        cardWrapper->setScale(scalecards);
        cardWrapper->setColor(cocos2d::Color3B::BLACK);
        cardWrapper->setContentSize(cards->getContentSize());
        cardWrapper->setOpacity(160);
        cardWrapper->setAnchorPoint(Vec2(0, 0));
        cardWrapper->setPosition(cards->getPosition());
        
        cardWrapper->setEnabled(true);
        cardWrapper->setTag(90 + i);
        listCardsButton.pushBack(cardWrapper);
        this->addChild(cardWrapper, 12);
    
        auto rewardClaimed = ui::Button::create("check-3.png"); // tao button
        rewardClaimed->setTouchEnabled(false);
        float ratiorewardClaimed = 11;
        float fixFontIpad = 1;
        if (h / w <= 1.53)
        {
            ratiorewardClaimed = 22;
            fixFontIpad = 0.5;
        }
        float scalerewardClaimed = w / ratiorewardClaimed/ rewardClaimed->getContentSize().width;
        rewardClaimed->setScale(scalerewardClaimed);
        //rewardClaimed->setAnchorPoint(Vec2(0, 0));
        auto yrewardClaimed = cards->getPositionY()+ cards->getContentSize().height * scalecards * 0.5;
        auto xrewardClaimed = cards->getPositionX() + cards->getContentSize().width * scalecards / 2;
        rewardClaimed->setPosition(Vec2(xrewardClaimed, yrewardClaimed));
        rewardClaimed->setEnabled(true);
        rewardClaimed->setTag(80 + i);
        listCardsButton.pushBack(rewardClaimed);
        this->addChild(rewardClaimed, 12);
        if (dailyRewardDay - 1 < i) {
            cardWrapper->setOpacity(0);
            rewardClaimed->setOpacity(0);
        }
        auto cardTitleString = cocos2d::__String::createWithFormat("Day %i", i + 1);
        auto cardTitle = Label::createWithTTF(cardTitleString->getCString(), "fonts/NunitoSans-Bold.ttf", 0.045 * w * fixFontIpad);
        cardTitle->setColor(Color3B().WHITE);
        auto ycardTitle = cards->getPositionY()+ cards->getContentSize().height * scalecards * 0.86;
        auto xcardTitle = cards->getPositionX() + cards->getContentSize().width * scalecards / 2;
        cardTitle->setPosition(Vec2(xcardTitle, ycardTitle));
        listCardsLabel.pushBack(cardTitle);
        addChild(cardTitle, 10);
        
        auto giftImg = "gold-daily-reward.png";
        if (Variable().arrDailyRewardType.at(i) == 1 and Variable().arrDailyRewardValue.at(dailyRewardWeek).at(i) > 200) {
            giftImg = "gold-daily-reward-2.png";
        }
        if (Variable().arrDailyRewardType.at(i) == 2) {
            giftImg = "diamod-daily-reward.png";
            if (Variable().arrDailyRewardValue.at(dailyRewardWeek).at(i) > 9) {
                giftImg = "diamod-daily-reward-2.png";
            }
        }
        
        auto gift0 = ui::Button::create(giftImg); // tao button
        gift0->setTouchEnabled(false);
        float ratiogift = 6.5;
        if (h / w <= 1.53)
        {
            ratiogift = 13;
        }
        float scalegift = w / ratiogift / gift0->getContentSize().width;
        gift0->setScale(scalegift);
        //gift0->setAnchorPoint(Vec2(0, 0));
        auto ygift = cards->getPositionY()+ cards->getContentSize().height * scalecards * 0.47;
        auto xgift = cards->getPositionX() + cards->getContentSize().width * scalecards / 2;
        gift0->setPosition(Vec2(xgift, ygift));
        gift0->setEnabled(true);
        listCardsButton.pushBack(gift0);
        this->addChild(gift0, 10);
        
        auto gift = ui::Button::create(giftImg); // tao button
        gift->setTouchEnabled(false);
        gift->setScale(scalegift);
        //gift->setAnchorPoint(Vec2(0, 0));
        gift->setPosition(Vec2(xgift, ygift));
        gift->setEnabled(true);
        gift->setTag(i + 1);
        listCardsButton.pushBack(gift);
        this->addChild(gift, 11);
        
        auto giftValueString = cocos2d::__String::createWithFormat("%i", Variable().arrDailyRewardValue.at(dailyRewardWeek).at(i));
        auto giftValue = Label::createWithTTF(giftValueString->getCString(), "fonts/NunitoSans-Bold.ttf", 0.061 * w * fixFontIpad);
        giftValue->setTextColor(labelGiftValueColor);
        giftValue->enableOutline(cocos2d::Color4B::WHITE, 1);
        auto ygiftValue = cards->getPositionY()+ cards->getContentSize().height * scalecards * 0.13;
        auto xgiftValue = cards->getPositionX() + cards->getContentSize().width * scalecards / 2;
        giftValue->setPosition(Vec2(xgiftValue, ygiftValue));
        addChild(giftValue, 10);
        listCardsLabel.pushBack(giftValue);
        positionX++;
    }
    //create claim button
    claimButton = ui::Button::create("button-claim.png", "button-claim.png"); // tao button
    float ratioButtonClaim = 4.5;
    if (h / w <= 1.53)
    {
        ratioButtonClaim = 9;
    }
    //auto claimButtonHeight = claimButton->getContentSize().height;
    auto claimButtonWidth = claimButton->getContentSize().width;

    float scaleClaimButton = w / ratioButtonClaim / claimButtonWidth;
    claimButton->setScale(scaleClaimButton);
    claimButton->setPosition(Vec2(w/2, h * 0.2));
    claimButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                //HuyFunctions().animationClickedButton(button, [this](){
                claimHandle(w, h);
                //});

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(claimButton, 10);//add button vao scene
    
    float timeAnimation = 0.4;
    auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * scaleClaimButton);
    auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.1, scaleClaimButton * 0.95);
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    claimButton->runAction((RepeatForever::create(sq3)));
    
    //create close button
    auto closeButton = ui::Button::create("nhan-finish2.png", "nhan-finish2.png"); // tao button
    float ratio = 17;
    if (h / w <= 1.53)
    {
        ratio = 34;
    }
    //auto closeButtonHeight = closeButton->getContentSize().height;
    auto closeButtonWidth = closeButton->getContentSize().width;

    float scale = w / ratio / closeButtonWidth;
    closeButton->setScale(scale);
    closeButton->setPosition(Vec2(w * 0.9, pictureHeader->getPositionY()));
    closeButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                animationChallenge();
                
                HuyFunctions().animationClickedButton(button, [this, button](){
                    float t = 0.3f;
                    button->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    pictureHeader->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    bgReward->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    if (claimButton) {
                        claimButton->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    }
                    for (auto label : listCardsLabel) {
                        label->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    }
                    for (auto btn : listCardsButton) {
                        btn->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(closeButton, 10);//add button vao scene
}
void HelloWorld::createTemplateInputTen(float w, float h) {
    //create bg
    auto fontStyle = "fonts/NunitoSans-Bold.ttf";
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
    }
    
    bgReward2 = ui::Button::create("bg-daily-reward.png"); // tao button
    bgReward2->setTouchEnabled(false);
    float ratiobgReward2 = 1;
    float scalebgReward2 = h / ratiobgReward2 / bgReward2->getContentSize().height;
    if(scalebgReward2 < w / ratiobgReward2 / bgReward2->getContentSize().width) {
        scalebgReward2 = w / ratiobgReward2 / bgReward2->getContentSize().width;
    }
    //log("ti le test: %f", scalebgReward2);
    //log("ti le test theo w: %f", w / ratiobgReward2 / bgReward2->getContentSize().width);
    bgReward2->setScale(scalebgReward2);
    bgReward2->setAnchorPoint(Vec2(0, 0));
    bgReward2->setPosition(Vec2(0, 0));
    bgReward2->setEnabled(true);
    this->addChild(bgReward2, 12);
    
    auto fontTitle = 0.08 * w;
    auto fixIpad = 1;
    Size sizeOfEditBox = Size(200,50);
    if (h / w <= 1.53)
    {
        fontTitle = 0.04 * w;
        sizeOfEditBox = Size(100,25);
        fixIpad = 0.5;
    }
    
    labelTitleNguoiChoi = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("BANTENLAGI").c_str(), fontStyle, fontTitle);
    labelTitleNguoiChoi->setHorizontalAlignment(TextHAlignment::CENTER);
    labelTitleNguoiChoi->setTextColor(Color4B::YELLOW);
    labelTitleNguoiChoi->setPosition(Vec2(w/2, h * 0.85));
    this->addChild(labelTitleNguoiChoi, 13);
    
    auto bgSprite = ui::Scale9Sprite::create();
    bgSprite->setContentSize(sizeOfEditBox);
    bgSprite->setColor(Color3B::WHITE);  // nền trắng
    bgSprite->setOpacity(255);
    nameEditBox = ui::EditBox::create(sizeOfEditBox, bgSprite);
    //nameEditBox->setPosition(Vec2(w/ 2, h / 2));
    nameEditBox->setFontColor(Color3B::BLACK);
    nameEditBox->setMaxLength(20);
    nameEditBox->setFontSize(fontTitle);
    nameEditBox->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    nameEditBox->setInputMode(ui::EditBox::InputMode::SINGLE_LINE);
    nameEditBox->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    // Tự động focus:
    nameEditBox->openKeyboard();
    
    float paddingX = 30 * fixIpad, paddingY = 5 * fixIpad;
    Size bgSize(nameEditBox->getContentSize().width + paddingX,
                nameEditBox->getContentSize().height + paddingY);
    auto bg = DrawNode::create();
    HuyFunctions().drawSolidRoundedRect(bg, Vec2::ZERO, bgSize, bgSize.height / 2, Color4F(1, 1, 1, 1.0f));
    node = Node::create();
    node->addChild(bg);
    node->addChild(nameEditBox);
    nameEditBox->setPosition(Vec2(bgSize.width * 0.5f, bgSize.height * 0.5f));
    this->addChild(node, 12);
    node->setPosition(w/2 - bgSize.width / 2, labelTitleNguoiChoi->getPositionY() - h / 7);
    
    labelErr = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("LOI_DIEN_TEN").c_str(), fontStyle, fontTitle * 0.7);
    labelErr->setHorizontalAlignment(TextHAlignment::CENTER);
    labelErr->setColor(Color3B::RED);
    labelErr->setPosition(Vec2(w/2, node->getPositionY() - labelErr->getContentSize().height));
    this->addChild(labelErr, 13);
    labelErr->setVisible(false);
    
    
    auto dogName = Sprite::create("dog-whatname.png");
    
    float ratioDogName = 2;
  
    if (ratioScreenHello <= 1.53)
    {
        ratioDogName = 4;
      
    }
    float scaleDogName = wScene / ratioDogName / dogName->getContentSize().width;
    dogName->setScale(scaleDogName);
    dogName->setPosition(Vec2(wScene - dogName->getContentSize().width * scaleDogName * 0.6, node->getPositionY() - labelErr->getContentSize().height - dogName->getContentSize().height * scaleDogName / 2 - h / 50)); // Đặt vị trí
    this->addChild(dogName, 13);
    
    //create claim button
    okButton = ui::Button::create("button-claim.png", "button-claim.png"); // tao button
    float ratioButtonClaim = 4.5;
    if (h / w <= 1.53)
    {
        ratioButtonClaim = 9;
    }
    //auto okButtonHeight = okButton->getContentSize().height;
    auto okButtonWidth = okButton->getContentSize().width;

    float scaleokButton = w / ratioButtonClaim / okButtonWidth;
    okButton->setScale(scaleokButton);
    okButton->setPosition(Vec2(w/2, dogName->getPositionY() - dogName->getContentSize().height * scaleDogName - h / 10));
    okButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                //HuyFunctions().animationClickedButton(button, [this](){
                inputTenHandle(w, h);
                //});

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(okButton, 12);//add button vao scene
    
    //create close button
    closeButton2 = ui::Button::create("nhan-finish2.png", "nhan-finish2.png"); // tao button
    float ratio = 17;
    if (h / w <= 1.53)
    {
        ratio = 34;
    }
    //auto closeButton2Height = closeButton2->getContentSize().height;
    auto closeButton2Width = closeButton2->getContentSize().width;

    float scale = w / ratio / closeButton2Width;
    closeButton2->setScale(scale);
    closeButton2->setPosition(Vec2(w * 0.9, h * 0.9));
    closeButton2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                animationChallenge();
                
                HuyFunctions().animationClickedButton(button, [this, button](){
                    float t = 0.3f;
                    button->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    
                    bgReward2->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    labelTitleNguoiChoi->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    node->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    labelErr->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    if (okButton) {
                        okButton->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
                    }
                    
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(closeButton2, 13);//add button vao scene
}
void HelloWorld::animationChallenge() {
    
    auto progressTo = ProgressTo::create(1.0f, perCent); // Thời gian 2 giây
    loadingBar->runAction(progressTo);
    
    if (perCent == 100) {
        UserDefault::getInstance()->setIntegerForKey("bat-dau-thu-thach-moi", 0);
        UserDefault::getInstance()->setIntegerForKey("challenge-index", challengeIndex + 1);
        
        //move vang va kim cuong vao score va diem so duoc cong them
        
        if (loaiPhanThuong == 1) {
            auto tongDiem = HuyFunctions().getSoVang();
            UserDefault::getInstance()->setIntegerForKey("sovang", tongDiem + giftNumber);
            // Gửi điểm số
            int soVangDaily = UserDefault::getInstance()->getIntegerForKey("daily-sovang", 0);
            
            if (HuyFunctions().inVietNam() == false) {
                // Gửi điểm số
                GameCenterBridge::submitScore(soVangDaily + giftNumber, "com.huy.mentalmath.dailygold");
                GameCenterBridge::submitScore(tongDiem + giftNumber, "com.huy.mentalmath.Golds");
            }
            iconGift->runAction(
                    Sequence::create(
                        DelayTime::create(1),
                        EaseExponentialIn::create(MoveTo::create(0.6, myGold->getPosition())),
                        FadeOut::create(0.3),
                        nullptr)
            );
            valueTongDiem->runAction(
                   Sequence::create(
                       DelayTime::create(1.6),
                       ScaleTo::create(0.3, 1.3),
                       CallFunc::create([=]() {
                           valueTongDiem->setString(cocos2d::__String::createWithFormat("%i", tongDiem + giftNumber)->getCString());
                       }),
                       DelayTime::create(0.2),
                       ScaleTo::create(0.3, 1),
                       nullptr
                   )
            );
            
        } else {
            HuyFunctions().saveDiamondToDBAndGameCenterAchievement(giftNumber);
            iconGift->runAction(
                    Sequence::create(
                        DelayTime::create(1),
                        EaseExponentialIn::create(MoveTo::create(0.6, myImg->getPosition())),
                        FadeOut::create(0.3),
                         nullptr)
            );
            valueDiamond->runAction(
                   Sequence::create(
                       DelayTime::create(1.6),
                       ScaleTo::create(0.3, 1.3),
                       CallFunc::create([=]() {
                           valueDiamond->setString(cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("diamond", 0) + giftNumber)->getCString());
                       }),
                       DelayTime::create(0.2),
                       ScaleTo::create(0.3, 1),
                       nullptr
                   )
            );
        }
    }
}

void HelloWorld::inputTenHandle(float w, float h) {
    std::string name = HuyFunctions().trim(nameEditBox->getText());
    if (name == "") {
        labelErr->setVisible(true);
    }else{
        labelErr->setVisible(false);
        log("Tên cua ban: %s", name.c_str());
        UserDefault::getInstance()->setStringForKey("ten-nguoi-choi", name);
        float t = 0.3f;
        bgReward2->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
        labelTitleNguoiChoi->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
        node->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
        labelErr->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
        if (okButton) {
            okButton->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
        }
        if (closeButton2) {
            closeButton2->runAction(cocos2d::Sequence::create(cocos2d::FadeOut::create(t), cocos2d::RemoveSelf::create(), nullptr));
        }
        
//        auto tenNguoiChoi = UserDefault::getInstance()->getStringForKey("ten-nguoi-choi");
//        auto xinChao = LanguageManager::getInstance()->getStringForKey("HELLO");
//        auto hienThiTenNguoiChoi = cocos2d::__String::createWithFormat("%s\n%s", xinChao.c_str(), tenNguoiChoi.c_str());
//        labelNguoiChoi->setString(hienThiTenNguoiChoi->getCString());
        
        //thêm tên cho người chơi
        auto tenNguoiChoi = UserDefault::getInstance()->getStringForKey("ten-nguoi-choi");
        auto xinChao = LanguageManager::getInstance()->getStringForKey("HELLO");
        //if (tenNguoiChoi != "") {
            auto hienThiTenNguoiChoi = cocos2d::__String::createWithFormat("%s\n%s", xinChao.c_str(), tenNguoiChoi.c_str());
            labelNguoiChoi = Label::createWithTTF(hienThiTenNguoiChoi->getCString(), "fonts/NunitoSans-Bold.ttf", 13);
            labelNguoiChoi->setHorizontalAlignment(TextHAlignment::CENTER);
            float paddingX = 40, paddingY = 10;
            Size bgSize(labelNguoiChoi->getContentSize().width + paddingX,
                        labelNguoiChoi->getContentSize().height + paddingY);
            auto bg = DrawNode::create();
            HuyFunctions().drawSolidRoundedRect(bg, Vec2::ZERO, bgSize, bgSize.height / 2, Color4F(0.1176f, 0.0275f, 0.3373f, 1.0f));
            auto node = Node::create();
            node->addChild(bg);
            node->addChild(labelNguoiChoi);
            labelNguoiChoi->setPosition(Vec2(bgSize.width * 0.5f, bgSize.height * 0.5f));
            this->addChild(node, 5);
            node->setRotation(-2);
            node->setPosition(mainActor->getPositionX() -  bgSize.width - mainActor->getContentSize().width * mainActor->getScale() / 4, mainActor->getPositionY());
        //}
        
        //thêm tên cho người chơi --- kết thúc
    }
    
    
}
void HelloWorld::claimHandle(float w, float h) {
    auto fadeOut = cocos2d::FadeOut::create(1.0f);
    //auto remove = cocos2d::RemoveSelf::create(); // Thêm hành động xóa phần tử khỏi scene
    claimButton->runAction(cocos2d::Sequence::create(fadeOut, nullptr));
    for (auto btn : listCardsButton) {
        if (btn->getTag() == dailyRewardDay + 1) {
            float scaleBtn = btn->getScale();
            float timeAnimation = 0.2;
            auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation, 1.2 * scaleBtn);
            auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation, scaleBtn * 1);
            auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
            btn->runAction((RepeatForever::create(sq3)));
            
            //xac dinh xem la kim cuong hay gold: 1- gold, 2 - kim cuong
            int type = Variable().arrDailyRewardType.at(dailyRewardDay);
            auto viTriDich = Vec2();
            auto btnDich = ui::Button::create();
            float scaleBtnDich = 1;
            
            int soDiemMoi = tongDiem + Variable().arrDailyRewardValue.at(dailyRewardWeek).at(dailyRewardDay);
            auto labelDich = valueTongDiem;
            if (type == 1) {
                //gold
                viTriDich = myGold->getPosition();
                btnDich = myGold;
                scaleBtnDich = myGold->getScale();
                
                UserDefault::getInstance()->setIntegerForKey("sovang", soDiemMoi);
                // Gửi điểm số
                int soVangDaily = UserDefault::getInstance()->getIntegerForKey("daily-sovang", 0);
                UserDefault::getInstance()->setIntegerForKey("daily-sovang", soVangDaily + Variable().arrDailyRewardValue.at(dailyRewardWeek).at(dailyRewardDay));
                if (HuyFunctions().inVietNam() == false) {
                    // Gửi điểm số
                    GameCenterBridge::submitScore(soVangDaily + Variable().arrDailyRewardValue.at(dailyRewardWeek).at(dailyRewardDay), "com.huy.mentalmath.dailygold");
                    GameCenterBridge::submitScore(soDiemMoi, "com.huy.mentalmath.Golds");
                }
            } else {
                //diamond
                viTriDich = myImg->getPosition();
                btnDich = myImg;
                scaleBtnDich = myImg->getScale();
                labelDich = valueDiamond;
                soDiemMoi = UserDefault::getInstance()->getIntegerForKey("diamond", 0) + Variable().arrDailyRewardValue.at(dailyRewardWeek).at(dailyRewardDay);
                HuyFunctions().saveDiamondToDBAndGameCenterAchievement(Variable().arrDailyRewardValue.at(dailyRewardWeek).at(dailyRewardDay));
            }
            //move vang ve vi tri dich
            auto actionMoveTo = MoveTo::create(0.7, viTriDich);
            btn->runAction(
                    Sequence::create(
                        DelayTime::create(1.3),
                        Spawn::create(
                                EaseExponentialIn::create(actionMoveTo),
                                //ScaleTo::create(0.7, scaleBtn * 0.2),
                                nullptr),
                        FadeOut::create(0.3),
                        NULL)
            );
            
            btnDich->runAction(
                Sequence::create(
                    DelayTime::create(2.3),
                    ScaleTo::create(0.3, 2 * scaleBtnDich),
                    ScaleTo::create(0.2, 0.95 * scaleBtnDich),
                    ScaleTo::create(0.1, 1 * scaleBtnDich),
                    NULL)
            );
            labelDich->runAction(
                   Sequence::create(
                       DelayTime::create(2.3),
                       ScaleTo::create(0.3, 1.3),
                       CallFunc::create([=]() {
                           labelDich->setString(cocos2d::__String::createWithFormat("%i", soDiemMoi)->getCString());
                       }),
                       DelayTime::create(0.2),
                       ScaleTo::create(0.3, 1),
                       nullptr
                   )
            );
        }
        if (btn->getTag() == (90 + dailyRewardDay)) {
            btn->runAction(
                Sequence::create(
                    DelayTime::create(2.3),
                    FadeTo::create(0.3, 160),
                    NULL)
            );
        }
        if (btn->getTag() == (80 + dailyRewardDay) ) {
            btn->runAction(
                Sequence::create(
                    DelayTime::create(2.3),
                    FadeIn::create(0.3),
                    NULL)
            );
        }
    }
    if (dailyRewardDay == 6) {
        UserDefault::getInstance()->setIntegerForKey("daily-reward", 0);
        UserDefault::getInstance()->setIntegerForKey("daily-reward-sotuan", dailyRewardWeek + 1);
    } else {
        UserDefault::getInstance()->setIntegerForKey("daily-reward", dailyRewardDay + 1);
    }
}
void HelloWorld::createButtonLearnPlayRateGift(){
    auto buttonLearn = ui::Button::create("home-learn2.png", "home-learn2.png"); // tao button
    float ratioButtonLearn = 7;
    if (hScene / wScene <= 1.53)
    {
        ratioButtonLearn = 14;
    }
    
    float scaleButtonLearn = wScene / ratioButtonLearn / buttonLearn->getContentSize().width;
    buttonLearn->setScale(scaleButtonLearn);
    float yButtonLearn = hScene * 0.05 + buttonLearn->getContentSize().height / 2 * scaleButtonLearn;
    if (hScene / wScene <= 1.8)
    {
        yButtonLearn = hScene * 0.025 + buttonLearn->getContentSize().height / 2 * scaleButtonLearn;
    }
    buttonLearn->setPosition(Vec2(wScene * 0.05 + buttonLearn->getContentSize().width / 2 * scaleButtonLearn, yButtonLearn));
    if (hScene / wScene <= 1.53)
    {
        
        buttonLearn->setPosition(Vec2(wScene * 0.1 + buttonLearn->getContentSize().width / 2 * scaleButtonLearn, yButtonLearn));
        
    }
    buttonLearn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                //log("Button learn touch");
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, LearnSelect::createScene(), Color3B().WHITE));
                    
                    //IAPManager::getInstance()->purchase(Variable().proProductionID);
                    //IAPManager::getInstance()->restorePurchases();
                });
                
                
                
                break;
            default:
                break;
        }
        
        
    });
    this->addChild(buttonLearn);//add button vao scene

    //btn Rate
    auto buttonRate = ui::Button::create("parent.png", "parent.png"); // tao button
    float ratioButtonRate = 7;
    if (hScene / wScene <= 1.53)
    {
        ratioButtonRate = 14;

    }
    float scaleButtonRate = wScene / ratioButtonRate / buttonRate->getContentSize().width;
    buttonRate->setScale(scaleButtonRate);

    //float xButtonRate = wScene / 2 + buttonLearn->getContentSize().height / 2 * scaleButtonLearn + 30;
    buttonRate->setPosition(Vec2(buttonLearn->getPositionX(), buttonLearn->getPositionY() + buttonLearn->getContentSize().width * buttonLearn->getScale() + hScene / 50));
    if (hScene / wScene <= 1.53)
    {
        
        buttonRate->setPosition(Vec2(buttonLearn->getPositionX(), buttonLearn->getPositionY() + buttonLearn->getContentSize().width * buttonLearn->getScale()  + hScene / 50));
    }
    buttonRate->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, ParentScreen::createScene(), Color3B().WHITE));
                });
                break;
            default:
                break;
        }
    });
    this->addChild(buttonRate);//add button vao scene
    
    //sticker
    auto stickerButton = ui::Button::create("medal.png", "medal.png");
    float ratioSticker = 7;
    if (hScene / wScene <= 1.53)
    {
        ratioSticker = 14;
    }
    float scaleSticker = wScene / ratioSticker / stickerButton->getContentSize().width;
    
    stickerButton->setScale(scaleSticker);
    float ystickerButton = buttonRate->getPositionY() + buttonRate->getContentSize().height * buttonRate->getScale() + hScene / 30;
    stickerButton->setPosition(Vec2(wScene - buttonRate->getPositionX(), ystickerButton));
    stickerButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Medal::createScene(), Color3B().WHITE));
                });
                break;
            default:
                break;
        }
    });
    this->addChild(stickerButton);//add button vao scene
    auto buttonCricleRed2 = ui::Button::create("circleRed.png", "circleRed.png"); // tao button
    float ratioButtonCricleRed2 = 16;
    if (hScene / wScene <= 1.53)
    {
        ratioButtonCricleRed2 = 32;
    }
    float scaleButtonCricleRed2 = wScene / ratioButtonCricleRed2 / buttonCricleRed2->getContentSize().width;
    buttonCricleRed2->setScale(scaleButtonCricleRed2);
    float yButtonCricleRed2 = stickerButton->getPositionY() + buttonCricleRed2->getContentSize().height * scaleButtonCricleRed2 * 1.2;
    buttonCricleRed2->setPosition(Vec2(stickerButton->getPositionX(), yButtonCricleRed2));
    this->addChild(buttonCricleRed2);//add button vao scene
   
    auto fontSize = 0.042 * wScene;
    if (ratioScreenHello <= 1.53) {
        fontSize = 0.021 * wScene;
    }
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    
    auto achievementLabel2 = Label::createWithTTF(StringUtils::format("%d", HuyFunctions().tinhTongSoStickerBangKhen()), fontStyle, fontSize);
    achievementLabel2->setColor(Color3B().WHITE);
    achievementLabel2->setPosition(buttonCricleRed2->getPosition());
    achievementLabel2->setAnchorPoint({0.5, 0.5});
    achievementLabel2->setHorizontalAlignment(TextHAlignment::CENTER);
    addChild(achievementLabel2);
    
    
    
    //buy pro version
    auto buttonBuyProVer = ui::Button::create("tv-ads.png", "tv-ads.png"); // tao button
    float ratioButtonPro = 7;
    if (hScene / wScene <= 1.53)
    {
        ratioButtonPro = 14;
    }
    float scaleButtonPro = wScene / ratioButtonPro / buttonBuyProVer->getContentSize().width;
    
    buttonBuyProVer->setScale(scaleButtonPro);
    float ybuttonBuyProVer = stickerButton->getPositionY() + stickerButton->getContentSize().height * stickerButton->getScale() + hScene / 25;
    
    
    
    buttonBuyProVer->setPosition(Vec2(stickerButton->getPositionX(), ybuttonBuyProVer));
    buttonBuyProVer->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = dynamic_cast<ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                //log("Button learn touch");
                HuyFunctions().animationClickedButton(button, [](){
                    //IAPManager::getInstance()->purchase(Variable().proProductionID);
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, BuyPro::createScene(false), Color3B().WHITE));
                });
               
                break;
            default:
                break;
        }
    });
    this->addChild(buttonBuyProVer);//add button vao scene
    float timePlay2 = 0.09f;
    auto rotateLeft2 = RotateBy::create(timePlay2, -5.0f); // Rotate left by 10 degrees
    auto rotateRight2 = RotateBy::create(timePlay2, 10.0f); // Rotate right by 20 degrees (to 10 degrees right)
    auto rotateBack2 = RotateBy::create(timePlay2, -5.0f); // Rotate back to center

    // Create a sequence and repeat it forever
    auto tiltSequence2 = Sequence::create(DelayTime::create(3), rotateLeft2, rotateRight2, rotateBack2,rotateLeft2, rotateRight2, rotateBack2,rotateLeft2, rotateRight2, rotateBack2, nullptr);
    auto repeatTilt2 = RepeatForever::create(tiltSequence2);

    // Run the action on the parent button
    buttonBuyProVer->runAction(repeatTilt2);
    buttonBuyProVer->setOpacity(0);
    
    if (inVN == false) {
        
        auto buttonLeaderBoard = ui::Button::create("leaderboards.png", "leaderboards.png"); // tao button
        float ratioButtonLeaderBoard = 7;
        if (hScene / wScene <= 1.53)
        {
            ratioButtonLeaderBoard = 14;
        }
        
        float scaleButtonLeaderBoard = wScene / ratioButtonLeaderBoard / buttonLeaderBoard->getContentSize().width;
        buttonLeaderBoard->setScale(scaleButtonLeaderBoard);
//        float yButtonLeaderBoard = hScene * 0.05 + buttonLeaderBoard->getContentSize().height / 2 * scaleButtonLeaderBoard;
//        if (hScene / wScene <= 1.8)
//        {
//            yButtonLeaderBoard = hScene * 0.025 + buttonLeaderBoard->getContentSize().height / 2 * scaleButtonLeaderBoard;
//        }
        buttonLeaderBoard->setPosition(Vec2(wScene - wScene * 0.05 - buttonLeaderBoard->getContentSize().width / 2 * scaleButtonLeaderBoard, buttonLearn->getPositionY()));
        if (hScene / wScene <= 1.53)
        {
            buttonLeaderBoard->setPosition(Vec2(wScene - wScene * 0.1 - buttonLeaderBoard->getContentSize().width / 2 * scaleButtonLeaderBoard, buttonLearn->getPositionY()));
        }
        buttonLeaderBoard->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = dynamic_cast<ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    

                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    //log("Button learn touch");
                    HuyFunctions().animationClickedButton(button, [](){
                        // Hiển thị bảng xếp hạng
                        GameCenterBridge::showLeaderboard("com.huy.mentalmath");
                    });
                   
                    break;
                default:
                    break;
            }
            
            
        });
        this->addChild(buttonLeaderBoard);//add button vao scene
        float timeLeaderBoards = 0.07f;
        buttonLeaderBoard->runAction(
            RepeatForever::create(
                    Sequence::create(
                         DelayTime::create(3),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, 12.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, 12.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, 12.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, 12.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, 12.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f),
                         RotateBy::create(timeLeaderBoards, 12.0f),
                         RotateBy::create(timeLeaderBoards, -6.0f)
                         , nullptr)
            )
        );
        
        
        auto buttonachievement = ui::Button::create("achievement-button.png.png", "achievement-button.png.png"); // tao button
        
        buttonachievement->setScale(scaleButtonLeaderBoard);
//        float yButtonachievement = buttonLeaderBoard->getPositionY() + buttonachievement->getContentSize().height * 1.2 * scaleButtonLeaderBoard;
    //    if (hScene / wScene <= 1.8)
    //    {
    //        yButtonachievement = hScene * 0.38 + buttonachievement->getContentSize().height / 2 * scaleButtonLeaderBoard;
    //    }
        buttonachievement->setPosition(Vec2(buttonLeaderBoard->getPositionX(), buttonRate->getPositionY()));
    //    if (hScene / wScene <= 1.53)
    //    {
    //
    //        buttonachievement->setPosition(Vec2(buttonLeaderBoard->getPositionX(), yButtonachievement));
    //
    //    }
        buttonachievement->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            auto button = dynamic_cast<ui::Button*>(sender);
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    

                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    //log("Button 1 clicked");
                    if (soundHello == 0)
                    {
                        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                    }
                    //log("Button learn touch");
                    HuyFunctions().animationClickedButton(button, [](){
                        // Hiển thị bảng xếp hạng
                        GameCenterBridge::showAchievements();
                    });
                   
                    break;
                default:
                    break;
            }
        });
        this->addChild(buttonachievement);//add button vao scene
        
        
        buttonCricleRed = ui::Button::create("circleRed.png", "circleRed.png"); // tao button
        float ratioButtonCricleRed = 16;
        if (hScene / wScene <= 1.53)
        {
            ratioButtonCricleRed = 32;
        }
        float scaleButtonCricleRed = wScene / ratioButtonCricleRed / buttonCricleRed->getContentSize().width;
        buttonCricleRed->setScale(scaleButtonCricleRed);
        float yButtonCricleRed = buttonachievement->getPositionY() + buttonCricleRed->getContentSize().height * scaleButtonCricleRed * 1.2;
        buttonCricleRed->setPosition(Vec2(buttonachievement->getPositionX(), yButtonCricleRed));
        this->addChild(buttonCricleRed);//add button vao scene
       
        auto fontSize = 0.042 * wScene;
        if (ratioScreenHello <= 1.53) {
            fontSize = 0.021 * wScene;
        }
        auto fontStyle = "fonts/BraahOne-Regular.ttf";
        
        achievementLabel = Label::createWithTTF("0", fontStyle, fontSize);
        achievementLabel->setColor(Color3B().WHITE);
        achievementLabel->setPosition(buttonCricleRed->getPosition());
        achievementLabel->setAnchorPoint({0.5, 0.5});
        achievementLabel->setHorizontalAlignment(TextHAlignment::CENTER);
        addChild(achievementLabel);
        
        buttonCricleRed->setOpacity(0);
        achievementLabel->setOpacity(0);
        
        this->retain(); // Giữ lại đối tượng để tránh bị hủy

        GameCenterBridge::getCompletedAchievements([this](int count) {
            log("Số achievement đã hoàn thành: %d", count);

            if (this->achievementLabel && this->buttonCricleRed) {
                this->achievementLabel->setString(std::to_string(count));
                this->buttonCricleRed->setOpacity(255);
                this->achievementLabel->setOpacity(255);
            }

            this->release(); // Giải phóng đối tượng sau khi callback hoàn tất
        });
        
    //    float timeachievements = 0.08f;
    //    buttonachievement->runAction(
    //        RepeatForever::create(
    //                Sequence::create(
    //                     DelayTime::create(5),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     RotateBy::create(timeachievements, 14.0f),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     RotateBy::create(timeachievements, 14.0f),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     RotateBy::create(timeachievements, 14.0f),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     RotateBy::create(timeachievements, 14.0f),
    //                     RotateBy::create(timeachievements, -7.0f),
    //                     nullptr)
    //        )
    //    );
        
        //set position for buyProButton
        //float ybuttonBuyProVer = buttonachievement->getPositionY() + buttonBuyProVer->getContentSize().height * 1.2 * scaleButtonPro;
        //buttonBuyProVer->setPosition(Vec2(buttonLeaderBoard->getPositionX(), ybuttonBuyProVer));
        
        
    }else{
        stickerButton->setPositionY(buttonLearn->getPositionY());
        yButtonCricleRed2 = stickerButton->getPositionY() + buttonCricleRed2->getContentSize().height * scaleButtonCricleRed2 * 1.2;
        buttonCricleRed2->setPositionY(yButtonCricleRed2);
        achievementLabel2->setPosition(buttonCricleRed2->getPosition());
        ybuttonBuyProVer = stickerButton->getPositionY() + stickerButton->getContentSize().height * stickerButton->getScale() + hScene / 35;
        buttonBuyProVer->setPositionY(ybuttonBuyProVer);
    }
    //btn Gift
    auto buttonGift = ui::Button::create("icon-gift.png", "icon-gift.png"); // tao button
    if (Variable().hasHaloween) {
        buttonGift->loadTextureNormal("gift-haloween.png");
    }
    float ratioButtonGift = 7;
    if (hScene / wScene <= 1.53)
    {
        ratioButtonGift = 14;
    }
    
    float scaleButtonGift = wScene / ratioButtonGift / buttonGift->getContentSize().width;
    buttonGift->setScale(scaleButtonGift * 1.2);

    //float xButtonGift = wScene / 2 + buttonLearn->getContentSize().height / 2 * scaleButtonLearn + 30;
    buttonGift->setPosition(Vec2(buttonLearn->getPositionX(), buttonRate->getPositionY() + 20 + buttonLearn->getContentSize().width * buttonLearn->getScale()));
    if (hScene / wScene <= 1.8)
    {
        buttonGift->setPosition(Vec2(buttonLearn->getPositionX(),10 + buttonRate->getPositionY() + buttonLearn->getContentSize().width * buttonLearn->getScale()));
    }
    buttonGift->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Buy::createScene(2), Color3B().WHITE));
                });
                break;
            default:
                break;
        }
    });
    this->addChild(buttonGift);//add button vao scene
    float timePlay = 0.1f;
    auto rotateLeft = RotateBy::create(timePlay, -6.0f); // Rotate left by 10 degrees
    auto rotateRight = RotateBy::create(timePlay, 12.0f); // Rotate right by 20 degrees (to 10 degrees right)
    auto rotateBack = RotateBy::create(timePlay, -6.0f); // Rotate back to center

    // Create a sequence and repeat it forever
    auto tiltSequence = Sequence::create(DelayTime::create(2), rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack, nullptr);
    auto repeatTilt = RepeatForever::create(tiltSequence);

    // Run the action on the parent button
    buttonGift->runAction(repeatTilt);
        
    if(Variable().isProVer) {
        buttonBuyProVer->setTouchEnabled(false);
        buttonBuyProVer->setVisible(false);
    }
    
    //button play
    auto buttonPlayDual = ui::Button::create("play-home-big.png", "play-home-big.png"); // tao button
    float ratioButtonPlayDual = 3.3;
    if (hScene / wScene <= 1.53)
    {
        ratioButtonPlayDual = 6.6;
        
    }
    float scaleButtonPlayDual = wScene / ratioButtonPlayDual / buttonPlayDual->getContentSize().width;
    buttonPlayDual->setScale(scaleButtonPlayDual);
    float yButtonPlayDual = buttonPlayDual->getContentSize().height * scaleButtonPlayDual * 1.2;

    float xButtonPlayDual = wScene * 0.5;
    if (hScene / wScene <= 1.8)
    {
        yButtonPlayDual = buttonPlayDual->getContentSize().height * scaleButtonPlayDual * 0.8;
        
    }
    if (hScene / wScene <= 1.53)
    {
        
        yButtonPlayDual = buttonPlayDual->getContentSize().height * scaleButtonPlayDual;
    }

    buttonPlayDual->setPosition(Vec2(xButtonPlayDual, yButtonPlayDual));

    buttonPlayDual->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button 1 clicked");
                //HuyFunctions().animationClickedButton(button);
                if (soundHello == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                log("Button 1 touch");
                //redirect to play
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(), Color3B().WHITE));
//                    if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
//                        HuyFunctions().showAds();
//                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                
                break;
            default:
                break;
            }
        });
    addChild(buttonPlayDual);//add button vao scene
    
//    // Nén dọc (chiều Y nhỏ lại, chiều X giữ nguyên)
//    auto squash = ScaleTo::create(0.5f, 1.1f * scaleButtonPlayDual, 0.9f * scaleButtonPlayDual);
//    // Trở lại bình thường
//    auto stretch = ScaleTo::create(0.5f, 1.0f * scaleButtonPlayDual, 1.0f * scaleButtonPlayDual);
//
//    // Chạy lặp lại
//    auto sequence = Sequence::create(squash, stretch, nullptr);
//    buttonPlayDual->runAction(RepeatForever::create(sequence));
    
  
}

void HelloWorld::createMainActor(float w, float h){
    auto viTriNhanVat = UserDefault::getInstance()->getIntegerForKey("nhanvatdachon", 0) + 1;
    
    auto imageName = StringUtils::format("home-nv%d.png", viTriNhanVat);
//    if (h / w <= 1.53)
//    {
//        imageName = "bg-home-ipad2.png";
//    }
    mainActor = ui::Button::create(imageName); // tao button
    //mainActor->setTouchEnabled(false);
    float ratiomainActor = 2.5;
    if (h / w <= 1.53)
    {
        ratiomainActor = 5;
    }
    float scalemainActor = w / ratiomainActor / mainActor->getContentSize().width;
    mainActor->setScale(scalemainActor);

    float ymainActor = 0.73 * h - (mainActor->getContentSize().height / 2 * scalemainActor);
    log("ti le man hinh: %f", h / w);
    
    if (h / w <= 1.8)
    {
        ymainActor = 0.73 * h - (mainActor->getContentSize().height / 2 * scalemainActor);
    }
    mainActor->setPosition(Vec2(w - mainActor->getContentSize().width * scalemainActor * 0.18, ymainActor));
    mainActor->setEnabled(true);
    mainActorScale = scalemainActor;
    this->addChild(mainActor);
    mainActor->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto clickedButton = dynamic_cast<ui::Button*>(sender);
        
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                mainActor->runAction(
                     Sequence::create(
                        Spawn::create(ScaleTo::create(0.3, 0), FadeOut::create(0.15), nullptr),
                          nullptr)
                );
                mainActorMiror->runAction(
                     Sequence::create(
                        FadeIn::create(0),
                        DelayTime::create(1),
                              ScaleTo::create(0.05, 1.2 * mainActorScale),
                              ScaleTo::create(0.2, mainActorScale),
                              nullptr)
                );
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
            }
        });
    
    float timeAnimation = 1.5;
    auto playAnimationZoomOut5 = MoveBy::create(timeAnimation / 0.8, Vec2(0, 15));
    auto playAnimationZoomOut6 = MoveBy::create(timeAnimation  / 0.9, Vec2(0, -15));
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    mainActor->runAction((RepeatForever::create(sq3)));
    
    
    
}
void HelloWorld::createMainActorMiror(float w, float h){
    auto viTriNhanVat = UserDefault::getInstance()->getIntegerForKey("nhanvatdachon", 0) + 1;
    auto imageName = StringUtils::format("home-nv%d.png", viTriNhanVat);
    mainActorMiror = ui::Button::create(imageName); // tao button
    float ratiomainActorMiror = 2.5;
    if (h / w <= 1.53)
    {
        ratiomainActorMiror = 5;
    }
    float scalemainActorMiror = w / ratiomainActorMiror / mainActorMiror->getContentSize().width;
    mainActorMiror->setScale(scalemainActorMiror);

    float ymainActorMiror = 0.68 * h - (mainActorMiror->getContentSize().height / 2 * scalemainActorMiror);
    log("ti le man hinh: %f", h / w);
    
    if (h / w <= 1.8)
    {
        ymainActorMiror = 0.73 * h - (mainActorMiror->getContentSize().height / 2 * scalemainActorMiror);
    }
    mainActorMiror->setPosition(Vec2(w - mainActorMiror->getContentSize().width * scalemainActorMiror * 0.18, ymainActorMiror));
    mainActorMiror->setEnabled(true);
    this->addChild(mainActorMiror);
    mainActorMiror->setOpacity(0);
    mainActorMiror->setScale(0);
    
    mainActorMiror->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = dynamic_cast<ui::Button*>(sender);
        
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                mainActorMiror->runAction(
                     Sequence::create(
                        Spawn::create(ScaleTo::create(0.3, 0), FadeOut::create(0.15), nullptr),
                          nullptr)
                );
                mainActor->runAction(
                     Sequence::create(
                        FadeIn::create(0),
                        DelayTime::create(1),
                        ScaleTo::create(0.05, 1.2 * mainActorScale),
                                      ScaleTo::create(0.2, mainActorScale),
                          nullptr)
                );
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
            }
        });
    
    float timeAnimation = 1.3;
    auto playAnimationZoomOut5 = MoveBy::create(timeAnimation / 0.8, Vec2(0, 16));
    auto playAnimationZoomOut6 = MoveBy::create(timeAnimation  / 0.9, Vec2(0, -16));
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    mainActorMiror->runAction((RepeatForever::create(sq3)));
    
    
    
}
void HelloWorld::createButtonSetting(){
    auto btn = ui::Button::create("setting2.png"); // tao button
    float ratio = 10.3;
    double heightPercent = 0.96;
    if (hScene / wScene > 2.168) {
        heightPercent = 0.945;
    }
    if (hScene/ wScene <= 1.8)
    {
        heightPercent = 0.992;
    }
    if (hScene/ wScene <= 1.53)
    {
        heightPercent = 0.99;
        ratio = 15;

    }
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    float xBtn = (btnWidth * scale / 2 + 8);
    btn->setPosition(Vec2(xBtn, hScene * heightPercent - (btnWidth * scale * 2 / 3)));
    
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("Button setting");
                //redirect to play
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Setting::createScene(), Color3B().WHITE));
                    if (Variable().isProduction == true && cocos2d::RandomHelper::random_int(1, 1) == 1) {
                        HuyFunctions().showAds();
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    this->addChild(btn);//add button vao scene
}
void HelloWorld::createValueKey(){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    valueKey = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * wScene);
    valueKey->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = valueKey->getContentSize().height;
    auto btnWidthKey = valueKey->getContentSize().width;
    yValueKey = hScene - (btnHeightKey / 2 + 5);
    xValueKey = wScene - (btnWidthKey / 2 + 5);
    valueKey->setPosition(Vec2(xValueKey, yValueKey));
    // add the label as a child to this layer
    this->addChild(valueKey);
}
void HelloWorld::createButtonKey(){
    createValueKey();
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    //auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;
    float scale = wScene / ratio / btnWidth;
    float xBtn = xValueKey - 7 - valueKey->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, yValueKey));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                //restart valueKey Label
                removeChild(valueKey);
                createValueKey();

                break;
            default:
                break;
        }
    });
    this->addChild(btn);//add button vao scene
}
