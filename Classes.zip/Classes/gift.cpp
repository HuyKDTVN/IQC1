#include "gift.h"
#include "HelloWorldScene.h"
#include "ui/CocosGUI.h"
#include "Huy_functions/HuyFunctions.hpp"
#include <SimpleAudioEngine.h>
#include <iostream>
#include "GameCenterBridge.h"
USING_NS_CC;

cocos2d::ui::Button* bgColor;
cocos2d::Label* valueTongDiem;
cocos2d::ui::Button* buttonAdd200Gold3;

Scene* Gift::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = Gift::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Gift::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;

    
    
    //set bg
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    createBg(wScene, hScene);
    
    createTemplate(wScene, hScene);
    HuyFunctions().requestRewardedAd2();
    createLabel(wScene, hScene);
    
    back(wScene, hScene);
    
    soLanChayHam = 0;
    soLanChayHamAddGold = 0;
    this->schedule(CC_SCHEDULE_SELECTOR(Gift::updateEverySecondToLoadAds), 1.0f);
    return true;
}

void Gift::updateEverySecondToLoadAds(float dt) {
    if (soLanChayHamAddGold == 0) {
        int didLoadAds = UserDefault::getInstance()->getIntegerForKey("loadadsgift", 0);
        if (didLoadAds == 1) {
            showButtonAdd200();
            soLanChayHam = 10;
            soLanChayHamAddGold = 1;
        }
        log("so lan chay ham update lien tuc %d, da load ads chua: %d", soLanChayHam, didLoadAds);
    }
    if (soLanChayHam >= 10) { // Điều kiện dừng, ví dụ a == 10
        if (soLanChayHamAddGold == 0) {
            // Hủy bỏ schedule
            this->unschedule(CC_SCHEDULE_SELECTOR(Gift::updateEverySecondToLoadAds));
            log("Stopped scheduling because cannot load Ads");
        } else {
            
            int didCloseAds = UserDefault::getInstance()->getIntegerForKey("addgoldadsgift", 0);
            if (didCloseAds == 1) {
                addGold();
                
                soLanChayHamAddGold = 1000;
            }
            log("so lan chay ham update lien tuc truoc khi close Ads by User %d, da load ads chua: %d", soLanChayHamAddGold, didCloseAds);
            if (soLanChayHamAddGold == 1000) {
                this->unschedule(CC_SCHEDULE_SELECTOR(Gift::updateEverySecondToLoadAds));
                log("Stopped scheduling because User close Ads Popup (Add gold)");
            }
            
            soLanChayHamAddGold++;
        }
        
    }

    // Tăng giá trị của a hoặc thực hiện công việc khác
    soLanChayHam++;
}

void Gift::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bg = ui::Button::create("bg-blurr.jpg"); // tao button
    bg->setTouchEnabled(false);
    float ratiobg = 1;
    float scalebg = hScene / ratiobg / bg->getContentSize().height;
    if(scalebg < wScene / ratiobg / bg->getContentSize().width) {
        scalebg = wScene / ratiobg / bg->getContentSize().width;
    }
    //log("ti le test: %f", scalebg);
    //log("ti le test theo w: %f", w / ratiobg / bg->getContentSize().width);
    bg->setScale(scalebg);
    bg->setAnchorPoint(Vec2(0, 0));
    bg->setPosition(Vec2(0, 0));
    bg->setEnabled(true);
    addChild(bg, 0);
    log("hien thi Gift screen");
}
void Gift::createLabel(float w, float h) {
    float fontSize = 0.1 * w;
    float fixIpad = 1;
    auto fontStyle = "fonts/BraahOne-Regular.ttf";
    auto tongDiem = HuyFunctions().getSoVang();
    auto labelTongDiem = cocos2d::__String::createWithFormat("%i", tongDiem);
    valueTongDiem = Label::createWithTTF(labelTongDiem->getCString(), fontStyle, fontSize);
    valueTongDiem->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    auto xValueScore = w / 2;
    auto yValueScore = bgColor->getPositionY() + bgColor->getContentSize().height * bgColor->getScale() / 8;
    log("yValueScore: %f, %f", yValueScore, h);
    if (h/ w <= 1.53)
    {
        fontSize = 0.05 * w;
        fixIpad = 0.5;
    }
    valueTongDiem->setPosition(Vec2(xValueScore, yValueScore));
    valueTongDiem->setAnchorPoint({0.5, 0.5});
    addChild(valueTongDiem, 1);
    
    valueTongDiem->setOpacity(0);
    valueTongDiem->runAction(
        Sequence::create(
            DelayTime::create(1),
              Spawn::create(
                    FadeIn::create(0.2),
                    ScaleTo::create(0.2, 1.2 * fixIpad), nullptr),
              ScaleTo::create(0.05, 1 * fixIpad), nullptr)
    );
}
void Gift::createTemplate(float w, float h) {
    bgColor = ui::Button::create("cardGold.png"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1.3;
    if (h / w <= 1.53)
    {
        
        ratiobgColor = 2.6;
    }
    float scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0.5, 0.5));
    bgColor->setPosition(Vec2(w / 2, h / 2));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
    
    bgColor->setOpacity(0);
    bgColor->runAction(
        Sequence::create(
              DelayTime::create(0.5),
              Spawn::create(
                    FadeIn::create(0.2),
                    ScaleTo::create(0.2, 1.1 * scalebgColor), nullptr),
              ScaleTo::create(0.05, 1 * scalebgColor), nullptr)
    );
}
void Gift::createButtonAdd200(float w, float h) {
    buttonAdd200Gold3 = ui::Button::create("add200Green.png"); // tao button
    buttonAdd200Gold3->setTouchEnabled(true);
    auto tongDiem = HuyFunctions().getSoVang();
    
    auto labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (tongDiem + 200 ));
    buttonAdd200Gold3->setName(labelScoreAdd200->getCString());
    float ratiobuttonAdd200Gold3 = 2;
    float fixHeightIphone = h / 23;
    if (h / w <= 1.8)
    {
        //ratiobuttonAdd200Gold3 = 2;
        //fixHeightIphone = h / 40;
    }
    if (h / w <= 1.53)
    {
        ratiobuttonAdd200Gold3 = 4;
        fixHeightIphone = h / 23;
    }
    float scalebuttonAdd200Gold3 = w / ratiobuttonAdd200Gold3 / buttonAdd200Gold3->getContentSize().width;
    buttonAdd200Gold3->setScale(scalebuttonAdd200Gold3);
    buttonAdd200Gold3->setAnchorPoint({0.5, 0});
    if (buttonAdd200Gold3) {
        buttonAdd200Gold3->setPosition(Vec2(w / 2,  bgColor->getPositionY() - bgColor->getContentSize().height * bgColor->getScale() / 2 + 30));
        log("tong diem %d, vitri x: %f, y: %f, width: %f, height: %f", tongDiem, buttonAdd200Gold3->getPositionX(), buttonAdd200Gold3->getPositionY(), buttonAdd200Gold3->getContentSize().width * scalebuttonAdd200Gold3, buttonAdd200Gold3->getContentSize().height * scalebuttonAdd200Gold3);
        
        buttonAdd200Gold3->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
            switch (type)
            {
                case cocos2d::ui::Widget::TouchEventType::BEGAN:
                    HuyFunctions().showRewardedAd2();
                    buttonAdd200Gold3->setOpacity(0);
                    //buttonAdd200Gold3->setScale(0.8);
                    buttonAdd200Gold3->setEnabled(false);
                    //removeChild(buttonAdd200Gold3);
                    //valueTongDiem->setOpacity(0);
                    //removeChild(valueTongDiem);
                    
                    //addGold();
                    
                    break;
                case cocos2d::ui::Widget::TouchEventType::ENDED:
                    
                    break;
                default:
                    break;
            }
        });
        
        this->addChild(buttonAdd200Gold3, 100);//add button vao scene
        buttonAdd200Gold3->setOpacity(0);
        //buttonAdd200Gold3->runAction(Spawn::create(FadeOut::create(0), nullptr));
        float scale = buttonAdd200Gold3->getScale();
        log("do dai: %f", scale);
        buttonAdd200Gold3->runAction(
            Sequence::create(
                  Spawn::create(
                    FadeIn::create(0.3),
                    ScaleTo::create(0.3, 1.1 * scale), nullptr),
                  ScaleTo::create(0.1, 1 * scale), nullptr)
        );
        
        //buttonAdd200Gold3->runAction(Sequence::create(DelayTime::create(3), FadeIn::create(0.2), nullptr));
    }
    
    
}

void Gift::showButtonAdd200() {
    
    log("test do lon man hinh %f x %f", wScene, hScene);
    createButtonAdd200(wScene, hScene);
}
void Gift::addGold() {
     //Kiểm tra null pointerfloat fontSize = 0.1 * w;
//    float w = Director::getInstance()->getVisibleSize().width;
//    float fontSize = 0.1 * w;
//    auto fontStyle = "fonts/BraahOne-Regular.ttf";
//    auto tongDiem = HuyFunctions().getSoVang();
//    auto labelTongDiem = cocos2d::__String::createWithFormat("%i", tongDiem);
//    valueTongDiem = Label::createWithTTF(labelTongDiem->getCString(), fontStyle, fontSize);
//    addChild(valueTongDiem);
    if (valueTongDiem == nullptr) {
        //  OcreateLabel(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
        
        return;
    }
    if ( !buttonAdd200Gold3) {
        log("buttonAdd200Gold3 is null");
        return;
    }

    //log("Starting the add gold effect");
    
    float delayAnimationDesc = 0.3;
    float timeAnimation = 0.3;
    
    int soVang = UserDefault::getInstance()->getIntegerForKey("sovang", 0);
    // Gửi điểm số
    GameCenterBridge::submitScore(soVang, "com.huy.mentalmath.Golds");
    
    std::string sdString = std::to_string(soVang);
    if (auto label = dynamic_cast<cocos2d::Label*>(valueTongDiem)) {
        // valueTongDiem là một đối tượng Label
        label->setString(sdString);
    } else {
        // valueTongDiem không phải là một đối tượng Label
        log("valueTongDiem is not a Label");
    }
    
   
    if (UserDefault::getInstance()->getIntegerForKey("sound", 0) == 0) {
        valueTongDiem->runAction(Sequence::createWithTwoActions(DelayTime::create(delayAnimationDesc + timeAnimation), CallFunc::create([&]() {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        })));
    }

    valueTongDiem->runAction(Sequence::create(
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 2),
              FadeOut::create(timeAnimation / 1.2), nullptr),
          nullptr)

    );
 
    valueTongDiem->runAction(Sequence::create(
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 2),
              FadeOut::create(timeAnimation / 1.2), nullptr),
                                              
          DelayTime::create(delayAnimationDesc),
          Spawn::create(
              ScaleTo::create(timeAnimation / 1.2, 0.8),
              FadeIn::create(timeAnimation / 1.2), nullptr),
          DelayTime::create(0.1),
          ScaleTo::create(timeAnimation / 1, 1),
          nullptr)
    );
    //auto tongDiem = HuyFunctions().getSoVang();
    //auto labelScoreAdd200 = cocos2d::__String::createWithFormat("%i", (tongDiem + 200 ));
    //buttonAdd200Gold3->setName(labelScoreAdd200->getCString());
    
    //HuyFunctions().requestRewardedAd2();
}

void Gift::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
