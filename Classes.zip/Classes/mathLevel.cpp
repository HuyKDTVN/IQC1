#include "mathLevel.h"
#include "mathSelect.h"
#include "play.h"
#include "playDual.h"
#include "play2.h"
#include "play3.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>

USING_NS_CC;

int typeOfWork;

Label* valueKey2;
float yValueKey2;
float xValueKey2;
int soundMathLevel;
int myMode;

Scene* MathLevel::createScene(int mode, int type)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    typeOfWork = type;
    myMode = mode;
    // 'layer' is an autorelease object
    auto layer = MathLevel::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool MathLevel::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    float wScene;
    float hScene;


    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;

    soundMathLevel = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
    //set bg
    createBg(wScene, hScene);

    back(wScene, hScene);
    createTite(wScene, hScene);
    //createButtonKey(wScene, hScene);
    create3ButtonTop(wScene, hScene);

    //createMainTemplate(typeOfWork, wScene, hScene);

    switch (typeOfWork)
    {
        case 1:
            CCLOG("Lam phep toan: Multi");
            break;
        case 2:
            CCLOG("Lam phep toan: nhan");
            break;
        case 3:
            CCLOG("Lam phep toan: chia");
            break;
        case 4:
            CCLOG("Lam phep toan: cong");
            break;
        case 5:
            CCLOG("Lam phep toan: tru");
            break;

        default:
            CCLOG("Lam phep toan: Multi");
            break;
    }

    //this->setKeypadEnabled(true);
    
    if(myMode == 1){
        CCLOG("che do 2 nguoi choi");
    }else{
        CCLOG("che do 1 nguoi choi");
    }
    
    
    return true;
}
void MathLevel::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    auto imageName = "bg-kid-top-3.png";
    if (hScene / wScene <= 1.53)
    {
        imageName = "bg-top-ipad.png";
        
    }
    auto bgTopKid = ui::Button::create(imageName); // tao button
    float ratioButtonkidTop = 1;
    float scaleButtonKidTop = wScene / ratioButtonkidTop / bgTopKid->getContentSize().width;
    bgTopKid->setScale(scaleButtonKidTop);
    float yButtonKidTop = hScene - bgTopKid->getContentSize().height / 2 * scaleButtonKidTop;
    float xButtonKidTop = bgTopKid->getContentSize().width / 2 * scaleButtonKidTop;
    bgTopKid->setPosition(Vec2(xButtonKidTop, yButtonKidTop));
    bgTopKid->setEnabled(false);
    this->addChild(bgTopKid);//add button vao scene
    
    auto imageNameBottom = "bg-kid.png";
    if (hScene / wScene <= 1.53)
    {
        imageNameBottom = "bg-bottom-ipad.png";
        
    }
    
    auto bgKid = ui::Button::create(imageNameBottom); // tao button
    float ratioButtonkid = 1;
    float scaleButtonKid = wScene / ratioButtonkid / bgKid->getContentSize().width;
    bgKid->setScale(scaleButtonKid);
    float yButtonKid = 0 + bgKid->getContentSize().height / 2 * scaleButtonKid;
    float xButtonKid = 0 + bgKid->getContentSize().width / 2 * scaleButtonKid;
    bgKid->setPosition(Vec2(xButtonKid, yButtonKid));
    bgKid->setEnabled(false);
    this->addChild(bgKid);//add button vao scene
}
void MathLevel::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(), Color3B().WHITE));
}

void MathLevel::createTite(float w, float h){
    auto imageName = "chon-do-kho.png";
    if (h / w <= 1.53)
    {
        imageName = "chon-do-kho-ipad.png";

    }
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    float fontSize = 0.12 * w;
    auto title = ui::Button::create(imageName); // tao button
    title->setPressedActionEnabled(true);
    title->setZoomScale(-0.1f);
    title->setScale9Enabled(true);
    title->setTitleText(LanguageManager::getInstance()->getStringForKey("SELECTLEVEL").c_str());
    if(appLang == "en" || appLang == "vi"){
        title->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
   

    title->setTitleColor(Color3B(214, 48, 49));
    title->setTitleAlignment(cocos2d::TextHAlignment::LEFT);
    title->setTouchEnabled(false);
    float ratiotitle = 1;
    if (h / w <= 1.53)
    {
        ratiotitle = 1.5;
        fontSize = 0.06 * w;
    }
    float scaletitle = w / ratiotitle / title->getContentSize().width;
    title->setScale(scaletitle);
    title->setTitleFontSize(fontSize / scaletitle);
    if (appLang == "ja")
    {
        title->setTitleFontName("fonts/KosugiMaru.ttf");
        title->setTitleFontSize(0.09 * w / scaletitle);
    }
    if (h / w <= 1.53)
    {
        if (appLang == "ja")
        {
            
            title->setTitleFontSize(0.045 * w / scaletitle);
        }
    }
    
    float ytitle = 0.93 * h - (title->getContentSize().height / 2 * scaletitle);
    if (h / w <= 1.8)
    {
        ytitle = 0.96 * h - (title->getContentSize().height / 2 * scaletitle);
    }
    
    title->setPosition(Vec2(w / 2, ytitle));
    title->setEnabled(true);
    addChild(title);
    
    auto burrLeft = ui::Button::create("burr-left-tim.png"); // tao button
    burrLeft->setTouchEnabled(false);
    float ratioburrLeft = 5;
    float scaleburrLeft = w / ratioburrLeft / burrLeft->getContentSize().width;
    burrLeft->setScale(scaleburrLeft);
    
    float yburrLeft = ytitle * 1.15 - title->getContentSize().height / 2 * scaletitle - (burrLeft->getContentSize().height / 2 * scaleburrLeft);
    burrLeft->setPosition(Vec2(burrLeft->getContentSize().width / 2 * scaleburrLeft, yburrLeft));
    burrLeft->setEnabled(true);
    this->addChild(burrLeft);
    
    
    auto burrRight = ui::Button::create("burr-right-xanh.png"); // tao button
        burrRight->setTouchEnabled(false);
        float ratioburrRight = 5;
        float scaleburrRight = w / ratioburrRight / burrRight->getContentSize().width;
        burrRight->setScale(scaleburrRight);
        
        float yburrRight = ytitle - title->getContentSize().height / 2 * scaletitle - (burrRight->getContentSize().height / 2 * scaleburrRight);
        burrRight->setPosition(Vec2( w - burrRight->getContentSize().width / 2 * scaleburrRight, yburrRight));
        burrRight->setEnabled(true);
        this->addChild(burrRight);
    
    
    auto dot1 = ui::Button::create("cricle-xanh.png"); // tao button
        dot1->setTouchEnabled(false);
        float ratiodot1 = 38;
        if (h / w <= 1.53)
        {
            ratiodot1 = 76;
            
        }
        float scaledot1 = w / ratiodot1 / dot1->getContentSize().width;
        dot1->setScale(scaledot1);
        
    float ydot1 = yburrRight * 1.1;
        dot1->setPosition(Vec2(w /5, ydot1));
        dot1->setEnabled(true);
        this->addChild(dot1);


        auto dot2 = ui::Button::create("cricle-do.png"); // tao button
        dot2->setTouchEnabled(false);
        float ratiodot2 = 33;
        if (h / w <= 1.53)
        {
            ratiodot2 = 66;
            
        }

        float scaledot2 = w / ratiodot2 / dot2->getContentSize().width;
        dot2->setScale(scaledot2);
        
        float ydot2 = yburrRight * 1;
        dot2->setPosition(Vec2(w / 1.85, ydot2));
        dot2->setEnabled(true);
        this->addChild(dot2);


        auto dot3 = ui::Button::create("cricle-tim.png"); // tao button
        dot3->setTouchEnabled(false);
        float ratiodot3 = 28;
        if (h / w <= 1.53)
        {
            ratiodot3 = 56;
            
        }
        float scaledot3 = w / ratiodot3 / dot3->getContentSize().width;
        dot3->setScale(scaledot3);
        
        float ydot3 = yburrRight * 1.2;
        dot3->setPosition(Vec2(w / 1.2 * scaledot3, ydot3));
        dot3->setEnabled(true);
        this->addChild(dot3);

    if (h / w <= 1.53)
    {
        auto dot4 = ui::Button::create("cricle-hong.png"); // tao button
        dot4->setTouchEnabled(false);
        float ratiodot4 = 52;
      
        float scaledot4 = w / ratiodot4 / dot4->getContentSize().width;
        dot4->setScale(scaledot4);
        
        float ydot4 = yburrRight * 0.35;
        dot4->setPosition(Vec2(w / 5.7, ydot4));
        dot4->setEnabled(true);
        this->addChild(dot4);
        
        auto dot5 = ui::Button::create("cricle-blue.png"); // tao button
        dot5->setTouchEnabled(false);
        float ratiodot5 = 70;
        
        float scaledot5 = w / ratiodot5 / dot5->getContentSize().width;
        dot5->setScale(scaledot5);
        
        float ydot5 = yburrRight * 0.5;
        dot5->setPosition(Vec2(w / 1.2, ydot5));
        dot5->setEnabled(true);
        this->addChild(dot5);
        
    }
}
void MathLevel::createMainTemplate(int level, float w, float h){
    //tmp
    auto buttonLearn = ui::Button::create("tmp-play.png"); // tao button
    float ratioButtonLearn = 3;
    
    float scaleButtonLearn = w / ratioButtonLearn / buttonLearn->getContentSize().width;
    buttonLearn->setScale(scaleButtonLearn);
    float yButtonLearn = 300 + buttonLearn->getContentSize().height / 2 * scaleButtonLearn;
    buttonLearn->setPosition(Vec2(w / 2, yButtonLearn));
    buttonLearn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button learn touch");
                //Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(), Color3B().WHITE));

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonLearn);//add button vao scene
}
void MathLevel::create3ButtonTop(float w, float h){
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    float fontSize = 0.06 * w;
    auto buttonEasy = ui::Button::create("box-big.png", "box-big.png"); // tao button
//  buttonEasy->setPressedActionEnabled(true);
//  buttonEasy->setZoomScale(-0.1f);
//  buttonEasy->setScale9Enabled(true);
    buttonEasy->setTitleText(LanguageManager::getInstance()->getStringForKey("LEVEL3").c_str());
    if(appLang == "en" || appLang == "vi"){
        buttonEasy->setTitleFontName("fonts/comfortaa.ttf");
    }

    buttonEasy->setTitleColor(Color3B(144, 184, 31));

    float ratioButtonEasy = 1.2;
    if (h / w <= 1.53)
    {
        ratioButtonEasy = 2.4;
        fontSize = 0.03 * w;
        
    }
    float scaleButtonEasy = w / ratioButtonEasy / buttonEasy->getContentSize().width;
    buttonEasy->setScale(scaleButtonEasy);
    buttonEasy->setTitleFontSize(fontSize / scaleButtonEasy);
    if (appLang == "ja")
    {
        buttonEasy->setTitleFontName("fonts/KosugiMaru.ttf");
        buttonEasy->setTitleFontSize(0.06 * w / scaleButtonEasy);
    }
    if (h / w <= 1.53)
    {
        if (appLang == "ja")
        {
            
            buttonEasy->setTitleFontSize(0.036 * w / scaleButtonEasy);
        }
        
    }
    float yButtonEasy = 50 + buttonEasy->getContentSize().height / 2 * scaleButtonEasy;

    buttonEasy->setPosition(Vec2(w / 2, yButtonEasy));
    buttonEasy->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathLevel == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                //CCLOG("Button Easy touch");
                if(myMode == 1){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(typeOfWork, 3), Color3B().WHITE));
                }
                else if(myMode == 2){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(typeOfWork, 3, 0), Color3B().WHITE));
                }
                else if(myMode == 3){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(typeOfWork, 3, 0), Color3B().WHITE));
                }
                else{
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(typeOfWork, 3, 0), Color3B().WHITE));
                }

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonEasy);//add button vao scene

    //button Normal
    auto buttonNormal = ui::Button::create("box-m.png", "box-m.png"); // tao button
    float ratioButtonNormal = 2.1;
    if (h / w <= 1.53)
    {
        ratioButtonNormal = 4.2;
        
        
    }
    float scaleButtonNormal = w / ratioButtonNormal / buttonNormal->getContentSize().width;
    buttonNormal->setScale(scaleButtonNormal);
    float xButtonNormal = w * 0.1 + buttonNormal->getContentSize().width / 2 * scaleButtonNormal;
    float yButtonNormal = 0.1 * w + yButtonEasy + buttonNormal->getContentSize().height * scaleButtonNormal;
    if (h / w <= 1.53)
    {
        xButtonNormal = w * 0.3 + buttonNormal->getContentSize().width / 2 * scaleButtonNormal;
        yButtonNormal = 0.05 * w + yButtonEasy + buttonNormal->getContentSize().height * scaleButtonNormal;
    }
//  buttonNormal->setPressedActionEnabled(true);
//  buttonNormal->setZoomScale(-0.1f);
//  buttonNormal->setScale9Enabled(true);
    buttonNormal->setTitleText(LanguageManager::getInstance()->getStringForKey("LEVEL1").c_str());
    if(appLang == "en" || appLang == "vi"){
        buttonNormal->setTitleFontName("fonts/comfortaa.ttf");
    }
    buttonNormal->setTitleFontSize(fontSize / scaleButtonEasy);
    if (appLang == "ja")
    {
        buttonNormal->setTitleFontName("fonts/KosugiMaru.ttf");
        buttonNormal->setTitleFontSize(0.06 * w / scaleButtonEasy);
    }
    if (h / w <= 1.53)
    {
        if (appLang == "ja")
        {
            
            buttonNormal->setTitleFontSize(0.036 * w / scaleButtonEasy);
        }
        
    }
    buttonNormal->setTitleColor(Color3B(44, 166, 156));

    buttonNormal->setPosition(Vec2(xButtonNormal, yButtonNormal));

    buttonNormal->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){
        
        // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathLevel == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                CCLOG("Button 1 touch");
                //redirect to play
                if(myMode == 1){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(typeOfWork, 1), Color3B().WHITE));
                }
                else if(myMode == 2){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(typeOfWork, 1, 0), Color3B().WHITE));
                }else if(myMode == 3){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(typeOfWork, 1, 0), Color3B().WHITE));
                }
                else{
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(typeOfWork, 1, 0), Color3B().WHITE));
                }
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonNormal);//add button vao scene

    //button Hard
    auto buttonHard = ui::Button::create("box-s.png", "box-s.png"); // tao button
    float ratioButtonHard = 3.6;
    if (h / w <= 1.53)
    {
        ratioButtonHard = 7.2;
    }
    float scaleButtonHard = w / ratioButtonHard / buttonHard->getContentSize().width;
    buttonHard->setScale(scaleButtonHard);
    float xButtonHard = 0.9 * w - buttonHard->getContentSize().width / 2 * scaleButtonHard;
        if (h / w <= 1.53)
        {
            xButtonHard = 0.7 * w - buttonHard->getContentSize().width / 2 * scaleButtonHard;

        }
    buttonHard->setPosition(Vec2(xButtonHard, yButtonNormal));

//  buttonHard->setPressedActionEnabled(true);
//  buttonHard->setZoomScale(-0.1f);
//  buttonHard->setScale9Enabled(true);
    buttonHard->setTitleText(LanguageManager::getInstance()->getStringForKey("LEVEL2").c_str());
    if(appLang == "en" || appLang == "vi"){
        buttonHard->setTitleFontName("fonts/comfortaa.ttf");
    }
    
    buttonHard->setTitleFontSize(fontSize / scaleButtonEasy);
    if (appLang == "ja")
    {
        buttonHard->setTitleFontName("fonts/KosugiMaru.ttf");
        buttonHard->setTitleFontSize(0.06 * w / scaleButtonEasy);
    }
    if (h / w <= 1.53)
    {
        if (appLang == "ja")
        {
            buttonHard->setTitleFontSize(0.036 * w / scaleButtonEasy);
        }
        
    }
    buttonHard->setTitleColor(Color3B(195, 181, 50));

    buttonHard->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ //
        
        
        
        //xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (soundMathLevel == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                if(myMode == 1){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, PlayDual::createScene(typeOfWork, 2), Color3B().WHITE));
                }
                else if(myMode == 2){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play2::createScene(typeOfWork, 2, 0), Color3B().WHITE));
                }
                else if(myMode == 2){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play3::createScene(typeOfWork, 2, 0), Color3B().WHITE));
                }
                else{
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(typeOfWork, 2, 0), Color3B().WHITE));
                }
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonHard);//add button vao scene
    
    
    //animation show buttonPlay
    float time = 0.2;
    buttonNormal->runAction(Spawn::create(FadeOut::create(0), nullptr));
    buttonNormal->runAction(Sequence::create(DelayTime::create(0.3), FadeIn::create(time), nullptr));
    
    buttonHard->runAction(Spawn::create(FadeOut::create(0), nullptr));
    buttonHard->runAction(Sequence::create(DelayTime::create(0.6), FadeIn::create(time), nullptr));
    
    buttonEasy->runAction(Spawn::create(FadeOut::create(0), nullptr));
    buttonEasy->runAction(Sequence::create(DelayTime::create(1), FadeIn::create(time), nullptr));
}
void MathLevel::back(float w, float h){
    auto btn = ui::Button::create("back.png"); // tao button
    float ratio = 6;
    if (h / w <= 1.53)
    {
        ratio = 12;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 10), h - (btnHeight / 2 * scale + 10)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(myMode, 0), Color3B().WHITE));
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}

void MathLevel::createValueKey(float w, float h){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    valueKey2 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * w);
    valueKey2->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = valueKey2->getContentSize().height;
    auto btnWidthKey = valueKey2->getContentSize().width;
    yValueKey2 = h - (btnHeightKey / 2 + 5);
    xValueKey2 = w - (btnWidthKey / 2 + 5);
    valueKey2->setPosition(Vec2(xValueKey2, yValueKey2));
    // add the label as a child to this layer
    addChild(valueKey2);
}
void MathLevel::createButtonKey(float w, float h){
    createValueKey(w, h);
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    auto btnWidth = btn->getContentSize().width;
    float scale = w / ratio / btnWidth;
    float xBtn = xValueKey2 - 7 - valueKey2->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, yValueKey2));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                //restart valueKey Label
                removeChild(valueKey2);
                createValueKey(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
