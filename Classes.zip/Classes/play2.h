#ifndef __PLAY2_H__
#define __PLAY2_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"


class Play2 : public cocos2d::Layer
{
public:

    float phepTinhSoSanh1 = false;
    
    const char *HIGH_SCORE2 = "height-score2";
    int realType2;
    int answer1_2;
    int answer2_2;
    int answer3_2;
    int answer4_2;

    double wScenePlay2;
    double hScenePlay2;

    int correctAnswer2;
    int score2;
    
    int indexThemDiem;
    
    int maxDoiSo2;

    bool flagB1ChuSo;
    cocos2d::__String *phepToan2;
    int soA;
    int soB;
    std::string phepTinhSmallA;
    std::string phepTinhSmallB;
    cocos2d::__String *loaiPhepTinh;
    
    cocos2d::Vector<cocos2d::ui::Button*> listBgNumber;
    cocos2d::Vector<cocos2d::Sprite*> listIcon;
    cocos2d::Vector<cocos2d::Sprite*> listIconTru;
    
    cocos2d::ui::Button* buttonOK;
    
    cocos2d::__String *score2String2;
    float xDichPhiThuyen2;
    float yTenLua2;
    bool sapXepPhepTinhTheoChieuDoc;
    bool hasGuide;
    
    cocos2d::Label* lblPhepToan2;
    cocos2d::DrawNode* gachChan;
    cocos2d::Label* lblB;
    cocos2d::Label* lblBHangChuc;
    cocos2d::Label* lblLoaiPhepTinh;
    cocos2d::Label* lblA;
    cocos2d::Label* lblAKetQua;
    cocos2d::Label* lblBKetQua;
    cocos2d::Label* lblPhepSoSanh1;
    cocos2d::Label* lblAHangChuc;
    cocos2d::Label* lblDapAnHangChuc;
    cocos2d::Label* lblDapAnHangDV;
    cocos2d::Label* lblDapAnPhanNhoDV;
    cocos2d::Label* lblDapAnPhanNhoHangChuc;
    
    cocos2d::Label* lblScore2;
    cocos2d::ui::Button* score2Icon2;
    cocos2d::Sprite* phithuyenHienThi2;
    

    cocos2d::Sprite* buttonAnswer1_2;
    cocos2d::ui::Button* buttonAnswer1Number_2;
    cocos2d::Sprite* bomAnswer1_2;

    cocos2d::Sprite* buttonAnswer2_2;
    cocos2d::ui::Button* buttonAnswer2Number_2;
    cocos2d::Sprite* bomAnswer2_2;

    cocos2d::Sprite* buttonAnswer3_2;
    cocos2d::ui::Button* buttonAnswer3Number_2;
    cocos2d::Sprite* bomAnswer3_2;

    cocos2d::Sprite* buttonAnswer4_2;
    cocos2d::ui::Button* buttonAnswer4Number_2;
    cocos2d::Sprite* bomAnswer4_2;

    cocos2d::ui::Button* buttonPause2;

    float scaleButtonAnswer1_2;
    float scaleButtonAnswerNumber1_2;
    float scaleButtonAnswer2_2;
    float scaleButtonAnswerNumber2_2;
    float scaleButtonAnswer3_2;
    float scaleButtonAnswerNumber3_2;
    float scaleButtonAnswer4_2;
    float scaleButtonAnswerNumber4_2;

    float timeRemaining2;
    float timeMax2;
    bool isPause2 = false;

    cocos2d::ui::LoadingBar* loadingBar1_2;
    cocos2d::ui::LoadingBar* loadingBarWrap1_2;
    cocos2d::ui::LoadingBar* loadingBar2_2;
    cocos2d::ui::LoadingBar* loadingBarWrap2_2;
    cocos2d::ui::LoadingBar* loadingBar3_2;
    cocos2d::ui::LoadingBar* loadingBarWrap3_2;
    cocos2d::ui::LoadingBar* loadingBar4_2;
    cocos2d::ui::LoadingBar* loadingBarWrap4_2;

    float hLoadingBar_2;
    float ratioLoadingBar_2;

    cocos2d::Label* valueKey3_2;
    float yValueKey3_2;
    float xValueKey3_2;

    cocos2d::Label* buttonAnswer1NumberLabel_2;
    cocos2d::Label* buttonAnswer2NumberLabel_2;
    cocos2d::Label* buttonAnswer3NumberLabel_2;
    cocos2d::Label* buttonAnswer4NumberLabel_2;

    cocos2d::ui::Button* popupthanhCong;
    cocos2d::ui::Button* popupthatBai;
    
    int sound2;
    int prevA2 = 2;
    int prevB2 = 2;
    cocos2d::ui::Button* earth_2;
    cocos2d::ui::Button* anhSangPhiThuyen_2;
    
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int type, int level, int backTypePhepTinh, bool fromChallenge = false);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void update(float dt);
    void coundownTimer(float w, float h);
    void back(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void createButtonKey(float w, float h);
    void createValueKey(float w, float h);
    void createScore(float w, float h);
    void createMainTemplate(float w, float h);
    void createPopupFinish(float w, float h);
    void showMedal(float w, float h, std::string medal);
    void createBg();
    void createBgColor(float w, float h);
    void createTraiDatAndPhiThuyenTenLua(float w, float h);
    void createAnswer(float w, float h);
    void animationShowAnswer(cocos2d::ui::Button* button, float time, float scale);
    void handlerClickAnswer(int v);

    void moveSceneGameOver();
    void nextPlay();
    
    void hideAnswer1(float myDelay, float myTime);
    void hideAnswer2(float myDelay, float myTime);
    void hideAnswer3(float myDelay, float myTime);
    void hideAnswer4(float myDelay, float myTime);

    
    void createTemplateGuideLevel1(float w, float h);
    void createTemplateGuideLevel1Cong(float w, float h);
    void createTemplateGuideLevel1Tru(float w, float h);
    void createTemplateGuideLevel1Nhan(float w, float h);
    void createTemplateGuideLevel1Chia(float w, float h);
    
    void createTemplateGuideLevel2(float w, float h);
    void createTemplateGuideLevel2Cong(float w, float h);
    void createTemplateGuideLevel2SoSanh(float w, float h);
    void createTemplateGuideLevel2Tru(float w, float h);
    void createTemplateGuideLevel2Nhan(float w, float h);
    void createTemplateGuideLevel2Chia(float w, float h);
    
    void createTemplateGuideLevel3(float w, float h);
    void createTemplateGuideLevel3Cong(float w, float h);
    void createTemplateGuideLevel3Tru(float w, float h);
    void createTemplateGuideLevel3Nhan(float w, float h);
    void createTemplateGuideLevel3Chia(float w, float h);


    void createBgPro(float w, float h);
    void finish();
    virtual void onEnter() override;
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(Play2);
    
    

};

#endif // __PLAY2_H__
