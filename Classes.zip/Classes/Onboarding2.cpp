//
//  Onboarding2.cpp
//  mentalmath
//
//  Created by Huy Le on 21/2/26.
//

#include "Onboarding2.hpp"
#include "AllowNoti.hpp"
#include "Onboarding1.hpp"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "GameCenterBridge.h"
#include "Huy_functions/HuyFunctions.hpp"

USING_NS_CC;

Scene* Onboarding2::createScene()

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = Onboarding2::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool Onboarding2::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;

    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    back(wScene, hScene);
    createTemplate(wScene, hScene);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(6);
    }
    //this->setKeypadEnabled(true);
    return true;
}
void Onboarding2::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg01.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void Onboarding2::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void Onboarding2::createTemplate(float w, float h){
    
    auto fontStyle = "Helvetica-Bold";
//    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
//    {
//        fontStyle = "fonts/KosugiMaru.ttf";
//    }
    auto fontTitle = 0.06 * w;
    auto fixIpad = 1;
    Size sizeOfEditBox = Size(200,50);
    auto topTitle = h * 0.9;
    if (h / w <= 1.8){
        topTitle = h * 0.89;
    }
    if (h / w <= 1.53)
    {
        topTitle = h * 0.94;
        fontTitle = 0.03 * w;
        sizeOfEditBox = Size(100,25);
        fixIpad = 0.5;
        
    }
    
    labelTitleNguoiChoi = Label::createWithSystemFont(LanguageManager::getInstance()->getStringForKey("DUATAICUNGTHEGIOI").c_str(), fontStyle, fontTitle);
    labelTitleNguoiChoi->setWidth(wScene - 20);
    labelTitleNguoiChoi->setHorizontalAlignment(TextHAlignment::CENTER);
    labelTitleNguoiChoi->setTextColor(Color4B::YELLOW);
    labelTitleNguoiChoi->setPosition(Vec2(w/2, topTitle));
    this->addChild(labelTitleNguoiChoi, 13);
    
    auto descTitleNguoiChoi = Label::createWithSystemFont(LanguageManager::getInstance()->getStringForKey("LUUDIEMCUNGGAMECENTER").c_str(), "Helvetica", fontTitle * 0.75);
    descTitleNguoiChoi->setWidth(wScene - 20);
    descTitleNguoiChoi->setHorizontalAlignment(TextHAlignment::CENTER);
    descTitleNguoiChoi->setTextColor(Color4B::WHITE);
    descTitleNguoiChoi->setPosition(Vec2(w/2, labelTitleNguoiChoi->getPositionY() - labelTitleNguoiChoi->getContentSize().height - 2));
    this->addChild(descTitleNguoiChoi, 13);
    
    auto chart = Sprite::create("chart0.png");
    
    float ratiochart = 3;
    if (ratioScreen <= 1.8)
    {
        ratiochart = 3.8;
    }
    if (ratioScreen <= 1.53)
    {
        ratiochart = 4;
    }
    float scalechart = wScene / ratiochart / chart->getContentSize().width;
    chart->setScale(scalechart);
    chart->setPosition(Vec2(wScene / 2, descTitleNguoiChoi->getPositionY() - descTitleNguoiChoi->getContentSize().height - chart->getContentSize().height * scalechart / 2 - 2)); // Đặt vị trí
    this->addChild(chart, 13);
    
    auto demoGame = Sprite::create("demo-game.png");
    
    float ratiodemoGame = 2.2;
    if (ratioScreen <= 1.8)
    {
        ratiodemoGame = 2.9;
    }
    if (ratioScreen <= 1.53)
    {
        ratiodemoGame = 3;
    }
    float scaledemoGame = wScene / ratiodemoGame / demoGame->getContentSize().width;
    demoGame->setScale(scaledemoGame);
    demoGame->setPosition(Vec2(wScene / 2, chart->getPositionY() - chart->getContentSize().height * scalechart / 2 - demoGame->getContentSize().height * scaledemoGame / 2)); // Đặt vị trí
    this->addChild(demoGame, 13);
    
    //create claim button
    okButton = ui::Button::create("button-claim.png", "button-claim.png"); // tao button
    float ratioButtonClaim = 4.5;
    if (h / w <= 1.53)
    {
        ratioButtonClaim = 9;
    }
    //auto okButtonHeight = okButton->getContentSize().height;
    auto okButtonWidth = okButton->getContentSize().width;

    float scaleokButton = w / ratioButtonClaim / okButtonWidth;
    okButton->setScale(scaleokButton);
    okButton->setPosition(Vec2(w/2, demoGame->getPositionY() - demoGame->getContentSize().height * scaledemoGame / 2 - okButton->getContentSize().height * scaleokButton / 2 - h / 30));
    okButton->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                // Đăng nhập Game Center
                GameCenterBridge::authenticatePlayer();
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, AllowNoti::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(okButton, 12);//add button vao scene
    
    float timeAnimation = 0.4;
    auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * okButton->getScale());
    auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.2, okButton->getScale() * 0.95);
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    okButton->runAction((RepeatForever::create(sq3)));
}
void Onboarding2::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Onboarding1::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
