#ifndef __LEARNING_H__
#define __LEARNING_H__

#include "cocos2d.h"

class Learning : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(bool flag, int i);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
	void createTite(float w, float h);
    void createBg();
	void createButtonSelectLevel(float w, float h);
	void createMainTemplate(float w, float h);
	void handleClickButtonSelectLevel(int level);
	void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);

    // implement the "static create()" method manually
	CREATE_FUNC(Learning);
};

#endif // __LEARNING_H__
