//
//  giftDiamond.hpp
//  mentalmath
//
//  Created by Huy Le on 30/12/24.
//

#ifndef __GIFTDIAMOND_H__
#define __GIFTDIAMOND_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class GiftDiamond : public cocos2d::Layer
{
public:
    
    float wScene;
    float hScene;
    int soLanChayHam;
    int soLanChayHamAddGold;
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();
    
    
    
    
    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    void back(float w, float h);
    void createBg(float w, float h);
    void createTemplate(float w, float h);
    void createLabel(float w, float h);
    void createButtonAdd200(float w, float h);
    void showButtonAdd200();
    void updateEverySecondToLoadAds(float dt);
    void addGold();

    
    // implement the "static create()" method manually
    CREATE_FUNC(GiftDiamond);
};
#endif // __GIFTDIAMOND_H__
