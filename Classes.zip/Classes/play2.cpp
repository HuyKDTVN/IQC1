#include "play2.h"
#include "mathSelect.h"
#include "finish.h"
#include "SelectGame.hpp"
#include "ui/CocosGUI.h"
#include <SimpleAudioEngine.h>
#include <iostream>
#include <string>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "Huy_functions/CreatePhepToan.hpp"
#include "LanguageManager.h"
#include "IAPManager.h"

using namespace std;
USING_NS_CC;

int typeOfW2;
int levelOfW2;
int isMulti2 = false;
int backTypePT2 = 0;
bool fromChallenge2;
Scene* Play2::createScene(int type, int level, int backTypePhepTinh, bool fromChallenge)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    typeOfW2 = type;
    if(typeOfW2 == 1){
        isMulti2 = true;
    }
    levelOfW2 = level;
    // 'layer' is an autorelease object
    backTypePT2 = backTypePhepTinh;
    fromChallenge2 = fromChallenge;
    auto layer = Play2::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
// on "init" you need to initialize your instance
bool Play2::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }
    score2 = 0;
    if (UserDefault::getInstance()->getIntegerForKey("height-score2", 99999) == 99999)
    {
        UserDefault::getInstance()->setIntegerForKey(HIGH_SCORE2, 0);
        UserDefault::getInstance()->flush();
    }
    auto mLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    maxDoiSo2 = HuyFunctions().SoLonNhat(mLang);
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float wScene;
    float hScene;

    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    wScenePlay2 = wScene;
    hScenePlay2 = hScene;

    hasGuide = false;
    
    //set bg
    //createBg(wScene, hScene);
    
    //countdown timer + loading bar
    coundownTimer(wScene, hScene);
    //end: countdown timer + loading bar

    realType2 = typeOfW2;

    back(wScene, hScene);
    //createButtonKey(wScene, hScene);
    auto arr = CreatePhepToan().createAnswerQuestions(typeOfW2, levelOfW2, prevA2, prevB2, maxDoiSo2);
    
    auto arrNoti = CreatePhepToan().createAnswerQuestions(typeOfW2, levelOfW2, prevA2, prevB2, maxDoiSo2);
    UserDefault::getInstance()->setStringForKey("noti-title1", HuyFunctions().createPhepToanWithEmoji(arrNoti.at(2).c_str()));
    log("test improve function");
    //    0 - prevA
    //    1 - prevB
    //    2 - phepToan
    //    3 - correctAnswer
    //    4 - answer1
    //    5 - answer2
    //    6 - answer3
    //    7 - answer4
    prevA2 = std::stoi(arr.at(0));
    prevB2 = std::stoi(arr.at(1));
    phepTinhSmallA = arr.at(9);
    phepTinhSmallB = arr.at(10);
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", arr.at(8).c_str());
    sapXepPhepTinhTheoChieuDoc = CreatePhepToan().needPhepTinhTheoChieuDoc(loaiPhepTinh->getCString(), levelOfW2);
    soA = std::stoi(arr.at(0));
    soB = std::stoi(arr.at(1));
    if (sapXepPhepTinhTheoChieuDoc) {
        phepToan2 = cocos2d::__String::createWithFormat("?");//cocos2d::__String::createWithFormat("%s", arr.at(8).c_str())
        
        
        flagB1ChuSo = false;
        if (arr.at(1).size() < 2) {
            flagB1ChuSo = true;
        }
    } else {
        phepToan2 = cocos2d::__String::createWithFormat("%s", arr.at(2).c_str());
    }
    
    
    correctAnswer2 = std::stoi(arr.at(3));
    answer1_2 = std::stoi(arr.at(4));
    answer2_2 = std::stoi(arr.at(5));
    answer3_2 = std::stoi(arr.at(6));
    answer4_2 = std::stoi(arr.at(7));
    
    log("cau hoi: %s",  arr.at(2).c_str());
    log("4 dap an: %i, %i, %i, %i",  std::stoi(arr.at(4)), std::stoi(arr.at(5)), std::stoi(arr.at(6)), std::stoi(arr.at(7)));
    log("dap dung: %i",  std::stoi(arr.at(3)));
    
    indexThemDiem = HuyFunctions().getRandomForThemDiem();

    createScore(wScene, hScene);
    createMainTemplate(wScene, hScene);
    createAnswer(wScene, hScene);
    createPopupFinish(wScene, hScene);
    
    //log("HUY ----- type: %i, level: %i", typeOfW2, levelOfW2);
    
    createBgColor(wScene, hScene);
    createTraiDatAndPhiThuyenTenLua(wScene, hScene);

    //log("hLoadingBar: %f", hLoadingBar);
    if (Variable().isProduction == true) {
        HuyFunctions().requestAds(2);
    }
    //this->setKeypadEnabled(true);
    
    if (levelOfW2 == 1) {
        createTemplateGuideLevel1(wScene, hScene);
    } else {
        createTemplateGuideLevel2(wScene, hScene);
    }
    
    return true;
}
void Play2::createTemplateGuideLevel1(float w, float h) {
    if ( typeOfW2 == 4 or typeOfW2 == 5 or typeOfW2 == 6) {
        hasGuide = true;
    }
}

void Play2::createTemplateGuideLevel2(float w, float h) {
    if ( typeOfW2 == 4 or typeOfW2 == 5 or typeOfW2 == 6) {
        hasGuide = true;
    }
    
}

void Play2::createTemplateGuideLevel2Cong(float w, float h) {
    int congDonVi = HuyFunctions().getSoHangDonVi(soA) + HuyFunctions().getSoHangDonVi(soB);
    
    lblPhepToan2->runAction(FadeOut::create(0.1));
    auto fontStyle = "fonts/DeliusSwashCaps.ttf";
    float fontSize = 0.18 * w;
    if (h / w > 1.53 && h / w <= 1.8){
        fontSize = 0.15 * w;
    }
    if (h / w <= 1.53)
    {
        fontSize = 0.09 * w;
    }

    float time = 0.2;
    float width = 50.0f;
    float fixWithIpad = 1.0f;
    if (h / w <= 1.53)
    {
        fixWithIpad = 0.5f;
    }
    if (levelOfW2 > 1) {
        width = 70.0f;
    }
    float height = 3.0f * fixWithIpad;
    width = width * fixWithIpad;
    cocos2d::Vec2 origin(w / 2 - width / 2 - 16 * fixWithIpad, lblPhepToan2->getPositionY() + lblPhepToan2->getContentSize().height / 2);
    gachChan = HuyFunctions().createChuNhatBoGoc(width, height, origin);
    this->addChild(gachChan, 2);
    
    lblB = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soB))->getCString(), fontStyle, fontSize);
    float xLblB = w / 2;
    lblB->setPosition(Vec2(xLblB, lblPhepToan2->getPositionY() + lblPhepToan2->getContentSize().height * 1.1));
    addChild(lblB, 2);
    lblB->setAlignment(TextHAlignment:: CENTER);
    lblB->setOpacity(0);
    lblB->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    if (soB > 9) {
        lblBHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soB))->getCString(), fontStyle, fontSize);
        
        lblBHangChuc->setPosition(Vec2(lblB->getPositionX() - lblB->getContentSize().height * 0.51, lblB->getPositionY()));
        addChild(lblBHangChuc, 2);
        lblBHangChuc->setAlignment(TextHAlignment:: CENTER);
        lblBHangChuc->setOpacity(0);
        lblBHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    }
    
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", "+");
    
    lblLoaiPhepTinh = Label::createWithTTF(loaiPhepTinh->getCString(), fontStyle, fontSize);
    lblLoaiPhepTinh->setPosition(Vec2(w/2 - lblB->getContentSize().height * 0.82, lblB->getPositionY() + lblB->getContentSize().height / 2));
    addChild(lblLoaiPhepTinh, 2);
    lblLoaiPhepTinh->setOpacity(0);
    lblLoaiPhepTinh->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblA = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA))->getCString(), fontStyle, fontSize);
    lblA->setPosition(Vec2(w / 2, lblLoaiPhepTinh->getPositionY() + lblLoaiPhepTinh->getContentSize().height / 2));
    addChild(lblA, 2);
    lblA->setAlignment(TextHAlignment:: CENTER);
    lblA->setOpacity(0);
    lblA->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblAHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA))->getCString(), fontStyle, fontSize);
    lblAHangChuc->setPosition(Vec2(lblA->getPositionX() - lblA->getContentSize().height * 0.51, lblA->getPositionY()));
    addChild(lblAHangChuc, 2);
    lblAHangChuc->setOpacity(0);
    lblAHangChuc->setAlignment(TextHAlignment:: CENTER);
    lblAHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA + soB))->getCString(), fontStyle, fontSize);
    lblDapAnHangDV->setPosition(Vec2(w / 2, lblB->getPositionY() - lblB->getContentSize().height * 1.1));
    addChild(lblDapAnHangDV, 2);
    lblDapAnHangDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnHangDV->setOpacity(0);
    //lblDapAnHangDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA + soB))->getCString(), fontStyle, fontSize);
    if (congDonVi > 9) {
        lblDapAnHangChuc->setString(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA + soB) - 1)->getCString());
    }
    lblDapAnHangChuc->setPosition(Vec2(lblAHangChuc->getPositionX(), lblDapAnHangDV->getPositionY()));
    addChild(lblDapAnHangChuc, 2);
    lblDapAnHangChuc->setOpacity(0);
    lblDapAnHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnPhanNhoDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(congDonVi))->getCString(), fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoDV->setPosition(Vec2(w * 0.8, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoDV, 2);
    lblDapAnPhanNhoDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnPhanNhoDV->setOpacity(0);
    //lblDapAnPhanNhoDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnPhanNhoHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(congDonVi))->getCString(), fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoHangChuc->setPosition(Vec2(lblDapAnPhanNhoDV->getPositionX() - lblDapAnPhanNhoDV->getContentSize().height * 0.51, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoHangChuc, 2);
    lblDapAnPhanNhoHangChuc->setOpacity(0);
    lblDapAnPhanNhoHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnPhanNhoHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    
    if (flagB1ChuSo) {
        xLblB = w / 2 + (lblA->getContentSize().width - lblB->getContentSize().width) / 2;
        lblB->setPosition(Vec2(xLblB, lblB->getPositionY()));
    }
    //animation cho hang don vi - phong to
    float timeAnimate = 0.2;
    float delayTime = 2;
    float fixTimeCoNho = 0;
    if (congDonVi > 9) {
        fixTimeCoNho = 2;
    }
    
    auto playSound = CallFunc::create([this]() {
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
    });
    auto congCaPhanNho = CallFunc::create([this]() {
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
        lblDapAnHangChuc->setString(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA + soB))->getCString());
    });
    
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    
    log("cong don vi: %i", congDonVi);
    
    if (congDonVi > 9) { // co nho
        lblDapAnPhanNhoDV->runAction(
            Sequence::create(
                DelayTime::create(delayTime + 0.5),
                Spawn::create(
                           FadeIn::create(timeAnimate),
                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                           TintTo::create(timeAnimate, Color3B::YELLOW),
                           //move to lblDapAnHangDV
                           
                           nullptr),
                 DelayTime::create(2),
                 MoveTo::create(timeAnimate * 3, Vec2(lblDapAnHangDV->getPositionX(), lblDapAnHangDV->getPositionY())),
                 FadeOut::create(timeAnimate)
                , NULL)
            );
            lblDapAnPhanNhoHangChuc->runAction(
                Sequence::create(
                    DelayTime::create(delayTime + 0.5),
                         Spawn::create(
                               FadeIn::create(timeAnimate),
                               ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                               TintTo::create(timeAnimate, Color3B::YELLOW),
                               nullptr),
                     DelayTime::create(5.5),
                     MoveTo::create(timeAnimate * 3, Vec2(lblDapAnHangChuc->getPositionX(), lblDapAnHangChuc->getPositionY())),
                     //DelayTime::create(1),
                     FadeOut::create(timeAnimate)
                                 
                    , NULL)
                );
    }
    lblDapAnHangDV->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 0.5),
                 Spawn::create(
                       FadeIn::create(timeAnimate),
                       ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                        playSound,
                       TintTo::create(timeAnimate, Color3B::GREEN),
                       nullptr)
            , NULL)
        );
    
    //hang don vi - thu nho va hien dap an don vi
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    lblDapAnHangDV->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
//    lblB->runAction(
//        Sequence::create(
//            DelayTime::create(delayTime),
//            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
//            , NULL)
//        );
    lblAHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2.5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                             DelayTime::create(delayTime + fixTimeCoNho + 2.5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
    }
    
    if (congDonVi > 9) {
        lblDapAnHangChuc->runAction(
            Sequence::create(
                             DelayTime::create(delayTime + fixTimeCoNho * 1.3 + 3),
                     Spawn::create(
                           FadeIn::create(timeAnimate),
                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                            playSound,
                           TintTo::create(timeAnimate, Color3B::GREEN),
                           
                           nullptr),
                             DelayTime::create(1),
                             congCaPhanNho
                , NULL)
            );
    } else {
        lblDapAnHangChuc->runAction(
            Sequence::create(
                             DelayTime::create(delayTime + fixTimeCoNho * 1.3 + 3),
                     Spawn::create(
                           FadeIn::create(timeAnimate),
                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                            playSound,
                           TintTo::create(timeAnimate, Color3B::GREEN),
                           nullptr)
                , NULL)
            );
    }
    
    //hang chuc thu nho
    
    lblAHangChuc->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho + 5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                DelayTime::create(delayTime + fixTimeCoNho + 5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
                , NULL)
            );
    }
    
    lblDapAnHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    //2 button retry va OK
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    float fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                        removeChild(lblA);
                        removeChild(lblAHangChuc);
                        removeChild(lblB);
                        removeChild(lblBHangChuc);
                        removeChild(gachChan);
                        removeChild(lblDapAnHangDV);
                        removeChild(lblDapAnHangChuc);
                        removeChild(lblDapAnPhanNhoDV);
                        removeChild(lblDapAnPhanNhoHangChuc);
                    }
                    
                    if (hasGuide) {
                        createTemplateGuideLevel2Cong(wScenePlay2, hScenePlay2);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    buttonOK->setScale(0);
    buttonRetry->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 5), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2

    buttonRetry->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 5 + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
}
void Play2::createBgPro(float wScene, float hScene) {
    auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
    LanguageManager::getInstanceRestart();
    
    auto bgTexture = Director::getInstance()->getTextureCache()->addImage("bg-nen-tet.png");

    // Set texture parameters to repeat
    Texture2D::TexParams texParams = { GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_REPEAT };
    bgTexture->setTexParameters(texParams);

    // Create a sprite with repeated texture
    auto bgNenPro = Sprite::createWithTexture(bgTexture, Rect(0, 0, wScene, hScene));
    bgNenPro->setAnchorPoint(Vec2(0, 0)); // Align to bottom-left
    bgNenPro->setOpacity(245);
    //bgNenPro->setOpacity(0);
    this->addChild(bgNenPro, 100);
    
    //close
    auto btn = ui::Button::create("close-btn.png"); // tao button
    float ratio = 10;
    if (hScene/wScene <= 1.53)
    {
        ratio = 17;
    }
    //CCLOG("Debug: 2");
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = wScene / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                finish();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 101);//add button vao scene
    
    float fontSize = 0.1 * wScene;
    float fontSizePrice = 0.135 * wScene;
    auto fontStyle = "fonts/ArialUnicodeMS.ttf";
    
    if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
    {
        fontStyle = "fonts/KosugiMaru.ttf";
        fontSize = 0.07 * wScene;
    }
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.05 * wScene;
        fontSizePrice = 0.06 * wScene;
        if (UserDefault::getInstance()->getStringForKey("LANGUAGE", "en") == "ja")
        {
           
            fontSize = 0.035 * wScene;
        }
    }
    //create title pro version
    std::string titleValue = LanguageManager::getInstance()->getStringForKey("TITLE_PRO").c_str();
    auto titlePro = Label::createWithTTF(titleValue, fontStyle, fontSize);
    titlePro->setColor(Color3B().WHITE);
    // position the label on the center of the
    auto btnHeightKey = titlePro->getContentSize().height;
    double ytitlePro = hScene * 0.9 - (btnHeightKey / 2 + 5);
    double xtitlePro = wScene / 2;// - (btnWidthKey / 2 + 5);
    titlePro->setPosition(Vec2(xtitlePro, ytitlePro));
    // add the label as a child to this layer
    addChild(titlePro, 101);
    
    auto bgVIP = Sprite::create("tv-ads.png");
    float ratiobgVIP = 2.4;

    float fixHeightIpad = 20;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        fixHeightIpad = 5;
    }
    
    if (hScene / wScene <= 1.53)
    {
        ratiobgVIP = 4.4;
    }
    
    float scalebgVIP = wScene / ratiobgVIP / bgVIP->getContentSize().width;
    bgVIP->setScale(scalebgVIP);
    bgVIP->setPosition(Vec2(wScene / 2, titlePro->getPositionY() - titlePro->getContentSize().height - 20 - bgVIP->getContentSize().height * scalebgVIP / 2)); // Đặt vị trí
    this->addChild(bgVIP, 101);
    
    
    //create desc pro version
    std::string descValue = LanguageManager::getInstance()->getStringForKey("REMOVE_ADS").c_str();
    auto descPro = Label::createWithTTF(descValue, fontStyle , fontSize * 0.8);
    descPro->setColor(Color3B().WHITE);
    // position the label on the center of the
    double ydescPro = bgVIP->getPositionY() - descPro->getContentSize().height /2 - 20 - bgVIP->getContentSize().height * scalebgVIP / 2;
    double xdescPro = wScene / 2;// - (btnWidthKey / 2 + 5);
    descPro->setPosition(Vec2(xdescPro, ydescPro));
    // add the label as a child to this layer
    addChild(descPro, 101);
    
    //create PRICE
    std::string priceValue = UserDefault::getInstance()->getStringForKey("gia", "");
    auto price = Label::createWithTTF(priceValue, "fonts/NunitoSans-Bold.ttf", fontSizePrice);
    price->setColor(Color3B(255, 195, 77));
    // position the label on the center of the
    double yprice = descPro->getPositionY() - descPro->getContentSize().height /2 - fixHeightIpad - price->getContentSize().height / 2;
    double xprice = wScene / 2;// - (btnWidthKey / 2 + 5);
    price->setPosition(Vec2(xprice, yprice));
    // add the label as a child to this layer
    addChild(price, 101);
    
    //create Underline
    auto underlineImg = Sprite::create("underline-pro.png");
    float ratiounderlineImg = 2;
    //float fixHeightNotiIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        ratiounderlineImg = 4;
        //fixHeightNotiIpad = 0.5;
    }
    
    float scaleunderlineImg = wScene / ratiounderlineImg / underlineImg->getContentSize().width;
    underlineImg->setScale(scaleunderlineImg);
    underlineImg->setPosition(Vec2(wScene / 2, price->getPositionY() - price->getContentSize().height / 2 - underlineImg->getContentSize().height * scaleunderlineImg * 0.15)); // Đặt vị trí
    this->addChild(underlineImg, 101);
    
    
    
    fontSize = 0.05 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize = 0.02 * wScene;
    }
    auto restorePurchaseBtn = ui::Button::create("empty.png");
    restorePurchaseBtn->setPressedActionEnabled(true);
    restorePurchaseBtn->setZoomScale(-0.1f);
    restorePurchaseBtn->setScale9Enabled(true);
    restorePurchaseBtn->setTitleText("Restore Purchase");
    if(appLang == "en" || appLang == "vi"){
        restorePurchaseBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    restorePurchaseBtn->setTitleColor(Color3B().WHITE);
    restorePurchaseBtn->setOpacity(200);
    restorePurchaseBtn->setTouchEnabled(true);
    float ratiotitle = 3;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 6;
        
    }
    auto scalerestoreBtn = wScene / ratiotitle / restorePurchaseBtn->getContentSize().width;
    restorePurchaseBtn->setScale(scalerestoreBtn);
    restorePurchaseBtn->setTitleFontSize(fontSize / scalerestoreBtn);
    if (appLang == "ja")
    {
        restorePurchaseBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        restorePurchaseBtn->setTitleFontSize(0.045 * wScene / scalerestoreBtn);
    }
    float ytitle = 40;
    if (hScene / wScene <= 1.8 && hScene / wScene > 1.53)
    {
        
        ytitle = 20;
    }
    if (hScene / wScene <= 1.53)
    {
        
        if (appLang == "ja")
        {
            
            restorePurchaseBtn->setTitleFontSize(0.02 * wScene / scalerestoreBtn);
        }
    }
    restorePurchaseBtn->setPosition(Vec2(wScene / 2, ytitle));
    restorePurchaseBtn->setEnabled(true);
    restorePurchaseBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("restore purchasing");
                IAPManager::getInstance()->restorePurchases();
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(restorePurchaseBtn, 101);
    
    float fontSize2 = 0.07 * wScene;
    if (hScene / wScene <= 1.53)
    {
        fontSize2 = 0.035 * wScene;
    }
    auto upProBtn = ui::Button::create("button-pro.png");
    upProBtn->setPressedActionEnabled(true);
    upProBtn->setZoomScale(-0.1f);
    upProBtn->setScale9Enabled(true);
    upProBtn->setTitleText(LanguageManager::getInstance()->getStringForKey("PRO_BUY").c_str());
    if(appLang == "en" || appLang == "vi"){
        upProBtn->setTitleFontName("fonts/NunitoSans-Bold.ttf");
    }
    upProBtn->setTitleColor(Color3B().WHITE);
    upProBtn->setTouchEnabled(true);
    ratiotitle = 1.5;
    if (hScene / wScene <= 1.53)
    {
        ratiotitle = 3.4;
       
    }
    auto scaleUpProBtn = wScene / ratiotitle / upProBtn->getContentSize().width;
    upProBtn->setScale(scaleUpProBtn);
    upProBtn->setTitleFontSize(fontSize2 / scaleUpProBtn);
    if (appLang == "ja")
    {
        upProBtn->setTitleFontName("fonts/KosugiMaru.ttf");
        upProBtn->setTitleFontSize(0.05 * wScene / scaleUpProBtn);
    }
    ytitle = ytitle + restorePurchaseBtn->getContentSize().height * scalerestoreBtn / 2 + upProBtn->getContentSize().height * scaleUpProBtn / 2 + 7;
    if (hScene / wScene <= 1.53)
    {
      
        if (appLang == "ja")
        {
            upProBtn->setTitleFontSize(0.025 * wScene / scaleUpProBtn);
        }
    }
    upProBtn->setPosition(Vec2(wScene / 2, ytitle));
    upProBtn->setEnabled(true);
    upProBtn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        //auto buttonIcon = dynamic_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                log("up to pro");
                IAPManager::getInstance()->purchase(Variable().proProductionID);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    
    addChild(upProBtn, 101);
    
}

void Play2::onEnter() {
    Layer::onEnter();

    // Đăng ký callback khi mua thành công
    IAPManager::getInstance()->setOnPurchaseSuccess([this](std::string productID) {
        log("🎉 Mua thành công - restore thanh cong: %s", productID.c_str());
        UserDefault::getInstance()->setBoolForKey("isProVer", true);
        //Variable().isProVer = true;
        UserDefault::getInstance()->flush();
        this->finish();
    });

    // Đăng ký callback khi mua thất bại
    IAPManager::getInstance()->setOnPurchaseFailed([this](std::string productID, std::string error) {
        log("❌ Mua thất bại: %s | Lỗi: %s", productID.c_str(), error.c_str());
        //this->finish();
        
        
    });
    
    // Đăng ký callback lấy giá
    IAPManager::getInstance()->setOnPriceRetrieved([this](std::string productID, std::string price) {
        log("📦 Giá của %s là: %s", productID.c_str(), price.c_str());
        // Gợi ý: update label nút mua
        //this->price->setString(price.c_str());
        UserDefault::getInstance()->setStringForKey("gia", price.c_str());
    });

    // Yêu cầu lấy giá từ App Store
    IAPManager::getInstance()->requestProductInfo(Variable().proProductionID);
}
void Play2::finish() {
    if (Variable().isProduction == true) {
        HuyFunctions().showAds();
    }
    
    HuyFunctions().saveSoGame("g3");
    if(isMulti2 == true){
        typeOfW2 = 1;
    }
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score2, typeOfW2, levelOfW2, 2, fromChallenge2), Color3B().WHITE));
}
void Play2::createTemplateGuideLevel2Tru(float w, float h) {
    bool flagCoNho = false;
    int congDonVi = 0;
    float fixWithCoNho = 1;
    if ( HuyFunctions().getSoHangDonVi(soA) - HuyFunctions().getSoHangDonVi(soB) < 0) {
        congDonVi = 10 + HuyFunctions().getSoHangDonVi(soA) - HuyFunctions().getSoHangDonVi(soB);
        flagCoNho = true;
        fixWithCoNho = 1.25;
    } else {
        congDonVi = HuyFunctions().getSoHangDonVi(soA) - HuyFunctions().getSoHangDonVi(soB);
    }
    
    
    lblPhepToan2->runAction(FadeOut::create(0.1));
    auto fontStyle = "fonts/DeliusSwashCaps.ttf";
    float fontSize = 0.18 * w;
    if (h / w > 1.53 && h / w <= 1.8){
        fontSize = 0.15 * w;
    }
    if (h / w <= 1.53)
    {
        fontSize = 0.09 * w;
    }

    float time = 0.2;
    float width = 50.0f;
    float fixWithIpad = 1.0f;
    if (h / w <= 1.53)
    {
        fixWithIpad = 0.5f;
    }
    if (levelOfW2 > 1) {
        width = 70.0f;
    }
    float height = 3.0f * fixWithIpad;
    width = width * fixWithIpad;
    cocos2d::Vec2 origin(w / 2 - width / 2 - 16 * fixWithIpad, lblPhepToan2->getPositionY() + lblPhepToan2->getContentSize().height / 2);
    gachChan = HuyFunctions().createChuNhatBoGoc(width, height, origin);
    this->addChild(gachChan, 2);
    
    lblB = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soB))->getCString(), fontStyle, fontSize);
    float xLblB = w / 2;
    lblB->setPosition(Vec2(xLblB, lblPhepToan2->getPositionY() + lblPhepToan2->getContentSize().height * 1.1));
    addChild(lblB, 2);
    lblB->setAlignment(TextHAlignment:: CENTER);
    lblB->setOpacity(0);
    lblB->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    if (soB > 9) {
        lblBHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soB))->getCString(), fontStyle, fontSize);
        
        lblBHangChuc->setPosition(Vec2(lblB->getPositionX() - lblB->getContentSize().height * 0.51 * fixWithCoNho, lblB->getPositionY()));
        addChild(lblBHangChuc, 2);
        lblBHangChuc->setAlignment(TextHAlignment:: CENTER);
        lblBHangChuc->setOpacity(0);
        lblBHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    }
    
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", "-");
    
    lblLoaiPhepTinh = Label::createWithTTF(loaiPhepTinh->getCString(), fontStyle, fontSize);
    lblLoaiPhepTinh->setPosition(Vec2(w/2 - lblB->getContentSize().height * 0.82 * fixWithCoNho, lblB->getPositionY() + lblB->getContentSize().height * 0.55));
    addChild(lblLoaiPhepTinh, 2);
    lblLoaiPhepTinh->setOpacity(0);
    lblLoaiPhepTinh->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblA = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA))->getCString(), fontStyle, fontSize);
    lblA->setPosition(Vec2(w / 2, lblLoaiPhepTinh->getPositionY() + lblLoaiPhepTinh->getContentSize().height * 0.4));
    addChild(lblA, 2);
    lblA->setAlignment(TextHAlignment:: CENTER);
    lblA->setOpacity(0);
    lblA->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblAHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA))->getCString(), fontStyle, fontSize);
    lblAHangChuc->setPosition(Vec2(lblA->getPositionX() - lblA->getContentSize().height * 0.51 * fixWithCoNho, lblA->getPositionY()));
    addChild(lblAHangChuc, 2);
    lblAHangChuc->setOpacity(0);
    lblAHangChuc->setAlignment(TextHAlignment:: CENTER);
    lblAHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(soA - soB))->getCString(), fontStyle, fontSize);
    lblDapAnHangDV->setPosition(Vec2(w / 2, lblB->getPositionY() - lblB->getContentSize().height * 1.1 * fixWithCoNho * 0.9));
    addChild(lblDapAnHangDV, 2);
    lblDapAnHangDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnHangDV->setOpacity(0);
    //lblDapAnHangDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnHangChuc = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangChuc(soA - soB))->getCString(), fontStyle, fontSize);
    lblDapAnHangChuc->setPosition(Vec2(lblAHangChuc->getPositionX(), lblDapAnHangDV->getPositionY()));
    addChild(lblDapAnHangChuc, 2);
    lblDapAnHangChuc->setOpacity(0);
    lblDapAnHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    
    lblDapAnPhanNhoDV = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", HuyFunctions().getSoHangDonVi(congDonVi))->getCString(), fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoDV->setPosition(Vec2(w * 0.8, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoDV, 2);
    lblDapAnPhanNhoDV->setAlignment(TextHAlignment:: CENTER);
    lblDapAnPhanNhoDV->setOpacity(0);
    //lblDapAnPhanNhoDV->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblDapAnPhanNhoHangChuc = Label::createWithTTF("1", fontStyle, fontSize * 0.8);
    lblDapAnPhanNhoHangChuc->setPosition(Vec2(lblDapAnPhanNhoDV->getPositionX() - lblDapAnPhanNhoDV->getContentSize().height * 0.51, lblLoaiPhepTinh->getPositionY()));
    addChild(lblDapAnPhanNhoHangChuc, 2);
    lblDapAnPhanNhoHangChuc->setOpacity(0);
    lblDapAnPhanNhoHangChuc->setAlignment(TextHAlignment:: CENTER);
    //lblDapAnPhanNhoHangChuc->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    
    auto playSound = CallFunc::create([this]() {
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
    });
    
    if (flagB1ChuSo) {
        xLblB = w / 2 + (lblA->getContentSize().width - lblB->getContentSize().width) / 2;
        lblB->setPosition(Vec2(xLblB, lblB->getPositionY()));
    }
    //animation cho hang don vi - phong to
    float timeAnimate = 0.2;
    float delayTime = 2;
    float fixTimeCoNho = 0;
    if (flagCoNho) {
        fixTimeCoNho = 2;
    }
    if (flagCoNho) {
        float timePlay = 0.07f;
        auto rotateLeft = RotateBy::create(timePlay, -5.0f); // Rotate left by 10 degrees
        auto rotateRight = RotateBy::create(timePlay, 10.0f); // Rotate right by 20 degrees (to 10 degrees right)
        auto rotateBack = RotateBy::create(timePlay, -5.0f); // Rotate back to center

        // Create a sequence and repeat it forever
        auto tiltSequence = Sequence::create( rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack, nullptr);
       
        lblB->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(
                              ScaleTo::create(timeAnimate, lblB->getScale() * 1.3),
                              TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
                DelayTime::create(1),
                tiltSequence,
                NULL)

            );
        rotateLeft = RotateBy::create(timePlay * 0.9, -5.0f); // Rotate left by 10 degrees
        rotateRight = RotateBy::create(timePlay * 0.9, 10.0f); // Rotate right by 20 degrees (to 10 degrees right)
        rotateBack = RotateBy::create(timePlay * 0.9, -5.0f); // Rotate back to center

        // Create a sequence and repeat it forever
        tiltSequence = Sequence::create( rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack,rotateLeft, rotateRight, rotateBack, nullptr);
        
        lblA->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
                             DelayTime::create(1),
                             tiltSequence
                , NULL)
            );
    } else {
        lblB->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
        lblA->runAction(
            Sequence::create(
                DelayTime::create(delayTime),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
    }
    
    
    log("cong don vi: %i", congDonVi);
    
    if (flagCoNho) { // co nho
//        lblDapAnPhanNhoDV->runAction(
//            Sequence::create(
//                DelayTime::create(delayTime + 0.5),
//                Spawn::create(
//                           FadeIn::create(timeAnimate),
//                           ScaleTo::create(timeAnimate, lblB->getScale() * 1.2),
//                           TintTo::create(timeAnimate, Color3B::YELLOW),
//                           //move to lblDapAnHangDV
//
//                           nullptr),
//                 DelayTime::create(2),
//                 MoveTo::create(timeAnimate * 3, Vec2(lblDapAnHangDV->getPositionX(), lblDapAnHangDV->getPositionY())),
//                 FadeOut::create(timeAnimate)
//                , NULL)
//            );
        auto positionPhanNho = Vec2(lblDapAnPhanNhoHangChuc->getPosition());
        
        auto changeText = CallFunc::create([this]() {
            lblDapAnPhanNhoHangChuc->setString("-1");
        });
        
        lblDapAnPhanNhoHangChuc->setPosition(Vec2(lblA->getPositionX() - lblA->getContentSize().width * 0.8, lblA->getPositionY())); // - lblA->getContentSize().width / 2)
            lblDapAnPhanNhoHangChuc->runAction(
                Sequence::create(
                    DelayTime::create(delayTime + 1.5 + 0.5),
                         Spawn::create(
                               FadeIn::create(timeAnimate),
                               ScaleTo::create(timeAnimate, lblB->getScale() * 0.7),
                                TintTo::create(timeAnimate, Color3B::GREEN),
                               nullptr),
                     DelayTime::create(2.5),
                     MoveTo::create(timeAnimate, positionPhanNho),
                     
                     DelayTime::create(2),
                                 Spawn::create(
                                        MoveTo::create(timeAnimate * 2, Vec2(lblDapAnHangChuc->getPositionX(), lblDapAnHangChuc->getPositionY() + lblDapAnHangChuc->getContentSize().height / 2)),
                                    changeText,
                                       nullptr),
                                 
                     DelayTime::create(2),
                     FadeOut::create(timeAnimate)
                    , NULL)
                );
    }
    lblDapAnHangDV->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 1.2 + 1),
                 Spawn::create(
                       FadeIn::create(timeAnimate),
                       ScaleTo::create(timeAnimate, lblB->getScale() * 1.2),
                        playSound,
                       TintTo::create(timeAnimate, Color3B::GREEN),
                       nullptr)
            , NULL)
        );
    
    //hang don vi - thu nho va hien dap an don vi
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    lblDapAnHangDV->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho + 2),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
//    lblB->runAction(
//        Sequence::create(
//            DelayTime::create(delayTime),
//            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
//            , NULL)
//        );
    lblAHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho * 1.8 + 2.5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
            , NULL)
        );
    
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                             DelayTime::create(delayTime + fixTimeCoNho * 1.8 + 2.5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.2), TintTo::create(timeAnimate, Color3B::GREEN), nullptr)
                , NULL)
            );
    }
    
    lblDapAnHangChuc->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 2 + 4),
                 Spawn::create(
                       FadeIn::create(timeAnimate),
                       ScaleTo::create(timeAnimate, lblB->getScale() * 1.2),
                        playSound,
                       TintTo::create(timeAnimate, Color3B::GREEN),
                       nullptr)
            , NULL)
        );
    
    
    //hang chuc thu nho
    
    lblAHangChuc->runAction(
        Sequence::create(
                         DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 5),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    if (soB > 9) {
        lblBHangChuc->runAction(
            Sequence::create(
                DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 5),
                Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
                , NULL)
            );
    }
    
    lblDapAnHangChuc->runAction(
        Sequence::create(
            DelayTime::create(delayTime + fixTimeCoNho * 1.5 + 6),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()), TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
        );
    
    //2 button retry va OK
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    //float fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                        removeChild(lblA);
                        removeChild(lblAHangChuc);
                        removeChild(lblB);
                        removeChild(lblBHangChuc);
                        removeChild(gachChan);
                        removeChild(lblDapAnHangDV);
                        removeChild(lblDapAnHangChuc);
                        removeChild(lblDapAnPhanNhoDV);
                        removeChild(lblDapAnPhanNhoHangChuc);
                    }
                    
                    if (hasGuide) {
                        createTemplateGuideLevel2Tru(wScenePlay2, hScenePlay2);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    buttonOK->setScale(0);
    buttonRetry->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 6), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2

    buttonRetry->runAction(Sequence::create(DelayTime::create(delayTime + fixTimeCoNho + 6 + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
}
void Play2::createTemplateGuideLevel1Tru(float w, float h) {
    auto viTriTenLua = UserDefault::getInstance()->getIntegerForKey("tenluadachon", 0) + 1;
    auto iconTenLua = StringUtils::format("icon-ten-lua-%d.png", viTriTenLua);
    float wLuoi = w / 10;
    int step = 1;
    float heightPhiThuyen = 0.75;
    
    float ratiobgNumber = 12;
    float fixIpad = 1;
    float fixHeightIpad = 0.65;
    if (h / w < 1.8 && h / w > 1.53) {
        fixHeightIpad = 0.77;
        heightPhiThuyen = 0.85;
    }
    if (h / w <= 1.53) {
        ratiobgNumber = 20;
        fixIpad = 0.8;
        fixHeightIpad = 0.77;
        heightPhiThuyen = 0.85;
    }
    
    for (int i = 1; i <= soA + 1; i++) {
        // create Phi thuyen
        auto viTriPhiThuyen = UserDefault::getInstance()->getIntegerForKey("phithuyendachon", 0) + 1;
        auto sprite_cachePhiThuyen = SpriteFrameCache::getInstance();
        sprite_cachePhiThuyen->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d1.plist", viTriPhiThuyen));
        Vector<SpriteFrame*> phiThuyen;
        phiThuyen.reserve(2);
        phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1a.png", viTriPhiThuyen)));
        phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("phithuyen0%d1b.png", viTriPhiThuyen)));
        Animation* animationPhiThuyen = Animation::createWithSpriteFrames(phiThuyen, 0.2f, -1);
        Animate* animatePhiThuyen = Animate::create(animationPhiThuyen);

        auto iconSoA = Sprite::createWithSpriteFrame(phiThuyen.front());
        iconSoA->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * heightPhiThuyen));
        if (i == soA + 1) {
            iconSoA->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 2) * wLuoi, h * heightPhiThuyen));
        }
        float ratioiconSoA = 12;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoA = w / ratioiconSoA / iconSoA->getContentSize().width;
        iconSoA->setScale(scaleiconSoA);
        this->addChild(iconSoA, 2);
        iconSoA->runAction(animatePhiThuyen);
        iconSoA->setTag(i);
        listIcon.pushBack(iconSoA);
        
        float ratiobgNumber = 12;
        float fixIpad = 1;
        if (h / w <= 1.53) {
            ratiobgNumber = 20;
            fixIpad = 0.8;
        }
        
        if (i <= soA + 1 && i > soB) {
            auto bgNumber = ui::Button::create("bgNumber 2.png");
            bgNumber->setPosition(Vec2(iconSoA->getPositionX(), iconSoA->getPositionY() + iconSoA->getContentSize().height * scaleiconSoA * 1.2 * fixIpad)); // Đặt vị trí
            
            float scalebgNumber = w / ratiobgNumber / bgNumber->getContentSize().width;
            bgNumber->setScale(scalebgNumber);
            bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", i - soB)->getCString());
            if (i == soA + 1) {
                
             
                bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", i - 1 - soB )->getCString());
        
            }
            bgNumber->setTitleFontName("Arial-BoldMT");
            bgNumber->setTitleColor(Color3B().WHITE);
            bgNumber->setTitleFontSize(0.12 * w * fixIpad);
            this->addChild(bgNumber, 2);
            listBgNumber.pushBack(bgNumber);
        }

        step++;
    }
    
    for (int i = 1; i <= soB; i++) {
        auto iconSoB = Sprite::create(iconTenLua.c_str());
        iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * fixHeightIpad));
        if (i == soB + 1) {
            iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (soB - 1) * wLuoi, h * fixHeightIpad));
        }
        float ratioiconSoB = 18;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoB = w / ratioiconSoB / iconSoB->getContentSize().width;
        iconSoB->setScale(scaleiconSoB);
        iconSoB->setRotation(-45);
        iconSoB->setTag(i);
        this->addChild(iconSoB, 2);
        listIconTru.pushBack(iconSoB);
        
        step++;
    }
    
    float time = 0;
    int step1 = 0;
    float scale;
    for (auto icon : listIcon) {
        if(icon) {
            if (step1 == 0) {
                scale = icon->getScale();
            }
            icon->setScale(0);
            time = 1.5 + step1 * 0.25;
            icon->runAction(Sequence::create(DelayTime::create(time), ScaleTo::create(0.3, scale), NULL));
            
            step1++;
        }
    }
    
    step1 = 0;
    for (auto icon : listIconTru) {
        if(icon) {
            if (step1 == 0) {
                scale = icon->getScale();
            }
            icon->setScale(0);
            time = time + 0.1;
            icon->runAction(Sequence::create(DelayTime::create(time), ScaleTo::create(0.3, scale), NULL));
            step1++;
        }
    }
    step1 = 0;
    
    time = time + 0.8;
    for (auto icon : listIconTru) {
        if (icon) {
            time = time + 0.3f;
            
            cocos2d::Vec2 position = Vec2(icon->getPositionX(), h * heightPhiThuyen);
            // Tạo hiệu ứng di chuyển và mờ dần
            auto moveAction = MoveTo::create(0.4f, position);
            auto fadeOut = FadeTo::create(0.2f, 0);
            // Callback để xử lý hành động sau khi icon biến mất
            auto callback = CallFunc::create([this, icon, position]() {
                for (auto phithuyen : listIcon) {
                    if (phithuyen && phithuyen->getTag() == icon->getTag()) {
                        phithuyen->runAction(Sequence::create(
                                //DelayTime::create(0.4),
                                FadeOut::create(0.2f), NULL)
                        );
                        //createGuideBom(scale, position);
                    }
                
                }
                

            });

            // Chạy hành động với easing
            icon->runAction(
                //EaseExponentialIn::create(
                    Sequence::create(
                        DelayTime::create(time),
                        moveAction,
                        callback,
                        fadeOut,
                        nullptr
                    )
                //)
            );

            step1++;
        }
    }

    int step2 = 0;
    for (auto button : listBgNumber) {
        if(button) {
            if (step2 == 0) {
                scale = button->getScale();
            }
            if (step2 < soA - soB) {
                button->setScale(0);
                button->runAction(Sequence::create(DelayTime::create(time + 1 + step2 * 0.6 ), ScaleTo::create(0.3, scale), NULL));//(1.5 + step1 * 0.6 + step2 * 0.5)
            } else{
                button->setScale(0);
                auto moveToDapAn = CallFunc::create([button, this]() {
                    button->runAction(
                            Sequence::create(
                                Spawn::create(
                                    ScaleTo::create(0.6, button->getScale() * 1.5),
                                    MoveTo::create(0.6, Vec2(lblPhepToan2->getPositionX() + lblPhepToan2->getContentSize().width * lblPhepToan2->getScale() / 2, lblPhepToan2->getPositionY())),
                                    nullptr),
                                FadeOut::create(0.2),
                            NULL)
                        );
                });
                button->runAction(Sequence::create(DelayTime::create(time + 1 + step2 * 0.6), ScaleTo::create(0, scale), moveToDapAn, NULL)); //1.5 + step1 * 0.6 + step2 * 0.5
                time = time + 1 + step2 * 0.6;
                
            }
            step2++;
        }
    }
    
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    listIconTru.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                    }
                    
                    lblPhepToan2->runAction(
                        Sequence::create(
                             FadeOut::create(0.3),
                             CallFunc::create([this]() {
                                lblPhepToan2->setString(cocos2d::__String::createWithFormat("%d - %d = ?", soA, soB)->getCString());
                                // Thêm câu lệnh khác nếu cần
                             }),
                             FadeIn::create(0.2), NULL));
                    if (hasGuide) {
                        createTemplateGuideLevel1Tru(wScenePlay2, hScenePlay2);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    
    float timeFinish = time + 0.6;
    buttonOK->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(timeFinish), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2
    
    buttonRetry->setScale(0);
    
    lblPhepToan2->runAction(
        Sequence::create(
             DelayTime::create(timeFinish + 0.2),
             FadeOut::create(0.1),
             ScaleTo::create(0, 2),
             CallFunc::create([this]() {
                lblPhepToan2->setString(cocos2d::__String::createWithFormat("%d - %d = %d", soA, soB, soA - soB)->getCString());
                 if (sound2 == 0)
                 {
                     CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                 }
                // Thêm câu lệnh khác nếu cần
             }),
             Spawn::create(FadeIn::create(0.2), ScaleTo::create(0.2, 1), nullptr), NULL));

    buttonRetry->runAction(Sequence::create(DelayTime::create(timeFinish + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
    
}
void Play2::createTemplateGuideLevel1Cong(float w, float h) {
    
    auto viTriTenLua = UserDefault::getInstance()->getIntegerForKey("tenluadachon", 0) + 1;
    auto iconTenLua = StringUtils::format("icon-ten-lua-%d.png", viTriTenLua);
    
    float wLuoi = w / 10;
    int step = 1;
    
    float heightHang1 = 0.7;
    float heightHang2 = 0.60;
    if (h / w < 1.8 and h / w > 1.53) {
        heightHang1 = 0.87;
        heightHang2 = 0.74;
    }
    if (h / w <= 1.53) {
        heightHang1 = 0.88;
        heightHang2 = 0.74;
    }
    for (int i = 1; i <= soA; i++) {
        auto iconSoA = Sprite::create(iconTenLua.c_str());
        iconSoA->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * heightHang1));
        float ratioiconSoA = 12;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoA = w / ratioiconSoA / iconSoA->getContentSize().width;
        iconSoA->setScale(scaleiconSoA);
        this->addChild(iconSoA, 2);
        listIcon.pushBack(iconSoA);
        
        float ratiobgNumber = 12;
        float fixIpad = 1;
        if (h / w <= 1.53) {
            ratiobgNumber = 20;
            fixIpad = 0.8;
        }
        
        auto bgNumber = ui::Button::create("bgNumber 2.png");
        bgNumber->setPosition(Vec2(iconSoA->getPositionX(), iconSoA->getPositionY() + iconSoA->getContentSize().height * scaleiconSoA * 1.2 * fixIpad)); // Đặt vị trí
        
        float scalebgNumber = w / ratiobgNumber / bgNumber->getContentSize().width;
        bgNumber->setScale(scalebgNumber);
        bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", i)->getCString());
        bgNumber->setTitleFontName("Arial-BoldMT");
        bgNumber->setTitleColor(Color3B().WHITE);
        bgNumber->setTitleFontSize(0.12 * w * fixIpad);
        this->addChild(bgNumber, 2);
        listBgNumber.pushBack(bgNumber);
        step++;
    }
    for (int i = 1; i <= soB + 1; i++) {
        float ratiobgNumber = 12;
        float fixIpad = 1;
        
        if (h / w <= 1.53) {
            ratiobgNumber = 20;
            fixIpad = 0.8;
            
        }
        
        auto iconSoB = Sprite::create(iconTenLua.c_str());
            iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (i - 1) * wLuoi, h * heightHang2));
        if (i == soB + 1) {
            iconSoB->setPosition(Vec2(w / 2 - (soA - 1) * wLuoi / 2 + (soB - 1) * wLuoi, h * heightHang2));
        }
        float ratioiconSoB = 12;
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scaleiconSoB = w / ratioiconSoB / iconSoB->getContentSize().width;
        iconSoB->setScale(scaleiconSoB);
        this->addChild(iconSoB, 2);
        listIcon.pushBack(iconSoB);
        
        
        auto bgNumber = ui::Button::create("bgNumber 2.png");
        bgNumber->setPosition(Vec2(iconSoB->getPositionX(), iconSoB->getPositionY() + iconSoB->getContentSize().height * scaleiconSoB * 1.2 * fixIpad)); // Đặt vị trí
       
        //float fontSizeNoti = 0.04 * w;
        //float fixHeightNotiIpad = 1;
        float scalebgNumber = w / ratiobgNumber / bgNumber->getContentSize().width;
        bgNumber->setScale(scalebgNumber);
        bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", step)->getCString());
        if (i == soB + 1) {
            
            iconSoB->setTag(100);
            bgNumber->setTitleText(cocos2d::__String::createWithFormat("%d", soB + soA)->getCString());
            bgNumber->setTag(100);
        }
        bgNumber->setTitleFontName("Arial-BoldMT");
        bgNumber->setTitleColor(Color3B().WHITE);
        bgNumber->setTitleFontSize(0.12 * w * fixIpad);
        this->addChild(bgNumber, 2);
        listBgNumber.pushBack(bgNumber);
        step++;
    }
    
    int step1 = 0;
    float scale;
    for (auto icon : listIcon) {
        if(icon) {
            if (step1 == 0) {
                scale = icon->getScale();
            }
            if (step1 < soA + soB) {
                icon->setScale(0);
                icon->runAction(Sequence::create(DelayTime::create(1.5 + step1 * 0.6), ScaleTo::create(0.3, scale), NULL));
            } else{
                icon->setScale(0);
            }
            
            step1++;
        }
    }
    int step2 = 0;
    for (auto button : listBgNumber) {
        if(button) {
            if (step2 == 0) {
                scale = button->getScale();
            }
            if (step2 < soA + soB) {
                button->setScale(0);
                button->runAction(Sequence::create(DelayTime::create(1.5 + step2 * 0.6 ), ScaleTo::create(0.3, scale), NULL));//(1.5 + step1 * 0.6 + step2 * 0.5)
            } else{
                button->setScale(0);
                auto moveToDapAn = CallFunc::create([button, this]() {
                    button->runAction(
                            Sequence::create(
                                Spawn::create(
                                    ScaleTo::create(0.6, button->getScale() * 1.5),
                                    MoveTo::create(0.6, Vec2(lblPhepToan2->getPositionX() + lblPhepToan2->getContentSize().width * lblPhepToan2->getScale() / 2, lblPhepToan2->getPositionY())),
                                    nullptr),
                                FadeOut::create(0.2),
                            NULL)
                        );
                });
                button->runAction(Sequence::create(DelayTime::create(1.5 + step2 * 0.6), ScaleTo::create(0, scale), moveToDapAn, NULL)); //1.5 + step1 * 0.6 + step2 * 0.5
                
            }
            step2++;
        }
    }
    
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    float fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                    }
                    
                    lblPhepToan2->runAction(
                        Sequence::create(
                             FadeOut::create(0.3),
                             CallFunc::create([this]() {
                                lblPhepToan2->setString(cocos2d::__String::createWithFormat("%d + %d = ?", soA, soB)->getCString());
                                // Thêm câu lệnh khác nếu cần
                             }),
                             FadeIn::create(0.2), NULL));
                    if (hasGuide == true) {
                        createTemplateGuideLevel1Cong(wScenePlay2, hScenePlay2);
                    }
                    
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    
    float timeFinish = 1.5 + step1 * 0.6; //1.5 + step1 * 0.6 + step2 * 0.5
    buttonOK->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(timeFinish), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2
    
    buttonRetry->setScale(0);
    
    lblPhepToan2->runAction(
        Sequence::create(
             DelayTime::create(timeFinish + 0.2),
             FadeOut::create(0.1),
             ScaleTo::create(0, 2),
             CallFunc::create([this]() {
                lblPhepToan2->setString(cocos2d::__String::createWithFormat("%d + %d = %d", soA, soB, soA + soB)->getCString());
                 if (sound2 == 0)
                 {
                     CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
                 }
                // Thêm câu lệnh khác nếu cần
             }),
             Spawn::create(FadeIn::create(0.2), ScaleTo::create(0.2, 1), nullptr), NULL));

    buttonRetry->runAction(Sequence::create(DelayTime::create(timeFinish + 0.3), ScaleTo::create(0.3, scalebuttonRetry), NULL));
    
}

void Play2::createTraiDatAndPhiThuyenTenLua(float w, float h) {
    //create earth
    earth_2 = ui::Button::create("earth4.png"); // tao button
    earth_2->setTouchEnabled(false);
    float ratiobgColor = 8;
    float scalebgColor = w / ratiobgColor / earth_2->getContentSize().width;
    earth_2->setScale(scalebgColor);

    float ytitle = h * 0.94 - (earth_2->getContentSize().height / 2 * scalebgColor);
    float xtitle = w - w * 0.03 - (earth_2->getContentSize().width / 2 * scalebgColor);
    if (h / w <= 1.8)
    {
        ytitle = h * 0.93 - (earth_2->getContentSize().height / 2 * scalebgColor);
    }
//    if (h / w <= 1.53)
//    {
//
//    }
    earth_2->setPosition(Vec2(xtitle, ytitle));
    earth_2->setEnabled(true);
    this->addChild(earth_2, 2);
    
    earth_2->setOpacity(0);
    earth_2->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(0.5), nullptr));
    
    //animation for earth_2
    float timeAnimation = 0.9;
    auto playAnimationZoomOut1 = ScaleTo::create(timeAnimation, 1 * scalebgColor);
    auto playAnimationZoomOut2 = ScaleTo::create(timeAnimation, scalebgColor * 0.9);
    auto sq = Sequence::create(playAnimationZoomOut1, playAnimationZoomOut2, nullptr);

    earth_2->runAction((RepeatForever::create(sq)));
    
    auto moveUp = MoveBy::create(0.8f, Vec2(0, 6));
    auto moveDown = MoveBy::create(0.8f, Vec2(0, -6));
    auto waveMotion = RepeatForever::create(Sequence::create(moveUp, moveDown, nullptr));
    
    earth_2->runAction(waveMotion);
    
    // create Phi thuyen
    int phiThuyenIndex = cocos2d::RandomHelper::random_int(2, 4);
    auto sprite_cachePhiThuyen = SpriteFrameCache::getInstance();
    sprite_cachePhiThuyen->addSpriteFramesWithFile(StringUtils::format("bigufo%d.plist", phiThuyenIndex));
    Vector<SpriteFrame*> phiThuyen;
    phiThuyen.reserve(2);
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("bigufo%d1.png", phiThuyenIndex)));
    phiThuyen.pushBack(sprite_cachePhiThuyen->getSpriteFrameByName(StringUtils::format("bigufo%d2.png", phiThuyenIndex)));
    Animation* animationPhiThuyen = Animation::createWithSpriteFrames(phiThuyen, 0.9f, -1);
    Animate* animatePhiThuyen = Animate::create(animationPhiThuyen);

    phithuyenHienThi2 = Sprite::createWithSpriteFrame(phiThuyen.front());
    float ratioPhiThuyen = 1.5;
    if (h / w > 1.53 && h / w <= 1.8){
        ratioPhiThuyen = 2;
    }
    if (h / w <= 1.53)
    {
        ratioPhiThuyen = 3;
    }
    float scalePhiThuyen = w / ratioPhiThuyen / phithuyenHienThi2->getContentSize().width;
    phithuyenHienThi2->setScale(scalePhiThuyen);

    //float ytitle = h * 0.9 - (earth2->getContentSize().height / 2 * scalebgColor);
    float xtitlePhiThuyen = w / 2 ;
    float ytitlePhiThuyen = h * 0.92 - (phithuyenHienThi2->getContentSize().height / 2 * scalePhiThuyen);
    if (h / w > 1.53 && h / w <= 1.8){
        ytitlePhiThuyen = h * 0.99 - (phithuyenHienThi2->getContentSize().height / 2 * scalePhiThuyen);
    }
    
    phithuyenHienThi2->setPosition(Vec2(xtitlePhiThuyen, ytitlePhiThuyen));
    phithuyenHienThi2->runAction(animatePhiThuyen);
    
    // Tạo hành động nghiêng sang trái
    auto tiltLeft = RotateBy::create(0.7f, -4);  // Xoay -2 độ
    // Tạo hành động nghiêng sang phải
    auto tiltRight = RotateBy::create(0.7f, 4);   // Xoay +2 độ
    // Lặp lại hành động
    auto tilting = RepeatForever::create(Sequence::create(tiltLeft, tiltRight, nullptr));
    // Chạy animation cho phi thuyền
    phithuyenHienThi2->runAction(tilting);
    
    
//    auto moveUp = MoveBy::create(0.7f, Vec2(0, 7));
//    auto moveDown = MoveBy::create(0.7f, Vec2(0, -7));
//    auto waveMotion = RepeatForever::create(Sequence::create(moveUp, moveDown, nullptr));
//
//    phithuyenHienThi2->runAction(waveMotion);
    
    this->addChild(phithuyenHienThi2, 2);
    
    //create anh sang phi thuyen
    anhSangPhiThuyen_2 = ui::Button::create(StringUtils::format("anhsangufo%d.png", phiThuyenIndex)); // tao button
    anhSangPhiThuyen_2->setTouchEnabled(false);
    float ratioAnhSang = 2.2;
    if (phiThuyenIndex == 3) {
        ratioAnhSang = 1.1;
    }
    if (phiThuyenIndex == 4) {
        ratioAnhSang = 1.9;
    }
    if (h / w > 1.53 && h / w <= 1.8){
        ratioAnhSang = ratioAnhSang * 2 / 1.5;
    }
    if (h / w <= 1.53)
    {
        ratioAnhSang = ratioAnhSang * 2;
        //ytitle = 1.3 * h - (anhSangPhiThuyen_2->getContentSize().height / 2 * scalebgColor);
    }
    
    float scaleAnhSang = w / ratioAnhSang / anhSangPhiThuyen_2->getContentSize().width;
    anhSangPhiThuyen_2->setScale(scaleAnhSang);

    float yAnhSang = phithuyenHienThi2->getPositionY() - phithuyenHienThi2->getContentSize().height * scalePhiThuyen / 2 - (anhSangPhiThuyen_2->getContentSize().height / 2 * scaleAnhSang) * 0.95;
    float xAnhSang = w/2;
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (anhSangPhiThuyen_2->getContentSize().height / 2 * scalebgColor);
    }
   
    anhSangPhiThuyen_2->setPosition(Vec2(xAnhSang, yAnhSang));
    anhSangPhiThuyen_2->setEnabled(true);
    this->addChild(anhSangPhiThuyen_2, 2);
    anhSangPhiThuyen_2->setOpacity(0);
    
    
}
void Play2::createBgColor(float w, float h) {
    //create bg color
    Sprite* bgColor = Sprite::create("bg13.jpg");
    float ratiobgColor = 1;
    float scalebgColor = h / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < w / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = w / ratiobgColor / bgColor->getContentSize().width;
    }
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    this->addChild(bgColor, 1);
    
    Sprite* bgColor2 = Sprite::create("bg13.jpg");
    bgColor2->setScale(scalebgColor);
    bgColor2->setAnchorPoint(Vec2(0, 0));
    bgColor2->setPosition(Vec2(0, 0));
    this->addChild(bgColor2, 1);
    
    bgColor->setPosition(Vec2(0, 0));
    bgColor2->setPosition(Vec2(0, bgColor->getContentSize().height * scalebgColor));

    // Tạo hành động di chuyển
 
    float duration = 8.0f; // Thời gian di chuyển từ một bên sang bên kia
    MoveBy* moveByAction = MoveBy::create(duration, Vec2(0, -h));
    bgColor->runAction(RepeatForever::create(Sequence::create(moveByAction, MoveTo::create(0, Vec2(0, h)), nullptr)));
    bgColor2->runAction(RepeatForever::create(Sequence::create(moveByAction->clone(), MoveTo::create(0, Vec2(0,  h - bgColor->getContentSize().height * scalebgColor)), nullptr)));

    
}
void Play2::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathLevel::createScene(typeOfW2), Color3B().WHITE));
}

void Play2::coundownTimer(float w, float h){
    switch (levelOfW2)
    {
        case 1:
            timeRemaining2 = Variable().timeBasic;
            timeMax2 = Variable().timeBasic;
            if (typeOfW2 == 3 || typeOfW2 == 2) {
                timeRemaining2 = Variable().timeBasicNhan;
                timeMax2 = Variable().timeBasicNhan;
            }
            break;
        case 2:
            timeRemaining2 = Variable().timeHard;
            timeMax2 = Variable().timeHard;
            if (typeOfW2 == 3 || typeOfW2 == 2) {
                timeRemaining2 = Variable().timeHardNhan;
                timeMax2 = Variable().timeHardNhan;
            }
            break;
        case 3:
            timeRemaining2 = Variable().timeVeryHard;
            timeMax2 = Variable().timeVeryHard;
            if (typeOfW2 == 3 || typeOfW2 == 2) {
                timeRemaining2 = Variable().timeVeryHardNhan;
                timeMax2 = Variable().timeVeryHardNhan;
            }
            break;
        default:
            timeRemaining2 = 20.f;
            timeMax2 = 20.f;
            break;
    }
    ratioLoadingBar_2 = 100 / timeRemaining2;
    this->scheduleUpdate();
}
void Play2::update(float dt) {
    // make sure game is still running
    if (timeRemaining2 > 0.f) {
        timeRemaining2 -= dt;
        if (isPause2 == true)
        {
            //log("da pause");
        }
        else{
            //log("loadingBar_2: %f", timeRemaining2 * ratioLoadingBar_2);
            loadingBar2_2->setPercent(timeRemaining2 * ratioLoadingBar_2);
            loadingBar1_2->setPercent(timeRemaining2 * ratioLoadingBar_2);
            loadingBar3_2->setPercent(timeRemaining2 * ratioLoadingBar_2);
            loadingBar4_2->setPercent(timeRemaining2 * ratioLoadingBar_2);
        }
        // update the label or whatever displays the time here. if displaying the number, use ceilf to round
        // up the time remaining so that you don't display lots of numbers after the decimal point

        // check if time ran out
        if (timeRemaining2 <= 0.f && isPause2 == false) {
            // timer ran out; react here

            handlerClickAnswer(33391);
            log("Het gio");
        }
    }
}


void Play2::createScore(float w, float h){
    score2String2 = cocos2d::__String::createWithFormat("%i", score2);//score2
    lblScore2 = Label::createWithTTF(score2String2->getCString(), "fonts/ComicNeue-Bold.ttf", 0.08 * w);
    if (h / w <= 1.53)
    {
        lblScore2 = Label::createWithTTF(score2String2->getCString(), "fonts/ComicNeue-Bold.ttf", 0.05 * w);
    }
    lblScore2->setColor(Color3B().WHITE);
    // position the label on the center of the screen
    float xScore = w - (lblScore2->getContentSize().width / 2 + 14);
    lblScore2->setPosition(Vec2(xScore, h - 6 - (lblScore2->getContentSize().height / 2)));
    // add the label as a child to this layer
    addChild(lblScore2, 11);
    
    //create score2Icon2
    score2Icon2 = ui::Button::create("gold.png"); // tao button
    score2Icon2->setTouchEnabled(false);
    float ratioscore2Icon2 = 10;
    float scaleI = 1;
    if (h / w <= 1.53)
    {
        ratioscore2Icon2 = 20;
        scaleI = 0.55;
        
    }
    float scalescore2Icon2 = w / ratioscore2Icon2 / score2Icon2->getContentSize().width;
    score2Icon2->setScale(scalescore2Icon2);
    score2Icon2->setAnchorPoint(Vec2({1, 0.5}));
    score2Icon2->setPosition(Vec2(lblScore2->getPositionX() - 3 - lblScore2->getContentSize().width / 2, h - 6 - (lblScore2->getContentSize().height / 2)));
    score2Icon2->setEnabled(true);
    this->addChild(score2Icon2, 11);
    
    //show lblscore2 with animation
    lblScore2->setOpacity(0);

    float valScale = 1.4;
    float time = 0.1;
    lblScore2->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, valScale), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, 1), FadeIn::create(time), nullptr), nullptr));

    score2Icon2->setOpacity(0);
    score2Icon2->runAction(Sequence::create(Spawn::create(ScaleTo::create(0, 1), FadeOut::create(0), nullptr), Spawn::create(ScaleTo::create(time, scaleI), FadeIn::create(time), nullptr), nullptr));
}
void Play2::createAnswer(float w, float h){
    log("tim random 4 so từ 2 -> 7");
    std::vector<int> randomNumbers = HuyFunctions().generateRandomNumbers();
    log("%i", randomNumbers[0]);
       
    float fontSize = 0.048 * w;
    auto bgDapAnNumber = "bg_dap_an_number.png";
    auto colorDapAnNumber = Color3B().WHITE;
    // ===============create dap an 1====================
    auto sprite_cacheButton1 = SpriteFrameCache::getInstance();
    sprite_cacheButton1->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d.plist", randomNumbers[0])); //"phithuyen02.plist");
    Vector<SpriteFrame*> sButton1;
    sButton1.reserve(2);
    sButton1.pushBack(sprite_cacheButton1->getSpriteFrameByName(StringUtils::format("phithuyen0%da.png", randomNumbers[0])));
    sButton1.pushBack(sprite_cacheButton1->getSpriteFrameByName(StringUtils::format("phithuyen0%db.png", randomNumbers[0])));
    Animation* animationButton1 = Animation::createWithSpriteFrames(sButton1, 0.3f, -1);
    Animate* animateButton1 = Animate::create(animationButton1);

    buttonAnswer1_2 = Sprite::createWithSpriteFrame(sButton1.front());
    buttonAnswer1_2->runAction(animateButton1);

    if (answer1_2 == correctAnswer2)
    {
        buttonAnswer1_2->setTag(1);
    }
    else
    {
        buttonAnswer1_2->setTag(0);
    }
    float ratioButtonAnswer1 = 4;
    if (h / w <= 1.53)
    {
        ratioButtonAnswer1 = 8;
        //fontSize = fontSize / 2;
    }
    
    scaleButtonAnswer1_2 = w / ratioButtonAnswer1 / buttonAnswer1_2->getContentSize().width;
    buttonAnswer1_2->setScale(scaleButtonAnswer1_2);
    float yButtonAnswer1 = 50 + buttonAnswer1_2->getContentSize().height / 2 * scaleButtonAnswer1_2;

    buttonAnswer1_2->setPosition(Vec2(w / 4 * 1.01, yButtonAnswer1));
    if (h / w <= 1.53)
    {
        buttonAnswer1_2->setPosition(Vec2(w / 2.5 - 20, yButtonAnswer1));
    }
    // Tạo một EventListener cảm ứng
    auto touchListener = EventListenerTouchOneByOne::create();
    touchListener->setSwallowTouches(true);

    // Gán hàm xử lý sự kiện
    touchListener->onTouchBegan = [=](Touch* touch, Event* event) {
        auto target = static_cast<Sprite*>(event->getCurrentTarget());
        Vec2 locationInNode = target->convertToNodeSpace(touch->getLocation());
        Size s = target->getContentSize();
        Rect rect = Rect(0, 0, s.width, s.height);

        if (rect.containsPoint(locationInNode)) {
            // Xử lý sự kiện khi Sprite được nhấn
            handlerClickAnswer(answer1_2);
            return true;
        }
        return false;
    };

    // Đăng ký EventListener với sprite
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(touchListener, buttonAnswer1_2);
    addChild(buttonAnswer1_2, 10);//add button vao scene

    //add answer 1 - number
    buttonAnswer1Number_2 = ui::Button::create(bgDapAnNumber); // tao button
    buttonAnswer1Number_2->setPressedActionEnabled(true);
    buttonAnswer1Number_2->setZoomScale(0);
    buttonAnswer1Number_2->setScale9Enabled(true);
    if (answer1_2 == correctAnswer2)
    {
        buttonAnswer1Number_2->setTag(1);
    }
    else
    {
        buttonAnswer1Number_2->setTag(0);
    }
    buttonAnswer1Number_2->setTouchEnabled(true);
    float ratioButtonAnswerNumber1_2 = 7;
    
    if (h / w <= 1.53)
    {
        ratioButtonAnswerNumber1_2 = 14;
        //fontSize = fontSize / 2;
    }
    scaleButtonAnswerNumber1_2 = w / ratioButtonAnswerNumber1_2 / buttonAnswer1Number_2->getContentSize().width;
    buttonAnswer1Number_2->setScale(scaleButtonAnswerNumber1_2);

    float yButtonAnswer1_2 = buttonAnswer1_2->getPosition().y - buttonAnswer1_2->getContentSize().height * scaleButtonAnswer1_2 / 2 - buttonAnswer1Number_2->getContentSize().height *  scaleButtonAnswerNumber1_2 / 2;

    buttonAnswer1Number_2->setPosition(Vec2(w / 4 * 1.01, yButtonAnswer1_2));
    if (h / w <= 1.53)
    {
        buttonAnswer1Number_2->setPosition(Vec2(w / 2.5 - 20, yButtonAnswer1_2));
    }
    buttonAnswer1Number_2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                handlerClickAnswer(answer1_2);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer1Number_2, 10);//add button vao scene
    auto answerString1_2 = cocos2d::__String::createWithFormat("%i", answer1_2);
    buttonAnswer1NumberLabel_2 = Label::createWithTTF(answerString1_2->getCString(), "fonts/NunitoSans-Bold.ttf", fontSize);
    buttonAnswer1NumberLabel_2->setColor(colorDapAnNumber);
    float xAsnswerLabel1_2 =  buttonAnswer1Number_2->getContentSize().width * scaleButtonAnswerNumber1_2 / 2 ;
    
    float yAsnswerLabel1_2 =  buttonAnswer1Number_2->getContentSize().width * scaleButtonAnswerNumber1_2 / 2 - buttonAnswer1NumberLabel_2->getContentSize().height / 2 - 2;
    
    if (h / w <= 1.53)
    {
        xAsnswerLabel1_2 = xAsnswerLabel1_2 + buttonAnswer1Number_2->getContentSize().width * scaleButtonAnswerNumber1_2 / 2 ;
        yAsnswerLabel1_2 =  yAsnswerLabel1_2 + buttonAnswer1Number_2->getContentSize().width * scaleButtonAnswerNumber1_2 / 2;
    }
    
    buttonAnswer1NumberLabel_2->setPosition(Vec2(xAsnswerLabel1_2, yAsnswerLabel1_2 ));
    buttonAnswer1Number_2->addChild(buttonAnswer1NumberLabel_2);
    
    //add loadingbar 1
    loadingBar1_2 = ui::LoadingBar::create("loading-small2.png");
    auto mySize = Vec2(buttonAnswer1_2->getPosition().x, buttonAnswer1_2->getPosition().y + buttonAnswer1_2->getContentSize().height * scaleButtonAnswer1_2 / 2 + 3);
    loadingBar1_2->setPosition(mySize);
    float scaleLoading = w / 6  / loadingBar1_2->getContentSize().width;
    if (h / w <= 1.53)
    {
        scaleLoading = w / 12  / loadingBar1_2->getContentSize().width;
    }
    loadingBar1_2->setScale(scaleLoading);
    loadingBar1_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBar1_2->setPercent(0);
    this->addChild(loadingBar1_2, 11);
    hLoadingBar_2 = loadingBar1_2->getContentSize().height * scaleLoading - 5;


    loadingBarWrap1_2 = ui::LoadingBar::create("wrap-loading-small2.png");
    loadingBarWrap1_2->setPosition(mySize);

    loadingBarWrap1_2->setScale(scaleLoading);
    loadingBarWrap1_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBarWrap1_2->setPercent(100);
    this->addChild(loadingBarWrap1_2, 10);
    // ===============create dap an 2====================
    auto sprite_cacheButton2 = SpriteFrameCache::getInstance();
    sprite_cacheButton2->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d.plist", randomNumbers[1])); //"phithuyen02.plist");
    Vector<SpriteFrame*> sButton2;
    sButton2.reserve(2);
    sButton2.pushBack(sprite_cacheButton2->getSpriteFrameByName(StringUtils::format("phithuyen0%da.png", randomNumbers[1])));
    sButton2.pushBack(sprite_cacheButton2->getSpriteFrameByName(StringUtils::format("phithuyen0%db.png", randomNumbers[1])));
    Animation* animationButton2 = Animation::createWithSpriteFrames(sButton2, 0.2f, -2);
    Animate* animateButton2 = Animate::create(animationButton2);

    buttonAnswer2_2 = Sprite::createWithSpriteFrame(sButton2.front());
    buttonAnswer2_2->runAction(animateButton2);

    if (answer2_2 == correctAnswer2)
    {
        buttonAnswer2_2->setTag(2);
    }
    else
    {
        buttonAnswer2_2->setTag(0);
    }
    float ratioButtonAnswer2 = 4;
    if (h / w <= 1.53)
    {
        ratioButtonAnswer2 = 7;
        fontSize = 0.045 * w;
    }
    
    scaleButtonAnswer2_2 = w / ratioButtonAnswer2 / buttonAnswer2_2->getContentSize().width;
    buttonAnswer2_2->setScale(scaleButtonAnswer2_2);
    float yButtonAnswer2 = 50 + buttonAnswer2_2->getContentSize().height / 2 * scaleButtonAnswer2_2;

    buttonAnswer2_2->setPosition(Vec2(w * 3 / 4 * 0.95, yButtonAnswer2));
    if (h / w <= 1.53)
    {
        buttonAnswer2_2->setPosition(Vec2(w / 2.5 + 20 + buttonAnswer2_2->getContentSize().width * scaleButtonAnswer2_2, yButtonAnswer2));
    }
    // Tạo một EventListener cảm ứng
    auto touchListener2 = EventListenerTouchOneByOne::create();
    touchListener2->setSwallowTouches(true);

    // Gán hàm xử lý sự kiện
    touchListener2->onTouchBegan = [=](Touch* touch, Event* event) {
        auto target = static_cast<Sprite*>(event->getCurrentTarget());
        Vec2 locationInNode = target->convertToNodeSpace(touch->getLocation());
        Size s = target->getContentSize();
        Rect rect = Rect(0, 0, s.width, s.height);

        if (rect.containsPoint(locationInNode)) {
            // Xử lý sự kiện khi Sprite được nhấn
            handlerClickAnswer(answer2_2);
            return true;
        }
        return false;
    };

    // Đăng ký EventListener với sprite
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(touchListener2, buttonAnswer2_2);

    addChild(buttonAnswer2_2, 10);//add button vao scene

    //add answer 2 - number
    buttonAnswer2Number_2 = ui::Button::create(bgDapAnNumber); // tao button
    buttonAnswer2Number_2->setPressedActionEnabled(true);
    buttonAnswer2Number_2->setZoomScale(0);
    buttonAnswer2Number_2->setScale9Enabled(true);
    if (answer2_2 == correctAnswer2)
    {
        buttonAnswer2Number_2->setTag(2);
    }
    else
    {
        buttonAnswer2Number_2->setTag(0);
    }
    buttonAnswer2Number_2->setTouchEnabled(true);
    float ratioButtonAnswerNumber2_2 = 7;
    
    if (h / w <= 1.53)
    {
        ratioButtonAnswerNumber2_2 = 14;
        fontSize = 0.045 * w;
    }
    scaleButtonAnswerNumber2_2 = w / ratioButtonAnswerNumber2_2 / buttonAnswer2Number_2->getContentSize().width;
    buttonAnswer2Number_2->setScale(scaleButtonAnswerNumber2_2);
    
    float yButtonAnswer2_2 = buttonAnswer2_2->getPosition().y - buttonAnswer2_2->getContentSize().height * scaleButtonAnswer2_2 / 2 - buttonAnswer2Number_2->getContentSize().height *  scaleButtonAnswerNumber2_2 / 2;

    buttonAnswer2Number_2->setPosition(Vec2(w * 3 / 4 * 0.95, yButtonAnswer2_2));
    if (h / w <= 1.53)
    {
        buttonAnswer2Number_2->setPosition(Vec2(w / 2.5 + 20 + buttonAnswer2_2->getContentSize().width * scaleButtonAnswer2_2, yButtonAnswer2_2));
    }
    buttonAnswer2Number_2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
               
                handlerClickAnswer(answer2_2);

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 2 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer2Number_2, 10);//add button vao scene
    auto answerString2_2 = cocos2d::__String::createWithFormat("%i", answer2_2);
    buttonAnswer2NumberLabel_2 = Label::createWithTTF(answerString2_2->getCString(), "fonts/NunitoSans-Bold.ttf", fontSize);
    buttonAnswer2NumberLabel_2->setColor(colorDapAnNumber);
    
    float xAsnswerLabel2_2 =  buttonAnswer2Number_2->getContentSize().width * scaleButtonAnswerNumber2_2 / 2 ;
    
    float yAsnswerLabel2_2 =  buttonAnswer2Number_2->getContentSize().width * scaleButtonAnswerNumber2_2 / 2 - buttonAnswer2NumberLabel_2->getContentSize().height / 2 - 2;
    
    if (h / w <= 1.53)
    {
        xAsnswerLabel2_2 = xAsnswerLabel2_2 + buttonAnswer2Number_2->getContentSize().width * scaleButtonAnswerNumber2_2 / 2 ;
        yAsnswerLabel2_2 =  yAsnswerLabel2_2 + buttonAnswer2Number_2->getContentSize().width * scaleButtonAnswerNumber2_2 / 2;
    }
    
    buttonAnswer2NumberLabel_2->setPosition(Vec2(xAsnswerLabel2_2, yAsnswerLabel2_2 ));
    buttonAnswer2Number_2->addChild(buttonAnswer2NumberLabel_2);
    
    //add loadingbar 1
    loadingBar2_2 = ui::LoadingBar::create("loading-small2.png");

auto mySize2 = Vec2(buttonAnswer2_2->getPosition().x, buttonAnswer2_2->getPosition().y + buttonAnswer2_2->getContentSize().height * scaleButtonAnswer2_2 / 2 + 3);
    loadingBar2_2->setPosition(mySize2);
   
    if (h / w <= 1.53)
    {
        scaleLoading = w / 12  / loadingBar2_2->getContentSize().width;
    }
    loadingBar2_2->setScale(scaleLoading);
    loadingBar2_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBar2_2->setPercent(0);
    this->addChild(loadingBar2_2, 12);
    hLoadingBar_2 = loadingBar2_2->getContentSize().height * scaleLoading - 5;

    loadingBarWrap2_2 = ui::LoadingBar::create("wrap-loading-small2.png");
    loadingBarWrap2_2->setPosition(mySize2);

    loadingBarWrap2_2->setScale(scaleLoading);
    loadingBarWrap2_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBarWrap2_2->setPercent(100);
    this->addChild(loadingBarWrap2_2, 10);
    
    // ===============create dap an 3====================
    auto sprite_cacheButton3 = SpriteFrameCache::getInstance();
    sprite_cacheButton3->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d.plist", randomNumbers[2])); //"phithuyen02.plist");
    Vector<SpriteFrame*> sButton3;
    sButton3.reserve(2);
    sButton3.pushBack(sprite_cacheButton3->getSpriteFrameByName(StringUtils::format("phithuyen0%da.png", randomNumbers[2])));
    sButton3.pushBack(sprite_cacheButton3->getSpriteFrameByName(StringUtils::format("phithuyen0%db.png", randomNumbers[2])));
    Animation* animationButton3 = Animation::createWithSpriteFrames(sButton3, 0.25f, -2);
    Animate* animateButton3 = Animate::create(animationButton3);

    buttonAnswer3_2 = Sprite::createWithSpriteFrame(sButton3.front());
    buttonAnswer3_2->runAction(animateButton3);

    if (answer3_2 == correctAnswer2)
    {
        buttonAnswer3_2->setTag(2);
    }
    else
    {
        buttonAnswer3_2->setTag(0);
    }
    float ratioButtonAnswer3 = 4;
    if (h / w <= 1.53)
    {
        ratioButtonAnswer3 = 7;
        fontSize = 0.045 * w;
    }
    
    scaleButtonAnswer3_2 = w / ratioButtonAnswer3 / buttonAnswer3_2->getContentSize().width;
    buttonAnswer3_2->setScale(scaleButtonAnswer3_2);
    
  
    
    float yButtonAnswer3 = yButtonAnswer1_2 + buttonAnswer3_2->getContentSize().height * scaleButtonAnswer3_2 * 2.5 + 20;

    buttonAnswer3_2->setPosition(Vec2(w / 4 * 1.01, yButtonAnswer3));
    if (h / w <= 1.53)
    {
        buttonAnswer3_2->setPosition(Vec2(w / 2.5 - 40, yButtonAnswer3));
    }
    // Tạo một EventListener cảm ứng
    auto touchListener3 = EventListenerTouchOneByOne::create();
    touchListener3->setSwallowTouches(true);

    // Gán hàm xử lý sự kiện
    touchListener3->onTouchBegan = [=](Touch* touch, Event* event) {
        auto target = static_cast<Sprite*>(event->getCurrentTarget());
        Vec2 locationInNode = target->convertToNodeSpace(touch->getLocation());
        Size s = target->getContentSize();
        Rect rect = Rect(0, 0, s.width, s.height);

        if (rect.containsPoint(locationInNode)) {
            // Xử lý sự kiện khi Sprite được nhấn
            handlerClickAnswer(answer3_2);
            return true;
        }
        return false;
    };

    // Đăng ký EventListener với sprite
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(touchListener3, buttonAnswer3_2);

    addChild(buttonAnswer3_2, 10);//add button vao scene

    //add answer 3 - number
    buttonAnswer3Number_2 = ui::Button::create(bgDapAnNumber); // tao button
    buttonAnswer3Number_2->setPressedActionEnabled(true);
    buttonAnswer3Number_2->setZoomScale(0);
    buttonAnswer3Number_2->setScale9Enabled(true);
    if (answer3_2 == correctAnswer2)
    {
        buttonAnswer3Number_2->setTag(2);
    }
    else
    {
        buttonAnswer3Number_2->setTag(0);
    }
    buttonAnswer3Number_2->setTouchEnabled(true);
    float ratioButtonAnswerNumber3_2 = 7;
    
    if (h / w <= 1.53)
    {
        ratioButtonAnswerNumber3_2 = 14;
        fontSize = 0.045 * w;
    }
    scaleButtonAnswerNumber3_2 = w / ratioButtonAnswerNumber3_2 / buttonAnswer3Number_2->getContentSize().width;
    buttonAnswer3Number_2->setScale(scaleButtonAnswerNumber3_2);

    float yButtonAnswer3_2 = buttonAnswer3_2->getPosition().y - buttonAnswer3_2->getContentSize().height * scaleButtonAnswer3_2 / 2 - buttonAnswer3Number_2->getContentSize().height *  scaleButtonAnswerNumber3_2 / 2;

    buttonAnswer3Number_2->setPosition(Vec2(w / 4 * 1.01, yButtonAnswer3_2));
    if (h / w <= 1.53)
    {
        buttonAnswer3Number_2->setPosition(Vec2(w / 2.5 - 20, yButtonAnswer3_2));
    }
    buttonAnswer3Number_2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
               
                handlerClickAnswer(answer3_2);

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 3 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer3Number_2, 10);//add button vao scene
    auto answerString3_2 = cocos2d::__String::createWithFormat("%i", answer3_2);
    buttonAnswer3NumberLabel_2 = Label::createWithTTF(answerString3_2->getCString(), "fonts/NunitoSans-Bold.ttf", fontSize);
    buttonAnswer3NumberLabel_2->setColor(colorDapAnNumber);
    float xAsnswerLabel3_2 =  buttonAnswer3Number_2->getContentSize().width * scaleButtonAnswerNumber3_2 / 2 ;
    
    float yAsnswerLabel3_2 =  buttonAnswer3Number_2->getContentSize().width * scaleButtonAnswerNumber3_2 / 2 - buttonAnswer3NumberLabel_2->getContentSize().height / 2 - 2;
    if (h / w <= 1.53)
    {
        xAsnswerLabel3_2 = xAsnswerLabel3_2 + buttonAnswer3Number_2->getContentSize().width * scaleButtonAnswerNumber3_2 / 2 ;
        yAsnswerLabel3_2 =  yAsnswerLabel3_2 + buttonAnswer3Number_2->getContentSize().width * scaleButtonAnswerNumber3_2 / 2;
    }
    
    buttonAnswer3NumberLabel_2->setPosition(Vec2(xAsnswerLabel3_2, yAsnswerLabel3_2 ));
    buttonAnswer3Number_2->addChild(buttonAnswer3NumberLabel_2);
    
    //add loadingbar 3
    loadingBar3_2 = ui::LoadingBar::create("loading-small2.png");

    auto mySize3 = Vec2(buttonAnswer3_2->getPosition().x, buttonAnswer3_2->getPosition().y + buttonAnswer3_2->getContentSize().height * scaleButtonAnswer3_2 / 2 + 3);
    loadingBar3_2->setPosition(mySize3);
   
    if (h / w <= 1.53)
    {
        scaleLoading = w / 12  / loadingBar3_2->getContentSize().width;
        
        
    }
    loadingBar3_2->setScale(scaleLoading);
    loadingBar3_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBar3_2->setPercent(0);
    this->addChild(loadingBar3_2, 12);
    hLoadingBar_2 = loadingBar3_2->getContentSize().height * scaleLoading - 5;
    loadingBarWrap3_2 = ui::LoadingBar::create("wrap-loading-small2.png");
    loadingBarWrap3_2->setPosition(mySize3);

    loadingBarWrap3_2->setScale(scaleLoading);
    loadingBarWrap3_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBarWrap3_2->setPercent(100);
    this->addChild(loadingBarWrap3_2, 10);
    
    
    // ===============create dap an 4====================
    auto sprite_cacheButton4 = SpriteFrameCache::getInstance();
    sprite_cacheButton4->addSpriteFramesWithFile(StringUtils::format("phithuyen0%d.plist", randomNumbers[3])); //"phithuyen02.plist");
    Vector<SpriteFrame*> sButton4;
    sButton4.reserve(2);
    sButton4.pushBack(sprite_cacheButton4->getSpriteFrameByName(StringUtils::format("phithuyen0%da.png", randomNumbers[3])));
    sButton4.pushBack(sprite_cacheButton4->getSpriteFrameByName(StringUtils::format("phithuyen0%db.png", randomNumbers[3])));
    Animation* animationButton4 = Animation::createWithSpriteFrames(sButton4, 0.15f, -2);
    Animate* animateButton4 = Animate::create(animationButton4);

    buttonAnswer4_2 = Sprite::createWithSpriteFrame(sButton4.front());
    buttonAnswer4_2->runAction(animateButton4);

    if (answer4_2 == correctAnswer2)
    {
        buttonAnswer4_2->setTag(2);
    }
    else
    {
        buttonAnswer4_2->setTag(0);
    }
    float ratioButtonAnswer4 = 4;
    if (h / w <= 1.53)
    {
        ratioButtonAnswer4 = 7;
        fontSize = 0.045 * w;
    }
    
    scaleButtonAnswer4_2 = w / ratioButtonAnswer4 / buttonAnswer4_2->getContentSize().width;
    buttonAnswer4_2->setScale(scaleButtonAnswer4_2);
    float yButtonAnswer4 = yButtonAnswer1_2 + buttonAnswer4_2->getContentSize().height * scaleButtonAnswer4_2 * 2.5 + 20;

    buttonAnswer4_2->setPosition(Vec2(w * 3 / 4 * 0.95, yButtonAnswer4));
    if (h / w <= 1.53)
    {
        buttonAnswer4_2->setPosition(Vec2(w / 2.5 + 20 + buttonAnswer2_2->getContentSize().width * scaleButtonAnswer2_2, yButtonAnswer4));
    }
    // Tạo một EventListener cảm ứng
    auto touchListener4 = EventListenerTouchOneByOne::create();
    touchListener4->setSwallowTouches(true);

    // Gán hàm xử lý sự kiện
    touchListener4->onTouchBegan = [=](Touch* touch, Event* event) {
        auto target = static_cast<Sprite*>(event->getCurrentTarget());
        Vec2 locationInNode = target->convertToNodeSpace(touch->getLocation());
        Size s = target->getContentSize();
        Rect rect = Rect(0, 0, s.width, s.height);

        if (rect.containsPoint(locationInNode)) {
            // Xử lý sự kiện khi Sprite được nhấn
            handlerClickAnswer(answer4_2);
            return true;
        }
        return false;
    };

    // Đăng ký EventListener với sprite
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(touchListener4, buttonAnswer4_2);

    addChild(buttonAnswer4_2, 10);//add button vao scene

    //add answer 4 - number
    buttonAnswer4Number_2 = ui::Button::create(bgDapAnNumber); // tao button
    buttonAnswer4Number_2->setPressedActionEnabled(true);
    buttonAnswer4Number_2->setZoomScale(0);
    buttonAnswer4Number_2->setScale9Enabled(true);
    if (answer4_2 == correctAnswer2)
    {
        buttonAnswer4Number_2->setTag(2);
    }
    else
    {
        buttonAnswer4Number_2->setTag(0);
    }
    buttonAnswer4Number_2->setTouchEnabled(true);
    float ratioButtonAnswerNumber4_2 = 7;
    
    if (h / w <= 1.53)
    {
        ratioButtonAnswerNumber4_2 = 14;
        fontSize = 0.045 * w;
    }
    scaleButtonAnswerNumber4_2 = w / ratioButtonAnswerNumber4_2 / buttonAnswer4Number_2->getContentSize().width;
    buttonAnswer4Number_2->setScale(scaleButtonAnswerNumber4_2);
    
    float yButtonAnswer4_2 = buttonAnswer4_2->getPosition().y - buttonAnswer4_2->getContentSize().height * scaleButtonAnswer4_2 / 2 - buttonAnswer4Number_2->getContentSize().height *  scaleButtonAnswerNumber4_2 / 2;

    buttonAnswer4Number_2->setPosition(Vec2(w * 3 / 4 * 0.95, yButtonAnswer4_2));
    if (h / w <= 1.53)
    {
        buttonAnswer4Number_2->setPosition(Vec2(w / 2.5 + 20 + buttonAnswer2_2->getContentSize().width * scaleButtonAnswer2_2, yButtonAnswer4_2));
    }
    buttonAnswer4Number_2->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
               
                handlerClickAnswer(answer4_2);

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 4 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAnswer4Number_2, 10);//add button vao scene
    auto answerString4_2 = cocos2d::__String::createWithFormat("%i", answer4_2);
    buttonAnswer4NumberLabel_2 = Label::createWithTTF(answerString4_2->getCString(), "fonts/NunitoSans-Bold.ttf", fontSize);
    buttonAnswer4NumberLabel_2->setColor(colorDapAnNumber);
    float xAsnswerLabel4_2 =  buttonAnswer4Number_2->getContentSize().width * scaleButtonAnswerNumber4_2 / 2 ;
    
    float yAsnswerLabel4_2 =  buttonAnswer4Number_2->getContentSize().width * scaleButtonAnswerNumber4_2 / 2 - buttonAnswer4NumberLabel_2->getContentSize().height / 2 - 2;
    
    if (h / w <= 1.53)
    {
        xAsnswerLabel4_2 = xAsnswerLabel4_2 + buttonAnswer4Number_2->getContentSize().width * scaleButtonAnswerNumber4_2 / 2 ;
        yAsnswerLabel4_2 =  yAsnswerLabel4_2 + buttonAnswer4Number_2->getContentSize().width * scaleButtonAnswerNumber4_2 / 2;
    }
    buttonAnswer4NumberLabel_2->setPosition(Vec2(xAsnswerLabel4_2, yAsnswerLabel4_2 ));
    buttonAnswer4Number_2->addChild(buttonAnswer4NumberLabel_2);
    
    //add loadingbar 1
    loadingBar4_2 = ui::LoadingBar::create("loading-small2.png");

    auto mySize4 = Vec2(buttonAnswer4_2->getPosition().x, buttonAnswer4_2->getPosition().y + buttonAnswer4_2->getContentSize().height * scaleButtonAnswer4_2 / 2 + 4);
    loadingBar4_2->setPosition(mySize4);
   
    if (h / w <= 1.53)
    {
        scaleLoading = w / 12  / loadingBar4_2->getContentSize().width;
    }
    loadingBar4_2->setScale(scaleLoading);
    loadingBar4_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBar4_2->setPercent(0);
    this->addChild(loadingBar4_2, 12);
    hLoadingBar_2 = loadingBar4_2->getContentSize().height * scaleLoading - 5;


    loadingBarWrap4_2 = ui::LoadingBar::create("wrap-loading-small2.png");
    loadingBarWrap4_2->setPosition(mySize4);

    loadingBarWrap4_2->setScale(scaleLoading);
    loadingBarWrap4_2->setDirection(ui::LoadingBar::Direction::LEFT);
    loadingBarWrap4_2->setPercent(100);
    this->addChild(loadingBarWrap4_2, 10);

    // ===============tim vi tri ngau nhien cho 4 dap an====================
    log("log play 2: go home");
    log("w/2: %f", w/2);
    log("h/2: %f", h/2);
    
    if (h / w <= 1.8)
    {
        h = h * 1.25;
    }
    
    float width1 = buttonAnswer1_2->getContentSize().width * scaleButtonAnswer1_2 / 2;
    float height1 = loadingBarWrap1_2->getPosition().y - buttonAnswer1Number_2->getPosition().y + buttonAnswer1Number_2->getContentSize().height * scaleButtonAnswerNumber1_2 / 2 + loadingBarWrap1_2->getContentSize().height * scaleLoading / 2;
    float x1 = cocos2d::RandomHelper::random_real(width1, w/2  - width1);
    float y1 = cocos2d::RandomHelper::random_real(height1, h/4  - height1);
    log("height1: %f", height1);
    log("x1: %f", x1);
    log("y1: %f", y1);
    
    float width2 = buttonAnswer2_2->getContentSize().width * scaleButtonAnswer2_2 / 2;
    float height2 = loadingBarWrap2_2->getPosition().y - buttonAnswer2Number_2->getPosition().y + buttonAnswer2Number_2->getContentSize().height * scaleButtonAnswerNumber2_2 / 2 + loadingBarWrap2_2->getContentSize().height * scaleLoading / 2;
    float x2 = cocos2d::RandomHelper::random_real(w/2 + width2, w  - width2);
    float y2 = cocos2d::RandomHelper::random_real(height2, h/4  - height2);
    
    float width3 = buttonAnswer3_2->getContentSize().width * scaleButtonAnswer3_2 / 2;
    float height3 = loadingBarWrap3_2->getPosition().y - buttonAnswer3Number_2->getPosition().y + buttonAnswer3Number_2->getContentSize().height * scaleButtonAnswerNumber3_2 / 2 + loadingBarWrap3_2->getContentSize().height * scaleLoading / 2;
    float x3 = cocos2d::RandomHelper::random_real(width3, w/2  - width3);
    float y3 = cocos2d::RandomHelper::random_real(h/4 + height3, h/2  - height3);
    
    float width4 = buttonAnswer4_2->getContentSize().width * scaleButtonAnswer4_2 / 2;
    float height4 = loadingBarWrap4_2->getPosition().y - buttonAnswer4Number_2->getPosition().y + buttonAnswer4Number_2->getContentSize().height * scaleButtonAnswerNumber4_2 / 2 + loadingBarWrap4_2->getContentSize().height * scaleLoading / 2;
    float x4 = cocos2d::RandomHelper::random_real(w/2 + width4, w  - width4);
    float y4 = cocos2d::RandomHelper::random_real(h/4 + height4, h/2  - height4);
    
//    y1 = y1 + 70;
//    y2 = y2 + 70;
//    y3 = y3 + 50;
//    y4 = y4 + 50;
    
    buttonAnswer1_2->setPosition(Vec2(x1, y1));
    buttonAnswer1Number_2->setPosition(Vec2(x1, y1 - height1 / 2));
    log("yNumber1: %f", y1 - height1 / 2);
    if (h / w <= 1.53)
    {
        //buttonAnswer1Number_2->setPosition(Vec2(w / 2.5 - 20, yButtonAnswer1_2));
    }
    mySize = Vec2(buttonAnswer1_2->getPosition().x, buttonAnswer1_2->getPosition().y + buttonAnswer1_2->getContentSize().height * scaleButtonAnswer1_2 / 2 + 3);

    loadingBar1_2->setPosition(mySize);
    loadingBarWrap1_2->setPosition(mySize);
    
    buttonAnswer2_2->setPosition(Vec2(x2, y2));
    buttonAnswer2Number_2->setPosition(Vec2(x2, y2 - height2 / 2));
    mySize2 = Vec2(buttonAnswer2_2->getPosition().x, buttonAnswer2_2->getPosition().y + buttonAnswer2_2->getContentSize().height * scaleButtonAnswer2_2 / 2 + 3);
    loadingBar2_2->setPosition(mySize2);
    loadingBarWrap2_2->setPosition(mySize2);
    
    buttonAnswer3_2->setPosition(Vec2(x3, y3));
    buttonAnswer3Number_2->setPosition(Vec2(x3, y3 - height3 / 2));
    mySize3 = Vec2(buttonAnswer3_2->getPosition().x, buttonAnswer3_2->getPosition().y + buttonAnswer3_2->getContentSize().height * scaleButtonAnswer3_2 / 2 + 3);
    loadingBar3_2->setPosition(mySize3);
    loadingBarWrap3_2->setPosition(mySize3);
    
    buttonAnswer4_2->setPosition(Vec2(x4, y4));
    buttonAnswer4Number_2->setPosition(Vec2(x4, y4 - height4 / 2));
    mySize4 = Vec2(buttonAnswer4_2->getPosition().x, buttonAnswer4_2->getPosition().y + buttonAnswer4_2->getContentSize().height * scaleButtonAnswer4_2 / 2 + 3);
    loadingBar4_2->setPosition(mySize4);
    loadingBarWrap4_2->setPosition(mySize4);
    
    //=======================create bom 4 dap an
    auto sprite_cacheBom1 = SpriteFrameCache::getInstance();
    sprite_cacheBom1->addSpriteFramesWithFile("bom-tim.plist");
    Vector<SpriteFrame*> bom1;
    bom1.reserve(12);
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("1.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("2.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("3.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("4.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("5.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("6.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("7.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("8.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("9.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("10.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("11.png"));
    bom1.pushBack(sprite_cacheBom1->getSpriteFrameByName("12.png"));
    Animation* animationBom1 = Animation::createWithSpriteFrames(bom1, 0.05f, -1);
    Animate* animateBom1 = Animate::create(animationBom1);

    bomAnswer1_2 = Sprite::createWithSpriteFrame(bom1.front());
    float ratioBom1 = 5;
    float scaleBom1 = w / ratioBom1 / bomAnswer1_2->getContentSize().width;
    bomAnswer1_2->setScale(scaleBom1);
    bomAnswer1_2->setPosition(Vec2(buttonAnswer1_2->getPositionX(), buttonAnswer1_2->getPositionY()));
    bomAnswer1_2->runAction(animateBom1);
    addChild(bomAnswer1_2, 11);
    bomAnswer1_2->setOpacity(0);
    
    auto sprite_cacheBom2 = SpriteFrameCache::getInstance();
    sprite_cacheBom2->addSpriteFramesWithFile("bom-tim.plist");
    Vector<SpriteFrame*> bom2;
    bom2.reserve(12);
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("1.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("2.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("3.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("4.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("5.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("6.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("7.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("8.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("9.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("10.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("11.png"));
    bom2.pushBack(sprite_cacheBom2->getSpriteFrameByName("12.png"));
    Animation* animationBom2 = Animation::createWithSpriteFrames(bom2, 0.05f, -1);
    Animate* animateBom2 = Animate::create(animationBom2);

    bomAnswer2_2 = Sprite::createWithSpriteFrame(bom2.front());
    float ratioBom2 = 5;
    float scaleBom2 = w / ratioBom2 / bomAnswer2_2->getContentSize().width;
    bomAnswer2_2->setScale(scaleBom2);
    bomAnswer2_2->setPosition(Vec2(buttonAnswer2_2->getPositionX(), buttonAnswer2_2->getPositionY()));
    bomAnswer2_2->runAction(animateBom2);
    addChild(bomAnswer2_2, 11);
    bomAnswer2_2->setOpacity(0);
    
    auto sprite_cacheBom3 = SpriteFrameCache::getInstance();
    sprite_cacheBom3->addSpriteFramesWithFile("bom-tim.plist");
    Vector<SpriteFrame*> bom3;
    bom3.reserve(12);
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("1.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("2.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("3.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("4.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("5.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("6.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("7.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("8.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("9.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("10.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("11.png"));
    bom3.pushBack(sprite_cacheBom3->getSpriteFrameByName("12.png"));
    Animation* animationBom3 = Animation::createWithSpriteFrames(bom3, 0.05f, -1);
    Animate* animateBom3 = Animate::create(animationBom3);

    bomAnswer3_2 = Sprite::createWithSpriteFrame(bom3.front());
    float ratioBom3 = 5;
    float scaleBom3 = w / ratioBom3 / bomAnswer3_2->getContentSize().width;
    bomAnswer3_2->setScale(scaleBom3);
    bomAnswer3_2->setPosition(Vec2(buttonAnswer3_2->getPositionX(), buttonAnswer3_2->getPositionY()));
    bomAnswer3_2->runAction(animateBom3);
    addChild(bomAnswer3_2, 11);
    bomAnswer3_2->setOpacity(0);
    auto sprite_cacheBom4 = SpriteFrameCache::getInstance();
    sprite_cacheBom4->addSpriteFramesWithFile("bom-tim.plist");
    Vector<SpriteFrame*> bom4;
    bom4.reserve(12);
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("1.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("2.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("3.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("4.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("5.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("6.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("7.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("8.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("9.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("10.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("11.png"));
    bom4.pushBack(sprite_cacheBom4->getSpriteFrameByName("12.png"));
    Animation* animationBom4 = Animation::createWithSpriteFrames(bom4, 0.05f, -1);
    Animate* animateBom4 = Animate::create(animationBom4);

    bomAnswer4_2 = Sprite::createWithSpriteFrame(bom4.front());
    float ratioBom4 = 5;
    float scaleBom4 = w / ratioBom4 / bomAnswer4_2->getContentSize().width;
    bomAnswer4_2->setScale(scaleBom4);
    bomAnswer4_2->setPosition(Vec2(buttonAnswer4_2->getPositionX(), buttonAnswer4_2->getPositionY()));
    bomAnswer4_2->runAction(animateBom4);
    addChild(bomAnswer4_2, 11);
    bomAnswer4_2->setOpacity(0);
    
    if (strcmp(loaiPhepTinh->getCString(), "ss") == 0) {
        phepTinhSoSanh1 = true;
        
        if (buttonAnswer1NumberLabel_2->getString() == "1") {
            
            buttonAnswer1NumberLabel_2->setString("v");
            buttonAnswer2NumberLabel_2->setString("x");
        }else{
            buttonAnswer1NumberLabel_2->setString("x");
            buttonAnswer2NumberLabel_2->setString("v");
        }
//        buttonAnswer1_2->setTitleText("");
//        buttonAnswer2_2->setTitleText("");
        buttonAnswer3_2->setVisible(false);
        buttonAnswer4_2->setVisible(false);
        loadingBar3_2->setVisible(false);
        loadingBar4_2->setVisible(false);
        loadingBarWrap3_2->setVisible(false);
        loadingBarWrap4_2->setVisible(false);
        buttonAnswer3Number_2->setVisible(false);
        buttonAnswer4Number_2->setVisible(false);
        
        //log("ban dang lam bai so sanh");
    }
}
void Play2::animationShowAnswer(cocos2d::ui::Button* button, float time, float scale){
    auto opButton1 = FadeOut::create(0);
    button->setOpacity(0);

    auto scaleButton1 = ScaleTo::create(0, scaleButtonAnswer1_2 * scale);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, scaleButtonAnswer1_2);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    auto sq = Sequence::create(sqButton1, sqB, nullptr);
    button->runAction(sq);
}
void Play2::hideAnswer1(float myDelay, float myTime){
    DelayTime *pauseButtonAnswer = DelayTime::create(myDelay);
    buttonAnswer1_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer1Number_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer1NumberLabel_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBarWrap1_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBar1_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
}
void Play2::hideAnswer2(float myDelay, float myTime){
    DelayTime *pauseButtonAnswer = DelayTime::create(myDelay);
    buttonAnswer2_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer2Number_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer2NumberLabel_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBarWrap2_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBar2_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
}
void Play2::hideAnswer3(float myDelay, float myTime){
    DelayTime *pauseButtonAnswer = DelayTime::create(myDelay);
    buttonAnswer3_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer3Number_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer3NumberLabel_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBarWrap3_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBar3_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
}

void Play2::hideAnswer4(float myDelay, float myTime){
    DelayTime *pauseButtonAnswer = DelayTime::create(myDelay);
    buttonAnswer4_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer4Number_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    buttonAnswer4NumberLabel_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBarWrap4_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
    loadingBar4_2->runAction(Sequence::create(pauseButtonAnswer, FadeOut::create(myTime), nullptr));
}
void Play2::handlerClickAnswer(int v){
    this->unscheduleUpdate();
    
    double scalePopup = 1;
    if (hScenePlay2 / wScenePlay2 <= 1.53)
    {
        scalePopup = 0.4;
    }
    int myTime = timeMax2 - timeRemaining2;
    int isCorrect = 0;
    if(v == correctAnswer2) {
        isCorrect = 1;
    }
    std::string ph = lblPhepToan2->getString().c_str();
    if (sapXepPhepTinhTheoChieuDoc) {
       ph = lblLoaiPhepTinh->getString().c_str();
    }
    sound2 = UserDefault::getInstance()->getIntegerForKey("sound", 0);

    buttonAnswer1Number_2->setTouchEnabled(false);
    buttonAnswer2Number_2->setTouchEnabled(false);
    buttonAnswer3Number_2->setTouchEnabled(false);
    buttonAnswer4Number_2->setTouchEnabled(false);
    this->getEventDispatcher()->removeEventListenersForTarget(buttonAnswer1_2);
    this->getEventDispatcher()->removeEventListenersForTarget(buttonAnswer2_2);
    this->getEventDispatcher()->removeEventListenersForTarget(buttonAnswer3_2);
    this->getEventDispatcher()->removeEventListenersForTarget(buttonAnswer4_2);

    
    //hide pheptoan
    float time = 0.2;
    float valScale = 1.4;
    if (v == correctAnswer2 || hasGuide == false)
    {
        lblPhepToan2->runAction(Spawn::create(ScaleTo::create(time, valScale), FadeOut::create(time), nullptr));
    }
    if (sapXepPhepTinhTheoChieuDoc) {
        gachChan->runAction(FadeOut::create(time));
        lblB->runAction(Spawn::create(ScaleTo::create(time, valScale), FadeOut::create(time), nullptr));
        lblLoaiPhepTinh->runAction(Spawn::create(ScaleTo::create(time, valScale), FadeOut::create(time), nullptr));
        lblA->runAction(Spawn::create(ScaleTo::create(time, valScale), FadeOut::create(time), nullptr));
    }
    
    double timeHide = 0.8;
    if (v != correctAnswer2 && hasGuide == true) //loaiPhepTinh->getCString() == std::string("+")
    {

        if (levelOfW2 == 1) {
            if (typeOfW2 == 4) {
                createTemplateGuideLevel1Cong(wScenePlay2, hScenePlay2);
            } else if (typeOfW2 == 5) {
                createTemplateGuideLevel1Tru(wScenePlay2, hScenePlay2);
            } else if (typeOfW2 == 6) {
                hasGuide = false;
            }
        }else {
            if (typeOfW2 == 4) {
                createTemplateGuideLevel2Cong(wScenePlay2, hScenePlay2);
            }else if (typeOfW2 == 5) {
                createTemplateGuideLevel2Tru(wScenePlay2, hScenePlay2);
            }else if (typeOfW2 == 6) {
                createTemplateGuideLevel2SoSanh(wScenePlay2, hScenePlay2);
            }
        }
        
        timeHide = 0.9;
    }
    
    //hide score2
    lblScore2->runAction(Sequence::create(DelayTime::create(1.9), FadeOut::create(time), NULL));
    score2Icon2->runAction(Sequence::create(DelayTime::create(2.0), FadeOut::create(time), NULL));

    float time1  =  0.2;
    float time2  =  0.3;
    float time3  =  0.5;
    
    auto phiThuyenPosition = Vec2(phithuyenHienThi2->getPositionX(), phithuyenHienThi2->getPositionY() * 0.85);
    
    if (v == correctAnswer2 || hasGuide == false)
    {
        lblPhepToan2->runAction(Spawn::create(ScaleTo::create(time, valScale), FadeOut::create(time), nullptr));
    }
    
    
    if (correctAnswer2 == answer1_2) {
        bomAnswer2_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer3_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer4_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        hideAnswer2(time2, time);
        hideAnswer3(time2, time);
        hideAnswer4(time2, time);
        hideAnswer1(time2 * 10, time);
        
    }else if(correctAnswer2 == answer2_2)
    {
        bomAnswer1_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer3_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer4_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        hideAnswer1(time2, time);
        hideAnswer3(time2, time);
        hideAnswer4(time2, time);
        hideAnswer2(time2 * 10, time);
        
    }else if(correctAnswer2 == answer3_2)
    {
        bomAnswer2_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer1_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer4_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        hideAnswer2(time2, time);
        hideAnswer1(time2, time);
        hideAnswer4(time2, time);
        hideAnswer3(time2 * 10, time);
        
    }else{
        bomAnswer2_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer3_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        bomAnswer1_2->runAction(Sequence::create(DelayTime::create(time2/2), FadeTo::create(0.1, 255), DelayTime::create(0.4),FadeTo::create(0.05, 0), NULL));
        hideAnswer2(time2, time);
        hideAnswer3(time2, time);
        hideAnswer1(time2, time);
        hideAnswer4(time2 * 10, time);
    }
    
    if (v == correctAnswer2)
    {
        //auto dungLienTiep = HuyFunctions().saveSoPhepTinhDungLienTiep(true);
        auto dungMoiNgay = HuyFunctions().saveSoPhepTinhDungMoiNgay(true);
//        if (dungLienTiep != "") {
//            showMedal(wScenePlay2, hScenePlay2, dungLienTiep);
//        }
        if (dungMoiNgay != "") {
            showMedal(wScenePlay2, hScenePlay2, dungMoiNgay);
        }
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");
        }
        //tra loi dung
        timeRemaining2 = timeRemaining2 + 1;
        anhSangPhiThuyen_2->runAction(Sequence::create(DelayTime::create(0), FadeIn::create(time1), DelayTime::create(0.03 + time1 + time3), FadeOut::create(time1), NULL));
        
        //popupthanhCong->runAction(Sequence::create(DelayTime::create(1.3), Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr), ScaleTo::create(0.03, 0.94 * scalePopup),DelayTime::create(0.5), FadeTo::create(0.1, 0), NULL));
        popupthanhCong->runAction(
          Sequence::create(
               DelayTime::create(0.65),
               Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr),
               ScaleTo::create(0.03, 0.94 * scalePopup),DelayTime::create(0.05),
               Spawn::create(
                     MoveTo::create(1.3, Vec2(score2Icon2->getPositionX() + score2Icon2->getScale() * score2Icon2->getContentSize().width, score2Icon2->getPositionY())),
                     ScaleTo::create(1.3, scalePopup / 2.5),
                     nullptr),
               FadeTo::create(0.1, 0), NULL)
        );
        
        
        if (v == answer1_2) {
          
            buttonAnswer1Number_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer1NumberLabel_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBar1_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBarWrap1_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer1_2->runAction(Sequence::create(DelayTime::create(time1), RotateTo::create(0.03, 5), RotateTo::create(time1, -30), MoveTo::create(time3, phiThuyenPosition), FadeTo::create(time1, 0), NULL));
            
            
        }else if(v == answer2_2)
        {
           
            buttonAnswer2Number_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer2NumberLabel_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBar2_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBarWrap2_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer2_2->runAction(Sequence::create(DelayTime::create(time1), RotateTo::create(0.02, -5), RotateTo::create(time1, 30), MoveTo::create(time3, phiThuyenPosition), FadeTo::create(time1, 0), NULL));
        }else if(v == answer3_2)
        {
            
            buttonAnswer3Number_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer3NumberLabel_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBar3_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBarWrap3_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer3_2->runAction(Sequence::create(DelayTime::create(time1), RotateTo::create(0.02, 5), RotateTo::create(time1, -30), MoveTo::create(time3, phiThuyenPosition), FadeTo::create(time1, 0), NULL));
            
        }else{
            
            buttonAnswer4Number_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer4NumberLabel_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBar4_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            loadingBarWrap4_2->runAction(Sequence::create(DelayTime::create(0), FadeTo::create(time1, 0), NULL));
            buttonAnswer4_2->runAction(Sequence::create(DelayTime::create(time1), RotateTo::create(0.02, -5), RotateTo::create(time1, 30), MoveTo::create(time3, phiThuyenPosition), FadeTo::create(time1, 0), NULL));
        }
        
    }else{
        //tra loi sai
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/bom-no-cham.mp3");
        }
        if (correctAnswer2 == answer1_2) {
         buttonAnswer1_2->runAction(Sequence::create(DelayTime::create(0.1), ScaleBy::create(0.05, 1.2f), DelayTime::create(0.2),ScaleBy::create(0.05, 0.8f), NULL));
            
        }else if(correctAnswer2 == answer2_2)
        {
            buttonAnswer2_2->runAction(Sequence::create(DelayTime::create(0.1), ScaleBy::create(0.05, 1.2f), DelayTime::create(0.2),ScaleBy::create(0.05, 0.8f), NULL));
            
        }else if(correctAnswer2 == answer3_2)
        {
            buttonAnswer3_2->runAction(Sequence::create(DelayTime::create(0.1), ScaleBy::create(0.05, 1.2f), DelayTime::create(0.2),ScaleBy::create(0.05, 0.8f), NULL));
            
        }else{
            buttonAnswer4_2->runAction(Sequence::create(DelayTime::create(0.1), ScaleBy::create(0.05, 1.2f), DelayTime::create(0.2),ScaleBy::create(0.05, 0.8f), NULL));
        }
        
       
        popupthatBai->runAction(Sequence::create(DelayTime::create(0.7), Spawn::create(FadeTo::create(0.1, 255), ScaleTo::create(0.07, scalePopup), nullptr), ScaleTo::create(0.03, 0.94 * scalePopup),DelayTime::create(1), FadeTo::create(0.1, 0), NULL));

    }
    
    phithuyenHienThi2->runAction(Sequence::create(DelayTime::create(time1 + time2 + time3 + 0.1 + 0.1), Spawn::create(ScaleBy::create(time3, 0.05f, 0.05f),MoveTo::create(time3, Vec2(earth_2->getPositionX(), earth_2->getPositionY())), FadeTo::create(time3 * 2, 0), NULL),  NULL));
    
    earth_2->runAction(Sequence::create(DelayTime::create(time1 + time2 + time3 + 0.1 + 0.1 + 2 * time1 ), ScaleBy::create(0.2, 1.3f), FadeTo::create(0.2, 0), NULL));
    
    
    
    DelayTime *pause = DelayTime::create(2.3);


    if (v == correctAnswer2)
    {
        score2 = HuyFunctions().getKetQuaDiemSoNgauNhien(score2, Variable().diemNgauNhienPhepTinh.at(indexThemDiem), Variable().diemNgauNhien.at(indexThemDiem));
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound2/hit.mp3");
        }

        log("ban da tra loi dung");
        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(Play2::nextPlay, this)), NULL);
        runAction(sqBOver);
    }
    else{
        log("ban da tra loi sai");
        if (sound2 == 0)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound2/bom-no-cham.mp3");
            
            //runAction(Sequence::create(DelayTime::create(0.3), CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound2/bom-no.mp3"), NULL));
        }

        if (hasGuide) {
            pause = DelayTime::create(20000);
        }
        //isPause2 = false;
        //auto opaB = FadeOut::create(v);
        auto sqBOver = Sequence::create(pause, CCCallFuncN::create(CC_CALLBACK_0(Play2::moveSceneGameOver, this)), NULL);
        runAction(sqBOver);

        //::getInstance()->replaceScene(TransitionFade::create(0.5, Finish::createScene(score2, typeOfW2, levelOfW2), Color3B().WHITE));
    }
    
    
    if(phepTinhSoSanh1){  
        if (v == correctAnswer2) {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 9999, myTime, levelOfW2, score2);
        } else {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, 2222, myTime, levelOfW2, score2);
        }
    }else {
        if (sapXepPhepTinhTheoChieuDoc) {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, cocos2d::__String::createWithFormat("%d%s%d=?", soA, ph.c_str(), soB)->getCString(), v, myTime, levelOfW2, score2);
        } else {
            HuyFunctions().savePhepTinhToDataBase(isCorrect, ph, v, myTime, levelOfW2, score2);
        }
    }
}
void Play2::nextPlay()
{
    if (realType2 == 1)
    {
        typeOfW2 = cocos2d::RandomHelper::random_int(2, 5);
    }
    removeChild(lblPhepToan2);
    if (sapXepPhepTinhTheoChieuDoc) {
        removeChild(lblB);
        removeChild(lblLoaiPhepTinh);
        removeChild(lblA);
        removeChild(gachChan);
    }
    
    removeChild(phithuyenHienThi2);
    removeChild(anhSangPhiThuyen_2);
    removeChild(earth_2);
    removeChild(lblScore2);
    removeChild(score2Icon2);
    
    removeChild(loadingBar1_2);
    removeChild(loadingBar2_2);
    removeChild(loadingBar3_2);
    removeChild(loadingBar4_2);
    removeChild(loadingBarWrap1_2);
    removeChild(loadingBarWrap2_2);
    removeChild(loadingBarWrap3_2);
    removeChild(loadingBarWrap4_2);
    
    removeChild(buttonAnswer1Number_2);
    removeChild(buttonAnswer2Number_2);
    removeChild(buttonAnswer3Number_2);
    removeChild(buttonAnswer4Number_2);
    
    removeChild(buttonAnswer1_2);
    removeChild(buttonAnswer2_2);
    removeChild(buttonAnswer3_2);
    removeChild(buttonAnswer4_2);
    
    removeChild(bomAnswer1_2);
    removeChild(bomAnswer2_2);
    removeChild(bomAnswer3_2);
    removeChild(bomAnswer4_2);
    removeChild(popupthanhCong);
    removeChild(popupthatBai);

    /*
    //reset pause
    isPause2 = false;
    buttonPause2->loadTextureNormal("pause.png");
    */
    
    auto arr = CreatePhepToan().createAnswerQuestions(typeOfW2, levelOfW2, prevA2, prevB2, maxDoiSo2);
    
    auto arrNoti = CreatePhepToan().createAnswerQuestions(typeOfW2, levelOfW2, prevA2, prevB2, maxDoiSo2);
    UserDefault::getInstance()->setStringForKey("noti-title1", HuyFunctions().createPhepToanWithEmoji(arrNoti.at(2).c_str()));
    log("test improve function");
    //    0 - prevA
    //    1 - prevB
    //    2 - phepToan
    //    3 - correctAnswer
    //    4 - answer1
    //    5 - answer2
    //    6 - answer3
    //    7 - answer4
    prevA2 = std::stoi(arr.at(0));
    prevB2 = std::stoi(arr.at(1));
    phepTinhSmallA = arr.at(9);
    phepTinhSmallB = arr.at(10);
    loaiPhepTinh = cocos2d::__String::createWithFormat("%s", arr.at(8).c_str());
    sapXepPhepTinhTheoChieuDoc = CreatePhepToan().needPhepTinhTheoChieuDoc(loaiPhepTinh->getCString(), levelOfW2);
    soA = std::stoi(arr.at(0));
    soB = std::stoi(arr.at(1));
    if (sapXepPhepTinhTheoChieuDoc) {
        phepToan2 = cocos2d::__String::createWithFormat("?");//cocos2d::__String::createWithFormat("%s", arr.at(8).c_str())
       
        flagB1ChuSo = false;
        if (arr.at(1).size() < 2) {
            flagB1ChuSo = true;
        }
    } else {
        phepToan2 = cocos2d::__String::createWithFormat("%s", arr.at(2).c_str());
        
    }
    
    correctAnswer2 = std::stoi(arr.at(3));
    answer1_2 = std::stoi(arr.at(4));
    answer2_2 = std::stoi(arr.at(5));
    answer3_2 = std::stoi(arr.at(6));
    answer4_2 = std::stoi(arr.at(7));
    
    log("cau hoi: %s",  arr.at(2).c_str());
    log("4 dap an: %i, %i, %i, %i",  std::stoi(arr.at(4)), std::stoi(arr.at(5)), std::stoi(arr.at(6)), std::stoi(arr.at(7)));
    log("dap dung: %i",  std::stoi(arr.at(3)));
    
    indexThemDiem = HuyFunctions().getRandomForThemDiem(score2);
    
    coundownTimer(wScenePlay2, hScenePlay2);
    createScore(wScenePlay2, hScenePlay2);
    
    createMainTemplate(wScenePlay2, hScenePlay2);
    createTraiDatAndPhiThuyenTenLua(wScenePlay2, hScenePlay2);
    createAnswer(wScenePlay2, hScenePlay2);
    createPopupFinish(wScenePlay2, hScenePlay2);
}
void Play2::createTemplateGuideLevel2SoSanh(float w, float h) {
    lblPhepToan2->runAction(FadeOut::create(0.1));
    auto fontStyle = "fonts/DeliusSwashCaps.ttf";
    float fontSize = 0.18 * w;
    if (h / w > 1.53 && h / w <= 1.8){
        fontSize = 0.15 * w;
    }
    if (h / w <= 1.53)
    {
        fontSize = 0.09 * w;
    }

    float time = 0.2;
    float width = 50.0f;
    float xLblA = w / 4;
    float xLblB = 3 * w / 4;
    if (h / w <= 1.53)
    {
        xLblA = 3 * w / 8;
        xLblB = 5 * w / 8;
    }
    float delayTime = 2;
    float fixTimeCoNho = 0;
    
    lblA = Label::createWithTTF(phepTinhSmallA.c_str(), fontStyle, fontSize);
    
    lblA->setPosition(Vec2(xLblA, lblPhepToan2->getPositionY() + lblPhepToan2->getContentSize().height));
    addChild(lblA, 2);
    lblA->setAlignment(TextHAlignment:: CENTER);
    //lblA->setOpacity(0);
    lblA->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblB = Label::createWithTTF(phepTinhSmallB.c_str(), fontStyle, fontSize);
    
    lblB->setPosition(Vec2(xLblB, lblA->getPositionY()));
    addChild(lblB, 2);
    lblB->setAlignment(TextHAlignment:: CENTER);
    //lblB->setOpacity(0);
    lblB->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblAKetQua = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", soA)->getCString(), fontStyle, fontSize * 0.8);
    lblAKetQua->setPosition(Vec2(xLblA, lblA->getPositionY() - lblA->getContentSize().height));
    addChild(lblAKetQua, 2);
    lblAKetQua->setColor(Color3B::GREEN);
    lblAKetQua->setAlignment(TextHAlignment:: CENTER);
    lblAKetQua->setOpacity(0);
    lblAKetQua->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    lblBKetQua = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", soB)->getCString(), fontStyle, fontSize * 0.8);
    lblBKetQua->setPosition(Vec2(xLblB, lblAKetQua->getPositionY()));
    addChild(lblBKetQua, 2);
    lblBKetQua->setAlignment(TextHAlignment:: CENTER);
    lblBKetQua->setOpacity(0);
    lblBKetQua->setColor(Color3B::GREEN);
    lblBKetQua->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));

    auto ketQuaSoSanh = ">";
    if (soA < soB) {
        ketQuaSoSanh = "<";
    }else if ( soA == soB) {
        ketQuaSoSanh = "=";
    }
    lblPhepSoSanh1 = Label::createWithTTF(ketQuaSoSanh, fontStyle, fontSize * 0.8);
    lblPhepSoSanh1->setPosition(Vec2(w / 2, lblAKetQua->getPositionY()));
    addChild(lblPhepSoSanh1, 2);
    lblPhepSoSanh1->setAlignment(TextHAlignment:: CENTER);
    lblPhepSoSanh1->setColor(Color3B::YELLOW);
    lblPhepSoSanh1->setOpacity(0);
    lblPhepSoSanh1->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
        
    //animation cho hang don vi - phong to
    float timeAnimate = 0.2;

    lblA->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale()),
                         TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
    );
    lblAKetQua->runAction(
        Sequence::create(
            ScaleTo::create(0, 0),
            DelayTime::create(delayTime + 1 + timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1 - timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblB->getScale() * 0.8), nullptr)
            , NULL)
    );
    
    delayTime = delayTime + timeAnimate * 2 + 2;
    lblB->runAction(
        Sequence::create(
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale()),
                         TintTo::create(timeAnimate, Color3B::WHITE), nullptr)
            , NULL)
    );
    lblBKetQua->runAction(
        Sequence::create(
            ScaleTo::create(0, 0),
            DelayTime::create(delayTime + 1 +  timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 1.3), TintTo::create(timeAnimate, Color3B::GREEN), nullptr),
            DelayTime::create(1 - timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 0.8), nullptr)
            , NULL)
    );
    
    delayTime = delayTime + timeAnimate * 3 + 2;
    lblPhepSoSanh1->runAction(
        Sequence::create(
            ScaleTo::create(0, 0),
            DelayTime::create(delayTime),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale() * 0.8), TintTo::create(timeAnimate, Color3B::YELLOW), nullptr),
            DelayTime::create(1 - timeAnimate),
            Spawn::create(ScaleTo::create(timeAnimate, lblA->getScale()), MoveTo::create(timeAnimate, Vec2(w / 2, lblA->getPositionY())), nullptr)
            , NULL)
    );

    //2 button retry va OK
    auto buttonRetry = ui::Button::create("button-retry.png"); // tao button
    buttonRetry->setPressedActionEnabled(true);
    buttonRetry->setZoomScale(0);
    buttonRetry->setScale9Enabled(true);
    
    buttonRetry->setTouchEnabled(true);
    float ratiobuttonRetry = 4.5;
    //float fixHeightIpad = 1.8;
    if (h / w <= 1.53)
    {
        ratiobuttonRetry = 9;
        
        //fixHeightIpad = 1.2;
    }
    
    float scalebuttonRetry = w / ratiobuttonRetry / buttonRetry->getContentSize().width;
    buttonRetry->setScale(scalebuttonRetry);
    
    float ybuttonRetry = buttonRetry->getContentSize().height * scalebuttonRetry;
   
    buttonRetry->setPosition(Vec2(w / 4, ybuttonRetry));
    
    buttonRetry->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto clickedButton = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(clickedButton, [this, w, h, clickedButton](){
                    for (auto icon : listIcon) {
                        removeChild(icon);
                    }
                    for (auto b : listBgNumber) {
                        removeChild(b);
                    }
                    listIcon.clear();
                    listBgNumber.clear();
                    if (clickedButton) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                        auto remove = CallFunc::create([clickedButton]() {
                            clickedButton->removeFromParent();
                            log("Button đã bị xóa sau hiệu ứng!");
                        });
                        clickedButton->runAction(Sequence::create(scaleOut, remove, nullptr));
                    }
                    
                    if (buttonOK) {
                        auto scaleOut = ScaleTo::create(0.2f, 0); // Thu nhỏ Button
                       
                        buttonOK->runAction(Sequence::create(scaleOut, nullptr));
                        removeChild(lblA);
                        removeChild(lblAKetQua);
                        removeChild(lblB);
                        removeChild(lblBKetQua);
                        removeChild(lblPhepSoSanh1);
                    }
                    
                    if (hasGuide) {
                        createTemplateGuideLevel2SoSanh(wScenePlay2, hScenePlay2);
                    }
                });
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonRetry, 2);//add button vao scene
    
    buttonOK = ui::Button::create("okbutton.png"); // tao button
    buttonOK->setPressedActionEnabled(true);
    buttonOK->setZoomScale(0);
    buttonOK->setScale9Enabled(true);
    
    buttonOK->setTouchEnabled(true);
   
    buttonOK->setScale(scalebuttonRetry);
  
   
    buttonOK->setPosition(Vec2(3 * w / 4, ybuttonRetry));
    
    buttonOK->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound2 == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [this](){
                    moveSceneGameOver();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonOK, 2);//add button vao scene
    buttonOK->setScale(0);
    buttonRetry->setScale(0);
    buttonOK->runAction(Sequence::create(DelayTime::create(delayTime + 1), ScaleTo::create(0.3, scalebuttonRetry), NULL));//step1 + step2 + 0.2

    buttonRetry->runAction(Sequence::create(DelayTime::create(delayTime + 1), ScaleTo::create(0.3, scalebuttonRetry), NULL));
}
void Play2::createPopupFinish(float w, float h) {
    //int bgIndex = cocos2d::RandomHelper::random_int(1, 4);
    //popupthanhCong = ui::Button::create(StringUtils::format("popup-thanh-cong-%d.png", bgIndex)); // tao button
    auto imgNameThemDiem = Variable().diemNgauNhienImg.at(indexThemDiem);
    popupthanhCong = ui::Button::create(imgNameThemDiem.c_str());
    popupthanhCong->setTouchEnabled(false);
    float ratiopopupthanhCong = 3;
    if (h / w <= 1.53)
    {
        ratiopopupthanhCong = 7;
    }
    float scalepopupthanhCong = w / ratiopopupthanhCong / popupthanhCong->getContentSize().width;
    

    //log("ti le test: %f", scalepopupthanhCong);
    //log("ti le test theo w: %f", w / ratiopopupthanhCong / popupthanhCong->getContentSize().width);
    popupthanhCong->setScale(scalepopupthanhCong);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }

    Vec2 positionPopupThanhCong = Vec2(w/2, h * 0.89);
    if (h / w <= 1.53)
    {
        positionPopupThanhCong = Vec2(w * 2.8 / 4, h * 0.9);
    }

    popupthanhCong->setPosition(positionPopupThanhCong);

    popupthanhCong->setEnabled(true);
    this->addChild(popupthanhCong, 12);
    popupthanhCong->setOpacity(0);
    popupthanhCong->setScale(0.6);
    
    popupthatBai = ui::Button::create("popup-that-bai2-1.png"); // tao button
    popupthatBai->setTouchEnabled(false);
   

    
    popupthatBai->setScale(scalepopupthanhCong);
    if (h / w <= 1.8)
    {
        //ytitle = 1.06 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    if (h / w <= 1.53)
    {
        //ytitle = 1.3 * h - (popupthanhCong->getContentSize().height / 2 * scalepopupthanhCong);
    }
    //popupthanhCong->setPosition(Vec2(w / 2, ytitle));
    //popupthanhCong->setAnchorPoint(Vec2(0, 0));
    popupthatBai->setPosition(Vec2(w/2, h * 0.45));

    popupthatBai->setEnabled(true);
    this->addChild(popupthatBai, 12);
    popupthatBai->setOpacity(0);
    popupthatBai->setScale(0.8);
}
void Play2::showMedal(float wScene, float hScene, std::string medal){
    auto fixIpad = 1;
    if (hScene / wScene <= 1.53)
    {
        fixIpad = 2;
    }

    auto iconMedal = Sprite::create(medal);

    float ratioMedal = 6 * fixIpad;
    float scaleiconMedal = wScene / ratioMedal / iconMedal->getContentSize().width;

    // Vị trí giữa màn hình
    iconMedal->setPosition(Vec2(wScene / 2, hScene * 0.7));

    // Bắt đầu từ 0
    iconMedal->setScale(0.0f);
    iconMedal->setOpacity(0);

    this->addChild(iconMedal, 15);

    /// ===== ANIMATION =====

    // Move lên khi xuất hiện (30px)
    auto moveUp = MoveBy::create(0.2f, Vec2(0, 30 / fixIpad));

    // Scale từ 0 -> x1.3
    auto scaleUp = ScaleTo::create(0.2f, scaleiconMedal * 1.3);

    // Fade in
    auto fadeIn = FadeTo::create(0.2f, 255);

    // Scale + Fade + Move lên cùng lúc
    auto spawnIn = Spawn::create(scaleUp, fadeIn, moveUp, nullptr);

    // Giữ 1 chút
    auto delay = DelayTime::create(0.4f);

    // Move xuống nhẹ khi hide
    auto moveDown = MoveBy::create(0.6f, Vec2(0, -15 / fixIpad));

    // Fade out
    auto fadeOut = FadeOut::create(0.6f);

    // Fade + Move xuống cùng lúc khi hide
    auto spawnOut = Spawn::create(fadeOut, moveDown, nullptr);

    // Xóa sprite sau khi xong
    auto remove = RemoveSelf::create();

    // Chạy sequence
    iconMedal->runAction(
        Sequence::create(
            spawnIn,
            delay,
            spawnOut,
            remove,
            nullptr
        )
    );
}
void Play2::moveSceneGameOver()
{
    //kiem tra xem co show man hinh mua hang khong
    if (Variable().isProVer == false && score2 >= Variable().soDiemShowPro &&  UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) >= Variable().showProSauBaoNhieuLan) {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", 0);
        createBgPro(wScenePlay2, hScenePlay2);
    } else {
        UserDefault::getInstance()->setIntegerForKey("diemshowpro", UserDefault::getInstance()->getIntegerForKey("diemshowpro", 0) + 1);
        finish();
    }
    
    
}
void Play2::createMainTemplate(float w, float h){
    auto fontStyle = "fonts/DeliusSwashCaps.ttf";
    float fontSize = 0.16 * w;
    if (h / w > 1.53 && h / w <= 1.8){
        fontSize = 0.11 * w;
    }
    if (h / w <= 1.53)
    {
        fontSize = 0.07 * w;
    }
    lblPhepToan2 = Label::createWithTTF(phepToan2->getCString(), fontStyle, fontSize);
    lblPhepToan2->setColor(Color3B().WHITE);//Color3B().BLACK
    // position the label on the center of the screen
    
    lblPhepToan2->setPosition(Vec2(w / 2, h * 0.50));
    if (h / w > 1.53 && h / w <= 1.8){
        lblPhepToan2->setPosition(Vec2(w / 2, h * 0.65));
    }
    if (h / w <= 1.53)
    {
        lblPhepToan2->setPosition(Vec2(w / 2, h * 0.62));
    }
    // add the label as a child to this layer
    addChild(lblPhepToan2, 2);
    lblPhepToan2->setOpacity(0);
    float time = 0.2;
    lblPhepToan2->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
    
    if (sapXepPhepTinhTheoChieuDoc) {
        float width = 50.0f;
        float fixWithIpad = 1.0f;
        if (h / w <= 1.53)
        {
            fixWithIpad = 0.5f;
        }
        if (levelOfW2 > 1) {
            width = 70.0f;
        }
        float height = 3.0f * fixWithIpad;
        width = width * fixWithIpad;
        cocos2d::Vec2 origin(w / 2 - width / 2 - 13 * fixWithIpad, lblPhepToan2->getPositionY() + lblPhepToan2->getContentSize().height / 2);
        gachChan = HuyFunctions().createChuNhatBoGoc(width, height, origin);
        this->addChild(gachChan, 2);
        
        lblB = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", soB)->getCString(), fontStyle, fontSize);
        float xLblB = w / 2;
        lblB->setPosition(Vec2(xLblB, lblPhepToan2->getPositionY() + lblPhepToan2->getContentSize().height));
        addChild(lblB, 2);
        lblB->setOpacity(0);
        lblB->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
        
        lblLoaiPhepTinh = Label::createWithTTF(loaiPhepTinh->getCString(), fontStyle, fontSize);
        lblLoaiPhepTinh->setPosition(Vec2(w/2 - lblB->getContentSize().width / 2 - 13, lblB->getPositionY() + lblPhepToan2->getContentSize().height / 2));
        addChild(lblLoaiPhepTinh, 2);
        lblLoaiPhepTinh->setOpacity(0);
        lblLoaiPhepTinh->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
        
        lblA = Label::createWithTTF(cocos2d::__String::createWithFormat("%d", soA)->getCString(), fontStyle, fontSize);
        lblA->setPosition(Vec2(w / 2, lblLoaiPhepTinh->getPositionY() + lblLoaiPhepTinh->getContentSize().height / 2));
        addChild(lblA, 2);
        lblA->setOpacity(0);
        lblA->runAction(Sequence::create(FadeOut::create(0), FadeIn::create(time), nullptr));
        
        if (flagB1ChuSo) {
            xLblB = w / 2 + (lblA->getContentSize().width - lblB->getContentSize().width) / 2;
            lblB->setPosition(Vec2(xLblB, lblB->getPositionY()));
        }
    }
}
void Play2::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //log("Button setting");
                //redirect to previous scene
                
                HuyFunctions().animationClickedButton(button, [](){
                    if (Variable().isProduction == true) {
                        HuyFunctions().showAds();
                    }
                    if (fromChallenge2) {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, SelectGame::createScene(typeOfW2, levelOfW2), Color3B().WHITE));
                    } else {
                        Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(2, backTypePT2), Color3B().WHITE));
                    }
                    
                });

                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn, 2);//add button vao scene
}
void Play2::createValueKey(float w, float h){
    //valueKey
    auto valueK = cocos2d::__String::createWithFormat("%i", UserDefault::getInstance()->getIntegerForKey("KEY", 0));
    valueKey3_2 = Label::createWithTTF(valueK->getCString(), "fonts/ComicNeue-Bold.ttf", 0.06 * w);
    valueKey3_2->setColor(Color3B().BLACK);
    // position the label on the center of the
    auto btnHeightKey = valueKey3_2->getContentSize().height;
    auto btnWidthKey = valueKey3_2->getContentSize().width;
    yValueKey3_2 = h - (btnHeightKey / 2 + 5);
    xValueKey3_2 = w - (btnWidthKey / 2 + 5);
    valueKey3_2->setPosition(Vec2(xValueKey3_2, yValueKey3_2));
    // add the label as a child to this layer
    addChild(valueKey3_2);
}
void Play2::createButtonKey(float w, float h){
    createValueKey(w, h);
    auto btn = ui::Button::create("key1.png", "key-active.png"); // tao button
    float ratio = 14;
    auto btnWidth = btn->getContentSize().width;
    float scale = w / ratio / btnWidth;
    float xBtn = xValueKey3_2 - 7 - valueKey3_2->getContentSize().width / 2 - btn->getContentSize().width / 2 * scale;
    btn->setScale(scale);
    btn->setPosition(Vec2(xBtn, yValueKey3_2));
    btn->setEnabled(true);
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //code admob
                UserDefault::getInstance()->setIntegerForKey("KEY", UserDefault::getInstance()->getIntegerForKey("KEY", 0) + 1);
                //restart valueKey Label
                removeChild(valueKey3_2);
                createValueKey(Director::getInstance()->getVisibleSize().width, Director::getInstance()->getVisibleSize().height);
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
