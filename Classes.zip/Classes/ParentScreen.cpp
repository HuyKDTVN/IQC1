#include "ParentScreen.h"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include "HelloWorldScene.h"
#include "Huy_functions/HuyFunctions.hpp"
#include "Variable.hpp"
#include "mathSelect.h"
#include <string>
#include <SimpleAudioEngine.h>
#include <iostream>
#include <sstream>

USING_NS_CC;

float ratioManhinhParent;
int soundParent;
std::string fontBold;
std::string fontNormal;
Scene* ParentScreen::createScene()
{
    auto scene = Scene::create();
    auto layer = ParentScreen::create();
    scene->addChild(layer);
    return scene;
}

bool ParentScreen::init()
{
    if (!Layer::init())
    {
        return false;
    }
   
   Size visibleSize = Director::getInstance()->getVisibleSize();
   //Vec2 origin = Director::getInstance()->getVisibleOrigin();
   
   float wScene;
   float hScene;
   
   //khoi tao gia tri ban dau
   wScene = visibleSize.width;
   hScene = visibleSize.height;
   
    soundParent = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    
   ratioManhinhParent = hScene / wScene;
   auto appLang = UserDefault::getInstance()->getStringForKey("LANGUAGE", "en");
   CCLOG("App Lang: %s", appLang.c_str());
   fontBold = "fonts/Livvic-Black.ttf";
   fontNormal = "fonts/Livvic-Regular.ttf";
   if (appLang == "ja")
   {
      fontBold = "fonts/KosugiMaru.ttf";
      fontNormal = "fonts/KosugiMaru.ttf";
   }
   if (appLang == "zh")
   {
      fontBold = "fonts/MaShanZheng-Regular.ttf";
      fontNormal = "fonts/MaShanZheng-Regular.ttf";
   }
   if (appLang == "ko" || appLang == "ru" || appLang == "th" || appLang == "gr" || appLang == "hi" || appLang == "uk")
   {
      fontBold = "fonts/ArialUnicodeMS.ttf";
      fontNormal = "fonts/ArialUnicodeMS.ttf";
   }
   
   //set bg
   createBg(wScene, hScene);
   
   
   //back
   auto btn = ui::Button::create("back4.png"); // tao button
   float ratio = 10;
   if (ratioManhinhParent <= 1.53)
   {
       ratio = 17;
   }
   //CCLOG("Debug: 2");
   auto btnHeight = btn->getContentSize().height;
   auto btnWidth = btn->getContentSize().width;

   float scale = wScene / ratio / btnWidth;
   btn->setScale(scale);
   btn->setPosition(Vec2((btnWidth / 2 * scale + 13), hScene - (btnHeight / 2 * scale + 13)));
   btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
       switch (type)
       {
           case cocos2d::ui::Widget::TouchEventType::BEGAN:
               //CCLOG("Button setting");
               //redirect to previous scene
               Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
               break;
           case cocos2d::ui::Widget::TouchEventType::ENDED:
               //CCLOG("Button 1 clicked");
               break;
           default:
               break;
       }
   });
   addChild(btn, 3);//add button vao scene

    std::string myDate = UserDefault::getInstance()->getStringForKey("install-date", "");
    CCLOG("Mydate: %s", myDate.c_str());
    // Add your layer content here
   createTemplate(wScene, hScene);
    return true;
}
double ParentScreen::createDiemTungPhepTinh(std::string content, std::string type, float w, float h, float fixHeight,int thuTu, cocos2d::ui::ScrollView *parent) {
   float fontSize = 0.07 * w;
//   if (ratioManhinhParent <= 1.53)
//   {
//      fontSize = 0.035 * w;
//
//   }
   int step = 0;
   auto myColor = Color3B(138, 28, 0);
   auto imageName = "parent-o-vuong-nho-1.png";
   auto iconName = "congSmall.png";
   if(type == "-"){
      imageName = "parent-o-vuong-nho-2.png";
      step = 1;
      myColor = Color3B(33, 91, 113);
      iconName = "truSmall.png";
   }
   if(type == "x"){
      imageName = "parent-o-vuong-nho-3.png";
      step = 2;
      myColor = Color3B(0, 0, 0);
      iconName = "nhanSmall.png";
   }
   if(type == ":"){
      imageName = "parent-o-vuong-nho-4.png";
      step = 3;
      myColor = Color3B(77, 70, 248);
      iconName = "chiaSmaill.png";
   }
//   if (ratioManhinhParent <= 1.53)
//   {
//       //imageName = "bg-home-ipad.png";
//   }
   auto title = ui::Button::create(imageName); // tao button


   title->setTitleText(content);
    title->setTitleFontName("fonts/Livvic-Black.ttf");
   title->setTitleColor(myColor);
   
   title->setTitleAlignment(cocos2d::TextHAlignment::CENTER);
  
   title->setTouchEnabled(false);
   float ratiotitle = 5;
   float fixIpad = 0;
   if (ratioManhinhParent <= 1.53)
   {
       ratiotitle = 10;
       fontSize = 0.03 * w;
       fixIpad = w/5;
   }
   float scaletitle = w / ratiotitle / title->getContentSize().width;
   title->setScale(scaletitle);
   title->setTitleFontSize(fontSize / scaletitle);
   
   float x = fixIpad + title->getContentSize().width * scaletitle * step + title->getContentSize().width / 2 * scaletitle + 15 + 11.5 * step;
   
   title->setPosition(Vec2(x, fixHeight - (title->getContentSize().height / 2 * scaletitle)));
   title->setEnabled(true);
   parent->addChild(title);
   
   auto icon = ui::Button::create(iconName); // tao button
   icon->setTouchEnabled(false);
   float ratioIcon = 15;
   if (ratioManhinhParent <= 1.53)
   {
      ratioIcon = 30;
       //fontSize = 0.03 * w;
   }
   float scaleIcon = w / ratioIcon / icon->getContentSize().width;
   icon->setScale(scaleIcon);
   icon->setRotation(17);
   icon->setPosition(Vec2(x, fixHeight));
   icon->setEnabled(true);
   parent->addChild(icon);
   
    //animation
    auto opButton1 = FadeOut::create(0);
    title->setOpacity(0);
    
    
    DelayTime *pauseButtonAnswer = DelayTime::create(0.3 * (thuTu));
    float time = 0.5;
    auto scaleButton1 = ScaleTo::create(0, 1.5 * scaletitle);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, scaletitle);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    auto sq = Sequence::create(pauseButtonAnswer, sqButton1, sqB, nullptr);
    title->runAction(sq);
    
    icon->setOpacity(0);
    auto scaleButton2 = ScaleTo::create(0, 1.5 * scaleIcon);
    auto sqButton2 = Spawn::create(scaleButton2, opButton1, nullptr);
    auto scaleIconB = ScaleTo::create(time, scaleIcon);
    auto opaBIcon = FadeIn::create(time);
    auto sqBIcon = Spawn::create(scaleIconB, opaBIcon, nullptr);
    auto sqIcon = Sequence::create(pauseButtonAnswer, sqButton2, sqBIcon, nullptr);
    icon->runAction(sqIcon);
    
//    if (soundParent == 0)
//    {
//        this->runAction(Sequence::createWithTwoActions(DelayTime::create((0.6 * (i + 1))), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");; })));
//    }
   
   return fixHeight - title->getContentSize().height / 2 * scaletitle;
}
double ParentScreen::createTongPhepTinh(std::string content, std::string type, float w, float h, float fixHeight,int thuTu, cocos2d::ui::ScrollView *parent) {
   
   
   float fontSize = 0.075 * w;
   int step = 0;
   auto myColor = Color3B(33, 91, 113);
   auto imageName = "parent-o-vuong-to-1.png";

   if(type == "speed"){
      imageName = "parent-o-vuong-to-2.png";
      step = 1;
      myColor = Color3B(211, 84, 0);

   }
  
   if (ratioManhinhParent <= 1.53)
   {
       //imageName = "bg-home-ipad.png";
   }
   auto title = ui::Button::create(imageName); // tao button
   
   title->setTitleText(content);
    title->setTitleFontName("fonts/Livvic-Black.ttf");

   if(step == 1) {
       title->setTitleText(content + LanguageManager::getInstance()->getStringForKey("SECOND").c_str());
   }
   title->setTitleColor(myColor);
   
   title->setTitleAlignment(cocos2d::TextHAlignment::CENTER);
  
   title->setTouchEnabled(false);
   float ratiotitle = 2.4;
   float fixIpad = 0;
   float fixFontSubTitle = 0.35;
   if (ratioManhinhParent <= 1.53)
   {
       ratiotitle = 4.8;
       fontSize = 0.03 * w;
      fixIpad = w/5;
      fixFontSubTitle = 0.7;
   }
   float scaletitle = w / ratiotitle / title->getContentSize().width;
   title->setScale(scaletitle);
   title->setTitleFontSize(fontSize / scaletitle);
   
   
   float x = fixIpad + title->getContentSize().width / 2 * scaletitle + 15;
   if(step == 1) {
      x = w - x;
   }
   
   title->setPosition(Vec2(x, fixHeight - (title->getContentSize().height / 2 * scaletitle)));
   title->setEnabled(true);
    parent->addChild(title);

   auto label = title->getTitleLabel();
    float yT = title->getContentSize().height - label->getContentSize().height;
   label->setPosition(Vec2(label->getPosition().x, yT));
   
//   auto titleLabel = Label::createWithTTF(content, "fonts/arial.ttf", fontSize);
//   titleLabel->setColor(myColor);
//   titleLabel->setPosition(Vec2(titleLabel->getPositionÏ().x, 50));
//   title->setTitleLabel(titleLabel);
   
//   auto subtitleLabel = Label::createWithTTF("content1", "fonts/arial.ttf", fontSize * 0.3);
//   subtitleLabel->setColor(myColor);
//   subtitleLabel->setPosition(Vec2(label->getPosition().x, label->getPosition().y - 20));
//   title->setTitleLabel(subtitleLabel);

    auto subTitle = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("PHEPTINH").c_str(), fontNormal, fontSize * fixFontSubTitle);
    if(step == 1) {
        subTitle = Label::createWithTTF(LanguageManager::getInstance()->getStringForKey("SPEED").c_str(), fontNormal, fontSize * fixFontSubTitle);
    }
    subTitle->setColor(myColor);
    // position the label on the center of the screen


    subTitle->setPosition(Vec2(label->getPosition().x, yT - 18));

    subTitle->setAnchorPoint({0.5, 0.5});
    subTitle->setHorizontalAlignment(TextHAlignment::CENTER);
    // add the label as a child to this laye r
    title->addChild(subTitle);
    
    //animation
    auto opButton1 = FadeOut::create(0);
    title->setOpacity(0);
    
    
    DelayTime *pauseButtonAnswer = DelayTime::create(0.3 * (thuTu));
    float time = 0.4;
    auto scaleButton1 = ScaleTo::create(0, 1.2 * scaletitle);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, scaletitle);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    auto sq = Sequence::create(pauseButtonAnswer, sqButton1, sqB, nullptr);
    title->runAction(sq);
    
    subTitle->setOpacity(0);
    auto scaleButton2 = ScaleTo::create(0, 1.2 * 1);
    auto sqButton2 = Spawn::create(scaleButton2, opButton1, nullptr);
    auto scaleIconB = ScaleTo::create(time, 1);
    auto opaBIcon = FadeIn::create(time);
    auto sqBIcon = Spawn::create(scaleIconB, opaBIcon, nullptr);
    auto sqIcon = Sequence::create(pauseButtonAnswer, sqButton2, sqBIcon, nullptr);
    subTitle->runAction(sqIcon);
    
//    if (soundParent == 0)
//    {
//        this->runAction(Sequence::createWithTwoActions(DelayTime::create((0.6 * (i + 1))), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");; })));
//    }
    
   return fixHeight - title->getContentSize().height / 2 * scaletitle;
}
std::vector<std::string> split(std::string str, std::string separator) {
    std::vector<std::string> result;
    int cutAt;
    while( (cutAt = str.find_first_of(separator)) != str.npos ) {
        if(cutAt > 0) {
            result.push_back(str.substr(0, cutAt));
        }
        str = str.substr(cutAt + 1);
    }
    if(str.length() > 0) {
        result.push_back(str);
    }
    return result;
}

double ParentScreen::createPhepTinhGanNhat(float w, float h, float fixHeight, std::string data,int thuTu, cocos2d::ui::ScrollView *parent)  {
    auto arrData = split(data, "AA");
    log("data: %s", data.c_str());
    auto dataSize = arrData.size();
    if(dataSize > Variable().showSoPhepTinhParentScreen) {
        dataSize = Variable().showSoPhepTinhParentScreen;
    }
    float yTitle = createLabel(LanguageManager::getInstance()->getStringForKey("PHEPTINHGANNHAT").c_str(),fontBold, 0.06, w, h, fixHeight - 40, "center",Color3B(80, 80, 80),thuTu, parent);
    auto myColor = Color3B(80, 80, 80);
    auto colorCorrect = Color3B(1, 190, 148);
    auto colorWrong = Color3B(231, 61, 38);
    auto colorNoSelect = Color3B(199, 156, 0);
    float y = yTitle;
    for(unsigned int i = 0; i <= dataSize; i++)
    {
        if(i == 0) {
            createLabel(LanguageManager::getInstance()->getStringForKey("CAUHOI").c_str(),fontNormal, 0.04, w, h, yTitle - 20, "left", myColor,thuTu, parent);
            createLabel(LanguageManager::getInstance()->getStringForKey("TRALOI").c_str(),fontNormal, 0.04, w, h, yTitle - 20, "center", myColor,thuTu, parent);
            y = createLabel(LanguageManager::getInstance()->getStringForKey("TIME").c_str(), fontNormal, 0.04, w, h, yTitle - 20, "right", myColor,thuTu, parent);
        }else{
            auto arrPhepTinh = split(arrData[i-1], "_");
            
         
            auto cauTraLoi = arrPhepTinh[1].c_str();
            
            auto thoiGian = arrPhepTinh[3].c_str();
            if(arrPhepTinh[1].compare("0") == 0) {
                cauTraLoi = "";
                thoiGian = "";
                myColor = colorNoSelect;
            }else{
                if(arrPhepTinh[2].compare("0") == 0) {
                    myColor = colorWrong;
                }else{
                    myColor = colorCorrect;
                }
            }
            
            if (strcmp(cauTraLoi, "33391") == 0) {
                cauTraLoi = "";
            }
            if (strcmp(cauTraLoi, "9999") == 0) {
                cauTraLoi = "v";
            }
            if (strcmp(cauTraLoi, "2222") == 0) {
                cauTraLoi = "x";
            }
            
            y = createLabel(arrPhepTinh[0].c_str(),fontNormal, 0.04, w, h, yTitle - 20, "left", myColor, thuTu,parent);
            createLabel(cauTraLoi,fontNormal, 0.04, w, h, yTitle - 20, "center", myColor, thuTu, parent);
            createLabel(thoiGian, fontNormal, 0.04, w, h, yTitle - 20, "right", myColor,thuTu, parent);
        }
       float fixIpad = 0;
       if (ratioManhinhParent <= 1.53)
        {
           fixIpad = w / 5;
            
        }
        auto drawNode = DrawNode::create();
        drawNode->drawLine(Vec2(fixIpad + 15, y-5), Vec2(w - 15 - fixIpad, y-5), Color4F::BLACK);
        drawNode->setOpacity(10);
        parent->addChild(drawNode);
        //CCLOG("do cao moi cau hoi: %f - %f", y - yTitle, h/(y-yTitle));
        yTitle = y;
    }
    return fixHeight;
}
double ParentScreen::createLabel(std::string content, std::string fontName, float fontSize, float wScene, float hScene, float fixHeight, std::string position, cocos2d::Color3B myColor, int thuTu, cocos2d::ui::ScrollView *parent = cocos2d::ui::ScrollView::create()){
   
   float fontScore = fontSize * wScene;
   //float fontScore2 = 0.065 * w;
   
   if (ratioManhinhParent <= 1.53)
   {
       fontScore = fontSize * 0.6 * wScene;
   }
   
   auto valueHeightScore = Label::createWithTTF(content, fontName, fontScore);
   valueHeightScore->setColor(myColor);
   // position the label on the center of the screen
   float xValueScore = wScene / 2;
   float fixIpad = 0;
   if (hScene/ wScene <= 1.53)
   {
      fixIpad = wScene / 5;
       
   }
   if(position == "left") {
       xValueScore = fixIpad + 20 + valueHeightScore->getContentSize().width / 2;
   }
    if(position == "right") {
        xValueScore = wScene - fixIpad - 20 - valueHeightScore->getContentSize().width / 2;
    }

   valueHeightScore->setPosition(Vec2(xValueScore, fixHeight));
   valueHeightScore->setAnchorPoint({0.5, 0.5});
   valueHeightScore->setHorizontalAlignment(TextHAlignment::CENTER);
   // add the label as a child to this laye r
   if(parent->getContentSize().width != 0) {
       parent->addChild(valueHeightScore, 1);
   }else{
       addChild(valueHeightScore, 1);
   }
    
    //animation
    auto opButton1 = FadeOut::create(0);
    valueHeightScore->setOpacity(0);

    DelayTime *pauseButtonAnswer = DelayTime::create(0.6 * (thuTu));
    float time = 0.5;
    auto scaleButton1 = ScaleTo::create(0, 1 * 1);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, 1);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    auto sq = Sequence::create(pauseButtonAnswer, sqButton1, sqB, nullptr);
    valueHeightScore->runAction(sq);

//    if (soundParent == 0)
//    {
//        this->runAction(Sequence::createWithTwoActions(DelayTime::create((0.6 * (thuTu))), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");; })));
//    }
    
   return fixHeight - valueHeightScore->getContentSize().height / 2;
}
double ParentScreen::createStar(float wScene, float hScene, float fixHeight, int position, cocos2d::ui::ScrollView *parent = cocos2d::ui::ScrollView::create()) {
   auto start1 = ui::Button::create("star.png"); // tao button
   start1->setTouchEnabled(false);
   float ratioStar1 = 8;
   //CCLOG("h/w: %f", ratioManhinhParent);
   if (ratioManhinhParent <= 1.53)
   {
      ratioStar1 = 16;
       
   }
   
   float scaleStar1 = wScene / ratioStar1 / start1->getContentSize().width;
   start1->setScale(scaleStar1);
   
   float yStar1 = hScene - 10 - fixHeight - start1->getContentSize().height / 2 * scaleStar1;
   float xStar1 = wScene / 2;
   if (position == 1) {
      xStar1 = start1->getContentSize().width * scaleStar1 * 1.2;
      start1->setRotation(25);
      if (ratioManhinhParent <= 1.53)
      {
         xStar1 = start1->getContentSize().width * scaleStar1 * 3.6;
          
      }
   }
   if (position == 2) {
      xStar1 = wScene - start1->getContentSize().width * scaleStar1 * 1.2;
      start1->setRotation(-23);
      if (ratioManhinhParent <= 1.53)
      {
         xStar1 = wScene - start1->getContentSize().width * scaleStar1 * 3.6;
          
      }
   }
   start1->setPosition(Vec2( xStar1, yStar1));
   start1->setEnabled(true);
    if(parent->getContentSize().width != 0) {
        parent->addChild(start1);
    }else{
        addChild(start1);
    }

    //animation for star
    auto opButton1 = FadeOut::create(0);
    start1->setOpacity(0);
    
    DelayTime *pauseButtonAnswer = DelayTime::create(0.6 * (position + 1));
    float time = 0.2;
    auto scaleButton1 = ScaleTo::create(0, 0.3 * scaleStar1);
    auto sqButton1 = Spawn::create(scaleButton1, opButton1, nullptr);
    auto scaleTitleB = ScaleTo::create(time, 1.3 * scaleStar1);
    auto opaB = FadeIn::create(time);
    auto sqB = Spawn::create(scaleTitleB, opaB, nullptr);
    
    //auto sqC = Spawn::create(scaleTitleB, nullptr);
    auto sq = Sequence::create(pauseButtonAnswer, sqButton1, sqB, ScaleTo::create(0.1, scaleStar1), nullptr);
    start1->runAction(sq);
    
    if (soundParent == 0)
    {
        this->runAction(Sequence::createWithTwoActions(DelayTime::create((0.6 * (position + 1))), CallFunc::create([&](){ CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hit.mp3");; })));
    }
   
   return yStar1 - start1->getContentSize().height * scaleStar1 / 2;
}
void ParentScreen::createTwoButtonPlay(float wScene, float hScene) {
    

    //button PlayDual
    auto buttonPlayDual = ui::Button::create("home-bg-play2.png", "home-bg-play2.png"); // tao button
    float ratioButtonPlayDual = 3.66;
    if (ratioManhinhParent <= 1.53)
    {
        ratioButtonPlayDual = 7.32;

    }
    float scaleButtonPlayDual = wScene / ratioButtonPlayDual / buttonPlayDual->getContentSize().width;
    buttonPlayDual->setScale(scaleButtonPlayDual);
    float yButtonPlayDual = 0.35 * wScene;

    float xButtonPlayDual = wScene * 0.1 + buttonPlayDual->getContentSize().width / 2 * scaleButtonPlayDual;
    if (ratioManhinhParent <= 1.53)
    {
        xButtonPlayDual = wScene * 0.3 + buttonPlayDual->getContentSize().width / 2 * scaleButtonPlayDual;
        yButtonPlayDual = 0.2 * wScene;
    }


    buttonPlayDual->setPosition(Vec2(xButtonPlayDual, yButtonPlayDual));

    buttonPlayDual->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button

        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                if (soundParent == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //redirect to play
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(1, 0), Color3B().WHITE));
                break;
            default:
                break;
        }
    });
    addChild(buttonPlayDual);//add button vao scene

    //button PlayDual Icon
    auto buttonPlayDualIcon = ui::Button::create("dual-player.png", "dual-player.png"); // tao button
    float ratiobuttonPlayDualIcon = 5;
    if (ratioManhinhParent <= 1.53)
    {
        ratiobuttonPlayDualIcon = 10;

    }
    float scalebuttonPlayDualIcon = wScene / ratiobuttonPlayDualIcon / buttonPlayDualIcon->getContentSize().width;
    buttonPlayDualIcon->setScale(scalebuttonPlayDualIcon);

    buttonPlayDualIcon->setPosition(Vec2(xButtonPlayDual, yButtonPlayDual));

    buttonPlayDualIcon->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button

        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                if (soundParent == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //redirect to play
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(1, 0), Color3B().WHITE));
                break;
            default:
                break;
        }
    });
    addChild(buttonPlayDualIcon);//add button vao scene

    //button Play
    auto buttonPlay = ui::Button::create("home-bg-play1.png", "home-bg-play1.png"); // tao button
    float ratioButtonPlay = 2.1;
    if (ratioManhinhParent <= 1.53)
    {
        ratioButtonPlay = 4.2;

    }
    float scaleButtonPlay = wScene / ratioButtonPlay / buttonPlay->getContentSize().width;
    buttonPlay->setScale(scaleButtonPlay);
    float heightButtonPlay = 0.35 * wScene;

    float xButtonPlay = 0.9 * wScene - buttonPlay->getContentSize().width / 2 * scaleButtonPlay;
    if (ratioManhinhParent <= 1.53)
    {
        xButtonPlay = 0.7 * wScene - buttonPlay->getContentSize().width / 2 * scaleButtonPlay;
        heightButtonPlay = 0.2 * wScene;

    }

    buttonPlay->setPosition(Vec2(xButtonPlay, heightButtonPlay));
    buttonPlay->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                if (soundParent == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //redirect to play
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(0, 0), Color3B().WHITE));

                break;
            default:
                break;
        }

    });
    this->addChild(buttonPlay);//add button vao scene


    //button Play Icon
    auto buttonPlayIcon = ui::Button::create("play.png", "play.png"); // tao button
    float ratiobuttonPlayIcon = 12;
    if (ratioManhinhParent <= 1.53)
    {
        ratiobuttonPlayIcon = 24;

    }
    float scalebuttonPlayIcon = wScene / ratiobuttonPlayIcon / buttonPlayIcon->getContentSize().width;
    buttonPlayIcon->setScale(scalebuttonPlayIcon);


    buttonPlayIcon->setPosition(Vec2(xButtonPlay, heightButtonPlay));
    buttonPlayIcon->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                if (soundParent == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                CCLOG("Button 1 touch");
                //redirect to play
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, MathSelect::createScene(0, 0), Color3B().WHITE));
                break;
            default:
                break;
        }

    });
    this->addChild(buttonPlayIcon);//add button vao scene

    auto burrLeft = ui::Button::create("burr-left-tim.png"); // tao button
    burrLeft->setTouchEnabled(false);
    float ratioburrLeft = 5;
    float scaleburrLeft = wScene / ratioburrLeft / burrLeft->getContentSize().width;
    burrLeft->setScale(scaleburrLeft);

    float yburrLeft = hScene / 4 + (burrLeft->getContentSize().height / 2 * scaleburrLeft);
    burrLeft->setPosition(Vec2(burrLeft->getContentSize().width / 2 * scaleburrLeft, yburrLeft));
    burrLeft->setEnabled(true);
    this->addChild(burrLeft);


    auto burrRight = ui::Button::create("burr-right-xanh.png"); // tao button
    burrRight->setTouchEnabled(false);
    float ratioburrRight = 5;
    float scaleburrRight = wScene / ratioburrRight / burrRight->getContentSize().width;
    burrRight->setScale(scaleburrRight);

    float yburrRight = hScene * 2 / 3 - (burrRight->getContentSize().height / 2 * scaleburrRight);
    burrRight->setPosition(Vec2( wScene - burrRight->getContentSize().width / 2 * scaleburrRight, yburrRight));
    burrRight->setEnabled(true);
    this->addChild(burrRight);


    auto dot1 = ui::Button::create("cricle-xanh.png"); // tao button
    dot1->setTouchEnabled(false);
    float ratiodot1 = 38;
    if (ratioManhinhParent <= 1.53)
    {
        ratiodot1 = 76;

    }
    float scaledot1 = wScene / ratiodot1 / dot1->getContentSize().width;
    dot1->setScale(scaledot1);

    float ydot1 = yburrRight * 1.1;
    dot1->setPosition(Vec2(wScene /5, ydot1));
    dot1->setEnabled(true);
    this->addChild(dot1);


    auto dot2 = ui::Button::create("cricle-do.png"); // tao button
    dot2->setTouchEnabled(false);
    float ratiodot2 = 33;
    if (ratioManhinhParent <= 1.53)
    {
        ratiodot2 = 66;

    }
    float scaledot2 = wScene / ratiodot2 / dot2->getContentSize().width;
    dot2->setScale(scaledot2);

    float ydot2 = yburrRight * 1;
    dot2->setPosition(Vec2(wScene / 1.85, ydot2));
    if (ratioManhinhParent <= 1.53)
    {
        ratiodot2 = 66;
        dot2->setPosition(Vec2(wScene / 1.35, ydot2));
    }
    dot2->setEnabled(true);
    this->addChild(dot2);


    auto dot3 = ui::Button::create("cricle-tim.png"); // tao button
    dot3->setTouchEnabled(false);
    float ratiodot3 = 28;
    if (ratioManhinhParent <= 1.53)
    {
        ratiodot3 = 56;

    }
    float scaledot3 = wScene / ratiodot3 / dot3->getContentSize().width;
    dot3->setScale(scaledot3);

    float ydot3 = yburrRight * 1.2;
    dot3->setPosition(Vec2(wScene / 1.2 * scaledot3, ydot3));
    dot3->setEnabled(true);
    this->addChild(dot3);

    if (ratioManhinhParent <= 1.53)
    {
        auto dot4 = ui::Button::create("cricle-hong.png"); // tao button
        dot4->setTouchEnabled(false);
        float ratiodot4 = 52;

        float scaledot4 = wScene / ratiodot4 / dot4->getContentSize().width;
        dot4->setScale(scaledot4);

        float ydot4 = yburrRight * 0.25;
        dot4->setPosition(Vec2(wScene / 4.5, ydot4));
        dot4->setEnabled(true);
        this->addChild(dot4);

        auto dot5 = ui::Button::create("cricle-blue.png"); // tao button
        dot5->setTouchEnabled(false);
        float ratiodot5 = 70;

        float scaledot5 = wScene / ratiodot5 / dot5->getContentSize().width;
        dot5->setScale(scaledot5);

        float ydot5 = yburrRight * 0.4;
        dot5->setPosition(Vec2(wScene / 1.1, ydot5));
        dot5->setEnabled(true);
        this->addChild(dot5);

    }
    //animation for play Icon
    float timeAnimation = 0.5;
    auto playAnimationZoomOut1 = ScaleTo::create(timeAnimation, 1 * scalebuttonPlayIcon);
    auto playAnimationZoomOut2 = ScaleTo::create(timeAnimation, scalebuttonPlayIcon * 0.8);
    auto sq = Sequence::create(playAnimationZoomOut1, playAnimationZoomOut2, nullptr);

    buttonPlayIcon->runAction((RepeatForever::create(sq)));

    //animation for play Icon
    auto playAnimationZoomOut3 = ScaleTo::create(timeAnimation * 0.8, 1 * scalebuttonPlayDualIcon);
    auto playAnimationZoomOut4 = ScaleTo::create(timeAnimation * 0.8, scalebuttonPlayDualIcon * 0.8);
    auto sq2 = Sequence::create(playAnimationZoomOut3, playAnimationZoomOut4, nullptr);

    buttonPlayDualIcon->runAction((RepeatForever::create(sq2)));
}
void ParentScreen::createTemplate(float wScene, float hScene) {
   
   float fixIpad = 1;
   float fixIpad2 = 1;
   float fixIpad3 = 1;
   if (ratioManhinhParent <= 1.53)
   {
      fixIpad = 0.5;
      fixIpad2 = 0.7;
      fixIpad3 = 0.1;
   }
   
    int phepTinhSoSanh = HuyFunctions().tongDiemPhepSoSanh();
    int phepCong = HuyFunctions().tongDiemPhepCong();
    int phepTru = HuyFunctions().tongDiemPhepTru();
    int phepNhan = HuyFunctions().tongDiemPhepNhan();
    int phepChia = HuyFunctions().tongDiemPhepChia();
    int tongPhepTinh = phepTinhSoSanh + phepCong + phepTru + phepNhan + phepChia;
    int tocDo = UserDefault::getInstance()->getFloatForKey("toc-do", 0);
   
   if(tocDo == 0) {
      tocDo = 1;
   }

    std::string titleValue = LanguageManager::getInstance()->getStringForKey("PARENT_TITLE_BAT_DAU").c_str();
    std::string descValue = LanguageManager::getInstance()->getStringForKey("PARENT_SUB_TITLE_BAT_DAU").c_str();
    if(tongPhepTinh == 0) {
        createStar(wScene, hScene, 40, 0); //center
        createStar(wScene, hScene, 75, 1); // left
        float yStar = createStar(wScene, hScene, 80, 2); // right
        float yTitle = createLabel(titleValue,fontBold, 0.06, wScene, hScene, yStar, "center", Color3B(80, 80, 80), 1);
        createLabel(descValue, fontNormal, 0.04, wScene, hScene, yTitle - 15 * fixIpad, "center", Color3B(80, 80, 80), 2);
        createTwoButtonPlay(wScene, hScene);

    }else{
       
        std::string data = UserDefault::getInstance()->getStringForKey("data-math", "");
        auto arrData = split(data, "AA");
        auto dataSize = arrData.size();
        //log("data size: %i", dataSize);
        if(dataSize > Variable().showSoPhepTinhParentScreen) {
            dataSize = Variable().showSoPhepTinhParentScreen;
        }
        int soHangTrong1ManHinh  = 25;
        if (ratioManhinhParent <= 1.8)
        {
            soHangTrong1ManHinh = 19;
        }
        if (ratioManhinhParent <= 1.53)
        {
            soHangTrong1ManHinh = 17;
        }
        auto scrollHeight = hScene * 0.9 + hScene * dataSize / soHangTrong1ManHinh; // moi hScene chua duoc 20.25 phep tinh
        log("hScene: %f", hScene);
        log("scrollHeight: %f", scrollHeight);
        if(scrollHeight < hScene) {
            scrollHeight = hScene;
        }
        cocos2d::ui::ScrollView *Item_Scroll = cocos2d::ui::ScrollView::create();
        Item_Scroll->setDirection(ui::ListView::Direction::VERTICAL);
        Item_Scroll->setAnchorPoint(Point::ANCHOR_TOP_LEFT);
        Item_Scroll->getInnerContainer()->setAnchorPoint(Point::ANCHOR_TOP_LEFT);
        Item_Scroll->setContentSize(Size(wScene,hScene));
        Item_Scroll->setBackGroundColorType(ui::ScrollView::BackGroundColorType::SOLID);
        Item_Scroll->setBackGroundColor(Color3B::WHITE);
        Item_Scroll->setInnerContainerSize(Size(wScene,scrollHeight));
        Item_Scroll->setBounceEnabled(true);
        Item_Scroll->setTouchEnabled(true);
        Item_Scroll->setScrollBarEnabled(false);
        Item_Scroll->setPosition(Vec2(wScene/2 - Item_Scroll->getContentSize().width / 2,hScene - 50 * fixIpad));
        this->addChild(Item_Scroll);

        createStar(wScene, scrollHeight, 0, 0, Item_Scroll); //center
        createStar(wScene, scrollHeight, 35, 1, Item_Scroll); // left
        float yStar = createStar(wScene, scrollHeight, 40, 2, Item_Scroll); // right
        if(tongPhepTinh < 11) {
            titleValue = LanguageManager::getInstance()->getStringForKey("PARENT_TITLE_MOI_BAT_DAU").c_str();
            descValue = LanguageManager::getInstance()->getStringForKey("PARENT_SUB_TITLE_MOI_BAT_DAU").c_str();
        }else{
            float percentCorrect = UserDefault::getInstance()->getFloatForKey("phan-tram-dung", 0);
            if(percentCorrect < 0.5) {
                titleValue = LanguageManager::getInstance()->getStringForKey("PARENT_TITLE_MOI_BAT_DAU").c_str();
                descValue = LanguageManager::getInstance()->getStringForKey("PARENT_SUB_TITLE_MOI_BAT_DAU").c_str();
                
                //test responsive mode
//                titleValue = LanguageManager::getInstance()->getStringForKey("PARENT_TITLE_BAD").c_str() + LanguageManager::getInstance()->getStringForKey("PARENT_TITLE_BAD").c_str();
//                descValue = LanguageManager::getInstance()->getStringForKey("PARENT_SUB_TITLE_BAD").c_str();

            }else if(percentCorrect < 0.8) {
                titleValue = LanguageManager::getInstance()->getStringForKey("PARENT_TITLE").c_str();
                descValue = LanguageManager::getInstance()->getStringForKey("PARENT_SUB_TITLE").c_str();
            }else{
                titleValue = LanguageManager::getInstance()->getStringForKey("PARENT_TITLE_GREAT").c_str();
                descValue = LanguageManager::getInstance()->getStringForKey("PARENT_SUB_TITLE_GREAT").c_str();
            }
        }
        float yTitle = createLabel(titleValue, fontBold, 0.06, wScene, scrollHeight, yStar, "center", Color3B(80, 80, 80),1, Item_Scroll);
        float ySubTitle = createLabel(descValue, fontNormal, 0.04, wScene, scrollHeight, yTitle - 15 * fixIpad, "center", Color3B(80, 80, 80),2, Item_Scroll);

//        createDiemTungPhepTinh(std::to_string(phepCong), "+", wScene, scrollHeight, ySubTitle - 50 * fixIpad,3, Item_Scroll);
//        createDiemTungPhepTinh(std::to_string(phepTru), "-", wScene, scrollHeight, ySubTitle - 50 * fixIpad,4, Item_Scroll);
//        createDiemTungPhepTinh(std::to_string(phepNhan), "x", wScene, scrollHeight, ySubTitle - 50 * fixIpad,5, Item_Scroll);
//        float yPhepTinh = createDiemTungPhepTinh(std::to_string(phepChia), ":", wScene, scrollHeight, ySubTitle - 50 * fixIpad,6, Item_Scroll);

        createTongPhepTinh(std::to_string(tongPhepTinh), "pheptinh", wScene, scrollHeight, ySubTitle - 50 * fixIpad2,7, Item_Scroll);
        float yTongPhepTinh = createTongPhepTinh(std::to_string(tocDo), "speed", wScene, scrollHeight, ySubTitle - 50 * fixIpad2 , 8,Item_Scroll);
        createPhepTinhGanNhat(wScene, Item_Scroll->getContentSize().height, yTongPhepTinh - 50 * fixIpad3,data,5, Item_Scroll);
    }
}
void ParentScreen::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B::WHITE));
    //this->addChild(cocos2d::LayerColor::create(Color4B(241, 241, 241, 255)));
   
//    auto imageName = "bg-kid-top-3.png";
//    if (ratioManhinhParent <= 1.53)
//    {
//        imageName = "bg-top-ipad.png";
//        
//    }
//    auto bgTopKid = ui::Button::create(imageName); // tao button
//    float ratioButtonkidTop = 1;
//    float scaleButtonKidTop = wScene / ratioButtonkidTop / bgTopKid->getContentSize().width;
//    bgTopKid->setScale(scaleButtonKidTop);
//    float yButtonKidTop = hScene - bgTopKid->getContentSize().height / 2 * scaleButtonKidTop;
//    float xButtonKidTop = bgTopKid->getContentSize().width / 2 * scaleButtonKidTop;
//    bgTopKid->setPosition(Vec2(xButtonKidTop, yButtonKidTop));
//    bgTopKid->setEnabled(false);
//    this->addChild(bgTopKid);//add button vao scene
//    
//    auto imageNameBottom = "bg-kid.png";
//    if (hScene / wScene <= 1.53)
//    {
//        imageNameBottom = "bg-bottom-ipad.png";
//        
//    }
//    
//    auto bgKid = ui::Button::create(imageNameBottom); // tao button
//    float ratioButtonkid = 1;
//    float scaleButtonKid = wScene / ratioButtonkid / bgKid->getContentSize().width;
//    bgKid->setScale(scaleButtonKid);
//    float yButtonKid = 0 + bgKid->getContentSize().height / 2 * scaleButtonKid;
//    float xButtonKid = 0 + bgKid->getContentSize().width / 2 * scaleButtonKid;
//    bgKid->setPosition(Vec2(xButtonKid, yButtonKid));
//    bgKid->setEnabled(false);
//    this->addChild(bgKid);//add button vao scene
}
void ParentScreen::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, Play::createScene(cType, cLevel), Color3B().WHITE));
}
