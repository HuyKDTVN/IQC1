//
//  AllowNoti.cpp
//  mentalmath
//
//  Created by Huy Le on 3/3/25.
//

#include "AllowNoti.hpp"
#include "Onboarding5.hpp"
#include "ui/CocosGUI.h"
#include "LanguageManager.h"
#include <SimpleAudioEngine.h>
#include "Variable.hpp"
#include "Huy_functions/HuyFunctions.hpp"
#include "Onboarding2.hpp"
USING_NS_CC;


Scene* AllowNoti::createScene()

{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = AllowNoti::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool AllowNoti::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();
    //Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //khoi tao gia tri ban dau
    wScene = visibleSize.width;
    hScene = visibleSize.height;
    ratioScreen = hScene / wScene;

    sound = UserDefault::getInstance()->getIntegerForKey("sound", 0);
    //set bg
    createBg(wScene, hScene);

    back(wScene, hScene);
    createTemplate(wScene, hScene);
    //this->setKeypadEnabled(true);
    return true;
}
void AllowNoti::createBg(float wScene, float hScene) {
    this->addChild(cocos2d::LayerColor::create(Color4B().WHITE));
    //create bg color
    auto bgColor = ui::Button::create("bg01.jpg"); // tao button
    bgColor->setTouchEnabled(false);
    float ratiobgColor = 1;
    float scalebgColor = hScene / ratiobgColor / bgColor->getContentSize().height;
    if(scalebgColor < wScene / ratiobgColor / bgColor->getContentSize().width) {
        scalebgColor = wScene / ratiobgColor / bgColor->getContentSize().width;
    }
    //log("ti le test: %f", scalebgColor);
    //log("ti le test theo w: %f", w / ratiobgColor / bgColor->getContentSize().width);
    bgColor->setScale(scalebgColor);
    bgColor->setAnchorPoint(Vec2(0, 0));
    bgColor->setPosition(Vec2(0, 0));
    bgColor->setEnabled(true);
    this->addChild(bgColor, 0);
}

void AllowNoti::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event){
    //Director::getInstance()->replaceScene(TransitionFade::create(0.5, HelloWorld::createScene(), Color3B().WHITE));
}
void AllowNoti::createTemplate(float w, float h){
    auto notiImg = ui::Button::create("notiImage.png"); // tao button
    notiImg->setTouchEnabled(false);
    float rationotiImg = 3;
    if (ratioScreen <= 1.53)
    {
        rationotiImg = 6;
    }
    float scalenotiImg = w / rationotiImg / notiImg->getContentSize().width;
    
    //log("ti le test: %f", scalenotiImg);
    //log("ti le test theo w: %f", w / rationotiImg / notiImg->getContentSize().width);
    notiImg->setScale(scalenotiImg);
    notiImg->setAnchorPoint(Vec2(0.5, 0.5));
    notiImg->setPosition(Vec2(w / 2, h * 0.85));
    notiImg->setEnabled(true);
    this->addChild(notiImg);

    float fontSizeTitle = 0.06 * w;
    float fontSizeDesc = 0.045 * w;
    if (ratioScreen <= 1.53)
    {
        fontSizeTitle = 0.03 * w;
        fontSizeDesc = 0.023 * w;

    }
    
    auto lblTitle = Label::createWithSystemFont(LanguageManager::getInstance()->getStringForKey("ALLOW_NOTI_TITLE").c_str(), "fonts/arial.ttf", fontSizeTitle);
    
    lblTitle->setColor(Color3B().YELLOW);
    lblTitle->setDimensions(w * 0.92, 0); // Giới hạn chiều rộng là 200px, chiều cao tự động điều chỉnh
    lblTitle->setAlignment(TextHAlignment::CENTER, TextVAlignment::CENTER);
    lblTitle->setPosition(Vec2(w / 2, notiImg->getPositionY() - notiImg->getContentSize().height * scalenotiImg / 2 - lblTitle->getContentSize().height * 1.3));
    // add the label as a child to this layer
    addChild(lblTitle);
    
    auto lblDesc = Label::createWithSystemFont(LanguageManager::getInstance()->getStringForKey("ALLOW_NOTI_DESC").c_str(), "fonts/arial.ttf", fontSizeDesc);
    lblDesc->setDimensions(w * 0.9, 0); // Giới hạn chiều rộng là 200px, chiều cao tự động điều chỉnh
    lblDesc->setPosition(Vec2(w / 2, lblTitle->getPositionY() - lblTitle->getContentSize().height * 0.8));
    lblDesc->setAlignment(TextHAlignment::CENTER, TextVAlignment::TOP);
    this->addChild(lblDesc);
    lblDesc->setAnchorPoint(Vec2(0.5, 1));
    

    
    float fontSize = 0.06 * w;
    auto buttonNotAllow = ui::Button::create("empty.png"); // tao button
    buttonNotAllow->setPressedActionEnabled(true);
    buttonNotAllow->setZoomScale(0);
    buttonNotAllow->setScale9Enabled(true);
    buttonNotAllow->setTitleFontName("Arial-BoldMT"); // Font đậm
    buttonNotAllow->setTitleText(LanguageManager::getInstance()->getStringForKey("NOT_ALLOW_BUTTON"));
    
    //buttonNotAllow->setTitleFontName("fonts/ComicNeue-Bold.ttf");
    buttonNotAllow->setTitleColor(Color3B().WHITE);
    buttonNotAllow->setTouchEnabled(true);
    float ratiobuttonNotAllow = 3;
    if (h / w <= 1.53)
    {
        ratiobuttonNotAllow = 6;
        fontSize = 0.03 * w;
    }
    
    float scalebuttonNotAllow = w / ratiobuttonNotAllow / buttonNotAllow->getContentSize().width;
    buttonNotAllow->setScale(scalebuttonNotAllow);
    buttonNotAllow->setTitleFontSize(fontSize / scalebuttonNotAllow * 0.8);
    float ybuttonNotAllow = h * 0.1;
   
    buttonNotAllow->setPosition(Vec2(w / 2, ybuttonNotAllow));
    
    buttonNotAllow->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Onboarding5::createScene(), Color3B().WHITE));
                    HuyFunctions().submitAllowNoti();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonNotAllow);//add button vao scene
    
    auto buttonAllow = ui::Button::create("buttonAllow.png"); // tao button
    buttonAllow->setPressedActionEnabled(true);
    buttonAllow->setZoomScale(0);
    buttonAllow->setScale9Enabled(true);
    buttonAllow->setTitleText(LanguageManager::getInstance()->getStringForKey("ALLOW_BUTTON"));
    buttonAllow->setTitleFontName("Arial-BoldMT"); // Font đậm
    buttonAllow->setTitleColor(Color3B().WHITE);
    buttonAllow->setTouchEnabled(true);
    float ratiobuttonAllow = 2.2;
    float fixHeightIpad = 1.8;
    if (ratioScreen <= 1.53)
    {
        ratiobuttonAllow = 4.4;
        fontSize = 0.035 * w;
        fixHeightIpad = 1.2;
    }
    
    float scalebuttonAllow = w / ratiobuttonAllow / buttonAllow->getContentSize().width;
    buttonAllow->setScale(scalebuttonAllow);
    buttonAllow->setTitleFontSize(fontSize / scalebuttonAllow);
    float ybuttonAllow = buttonNotAllow->getPositionY() + buttonNotAllow->getContentSize().height * fixHeightIpad;
   
    buttonAllow->setPosition(Vec2(w / 2, ybuttonAllow));
    
    buttonAllow->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                
                if (sound == 0)
                {
                    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/click.wav");
                }
                
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Onboarding5::createScene(), Color3B().WHITE));
                    HuyFunctions().submitAllowNoti();
                });

                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //log("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(buttonAllow);//add button vao scene
    float timeAnimation = 0.4;
    auto playAnimationZoomOut5 = ScaleTo::create(timeAnimation / 1.1, 1.05 * buttonAllow->getScale());
    auto playAnimationZoomOut6 = ScaleTo::create(timeAnimation  / 1.2, buttonAllow->getScale() * 0.95);
    auto sq3 = Sequence::create(playAnimationZoomOut5, playAnimationZoomOut6, nullptr);
    buttonAllow->runAction((RepeatForever::create(sq3)));
    
    auto SpriteBg = Sprite::create("bg-noti.png");
    SpriteBg->setPosition(Vec2(w / 2, buttonAllow->getPositionY() + buttonAllow->getContentSize().height * scalebuttonAllow * 2)); // Đặt vị trí
    float ratioSpriteBg = 1.1;
    float fontSizeNoti = 0.04 * w;
    float fixHeightNotiIpad = 1;
    if (ratioScreen <= 1.53)
    {
        ratioSpriteBg = 2.2;
        fontSizeNoti = 0.02 * w;
        fixHeightNotiIpad = 0.5;
    }
    
    float scaleSpriteBg = w / ratioSpriteBg / SpriteBg->getContentSize().width;
    SpriteBg->setScale(scaleSpriteBg);
    this->addChild(SpriteBg);
    
    auto iconApp = Sprite::create("logo-small.png");
    
    float ratioiconApp = 8.5;
        if (ratioScreen <= 1.53)
    {
        ratioiconApp = 17;
      
    }
    
    float scaleiconApp = w / ratioiconApp / iconApp->getContentSize().width;
    iconApp->setScale(scaleiconApp);
    iconApp->setPosition(Vec2(SpriteBg->getPositionX() - SpriteBg->getContentSize().width * scaleSpriteBg / 2 + iconApp->getContentSize().width * scaleiconApp, SpriteBg->getPositionY())); // Đặt vị trí
    this->addChild(iconApp);

    auto lblTitleNoti = Label::createWithSystemFont(LanguageManager::getInstance()->getStringForKey("YOURARCHIVE_TITLE").c_str(), "Helvetica-Bold", fontSizeNoti);
//    if (ratioScreen <= 1.53)
//    {
//        //lblTitleNoti = Label::createWithTTF(scoreString->getCString(), "fonts/ComicNeue-Bold.ttf", 0.05 * w);
//
//    }
    float xTitleNoti = iconApp->getPositionX() + iconApp->getContentSize().width * scaleiconApp / 2 + 10;
    lblTitleNoti->setColor(Color3B().WHITE);
    lblTitleNoti->setAlignment(TextHAlignment::LEFT);
    lblTitleNoti->setAnchorPoint(Vec2(0, 0.5));
    lblTitleNoti->setPosition(Vec2(xTitleNoti, SpriteBg->getPositionY() + SpriteBg->getContentSize().height * scaleSpriteBg / 2 - 12 * fixHeightNotiIpad - lblTitleNoti->getContentSize().height / 2));
    // add the label as a child to this layer
    addChild(lblTitleNoti);
    //lblDesc->setAlignment(TextHAlignment::LEFT, TextVAlignment::CENTER);
    
    
    auto ketQua = cocos2d::__String::createWithFormat(": %i %s (>=< %i, + %i, - %i, x %i, : %i)", 255, LanguageManager::getInstance()->getStringForKey("PHEPTINH").c_str(), 65, 70, 50, 40, 30);
    
    std::string desc = LanguageManager::getInstance()->getStringForKey("TOTAL").c_str();
    desc.append(ketQua->getCString());
    auto lblDescNoti = Label::createWithSystemFont(desc.c_str(), "Helvetica", fontSizeNoti);
//    if (ratioScreen <= 1.53)
//    {
//        //lblDescNoti = Label::createWithTTF(scoreString->getCString(), "fonts/ComicNeue-Bold.ttf", 0.05 * w);
//
//    }
    lblDescNoti->setDimensions(SpriteBg->getContentSize().width * scaleSpriteBg - iconApp->getContentSize().width * scaleiconApp - 40 * fixHeightNotiIpad, 0);
    lblDescNoti->setAlignment(TextHAlignment::LEFT);
    lblDescNoti->setColor(Color3B().WHITE);
    lblDescNoti->setPosition(Vec2(xTitleNoti, lblTitleNoti->getPositionY() - lblTitleNoti->getContentSize().height - 12 * fixHeightNotiIpad));
    lblDescNoti->setAnchorPoint(Vec2(0, 0.5));
    // add the label as a child to this layer
    addChild(lblDescNoti);
    //lblDesc->setAlignment(TextHAlignment::LEFT, TextVAlignment::TOP);
    
}
void AllowNoti::back(float w, float h){
    auto btn = ui::Button::create("back3.png", "back3.png"); // tao button
    float ratio = 10;
    if (h / w <= 1.53)
    {
        
        ratio = 17;
    }
    auto btnHeight = btn->getContentSize().height;
    auto btnWidth = btn->getContentSize().width;

    float scale = w / ratio / btnWidth;
    btn->setScale(scale);
    btn->setPosition(Vec2((btnWidth / 2 * scale + 13), h - (btnHeight / 2 * scale + 13)));
    btn->addTouchEventListener([&](Ref* sender, ui::Widget::TouchEventType type){ // xu ly su kien button
        auto button = static_cast<cocos2d::ui::Button*>(sender);
        switch (type)
        {
            case cocos2d::ui::Widget::TouchEventType::BEGAN:
                //CCLOG("Button setting");
                //redirect to previous scene
                HuyFunctions().submitAllowNoti();
                HuyFunctions().animationClickedButton(button, [](){
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Onboarding2::createScene(), Color3B().WHITE));
                });
                
                break;
            case cocos2d::ui::Widget::TouchEventType::ENDED:
                //CCLOG("Button 1 clicked");
                break;
            default:
                break;
        }
    });
    addChild(btn);//add button vao scene
}
