//
//  playGame1.hpp
//  mentalmath
//
//  Created by Huy Le on 11/11/24.
//

#ifndef __PLAYGAME1_H__
#define __PLAYGAME1_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class PlayGame1 : public cocos2d::Layer
{
public:
    int randomColor;
    bool isIpad;
    int soMang;
    cocos2d::ui::Button* statusIcon;
    int timeInSeconds;
    int timeInSecondsFor1PhepTinh;
    std::string cauHoi;

    cocos2d::ui::Button* pauseFullWidth;
    cocos2d::ui::Button* pauseSmallButton;
    cocos2d::Vector<cocos2d::ui::Button*> listButtonCauHoi;
    cocos2d::Vector<cocos2d::ui::Button*> listButtonTraLoi;
    
    //std::vector<std::vector<float>> arrBack;
    int countThaoTac;
    cocos2d::ui::Button* backButton;
    cocos2d::ui::Button* hintButton;
    
    cocos2d::Vec2 viTriCauHoiSelected;
    int xSelected;
    int ySelected;
    int soCauTraLoi;
    int cauTraLoiLuaChon;

    std::vector<std::vector<int>> arrCauHoi;
    std::vector<std::vector<int>> arrDapAn;
    
    std::vector<std::vector<int>> arrTraloi;
    cocos2d::Label* hintLabel;
    
    const char *HIGH_SCORE = "height-score";
    cocos2d::LayerColor* selectedCell;
    std::vector<cocos2d::LayerColor*> cellLayers;
    int realType;
    int answer1;
    int answer2;
    int answer3;
    int answer4;

    double wScenePlay;
    double hScenePlay;

    int correctAnswer;

    int score;

    int maxDoiSo;

    cocos2d::__String *ImageNamDapAn;
    
    cocos2d::__String *phepToan;
    cocos2d::__String *scoreString;

    cocos2d::Label* lblPhepToan;
    cocos2d::Label* lblScore;
    cocos2d::ui::Button* scoreIcon;
    cocos2d::ui::Button* earth;
    cocos2d::Sprite* phithuyenHienThi;
    cocos2d::Sprite* tenluaHienThi;
    cocos2d::Sprite* bomPhiThuyenHienThi;
    cocos2d::Sprite* bomEarthHienThi;
    cocos2d::Sprite* bomTenLuaHienThi;
    
    cocos2d::ui::Button* popupthanhCong;
    cocos2d::ui::Button* popupthatBai;

    float xDichPhiThuyen;
    float yTenLua;

    cocos2d::ui::Button* buttonAnswer1;
    cocos2d::ui::Button* buttonAnswer2;
    cocos2d::ui::Button* buttonAnswer3;
    cocos2d::ui::Button* buttonAnswer4;
    cocos2d::ui::Button* buttonPause;
    
    int indexThemDiem;

    float scaleButtonAnswer1;

    float timeRemaining;
    float timeMax;
    bool isPause = false;

    cocos2d::Label* valueKey3;
    float yValueKey3;
    float xValueKey3;

    int sound;
    int prevA = 2;
    int prevB = 2;
    
    
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int type, int level, int backTypePhepTinh, bool fromChallenge = false);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void back(float w, float h);
    void status(float w, float h);
    void pauseButton(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
   
    void createBg(float w, float h);
    void createScore(float w, float h);
    void createBg();
    void createBgColor(float w, float h);
    void createEarth(float w, float h);
    void resumeButtonFullWith(float w, float h);
    void createMainActor(float w, float h);
    void createButtonUndoAndHint(float w, float h);
    void hintAction(float w, float h);
    void backAction(cocos2d::ui::Button* btn, float w, float h);
    void updateClock(float dt);
    void pauseClock();
    void resumeClock();
    void shuffleArray(std::vector<std::vector<int>> arr);
    void createPopupFinish(float w, float h);
    void createMainTempate(float w, float h);
    void giamSoMang();
    void kiemTraChienThang();
    void moveSceneGameOver();
    int soDiem();
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    void checkCorrectOrNot(cocos2d::ui::Button* btn, int x, int y);
    void backColorForCells(cocos2d::ui::Button* btn);
    std::string getCauHoi(int xChon, int yChon, const char* vt1, const char* vt2, const char* vt3, const char* vt4, int cauTraLoi, bool direction);

    int getValueOfArray(std::vector<std::vector<int>> arrCauHoi, std::string viTri);
    int getNumberOfString(std::string input, bool first);
    void showMedal(float w, float h, std::string medal);
    void createBgPro(float w, float h);
    void finish();
    virtual void onEnter() override;
    
    
    // implement the "static create()" method manually
    CREATE_FUNC(PlayGame1);
};

#endif // __PLAYGAME1_H__
