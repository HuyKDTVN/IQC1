//
//  Streak.hpp
//  mentalmath
//
//  Created by Huy Le on 6/9/26.
//

#ifndef __STREAK_H__
#define __STREAK_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class Streak : public cocos2d::Layer
{
public:
    float wScene;
    float hScene;
    float ratioScreen;
    int sound;
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int soCau = 0, int score = 0, int type = 0, int level = 0, int typePlayBefore = 0, bool fromChallenge = false, bool finished10 = false, bool dualPlay = false, int scoreDup = 0);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void createBg(float w, float h);
    void back(float w, float h);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
    void createTemplate(float w, float h);
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(Streak);
};

#endif // !__CHANGENAME_H__
