#ifndef __MATHLEVEL_H__
#define __MATHLEVEL_H__

#include "cocos2d.h"

class MathLevel : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene(int mode, int type);

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    void createBg(float w, float h);
	void back(float w, float h);
	void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event);
	void createButtonKey(float w, float h);
	void createValueKey(float w, float h);
	void create3ButtonTop(float w, float h);
	void createMainTemplate(int level, float w, float h);
	void createTite(float w, float h);
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
	CREATE_FUNC(MathLevel);
};

#endif // __MATHLEVEL_H__
