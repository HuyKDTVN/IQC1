//
//  Kegel.swift
//  Period
//
//  Created by Huy Le on 08/05/2022.
//

import SwiftUI
import AppTrackingTransparency
import AdSupport
import HealthKit

@main
struct Kegel: App {
    //@UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @Environment(\.scenePhase) var scenePhase
    let variable = Variable()
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some Scene {
        WindowGroup {
            if (variable.getUserDefaultBool(name: "finishonboarding")){
                ContentView().preferredColorScheme(.dark)
            }else{
                Onboarding1().preferredColorScheme(.dark)
            }
            
//                .onAppear() {
//                    let healthStore = HKHealthStore()
//
//                    let typesToShare: Set = [
//                        HKObjectType.workoutType(),
//                        HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!
//                    ]
//
//                    let typesToRead: Set = [
//                        HKObjectType.workoutType(),
//                        HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!,
//                        HKObjectType.quantityType(forIdentifier: .heartRate)!,
//                        HKObjectType.quantityType(forIdentifier: .appleExerciseTime)!
//                    ]
//                    
//                    healthStore.requestAuthorization(toShare: typesToShare, read: typesToRead) { success, error in
//                        if success {
//                            print("Đã được cấp quyền HealthKit.")
//                        } else {
//                            print("Lỗi khi xin quyền: \(String(describing: error))")
//                        }
//                    }
//                }
                //.onAppear() {
//                    //requestAppTrackingPermission()
//                    
//                    if let displayName = Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String {
//                        print("App Display Name: \(displayName)")
//                    }
//                    
//                }
//                .onAppear {
//                    // Tải quảng cáo ngay khi ứng dụng bắt đầu
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//                        if let rootVC = UIApplication.shared.windows.first?.rootViewController {
//                            AppOpenAdManager.shared.loadAd()  // Tải quảng cáo ngay khi mở ứng dụng
//                            // Đảm bảo tải quảng cáo và hiển thị khi có sẵn
//                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
//                                AppOpenAdManager.shared.showAdIfAvailable(from: rootVC)
//                            }
//                        }
//                    }
//                }
                
//                .onChange(of: scenePhase) { newPhase in
//                    if newPhase == .active {
//                        // Tải và hiển thị quảng cáo khi quay lại từ nền
////                        if let rootVC = UIApplication.shared.windows.first?.rootViewController {
////                            AppOpenAdManager.shared.showAdIfAvailable(from: rootVC)
////                        }
//                    }
//                }
                
        }
        
        
    }
}

//class AppDelegate: UIResponder, UIApplicationDelegate {
//    func application(_ application: UIApplication,
//                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
//        
//        
//        
//        MobileAds.shared.start(completionHandler: nil)
//        
//        
//        return true
//    }
//    func applicationDidBecomeActive(_ application: UIApplication) {
//       
//
//    }
//}
func requestAppTrackingPermission() {
    print("test att")
    if #available(iOS 14, *) {
        ATTrackingManager.requestTrackingAuthorization { status in
            DispatchQueue.main.async {
                switch status {
                case .authorized:
                    print("✅ Cho phép tracking")
                case .denied:
                    print("❌ Từ chối tracking")
                case .notDetermined:
                    print("🕒 Chưa xác định")
                case .restricted:
                    print("🚫 Bị giới hạn")
                @unknown default:
                    break
                }
            }
        }
    }
}
