//
//  TapNgayTuChonBaiTap.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct TapNgayTuChonBaiTap: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationView{
            VStack{
                HStack{
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("day", comment: ""))
                        .font(.system(size: 20).bold())
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                    
               
                Spacer()
                
                NavigationLink{
                    ChonBaiTap()
                }label: {
                    HStack{
                        Text(NSLocalizedString("startnow", comment: ""))
                            .foregroundColor(Color.black)
                            .font(.system(size: 20).bold())
                            .padding(.leading, 10)
                        Spacer()
                        Circle()
                            .stroke(.black, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(.vertical, 40)
                    .padding(.horizontal, 20)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(Color("xanh"))
                    )
                    .padding(.horizontal, 40)
                    .padding(.bottom, 20)
                    
                }
                
                NavigationLink{
                    ChonBaiTap()
                }label: {
                    HStack{
                        Text(NSLocalizedString("tuchonbaitap", comment: ""))
                            .foregroundColor(Color.white)
                            .font(.system(size: 20).bold())
                            .padding(.leading, 10)
                        Spacer()
                        Circle()
                            .stroke(.white, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(.vertical, 40)
                    .padding(.horizontal, 20)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(Color.white.opacity(0.1))
                    )
                    .padding(.horizontal, 40)
                    .padding(.bottom, 20)
                    
                }
                
                
                
                Spacer()
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    TapNgayTuChonBaiTap().preferredColorScheme(.dark)
}
