//
//  variable.swift
//  Period - BMI
//
//  Created by Huy Le on 08/05/2022.
//

import Foundation
import UIKit
import SwiftUI
class Variable {
    var production:Bool = false
    let proVersion:Bool = false
    
    //var appID:String = "1623035516" // can thay
    var link_app:String = "https://itunes.apple.com/app/period-calendar-bmi-tracker/1623035516" // can thay
 
    var link_facebook_message: String = "https://forms.gle/jGd4uWnCnWpcjLDp9"
    
    var link_dev:String = "https://itunes.apple.com/developer/huy-le/id1279607371"
    var link_privacy: URL = URL(string: "https://sites.google.com/view/fitness-lady-privacy/")!
    var link_terms: URL = URL(string: "https://sites.google.com/view/k-up-terms-of-service-terms/")!
   
    var arrTinhTrangTitle = ["tinhtrang4", "tinhtrang3", "tinhtrang2", "tinhtrang1", "nogood"]
    var arrTinhTrangID = [4, 3, 2, 1, 99]
    var arrTinhTrangColor = [Color("xanh"), Color("tinhTrang3"), Color("tinhTrang2"), Color("tinhTrang1"), Color("tinhTrangNoGood")]
    
    var kegelTimes = [5, 10, 15, 20, 25, 30]
    var kegelTypes = [3, 4, 5, 1]
    var demoKegel = [
        [5, 5],
        [2, 8],
        [4, 6],
        [1, 12]
    ]
    
    //let cal = [410 / 60, 410 / 60, 400 / 60, 400 / 60, 410 / 60, 410 / 60]
    
    let mucTieuTitle: [String] = ["Thử thách 7 ngày Kegel", "Thử thách 14 ngày Kegel", "Thử thách 30 ngày Kegel"]
    let muctieuTimes: [Int] = [7, 14, 30]
    let mucTieuValue: [Int] = [35, 70, 150] // so phut trong toan bo muc tieu
    
    let flag = [
        ["uk", "English"],
        ["vi", "Tiếng Việt"],
        ["de", "Tiếng Đức"]
    ]
    
    let mucTieuNam = [
       "tangthoigianQH",
       "kiemsoatxuattinhsom",
       "caithiencuongcung",
       "hotrotuyentienliet",
       "kiemsoatbangquang",
       "chuatri"
    ]
    let mucTieuNu = [
       "phuchoisausinh",
       "tangcamgiac",
       "sontieu",
       "giamdauvungchau",
       "chuatri"
    ]
    
    let mucTieuGioiTinhThu3 = [
       "tangthoigianQH",
       "chuatri"
    ]
    let userDefaultGroupName: String = "group.com.huy.kegel"
    let userDefaultThanhTich = "thanhtich"
    
    
    func requestNotificationPermission() async -> Bool {
        do {
            return try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
        } catch {
            return false
        }
    }
    func getUserDefaultBool(name: String) -> Bool {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let result = defaults?.bool(forKey: name) ?? false
        return result
    }
    
    func getUserDefaultInt(name: String) -> Int {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let result = defaults?.integer(forKey: name) ?? 0
        return result
    }
    func getUserDefaultString(name: String) -> String {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let result = defaults?.string(forKey: name) ?? ""
        return result
    }
    func getUserDefaultArrInt(name: String) -> [[Int]] {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let arr = defaults?.array(forKey: name) as? [[Int]] ?? []
        return arr
    }
    func getUserDefaultArrInt1(name: String) -> [Int] {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let arr = defaults?.array(forKey: name) as? [Int] ?? []
        return arr
    }
}
