//
//  ChonBaiTap.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct ChonBaiTap: View {
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    var body: some View {
        NavigationView{
            VStack{
                HStack{
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("day", comment: "") + " 8")
                        .font(.system(size: 20).bold())
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                Spacer()
                ScrollView{
                    ForEach(variable.demoKegel, id: \.self) { item in
                        NavigationLink{
                            StartWorkout()
                        } label: {
                            HStack{
                                Circle()
                                    .stroke(Color("yellow"), lineWidth: 2)
                                    .frame(width: 10, height: 10, alignment: .trailing)
                                    .padding(.trailing, 0)
                                VStack (alignment: .leading) {
                                    Text("\(item[0]) " + NSLocalizedString("tập", comment: "") + ", " + "\(item[0]) " + NSLocalizedString("nghỉ", comment: ""))
                                        .padding(.bottom, 2)
                                        .font(Font.system(size: 16.0, weight: .bold))
                                        .foregroundColor(.white)
                                    
                                    Text("x\(item[1])")
                                        .padding(.bottom, 2)
                                        .font(Font.system(size: 14.0))
                                        .foregroundColor(.white)
                                    
                                }
                                .padding(.leading, 20)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .padding(.horizontal, 30)
                            .padding(.vertical, 40)
                            .background(
                                RoundedRectangle(cornerRadius: 50)
                                    .fill(Color.white.opacity(0.07))
                            )
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
              
                Spacer()
                
                
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    ChonBaiTap().preferredColorScheme(.dark)
}
