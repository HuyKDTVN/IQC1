import SwiftUI

import HealthKit
struct ContentView: View {
    var variable:Variable = Variable()
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    let data: [Double] = [40, 70, 55, 90, 30, 80, 60]
    let days = ["t2", "t3", "t4", "t5", "t6", "t7", "cn"]
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView{
            ScrollView(showsIndicators: false){
                VStack{
                    HStack(alignment: .top){
                        NavigationLink {
                            Setting()
                       } label: {
                            Image(systemName: "slider.horizontal.3")
                                .font(Font.system(size: 23))
                                .foregroundColor(Color("yellow"))
                                .frame(width: 45, height: 45)
                                //.background(Color.white.opacity(0))
                                .clipShape(Circle())
                                .overlay(
                                    RoundedRectangle(cornerRadius: 30)
                                        .stroke(Color.white.opacity(0.2), lineWidth: 1)
                                )
                        }
                        Spacer()
                    }.padding(.horizontal, 20)
                        .padding(.top, 10)
                    HomeGuide()
                    HomeThanhTichHomNay()
//                    Button {
//                        
//                    } label: {
//                        HStack{
//                            Text("ghinhanthoigianqh")
//                                .foregroundColor(Color.white)
//                                .font(Font.system(size: 18).bold())
//                                .padding(.leading, 10)
//                            Spacer()
//                            Image(systemName: "arrow.forward")
//                                .font(.system(size: 27).bold())
//                                .padding(13)
//                                .foregroundColor(Color.black)
//                                .background(Color("xanh"))
//                                .clipShape(Circle())
//                        }
//                        .padding(.vertical, 20)
//                        .padding(.horizontal, 15)
//                        .background(
//                            RoundedRectangle(cornerRadius: 50)
//                                .fill(Color.white.opacity(0.07))
//                        )
//                        .padding()
//                    }
                    HomeThoiGianDaTap()
                    VStack{
                        HStack{
                            Text("thanhtichtuannay")
                                .foregroundColor(Color("tim 1"))
                                .font(Font.system(size: 18).bold())
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                        }
                        HStack(alignment: .bottom, spacing: 8) {
                                    ForEach(0..<7) { i in
                                        VStack {
                                            RoundedRectangle(cornerRadius: 40)
                                                .fill(Color("tim 1"))
                                                .frame(height: data[i])
                                                .padding(.horizontal, 7)
                                            Text(NSLocalizedString(days[i], comment: ""))
                                                .font(.caption.bold())
                                        }
                                        .frame(maxWidth: .infinity)
                                    }
                                }
                                .frame(height: 120) // chiều cao chart
                                .padding()
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(.horizontal, 20)
                    HomeChartQH()
                    HomeChartSonTieu()
                    HomeChartTri()
                }

            }.onAppear(){
                defaults?.set(true, forKey: "finishonboarding")
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}
