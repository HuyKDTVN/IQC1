//
//  HomeThanhTichHomNay.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct HomeThanhTichHomNay: View {
    var variable:Variable = Variable()
    var columns = Array(repeating: GridItem(.flexible(), spacing: 20), count: 2)
    @State var stats_Data: [Stats] = []
    
    var body: some View {
        NavigationLink{
            TapNgayTuChonBaiTap()
        } label : {
            VStack{
                Text("titleTapLuyen")
                    .font(.system(size: 18))
                    .fontWeight(.bold)
                    .foregroundColor(Color("yellow2"))
                    .padding(.top, 10)
                LazyVGrid(columns: columns, spacing: 30){
                    ForEach(stats_Data){stat in
                        VStack(spacing: 15){
                           let widthCircle = (UIScreen.main.bounds.width - stat.w)/2
                            ZStack{
                                Circle()
                                    .trim(from: 0, to: 1)
                                    .stroke(stat.color.opacity(0.10), lineWidth: 10)
                                    .frame(width: widthCircle, height: widthCircle)
                                Circle()
                                    .trim(from: 0, to: stat.currentData / stat.goal)
                                    .stroke(stat.color, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                                    .frame(width: widthCircle, height: widthCircle)
                                    .rotationEffect(.init(degrees: -90))
                                Text(getPercent(current: stat.currentData, goal:stat.goal) + " %")
                                    .font(.system(size: 22))
                                    .fontWeight(.bold)
                                    .foregroundColor(stat.color)
                            }
                            HStack{
                               Spacer(minLength: 0)
                                Text(stat.title)
                                  .font(.custom("NunitoSans-Bold", size: 16))
                                    .foregroundColor(.white)
                                Spacer(minLength: 0)
                                    
                            }
                            .padding(.top, 0)

                        }
                        .padding()
                        .cornerRadius(15)
                    }
                }
                
                .onAppear(){
                    stats_Data = [
                         Stats(id: 1, title: NSLocalizedString("today", comment: ""), currentData: 2, goal: 2.5, color: Color("yellow2"), w: 170),
                         Stats(id: 2, title: NSLocalizedString("all", comment: ""), currentData: 1, goal: 2.5, color: Color("yellow2"), w: 170)
                      ]
                }
                HStack{
                    Button{
                        
                    } label : {
                        Image(systemName: "arrow.forward")
                            .font(.system(size: 27).bold())
                            .padding(13)
                            .foregroundColor(Color.black)
                            .background(Color("yellow2"))
                            .clipShape(Circle())
                            .opacity(0)
                    }
                    Spacer()
                    
                    Spacer()
                    Image(systemName: "arrow.forward")
                        .font(.system(size: 27).bold())
                        .padding(13)
                        .foregroundColor(Color.black)
                        .background(Color("yellow2"))
                        .clipShape(Circle())
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 50)
                    .fill(Color.white.opacity(0.07))
            )
            .padding(.horizontal, 20)
        }
    }
    func getPercent(current: CGFloat, goal: CGFloat) -> String{
        let per = current / goal * 100
        return String(format: "%.1f", per)
    }
}

#Preview {
    HomeThanhTichHomNay().preferredColorScheme(.dark)
}
struct Stats : Identifiable{
    var id: Int
    var title: String
    var currentData: CGFloat
    var goal: CGFloat
    var color: Color
   var w: CGFloat
    
}
