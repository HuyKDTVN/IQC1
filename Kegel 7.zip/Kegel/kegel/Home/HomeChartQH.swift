//
//  HomeChartQH.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct HomeChartQH: View {
    let dataQH: [Double] = [40, 30, 30, -50, -30, 40, 20] // Mon → Sun
        
    let days = ["1", "2", "3", "4", "5", "6", "7"]
    var body: some View {
        VStack{
            HStack{
                Image(systemName: "plus")
                    .font(.system(size: 25).bold())
                    .padding(10)
                    .foregroundColor(Color.black)
                    .background(Color("xanh"))
                    .clipShape(Circle())
                    .opacity(0)
                Text("chatluongQH")
                    .foregroundColor(Color("xanh"))
                    .font(Font.system(size: 18).bold())
                    .frame(maxWidth: .infinity, alignment: .center)
                Spacer()
                Image(systemName: "plus")
                    .font(.system(size: 25).bold())
                    .padding(10)
                    .foregroundColor(Color.black)
                    .background(Color("xanh"))
                    .clipShape(Circle())
            }
            
            ZStack{
                GeometryReader { geo in
                    let maxValue = dataQH.max() ?? 0
                    let minValue = dataQH.min() ?? 0
                    let absMax = max(abs(maxValue), abs(minValue))
                    
                    let chartHeight = geo.size.height
                    let zeroY = chartHeight / 2 - 20
                    
                    Path { path in
                        path.move(to: CGPoint(x: 0, y: zeroY))
                        path.addLine(to: CGPoint(x: geo.size.width, y: zeroY))
                    }
                    .stroke(Color.gray.opacity(0.5), lineWidth: 1)
                    
                    HStack(alignment: .bottom, spacing: 8) {
                        ForEach(0..<7) { i in
                            VStack {
                                if dataQH[i] > 0{
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(Color("xanh"))
                                        .frame(height: abs(dataQH[i]))
                                        .padding(.horizontal, 7)
                                        .padding(.bottom, 60)
                                }else{
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(Color("xanh"))
                                        .frame(height: abs(dataQH[i]))
                                        .padding(.horizontal, 7)
                                        .padding(.bottom, 60 + dataQH[i])
                                }
                                
                                Text(NSLocalizedString(days[i], comment: ""))
                                    .font(.caption.bold())
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                    
                }
                .frame(height: 120) // chiều cao chart
                .padding()
                
            }
        }
        .padding(.vertical, 15)
        .padding(.horizontal, 15)
        .background(
            RoundedRectangle(cornerRadius: 50)
                .fill(Color.white.opacity(0.07))
        )
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
    }
}

#Preview {
    HomeChartQH().preferredColorScheme(.dark)
}
