//
//  HomeChartTri.swift
//  kegel-exercise
//
//  Created by Huy Le on 4/5/26.
//

import SwiftUI

struct HomeChartTri: View {
    let data: [Double] = [40, 30, 30, -50, -30, 40, 20] // Mon → Sun
    let days = ["1", "2", "3", "4", "5", "6", "7"]
    var body: some View {
        NavigationView {
            NavigationLink{
                UpdateTri()
            } label: {
                if 1==1 {
                    VStack{
                        HStack{
                            Text("tinhtrangtri")
                                .foregroundColor(Color("xanhduong"))
                                .font(Font.system(size: 18).bold())
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                            
                        }
                        Spacer()
                            .frame(height: 40)
                        Image(systemName: "plus")
                            .font(.system(size: 25).bold())
                            .padding(10)
                            .foregroundColor(Color.black)
                            .background(Color("xanhduong"))
                            .clipShape(Circle())
                        Text("tinhtrangtri")
                            .foregroundColor(Color.white)
                            .font(Font.system(size: 14).bold())
                            .padding(.top, 5)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                            .frame(height: 40)
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(20)
                } else {
                    VStack{
                        HStack{
                            Image(systemName: "plus")
                                .font(.system(size: 25).bold())
                                .padding(10)
                                .foregroundColor(Color.black)
                                .background(Color("xanhduong"))
                                .clipShape(Circle())
                                .opacity(0)
                            Text("tinhtrangtri")
                                .foregroundColor(Color("xanhduong"))
                                .font(Font.system(size: 18).bold())
                                .padding(.leading, 10)
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                            Image(systemName: "plus")
                                .font(.system(size: 25).bold())
                                .padding(10)
                                .foregroundColor(Color.black)
                                .background(Color("xanhduong"))
                                .clipShape(Circle())
                        }
                        
                        ZStack{
                            GeometryReader { geo in
                                let maxValue = data.max() ?? 0
                                let minValue = data.min() ?? 0
                                let absMax = max(abs(maxValue), abs(minValue))
                                
                                let chartHeight = geo.size.height
                                let zeroY = chartHeight / 2 - 20
                                
                                Path { path in
                                    path.move(to: CGPoint(x: 0, y: zeroY))
                                    path.addLine(to: CGPoint(x: geo.size.width, y: zeroY))
                                }
                                .stroke(Color.gray.opacity(0.5), lineWidth: 1)
                                
                                HStack(alignment: .bottom, spacing: 8) {
                                    ForEach(0..<7) { i in
                                        VStack {
                                            if data[i] > 0{
                                                RoundedRectangle(cornerRadius: 40)
                                                    .fill(Color("xanhduong"))
                                                    .frame(height: abs(data[i]))
                                                    .padding(.horizontal, 7)
                                                    .padding(.bottom, 60)
                                            }else{
                                                RoundedRectangle(cornerRadius: 40)
                                                    .fill(Color("xanhduong"))
                                                    .frame(height: abs(data[i]))
                                                    .padding(.horizontal, 7)
                                                    .padding(.bottom, 60 + data[i])
                                            }
                                            
                                            Text(NSLocalizedString(days[i], comment: ""))
                                                .font(.caption.bold())
                                        }
                                        .frame(maxWidth: .infinity)
                                    }
                                }
                                
                            }
                            .frame(height: 120) // chiều cao chart
                            .padding()
                            
                        }
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(.horizontal, 20)
                }
            }
        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
//        
        
    }
}

#Preview {
    HomeChartTri().preferredColorScheme(.dark)
}
