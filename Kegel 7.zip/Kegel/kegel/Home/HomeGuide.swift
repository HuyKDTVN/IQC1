//
//  HomeGuide.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct HomeGuide: View {
    @State private var isCollapsed = false
    let variable = Variable()
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        VStack{
            HStack{
                Text("guide")
                    .foregroundColor(Color("xanhduong"))
                    .font(Font.system(size: 20).bold())
                    .padding(.leading, 10)
                Spacer()
                Button {
                    if isCollapsed {
                        defaults?.set(false, forKey: "hideguide")
                    }else{
                        defaults?.set(true, forKey: "hideguide")
                    }
                    withAnimation(.easeInOut) {
                        isCollapsed.toggle()
                    }
                } label: {
                    Image(systemName: "chevron.down")
                        .rotationEffect(.degrees(isCollapsed ? 0 : 180))
                        .animation(.easeInOut(duration: 0.25), value: isCollapsed)
                        .font(Font.system(size: 21))
                        .foregroundColor(Color.white)
                        .frame(width: 45, height: 45)
                        .background(Color.white.opacity(0.2))
                        .clipShape(Circle())
                }
            }
            .padding(.vertical, 15)
            .padding(.horizontal, 15)
            .background(
                RoundedRectangle(cornerRadius: 30)
                    .fill(Color("xam"))
            )
            .padding(.horizontal, 10)
            .zIndex(20)
            .onAppear(){
                if (variable.getUserDefaultBool(name: "hideguide")){
                    isCollapsed = true
                }
            }
            if !isCollapsed {
                VStack{
                    HStack{
                        Text("kegellagi")
                            .foregroundColor(Color.white)
                            .font(Font.system(size: 16).bold())
                            .padding(.leading, 10)
                        Spacer()
                        Button {
                            
                        } label: {
                            Image(systemName: "chevron.right")
                                .font(Font.system(size: 21))
                                .foregroundColor(Color.white)
                                .frame(width: 45, height: 45)
                        }
                    }
                    .padding(.vertical, 7)
                    .padding(.horizontal, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.05))
                    )
                    .padding(.vertical, 2)
                    HStack{
                        Text("guidecorrect")
                            .foregroundColor(Color.white)
                            .font(Font.system(size: 16).bold())
                            .padding(.leading, 10)
                        Spacer()
                        Button {
                            
                        } label: {
                            Image(systemName: "chevron.right")
                                .font(Font.system(size: 21))
                                .foregroundColor(Color.white)
                                .frame(width: 45, height: 45)
                        }
                    }
                    .padding(.vertical, 7)
                    .padding(.horizontal, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.05))
                    )
                    .padding(.vertical, 2)
                    HStack{
                        Text("kegelloiich")
                            .foregroundColor(Color.white)
                            .font(Font.system(size: 16).bold())
                            .padding(.leading, 10)
                        Spacer()
                        Button {
                            
                        } label: {
                            Image(systemName: "chevron.right")
                                .font(Font.system(size: 21))
                                .foregroundColor(Color.white)
                                .frame(width: 45, height: 45)
                        }
                    }
                    .padding(.vertical, 7)
                    .padding(.horizontal, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.05))
                    )
                    .padding(.vertical, 2)
                }
                .padding(.vertical, 15)
                .padding(.horizontal, 15)
                .zIndex(1)
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 0)
        .background(
            RoundedRectangle(cornerRadius: 50)
                .fill(Color.white.opacity(0.07))
        )
        .clipped()
        .padding()
    }
}

#Preview {
    HomeGuide()
        .preferredColorScheme(.dark)
}
