//
//  Setting.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct Setting: View {
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    @State private var amThanh = true
    @State var showPrivacyPage: Bool = false
    @State var showTermsPage: Bool = false
    @State private var nhacTuMoi = true
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //ScrollView {
            VStack{
                
                Text("Cài đặt")
                    .font(.largeTitle.bold())
                //NavigationView {
                    
                    List{
//                        Section{
//                            HStack {
//                                Circle()
//                                    .strokeBorder(Color("yellow2"),lineWidth: 2)
//                                    .background(Circle().foregroundColor(Color("yellow2").opacity(0.2))).frame(width: 20, height: 20)
//                               
//                                Toggle(NSLocalizedString("Ngôn ngữ", comment: ""), isOn: $amThanh)
//                                     .toggleStyle(SwitchToggleStyle(tint: Color("yellow2")))
//                                    .onChange(of: amThanh) { value in
//                                        defaults?.set(amThanh, forKey: "amThanh")
//                                       
//                                    }
//                                
//                               
//                            }
//                        }

                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow2"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow2").opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("Giới tính", comment: ""), isOn: $amThanh)
                                     .toggleStyle(SwitchToggleStyle(tint: Color("yellow2")))
                                    .onChange(of: amThanh) { value in
                                        defaults?.set(amThanh, forKey: "amThanh")
                                       
                                    }
                                
                               
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow2"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow2").opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("Cường độ tập", comment: ""), isOn: $amThanh)
                                     .toggleStyle(SwitchToggleStyle(tint: Color("yellow2")))
                                    .onChange(of: amThanh) { value in
                                        defaults?.set(amThanh, forKey: "amThanh")
                                       
                                    }
                                
                               
                            }
                        }
                       
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow2"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow2").opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("Nhắc nhở tập luyện", comment: ""), isOn: $nhacTuMoi)
                                     .toggleStyle(SwitchToggleStyle(tint: Color("yellow2")))
                                    .onChange(of: nhacTuMoi) { value in
                                        defaults?.set(nhacTuMoi, forKey: "nhacnhotu")
                                        if nhacTuMoi == false{
//                                            HuyFunc().removeNoti(myName: "nhactumoi1")
//                                            HuyFunc().removeNoti(myName: "nhactumoi2")
//                                            HuyFunc().removeNoti(myName: "nhactumoi3")
//                                            HuyFunc().removeNoti(myName: "nhactumoi4")
//                                            HuyFunc().removeNoti(myName: "nhactumoi5")
                                        }
                                       
                                    }
                            }
                            
                        }
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow2"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow2").opacity(0.2))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("Đánh giá 5*", comment: ""), destination: URL(string: variable.link_app)!).foregroundColor(.white)
                                
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow2"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow2").opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("Xem thêm", comment: ""), destination: URL(string: variable.link_dev)!).foregroundColor(.white)
                                
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(Color("yellow2"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("yellow2").opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("Trợ giúp & Phản hồi", comment: ""), destination: URL(string: variable.link_facebook_message)!).foregroundColor(.white)
                            }
                            NavigationLink {
                                Privacy()
                            } label: {
                                HStack{
                                    Circle()
                                        .strokeBorder(Color("yellow2"),lineWidth: 2)
                                        .background(Circle().foregroundColor(Color("yellow2").opacity(0.4))).frame(width: 20, height: 20)
                                    
                                    Text(NSLocalizedString("Chính sách riêng tư", comment: ""))
                                        .foregroundColor(.white)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                            }
                            NavigationLink {
                                Terms()
                            } label: {
                                HStack{
                                    Circle()
                                        .strokeBorder(Color("yellow2"),lineWidth: 2)
                                        .background(Circle().foregroundColor(Color("yellow2").opacity(0.4))).frame(width: 20, height: 20)
                                    
                                    Text(NSLocalizedString("Điều khoản dịch vụ", comment: ""))
                                        .foregroundColor(.white)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                            }
                        }
                    }
                    
                }
                
              //  Spacer()
            //}
            .onAppear() {
                amThanh = defaults?.bool(forKey: "amThanh") ?? false
                nhacTuMoi = defaults?.bool(forKey: "nhacnhotapluyen") ?? false
            }
            .padding(.top, 70)
            //.padding()
            
            
        .edgesIgnoringSafeArea(.all)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                NavigationLink(destination: ContentView()) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color("textTim"))
                        .clipShape(Circle())
                }
            }
        }
    }
}

#Preview {
    Setting().preferredColorScheme(.dark)
}
