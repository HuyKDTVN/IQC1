//
//  StartWorkout.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct StartWorkout: View {
    var body: some View {
        NavigationView{
            VStack{
                HStack{
                    NavigationLink {
                        PhoneFinish()
                    } label: {
                        Image(systemName: "xmark")
                            .font(Font.system(size: 23))
                            .foregroundColor(Color("yellow2"))
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                  
                    Spacer()
                    Button {
                        
                    } label: {
                        Image(systemName: "pause")
                            .font(Font.system(size: 25))
                            .foregroundColor(Color("yellow2"))
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                Text(NSLocalizedString("3 tap 3 nghi", comment: ""))
                    .font(.system(size: 22).bold())
                    .padding(.bottom, 0)
                
                Text(NSLocalizedString("1/5", comment: ""))
                    .font(.system(size: 22).bold())
                    .padding(.horizontal, 15)
                    .padding(.vertical, 6)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.1))
                    )
                Spacer()
                
              
                Spacer()
                
                HStack(alignment: .center, spacing: 8) {
                    ForEach(0..<7) { i in
                        
                        Circle()
                            .fill(i == 2 ? Color("yellow2") : Color.white.opacity(0.2))
                            .frame(width: i == 2 ? 15 : 10, height: i == 2 ? 15 : 10)
                            
                    }
                }
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    StartWorkout().preferredColorScheme(.dark)
}
