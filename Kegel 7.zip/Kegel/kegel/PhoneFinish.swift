//
//  PhoneFinish.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct PhoneFinish: View {
    var variable:Variable = Variable()
    let data: [Double] = [40, 70, 55, 90, 30, 80, 60]
    let days = ["t2", "t3", "t4", "t5", "t6", "t7", "cn"]
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView{
            ScrollView(showsIndicators: false){
                VStack{
                    Text("chucmung")
                        .font(.system(size: 25).bold())
                        .padding(.bottom, 20)
                    HomeThanhTichHomNay()
                    HomeThoiGianDaTap()
                    VStack{
                        HStack{
                            Text("thanhtichtuannay")
                                .foregroundColor(Color("tim 1"))
                                .font(Font.system(size: 18).bold())
                                .padding(.leading, 10)
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                        }
                        HStack(alignment: .bottom, spacing: 8) {
                                    ForEach(0..<7) { i in
                                        VStack {
                                            RoundedRectangle(cornerRadius: 40)
                                                .fill(Color("tim 1"))
                                                .frame(height: data[i])
                                                .padding(.horizontal, 7)
                                            Text(NSLocalizedString(days[i], comment: ""))
                                                .font(.caption.bold())
                                        }
                                        .frame(maxWidth: .infinity)
                                    }
                                }
                                .frame(height: 120) // chiều cao chart
                                .padding()
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(20)
                }
                HStack {
                    NavigationLink(destination: ContentView()) {
                        Image(systemName: "house")
                            .font(.system(size: 30))
                            .padding(18)
                            .foregroundColor(Color.white)
                            .background(Circle().foregroundColor(Color.white.opacity(0.2)))
                            //.frame(width: 50, height: 50)
                        
                    }
                    .buttonStyle(PlainButtonStyle())
                    
                    // Tuỳ chọn 2 → Màn hình C
                    
                    NavigationLink(destination: ContentView()) {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 42).bold())
                            .padding(25)
                            .foregroundColor(Color.black)
                            .background(Circle().foregroundColor(Color("yellow2")))
                            
                            //.frame(width: 50, height: 50)
                        .padding()
                    }
                    .buttonStyle(PlainButtonStyle())
                    
                }
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    PhoneFinish().preferredColorScheme(.dark)
}
