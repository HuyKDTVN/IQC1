//
//  Onboarding0.swift
//  kegel-exercise
//
//  Created by Huy Le on 27/4/26.
//

import SwiftUI

struct Onboarding0: View {
    let variable = Variable()
    var body: some View {
        NavigationView {
            VStack{
                Text(NSLocalizedString("selectlanguage", comment: ""))
                    .font(.system(size: 23).bold())
                    .padding(.top, 20)
                    .padding(.bottom, 0)
                
                ScrollView{
                    VStack(spacing: 0) {
                        ForEach(variable.flag, id: \.self) { item in
                            Button{
                                print("select: \(item[0])")
                            } label: {
                                HStack{
                                    Image(item[0])
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .foregroundColor(.white)
                                        .padding(10)
                                        .frame(width: 60, height: 60)
                                        .clipShape(Circle())
                                    Spacer()
                                    Text(item[1])
                                        .padding(0)
                                        .font(.system(size: 16).bold())
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    Spacer()
                                    Circle()
                                        .stroke(.white, lineWidth: 2)
                                        .frame(width: 15, height: 15)
                                    Spacer()
                                        .frame(width: 20)
                                }
                                .padding(.horizontal, 3)
                                .padding(.vertical, 5)
                                .background(Color.white.opacity(0.1))
                                .cornerRadius(9999)
                                .padding(.bottom, 20)
                            }
                        }
                    }
                    .padding()
                }
                Spacer()
                NavigationLink{
                    Onboarding1()
                }label: {
                    HStack {
                        Text("next")
                            .font(.system(size: 18).bold())
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                        Image(systemName: "arrow.forward")
                            .font(.system(size: 25).bold())
                            .padding(13)
                            .foregroundColor(Color.black)
                            .background(Color.black.opacity(0.25))
                            .clipShape(Circle())
                    }
                    .frame(width: 200)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color("xanh"))
    //                            .overlay(
    //                                RoundedRectangle(cornerRadius: 50)
    //                                    .stroke(Color("xanh").opacity(0.1), lineWidth: 1)
    //                            )
                    )
                }
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    Onboarding0()
        .preferredColorScheme(.dark)
}
