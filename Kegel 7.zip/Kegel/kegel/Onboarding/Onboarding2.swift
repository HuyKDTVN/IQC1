//
//  Onboarding2.swift
//  kegel-exercise
//
//  Created by Huy Le on 27/4/26.
//

import SwiftUI

struct Onboarding2: View {
    let gender: Int //1 - nam; 2 - nu; 3 - khong xac dinh
    
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    @State var data: [String] = []
    @State private var dataSelect: [Bool] = []
    @State private var hasRedirect = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        NavigationView {
            VStack{
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("selecttarget", comment: ""))
                        .font(.system(size: 20).bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }.padding(.horizontal, 20)
                    .padding(.top, 10)

                ScrollView{
                    VStack(spacing: 0) {
                        ForEach(Array(data.enumerated()), id: \.offset) { index, item in
                            Button{
                               //print("click\(index)")
                                dataSelect[index].toggle()
                            } label: {
                                HStack{
                                    Circle()
                                        .stroke(dataSelect[index] ? .black : .white, lineWidth: 2)
                                        .frame(width: 15, height: 15)
                                    Text(NSLocalizedString(item, comment: ""))
                                        .padding(.leading, 10)
                                        .font(.system(size: 18).bold())
                                        .foregroundColor(dataSelect[index] ? .black : .white)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    Spacer()
                                }
                                .padding(.horizontal, 20)
                                .padding(.vertical, 24)
                                .background(dataSelect[index] ? Color("xanh") : Color.white.opacity(0.1))
                                .cornerRadius(9999)
                                .padding(.bottom, 15)
                            }
                        }
                    }
                    .padding()
                }
                Spacer()
                Button{
                    defaults?.set(dataSelect, forKey: "arrcaithien")
                    hasRedirect = true
                }label: {
                    HStack {
                        Text("next")
                            .font(.system(size: 18).bold())
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                        Image(systemName: "arrow.forward")
                            .font(.system(size: 25).bold())
                            .padding(13)
                            .foregroundColor(Color.black)
                            .background(Color.black.opacity(0.25))
                            .clipShape(Circle())
                    }
                    .frame(width: 200)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color("xanh"))
    //                            .overlay(
    //                                RoundedRectangle(cornerRadius: 50)
    //                                    .stroke(Color("xanh").opacity(0.1), lineWidth: 1)
    //                            )
                    )
                }
                
                NavigationLink("", isActive: $hasRedirect) {
                    Onboarding3()
                }
                
            }.onAppear(){
                data = variable.mucTieuNam
                if (gender == 2) {
                    data = variable.mucTieuNu
                }
                if (gender == 3) {
                    data = variable.mucTieuGioiTinhThu3
                }
                
                dataSelect = Array(repeating: false, count: data.count)
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    Onboarding2(gender: 2).preferredColorScheme(.dark)
}
