//
//  Finish.swift
//  kegel-exercise
//
//  Created by Huy Le on 29/6/25.
//


import SwiftUI

struct Finish : View {
    @StateObject var healthKitManager = HealthKitManager()
    @EnvironmentObject var sessionManager: WatchSessionManager
    var myTitle:String = ""
    let widthCupPicture:CGFloat = WKInterfaceDevice.current().screenBounds.width * 0.6
    let isNewDayBool:Bool = false

    var doDaiBaiTap: Int = 0
    var kegelSecond: Int = 5
    var body: some View {
        NavigationStack {
            ScrollView () {
                
                VStack () {
                    
                    Text(myTitle)//myTitle
                            .foregroundColor(Color("textColorMain"))
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                            .padding(.top, 0)//
                            .padding(.bottom, -20)
                            .font(Font.system(size: 14.0, weight: .bold))
                            .padding(.leading, 5)
                    Image("cup")
                        .resizable()
                        .scaledToFit()
                        .frame(width: widthCupPicture, height: widthCupPicture)
                        //.background(Color.blue.opacity(0.3))
                        .padding(.bottom, -20)
                    HStack {
                        Image(systemName: "heart.fill")
                            .font(.system(size: 22))
                            .foregroundColor(Color.red)
                            //.frame(width: 50, height: 50)
                       
                        if let heartRate = healthKitManager.latestHeartRate {
                            Text(String(format: "%.0f", heartRate))
                            .foregroundColor(Color.white)
                        } else {
                            Text("")
                               
                        }
                        
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
//                    NavigationLink(destination: ContentView()) {
//                        ZStack{
//                            Circle()
//                                .trim(from: 0, to: 1)
//                                .stroke(.white, lineWidth: 15)
//                                .frame(width: widthCircle, height: widthCircle)
//                                .opacity(0.2)
//                            Circle()
//                                .trim(from: 0, to: (sessionManager.muctieuTiLeAll))
//                                .stroke(.xanh, style: StrokeStyle(lineWidth: 15, lineCap: .round))
//                                .frame(width: widthCircle, height: widthCircle)
//                                .rotationEffect(.init(degrees: -90))
//                            Circle()
//                                .trim(from: 0, to: 1)
//                                .stroke(.white, lineWidth: 15)
//                                .frame(width: widthCircleIn, height: widthCircleIn)
//                                .opacity(0.2)
//                            if isNewDayBool == false {
//
//                                Circle()
//                                    .trim(from: 0, to:sessionManager.muctieuTiLeHomNay)
//                                    .stroke(.hong, style: StrokeStyle(lineWidth: 15, lineCap: .round))
//                                    .frame(width: widthCircleIn, height: widthCircleIn)
//                                    .rotationEffect(.init(degrees: -90))
//                                if sessionManager.muctieuTiLeHomNay >= 1 {
//                                    Image(.checked)
//                                        .resizable()
//                                        .frame(width: 22, height: 22, alignment: .center)
//                                }
//                            }
//                        }
//                    }.buttonStyle(PlainButtonStyle())
                    
                    HStack {
                        NavigationLink(destination: ContentView()) {
                            Image(systemName: "house.circle.fill")
                                .font(.system(size: 40))
                                .foregroundColor(Color.white).opacity(0.8)
                                //.frame(width: 50, height: 50)
                            .padding()
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        // Tuỳ chọn 2 → Màn hình C
                        
                            NavigationLink(destination: StartWorkout(doDaiBaiTap2: doDaiBaiTap, loaiBaiTap2: kegelSecond)) {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 42))
                                .padding(9)
                                .foregroundColor(Color.black)
                                .background(Circle().foregroundColor(Color("bgColorMain")))
                                
                                //.frame(width: 50, height: 50)
                            .padding()
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                    }
                }
                
            }
            
        }
        //.ignoresSafeArea()
        .navigationBarBackButtonHidden(true)
        .onAppear() {
            WKInterfaceDevice.current().play(.notification)
            healthKitManager.fetchLatestHeartRate()
        }
    }
}

#Preview {
    Finish()
}
 
