//
//  StartWorkout 2.swift
//  kegel-exercise
//
//  Created by Huy Le on 29/6/25.
//

import SwiftUI
import HealthKit
import Combine
import AVFoundation
import MediaPlayer
import WatchKit
import UIKit

struct StartWorkout: View {
   
    var doDaiBaiTap2: Int // default = 5
    var loaiBaiTap2: Int
    //var loaiBaiTap: Int = 0
    @State private var isAnimating = true
    @State private var isPrepare: Bool = true
    @State private var prepareSecond: Int = 3
    
    @State public var kegelSecond: Int = 5 // can update theo loai bai tap
    
    @EnvironmentObject var sessionManager: WatchSessionManager
    
    @StateObject var healthKitManager = HealthKitManager()
    @StateObject var hkManager = HealthKitAWManager()
    @StateObject private var audioPlayer = AudioPlayer()
    @State private var isPlay: Bool = true
    @State private var isRest: Bool = false
    @State private var closed: Bool = false
    @State private var finished: Bool = false
    @State private var timeRemainingPrepare: Double = 3
    @State private var timeRemainingMax:Double = 5
    @State private var timeRemaining: Double = 5
    @State private var timeRest = 5
    @State private var timer: Timer?
    
    @State private var type:Int = 0
    @State private var rep:Int = 2
    @State private var step:Int = 0
    //@State private var repMax:Int = 3;
    @State private var rotate = false
    
    @State var widthCircle:CGFloat = WKInterfaceDevice.current().screenBounds.width * 0.65
    var widthCircleMax:CGFloat = WKInterfaceDevice.current().screenBounds.width * 0.65
    
    @State var widthSmallCircle:Int = 10
    var widthSmallCircleMin:Int = 7

    let workoutManager = WorkoutManager()
    
    var variable = Variable()
    
    @State var player:AVAudioPlayer = AVAudioPlayer()

    
    func playWorkout() {
        
    }
    func breakWorkout() {

    }

    func finish() {
        
        workoutManager.endWorkout()
        
        stopTimer()
        //let thoiGianTap = UserDefaults.standard.integer(forKey: "thoigiantap") + doDaiBaiTap2 * 10
        //UserDefaults.standard.set(thoiGianTap, forKey: "thoigiantap")
        AW_functions().updateThanhTich(soGiayTap: doDaiBaiTap2 * loaiBaiTap2 * 2)
        closed = true
        
        finished = true
        
    }
    func update() {
        
    }
    func startTimer() {
        isRest = false
        guard timer == nil else { return } // Không tạo lại nếu đã có
        isPlay = true
        timer = Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true) { t in
            
            if isPrepare {
                timeRemainingPrepare -= 0.03
                if timeRemainingPrepare >= 0 {
                    if abs(timeRemainingPrepare - Double(Int(timeRemainingPrepare))) <= 0.03 {
                        prepareSecond = prepareSecond - 1
                        WKInterfaceDevice.current().play(.notification)
                        if prepareSecond == 0 {
                            isPrepare = false
                        }
                    }
                }
                
            } else {
                timeRemaining -= 0.03
                if rep >= 0 {
                    if timeRemaining >= 0 {
                        
                        
                        let myT: Double = (timeRemainingMax)
                        let vanToc: Double = (widthCircleMax - 45.0)  / myT
                        let quangDuongNho: Double = vanToc * 0.03
                        
                        let delta: Double = Double(step) * quangDuongNho
                        
                        if isPlay {
                            withAnimation(.linear(duration: 0.03)) {
                                widthCircle = widthCircleMax - delta
                            }
                        } else {
                            withAnimation(.linear(duration: 0.03)) {
                               
                                widthCircle = 45 + delta
                            }
                        }
                        //print(widthCircle)
                        step = step + 1
                        
                        if abs(timeRemaining - Double(Int(timeRemaining))) <= 0.03 {
                            kegelSecond = kegelSecond - 1
                            if kegelSecond == timeRest - 1 && !isRest && !isPrepare {
                                if isPlay {
                                    
                                    widthSmallCircle = widthSmallCircleMin
                                } else {
                                    widthSmallCircle = 10
                                    
                                }
                               
                            }
                            if kegelSecond == 0 {
                                WKInterfaceDevice.current().play(.notification)
                                isPlay.toggle()
                                step = 0
                                if isPlay {
                                    rep = rep - 1
                                }else {
                                    //WKInterfaceDevice.current().play(.stop)
                                    if rep == 0 {
                                        //WKInterfaceDevice.current().play(.retry)
                                        //WKInterfaceDevice.current().play(.retry)
                                        finish()
                                    }
                                }
                                timeRemaining = timeRemainingMax
                                kegelSecond = Int(timeRemainingMax)
                            }
                        }
                    }
                } else {
                    
                    finish()
                }
                
            }
        }
    }
    func pauseTimer() {
        isRest = true
        timer?.invalidate()
        timer = nil
        isPlay = false
    }

    func stopTimer() {
        timer?.invalidate()
        timer = nil
        
        isPlay = false
    }
    var body: some View {
        
            TabView() {
                NavigationStack {
                    VStack(spacing: 20) {
                        Button(action: {
                            
                            if isRest {
                                if isPlay {
                                    print("pause")
                                    
                                    pauseTimer()
                                }else {
                                    print("start")
                                   
                                    startTimer()
                                }
                            } else {
                                print("pause2")
                                pauseTimer()
                            }
                            
                            
                        }) {
                            VStack {
                                ZStack {
                                    Text("\(doDaiBaiTap2 - rep)/\(doDaiBaiTap2)")
                                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
//                                    if !isPrepare {
//                                        Text("\(kegelSrecond)")
//                                            .foregroundColor(Color("textColorMain"))
//                                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
//                                            .padding(.bottom, 5)
//                                            .transition(.scale)
//                                            .animation(.easeIn(duration: 1), value: !isPrepare)
//                                    }
                                    
                                }
   
                                ZStack {
//                                    Circle()
//                                        .trim(from: 0, to: 1)
//                                        .stroke(isPlay ? Color("textColorMain") : Color.white.opacity(0.4), style: StrokeStyle(lineWidth: 6, lineCap: .round))
//                                        .frame(width: widthCircleMax, height: widthCircleMax)
//                                        .background(Circle().foregroundColor(Color("textColorMain")).frame(width: 100, height: 100))
//                                        .rotationEffect(.init(degrees: -90))
//                                        .shadow(color: Color("bgColorMain"), radius: 10, x: 0, y: 0)
                                    ZStack{
//
                                        ForEach((0...15), id: \.self) {
                                            Circle()
                                                .strokeBorder(Color("textColorMain"), lineWidth: 0)
                                                .background(
                                                    Circle()
                                                        .foregroundColor(Color("textColorMain"))
                                                        .frame(width: (widthCircle / 40 + 6),
                                                               height: (widthCircle / 40 + 6))
                                                )
                                                .offset(
                                                    x: CGFloat(widthCircle / 2) * sin(CGFloat(Int($0)) * .pi/(CGFloat(16) / 2)),
                                                    y: (-CGFloat(widthCircle / 2)) * cos(CGFloat(Int($0)) * .pi/(CGFloat(16) / 2))
                                                )
                                        }
                                    }
                                    
                                    if isPrepare {
                                        Text("\(prepareSecond)")
                                            .foregroundColor(Color.white)
                                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                                            
                                            .font(Font.system(size: 100.0, weight: .medium))
                                    }

                                }
                                
                                .frame(width: widthCircleMax, height: widthCircleMax)
                                HStack {
                                    Image(systemName: "heart.fill")
                                        .font(.system(size: 23))
                                        .foregroundColor(Color.red)
                                        //.frame(width: 50, height: 50)
                                        .shadow(color: Color.red.opacity(0.7), radius: 4, x: 0, y: 0)
//                                    Text("\((0))")
//                                        .foregroundColor(Color.white)
                                    if let heartRate = healthKitManager.latestHeartRate {
                                        Text(String(format: "%.0f", heartRate))
                                        .foregroundColor(Color.white)
                                    } else {
                                        Text("")
                                           
                                    }
                                    Spacer()
                                    
//                                    if !isPlay {
//                                        Text("Paused")
//                                            .font(Font.system(size: 12.0, weight: .bold))
//                                            .foregroundColor(.orange)
//                                            .multilineTextAlignment(TextAlignment.center)
//                                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
//                                            .padding(.trailing, 5)
//                                    }
                                    if isRest {
                                        Image(systemName: "mug.fill")
                                            .font(.system(size: 23))
                                            .foregroundColor(Color.orange)
//                                        Text("Rest")
//                                            .font(Font.system(size: 12.0, weight: .bold))
//                                            .foregroundColor(.orange)
//                                            .multilineTextAlignment(TextAlignment.center)
//                                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
//                                            .padding(.trailing, 5)
                                    }
                                        
                                }
                                .padding(.top, 0)
                            }
                            //r.background(Color.blue)
                        }.buttonStyle(PlainButtonStyle())
                        .navigationDestination(isPresented: $finished) {
                            Finish(myTitle: "\(doDaiBaiTap2) lần", doDaiBaiTap: doDaiBaiTap2, kegelSecond: kegelSecond)
                            
                        }
                        
                    }
                    .padding()
                }
                .navigationBarBackButtonHidden(true)
                VStack {
                    Text("Kegel")
                        .foregroundColor(Color("textColorMain"))
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top, 5)
                        .padding(.bottom, 7)
                        .font(Font.system(size: 13.0, weight: .bold))
                        .padding(.leading, 0)
                    
                    Button(action: {
                        isAnimating.toggle()
                        widthCircle = WKInterfaceDevice.current().screenBounds.width * 0.35
                        if isPlay {
                            pauseTimer()
                          
                        }else {
                            startTimer()
                        }
                    }) {
                        ZStack{
                            Rectangle()
                                .frame(width: 150, height: 60)
                                .foregroundColor(isPlay ? Color.yellow : Color.green).opacity(0.2)
                                .cornerRadius(30)
                                
                            Image(systemName: isPlay ? "pause" : "play.fill")
                                .font(.system(size: 30))
                                .foregroundColor(isPlay ? Color.orange : Color.green)
                            //.frame(width: 50, height: 50)
                                .padding()
                        }
                        
                    }.buttonStyle(PlainButtonStyle())
                    
                    Button(action: {
                        stopTimer()
                        closed = true
                        //finish()

                    }) {
                        ZStack{
                            Rectangle()
                                .frame(width: 150, height: 60)
                                .foregroundColor(Color.red).opacity(0.2)
                                .cornerRadius(30)
                            
                            Image(systemName: "xmark")
                                .font(.system(size: 30))
                                .foregroundColor(Color.red)
                            //.frame(width: 50, height: 50)
                                .padding()
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                    .padding(.top, 7)
                    .navigationDestination(isPresented: $closed) {
                        ContentView()
                        
                    }
                }
                //.ignoresSafeArea()
                .navigationBarBackButtonHidden(true)
            }
            .onAppear() {
                kegelSecond = loaiBaiTap2
                timeRemainingMax = Double(loaiBaiTap2)
                timeRemaining = Double(loaiBaiTap2)
                timeRest = loaiBaiTap2
                
                rep = doDaiBaiTap2 - 1
                workoutManager.startWorkout()
                healthKitManager.fetchLatestHeartRate()
                startTimer()
            }
    }
}

#Preview {
    StartWorkout(doDaiBaiTap2: 5, loaiBaiTap2: 1)
}
