//
//  ContentView.swift
//  Watchkegel Watch App
//
//  Created by Huy Le on 29/6/25.
//

import SwiftUI

struct ContentView: View {
    let variable = Variable()
    
    @State private var redirectToList: Bool = false
    let widthCircle:CGFloat = WKInterfaceDevice.current().screenBounds.width * 0.62
    let widthCircleIn:CGFloat = WKInterfaceDevice.current().screenBounds.width * 0.62 - 35
    let isNewDayBool:Bool = false
    
    //du lieu circle
    //date++++soNgayTap++++percent1Day++++percentAll
    //25/8/2025++++4++++0.4++++0.7
    //@State private var arrThanhTich:[CGFloat] = AW_functions().getThanhTich()
    
    var body: some View {
        NavigationStack {
            TimelineView(.everyMinute) { context in
                let arrThanhTich:[CGFloat] = AW_functions().getThanhTich()
                VStack{
                    Text(variable.mucTieuTitle[2])//myTitle
                        .foregroundColor(Color("textColorMain"))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 30)
                        .padding(.bottom, 5)
                        .font(Font.system(size: 14.0, weight: .bold))
                        .padding(.leading, 2)
                    
                    Button(action: {
                       //withAnimation(.easeOut(duration:0.5)){
                           print("clicked button")
                          redirectToList = true
                          
                       //}
                    }) {
                        ZStack{
                            Circle()
                                .trim(from: 0, to: 1)
                                .stroke(.white, lineWidth: 15)
                                .frame(width: widthCircle, height: widthCircle)
                                .opacity(0.2)
                            Circle()
                                .trim(from: 0, to: arrThanhTich[0])
                                .stroke(Color.green, style: StrokeStyle(lineWidth: 15, lineCap: .round))
                                .frame(width: widthCircle, height: widthCircle)
                                .rotationEffect(.init(degrees: -90))
                            Circle()
                                .trim(from: 0, to: 1)
                                .stroke(.white, lineWidth: 15)
                                .frame(width: widthCircleIn, height: widthCircleIn)
                                .opacity(0.2)
                            if isNewDayBool == false {
                                
                                    Circle()
                                    .trim(from: 0, to: arrThanhTich[1])
                                    .stroke(Color("bgColorMain"), style: StrokeStyle(lineWidth: 15, lineCap: .round))
                                        .frame(width: widthCircleIn, height: widthCircleIn)
                                        .rotationEffect(.init(degrees: -90))
                                if arrThanhTich[1] >= 1 {
                                        Image(.checked)
                                            .resizable()
                                            .frame(width: 35, height: 35, alignment: .center)
                                }
                            }
                        }
                    }
                    .navigationDestination(isPresented: $redirectToList) {
                        SelectType()
                    }
                    .buttonStyle(PlainButtonStyle())
                    .padding(.top, 20)
                    .padding(.bottom, 10)
                    .padding(.leading, 0)
                }
            }
            
        }
    }
        
    
    
}

#Preview {
    ContentView()
}
