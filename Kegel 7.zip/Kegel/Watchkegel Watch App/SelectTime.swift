//
//  SelectTime.swift
//  kegel-exercise
//
//  Created by Huy Le on 20/8/25.
//

import SwiftUI

struct SelectTime: View {
    var loaiBaiTap: Int = 0
    let variable = Variable()
    //@State var thoiGianTap = UserDefaults.standard.integer(forKey: "thoigiantap")
    var body: some View {
        NavigationStack {
            VStack{
                HStack {
                    Text("Thời gian tập")//myTitle
                        .foregroundColor(Color("textColorMain"))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 45)
                        .padding(.bottom, 5)
                        .font(Font.system(size: 14.0, weight: .bold))
                        .padding(.leading, 2)
                }
                
                let times = Array(variable.kegelTimes.enumerated())
                
                List(times, id: \.1) { index, item in
                    NavigationLink(
                        destination: StartWorkout(doDaiBaiTap2: item, loaiBaiTap2: loaiBaiTap)
                    ){
                        HStack{
                            Circle()
                                .stroke(Color("bgColorMain"), lineWidth: 2)
                                .frame(width: 10, height: 10, alignment: .trailing)
                                .padding(.trailing, 0)
                                
                            }
                            .padding(.leading, 10)
                            .padding(.trailing, 10)
                            VStack {
                                Text("\(item) " + NSLocalizedString("lần", comment: ""))
                                    .padding(.bottom, 2)
                                Text("\(item * 10)s")
                                    .padding(.bottom, 2)
                                    .opacity(0.5)
                                    .font(Font.system(size: 13.0, weight: .bold))
                            }
                            Spacer()
                            
                            //.padding(5)
                            //.padding(.leading, 2)
                        
                        .frame(maxWidth: .infinity, alignment: .leading) // 👈 tăng chiều cao
                            //.background(Color.white)
                    }
                }
                .listStyle(.plain)
                .navigationTitle("")//.foregroundColor(Color("bgColorMain)
               .buttonStyle(PlainButtonStyle())
            }
            .padding()
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
        
    }
}

#Preview {
    SelectTime()
}
