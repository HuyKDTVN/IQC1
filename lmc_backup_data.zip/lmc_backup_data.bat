@echo off
powershell -ExecutionPolicy Bypass -File "D:\hometime-share\lmc_backup\lmc_backup_data.ps1"
exit