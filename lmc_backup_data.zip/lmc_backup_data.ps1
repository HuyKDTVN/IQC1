﻿$source = "D:\hometime-share\hometime-data"
$destRoot = "D:\hometime-share\bk"
$log = "D:\hometime-share\backup_log.txt"

$date = Get-Date -Format "dd-MM-yyyy"
$dest = Join-Path $destRoot $date

if (!(Test-Path -Path $dest)) {
    New-Item -ItemType Directory -Path $dest | Out-Null
}

$subDirs = Get-ChildItem -Path $destRoot -Directory | Sort-Object CreationTime

if ($subDirs.Count -gt 2) {
    $numToDelete = $subDirs.Count - 2
    $dirsToDelete = $subDirs | Select-Object -First $numToDelete

    foreach ($dir in $dirsToDelete) {
        try {
            Remove-Item -Path $dir.FullName -Recurse -Force -ErrorAction Stop
            Add-Content -Path $log -Value "$(Get-Date -Format 'dd-MM-yyyy HH:mm:ss') - Deleted old folder: $($dir.FullName)"
        }
        catch {
            Add-Content -Path $log -Value "$(Get-Date -Format 'dd-MM-yyyy HH:mm:ss') - ERROR deleting folder: $($dir.FullName) - $($_.Exception.Message)"
        }
    }
}

Robocopy $source $dest /MIR /Z /R:3 /W:5 /LOG+:$log
