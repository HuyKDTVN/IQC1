//
//  variable.swift
//  Period - BMI
//
//  Created by Huy Le on 08/05/2022.
//

import Foundation
import UIKit
//import HealthKit
import SwiftUI
class Variable {
    var production:Bool = true
    
    let proVersion:Bool = false
    
    //var appID:String = "1623035516" // can thay
    var link_app:String = "https://itunes.apple.com/app/period-calendar-bmi-tracker/1623035516" // can thay
 
    var link_facebook_message: String = "https://forms.gle/jGd4uWnCnWpcjLDp9"
    
    var link_dev:String = "https://itunes.apple.com/developer/huy-le/id1279607371"
    var link_privacy: URL = URL(string: "https://sites.google.com/view/fitness-lady-privacy/")!
    var link_terms: URL = URL(string: "https://sites.google.com/view/k-up-terms-of-service-terms/")!
   
    var arrTinhTrangTitle = ["tinhtrang4", "tinhtrang3", "tinhtrang2", "tinhtrang1", "nogood"]
    var arrTinhTrangID = [4, 3, 2, 1, 99]
    var arrTinhTrangColor = [Color("xanh"), Color("tinhTrang3"), Color("tinhTrang2"), Color("tinhTrang1"), Color("tinhTrangNoGood")]
    
    var kegelTimes = [2, 10, 15, 20, 25, 30]
    var kegelTypes = [3, 4, 5, 1]
    var demoKegel = [
        [5, 5],
        [2, 8],
        [4, 6],
        [1, 12]
    ]
    //let cal = [410 / 60, 410 / 60, 400 / 60, 400 / 60, 410 / 60, 410 / 60]
    
    let mucTieuTitle: [String] = ["Thử thách 7 ngày Kegel", "Thử thách 14 ngày Kegel", "Thử thách 30 ngày Kegel"]
    let muctieuTimes: [Int] = [7, 14, 30] // hien tai chi chon arr[2]
    let mucTieuValue: [Int] = [35, 70, 120] // so phut trong toan bo muc tieu - // hien tai chi chon arr[2]
    
    let mucTieu30Ngay: [[[Int]]] = [
        [[3,6],[4,7],[3,6],[3,6]],//[[3,6],[4,7],[3,6],[3,6]],
        [[4,6],[3,7],[1,10],[4,7]],//[[4,6],[3,7],[1,10],[4,7]],
        [[5,6],[3,8],[1,10],[4,6]],
        [[3,7],[4,6],[1,8],[5,8]],
        [[4,6],[3,7],[1,10],[5,7]],
        [[3,8],[5,6],[4,7],[1,12]],
        [[4,7],[5,6],[3,9],[1,10]],
        [[3,10],[4,8],[5,6],[1,8]],
        [[4,10],[3,7],[5,5],[1,12]],
        [[1,10],[3,10],[5,6],[4,8]],
        [[5,8],[3,7],[4,10],[1,8]],
        [[6,6],[4,7],[5,8],[1,10]],
        [[6,5],[4,8],[5,9],[1,10]],
        [[4,8],[5,6],[6,7],[1,10]],
        [[1,10],[5,8],[4,9],[3,9]],
        [[6,6],[3,9],[1,15],[5,8]],
        [[5,8],[4,10],[1,15],[3,10]],
        [[3,12],[4,10],[6,5],[5,4]],
        [[5,10],[7,3],[4,7],[6,5]],
        [[1,15],[3,10],[7,4],[6,10]],
        [[5,8],[4,10],[3,10],[7,4]],
        [[5,8],[3,10],[7,5],[6,6]],
        [[3,10],[5,10],[1,15],[4,12]],
        [[7,5],[1,20],[5,10],[3,15]],
        [[6,6],[3,8],[5,10],[4,10]],
        [[4,10],[3,10],[6,10],[7,3]],
        [[5,10],[6,5],[7,4],[4,12]],
        [[3,12],[6,7],[4,10],[5,8]],
        [[6,6],[4,10],[5,10],[3,12]],
        [[1,15],[5,10],[3,12],[6,10]]
    ]
    let duytri5p: [[[Int]]] = [
        [[3,7],[4,5],[5,5],[1,10]],
        [[1,7],[3,6],[4,5],[5,6]],
        [[5,4],[3,6],[1,8],[4,7]],
        [[3,7],[4,6],[1,10],[5,4]],
        [[4,3],[3,7],[1,6],[5,7]],
        [[3,6],[5,5],[4,6],[1,9]]
    ]
    let duytri7p: [[[Int]]] = [
        [[5,7],[4,8],[3,8],[1,14]],
        [[1,12],[3,6],[4,9],[5,8]],
        [[5,8],[3,6],[1,7],[4,10]],
        [[3,7],[4,6],[1,10],[5,4]],
        [[4,7],[3,8],[1,8],[5,9]],
        [[3,8],[5,7],[4,9],[1,10]]
    ]
    let duytri9p: [[[Int]]] = [
        [[3,8],[4,6],[5,6],[1,12]],
        [[1,14],[3,6],[4,7],[5,6]],
        [[5,7],[3,5],[1,8],[4,8]],
        [[3,6],[4,9],[1,12],[5,5]],
        [[4,7],[3,8],[1,14],[5,5]],
        [[3,5],[5,7],[4,6],[1,16]]
    ]
    
    let arrCheDoTap = ["titleTapLuyen", "tap5pmoingay", "tap7pmoingay", "tap9pmoingay"]
    let flag = [
        ["uk", "English"],
        ["vi", "Tiếng Việt"],
        ["de", "Tiếng Đức"]
    ]
    
    let mucTieuNam = [
       "tangthoigianQH",
       "kiemsoatxuattinhsom",
       "caithiencuongcung",
       "hotrotuyentienliet",
       "kiemsoatbangquang",
       "chuatri"
    ]
    let mucTieuNu = [
       "phuchoisausinh",
       "tangcamgiac",
       "sontieu",
       "giamdauvungchau",
       "chuatri"
    ]
    
    let mucTieuGioiTinhThu3 = [
       "tangthoigianQH",
       "kiemsoatbangquang",
       "chuatri"
    ]
    let userDefaultGroupName: String = "group.com.huy.kegel"
    let userDefaultThanhTich = "thanhtich"
    
    
    func requestNotificationPermission() async -> Bool {
        do {
            return try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
        } catch {
            return false
        }
    }
    func getUserDefaultBool(name: String) -> Bool {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let result = defaults?.bool(forKey: name) ?? false
        return result
    }
    func getUserDefaultInt(name: String) -> Int {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let result = defaults?.integer(forKey: name) ?? 0
        return result
    }
    func getUserDefaultString(name: String) -> String {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let result = defaults?.string(forKey: name) ?? ""
        return result
    }
    func getUserDefaultArrInt(name: String) -> [[Int]] {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let arr = defaults?.array(forKey: name) as? [[Int]] ?? []
        return arr
    }
    func getUserDefaultArrInt1(name: String) -> [Int] {
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        let arr = defaults?.array(forKey: name) as? [Int] ?? []
        return arr
    }
    
    func getArrWorkoutToday() -> [[Int]] {
        let soNgayDaTap = soNgayDaTapArrayItem()
        var result: [[Int]] = [[]]
        let randomNumber = Int.random(in: 0...5)
        if soNgayDaTap < 30 {
            result = mucTieu30Ngay[soNgayDaTap]
        }else{
            result = duytri5p[randomNumber]
        }
        let cheDoTap = getUserDefaultInt(name: "chedotap")
        if cheDoTap > 0 {
            
            switch cheDoTap {
            case 1:
                result = duytri5p[randomNumber]
            case 2:
                result = duytri7p[randomNumber]
            case 3:
                result = duytri9p[randomNumber]
            default:
                result = duytri5p[randomNumber]
            }
        }
        return result
    }
    
//    func updateExerciseMinutes(minutes: Double, date: Date, totalCalories: Double) {
//        let healthStore = HKHealthStore()
//        let startDate = date
//        let endDate = date.addingTimeInterval(minutes * 60)
//
//        // Tính tổng calo tiêu thụ (tuỳ theo loại bài tập và người dùng thực tế bạn có thể tính chính xác hơn)
//        let energyUnit = HKUnit.kilocalorie()
//        let energyQuantity = HKQuantity(unit: energyUnit, doubleValue: totalCalories)
//
//        // Tạo workout sample
//        let workout = HKWorkout(activityType: .traditionalStrengthTraining,
//                                start: startDate,
//                                end: endDate,
//                                duration: minutes * 60,
//                                totalEnergyBurned: energyQuantity,
//                                totalDistance: nil,
//                                metadata: nil)
//
//        healthStore.save(workout) { (success, error) in
//            if success {
//                print("Cập nhật workout thành công với \(totalCalories) kcal.")
//            } else {
//                print("Lỗi khi cập nhật workout: \(String(describing: error))")
//            }
//        }
//    }
    func getTinhTrang(name: String) -> [Double] {
        let input = getUserDefaultArrInt1(name: name)
        let trimmed = input.count > 7
                ? Array(input.suffix(7))
                : input
            
            // Chuyển đổi theo quy tắc
            var result = trimmed.map { value -> Double in
                switch value {
                case 0:
                    return 4
                case 1:
                    return 3
                
                case 3:
                    return 1
                case 4:
                    return -2
                default:
                    return Double(value)
                }
            }
            
            // Thêm 0 cho đủ 7 phần tử
            while result.count < 7 {
                result.append(0)
            }
            return result
    }
    func percentToday() -> Int {
        var result : Int = 0
        let data = getUserDefaultString(name: userDefaultThanhTich)
       
        var soGiayCanTap = 0
        if !data.isEmpty {
            let arrData = data.components(separatedBy: "++++")
            var soGiayDaCo = 0
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy_MM_dd"
            let dataDate = dateFormatter.date(from:String(arrData[0]))!
            if (Calendar.current.isDateInToday(dataDate)){
                soGiayDaCo = Int(arrData[2]) ?? 0
            }
                
            if soGiayDaCo > 0 {
                let arrSoGiayCanTap = getArrWorkoutToday() //[3,7],[4,6],[1,8],[5,8]
                let cheDoTap = getUserDefaultInt(name: "chedotap")
                if cheDoTap != 1 {
                    for item in arrSoGiayCanTap {
                        soGiayCanTap = soGiayCanTap + item[0] * item[1] * 2 * 3 // moi ngay tap 3 lan
                    }
                }else{
                    for item in arrSoGiayCanTap {
                        soGiayCanTap = soGiayCanTap + item[0] * item[1] * 2 * 2 // moi ngay tap 2 lan
                    }
                }
                result = Int(Double(soGiayDaCo) * 100 / Double(soGiayCanTap))
            }
            
        }
        return result
    }
    
    func percentAll() -> Int {
        var result : Int = 0
        let data = getUserDefaultString(name: userDefaultThanhTich)
        var soNgayDaTap: Int = 0
        if !data.isEmpty {
            let arrData = data.components(separatedBy: "++++")
            soNgayDaTap = Int(arrData[1]) ?? 0
            print("soNgayDaTap: \(soNgayDaTap)")
            let soGiayDaTap = Int(arrData[2]) ?? 0
            if soGiayDaTap > 0 {
                result = Int(Double(soNgayDaTap + 1) * 100 / 30)
            }else{
                result = Int(Double(soNgayDaTap) * 100 / 30)
            }
            
        }
        print("percentAll: \(result)")
        return result
    }
    func soNgayDaTapArrayItem() -> Int {
//        let data = getUserDefaultString(name: userDefaultThanhTich)
        var soNgayDaTap: Int = 0
//        if !data.isEmpty {
//            let arrData = data.components(separatedBy: "++++")
//            soNgayDaTap = Int(arrData[1]) ?? 0
//        }
        soNgayDaTap = getNgayTap() - 1
        return soNgayDaTap
    }
    func savePhutTap(soGiayTap: Int) {
        let soGiayDaCo = getUserDefaultInt(name: "sogiaytap")
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        defaults?.set(soGiayDaCo + soGiayTap, forKey: "sogiaytap")
    }
    func saveThanhTichTuanNay(soGiayTap: Int) {
        let dayOfWeek:Int = Date().dayNumberOfWeek()!
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        switch (dayOfWeek) {
            case (1):
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day1"), forKey: "day1")
            case (2):
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day2"), forKey: "day2")
            case (3):
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day3"), forKey: "day3")
            case (4):
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day4"), forKey: "day4")
            case (5):
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day5"), forKey: "day5")
            case (6):
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day6"), forKey: "day6")
            case (7):
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day7"), forKey: "day7")
            default:
                defaults?.set(soGiayTap + getUserDefaultInt(name: "day1"), forKey: "day1")
        }
    }
    func getWeekOfYear() -> Int {
       // Lấy ngày hiện tại
       let currentDate = Date()
       // Tạo một đối tượng Calendar
       let calendar = Calendar.current
       let weekOfYear = calendar.component(.weekOfYear, from: currentDate)
       return  weekOfYear
    }
    func clearThanhTichTuanTruoc(){
        //sang tuan moi reset ket qua tuan ve 0
        let weekOfYear = getWeekOfYear()
        let weekOfYearInDataBase = UserDefaults.standard.integer(forKey: "weekofyear")
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        if(weekOfYear != weekOfYearInDataBase) {
            UserDefaults.standard.set(weekOfYear, forKey: "weekofyear")
            defaults?.set(0, forKey: "day1")
            defaults?.set(0, forKey: "day2")
            defaults?.set(0, forKey: "day3")
            defaults?.set(0, forKey: "day4")
            defaults?.set(0, forKey: "day5")
            defaults?.set(0, forKey: "day6")
            defaults?.set(0, forKey: "day7")
        }
    }
    func updateThanhTich(soGiayTap: Int) {
        //data sample
        //date++++soNgayTap++++sogiaytap
        //16/5/2026++++2++++210
        //let loaiMucTieu: Int = 2
        let date = Date()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy_MM_dd"
        
        var data = getUserDefaultString(name: userDefaultThanhTich)
        
        if data.isEmpty { //ngay tap dau tien
            data = dateFormatter.string(from: date) + "++++0++++" + String(soGiayTap)
        } else{
            print("data:")
            print( data)
            print("data:")
            
            //da tung tap truoc do
            let arrData = data.components(separatedBy: "++++")
            
            let dataDate = dateFormatter.date(from:String(arrData[0]))!
            
            let soNgayDaTap: Int = Int(arrData[1]) ?? 0
            if (Calendar.current.isDateInToday(dataDate)) {
                // hom nay da tung tap roi va gio tap them
                let soGiayHomNay = soGiayTap + (Int(arrData[2]) ?? 0)
                data = arrData[0] + "++++" + String(soNgayDaTap) + "++++" + String(soGiayHomNay)
            }else{
                //hom nay chua tung tap
                data = dateFormatter.string(from: date) + "++++" + String(soNgayDaTap + 1) + "++++" + String(soGiayTap)
            }
        }
       
        let defaults = UserDefaults(suiteName: userDefaultGroupName)
        defaults?.set(data, forKey: userDefaultThanhTich)
    }
    
    func getThoiGianNhacNho() -> [Int] {
        @AppStorage(
            "thoigiannhacnho",
            store: UserDefaults(suiteName: userDefaultGroupName)
        ) var selectThoiGianThongBaoTimestamp: Double = Date().timeIntervalSince1970

        let date = Date(timeIntervalSince1970: selectThoiGianThongBaoTimestamp)

        let hour = Calendar.current.component(.hour, from: date)
        let minute = Calendar.current.component(.minute, from: date)
        
        return [hour, minute]
    }
    
    func getTimeQH(name: String) -> [Int] {
        let input = getUserDefaultArrInt1(name: name)
        let trimmed = input.count > 7
                ? Array(input.suffix(7))
                : input
            
            // Chuyển đổi theo quy tắc
            var result = trimmed.map { value -> Int in
                return (value)
            }
            // Thêm 0 cho đủ 7 phần tử
            while result.count < 7 {
                result.append(0)
            }
            return result
    }
    
    func getTimeQHTrungBinh(name: String) -> Double {
        let input = getUserDefaultArrInt1(name: name)
        let result = average(input)
        return result
    }
    
    func getSoPhutTap() -> Double {
        var result: Double = Double(getUserDefaultInt(name: "sogiaytap")) / 60
        result = round(result * 10) / 10
        return result
    }
    
    func getNgayTap() -> Int {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy_MM_dd"
        
        let data = getUserDefaultString(name: userDefaultThanhTich)
        var soNgayDaTap: Int = 0
        if !data.isEmpty {
            let arrData = data.components(separatedBy: "++++")
            print("arrData1")
            print(arrData)
            soNgayDaTap = Int(arrData[1]) ?? 0
            let dataDate = dateFormatter.date(from:String(arrData[0]))!
            if (!Calendar.current.isDateInToday(dataDate)) {
                soNgayDaTap = soNgayDaTap + 1
            }
        }
        soNgayDaTap = soNgayDaTap + 1
        return soNgayDaTap
    }
    func getDataThanhTichTuanNay() -> [Double] {
        let result: [Double] = [Double(getUserDefaultInt(name: "day1")) / 60, Double(getUserDefaultInt(name: "day2")) / 60, Double(getUserDefaultInt(name: "day3")) / 60, Double(getUserDefaultInt(name: "day4")) / 60, Double(getUserDefaultInt(name: "day5")) / 60, Double(getUserDefaultInt(name: "day6")) / 60, Double(getUserDefaultInt(name: "day7")) / 60]
        return result
    }
    func average(_ numbers: [Int]) -> Double {
        guard !numbers.isEmpty else { return 0.0 }

        let avg = Double(numbers.reduce(0, +)) / Double(numbers.count)

        return Double(String(format: "%.1f", avg)) ?? 0.0
    }
    func formatTime(_ seconds: Int) -> String {
        let minutes = seconds / 60
        let secs = seconds % 60
        return String(format: "%02d:%02d", minutes, secs)
    }
    func percentCongThem(soGiayTap: Int) -> Int {
        var result : Int = 0
        let cheDoTap = getUserDefaultInt(name: "chedotap")
        let arrSoGiayCanTap = getArrWorkoutToday() //[3,7],[4,6],[1,8],[5,8]
        var soGiayCanTap = 0
        if cheDoTap != 1 {
            for item in arrSoGiayCanTap {
                soGiayCanTap = soGiayCanTap + item[0] * item[1] * 2 * 3 // moi ngay tap 3 lan
            }
        }else{
            for item in arrSoGiayCanTap {
                soGiayCanTap = soGiayCanTap + item[0] * item[1] * 2 * 2 // moi ngay tap 2 lan
            }
        }
        result = Int(Double(soGiayTap) * 100 / Double(soGiayCanTap))
        return result
    }
    func getColorByGender() -> Color {
        var result = Color("xanhnon")
        if getUserDefaultInt(name: "gender") != 0 {
            result = Color("tim")
        }
        return result
    }
    
    func getForeColorByGender() -> Color {
        var result = Color.black
        if getUserDefaultInt(name: "gender") != 0 {
            result = Color.white
        }
        
        return result
    }
    
    func getColorByGenderVar(gender: Int) -> Color {
        var result = Color("xanhnon")
        if gender != 0 {
            result = Color("tim")
        }
        return result
    }
    
    func getForeColorByGenderVar(gender: Int) -> Color {
        var result = Color.black
        if gender != 0 {
            result = Color.white
        }
        
        return result
    }
}
extension Date {
    // returns an integer from 1 - 7, with 1 being Sunday and 7 being Saturday
    func dayNumberOfWeek() -> Int? {
        return Calendar.current.dateComponents([.weekday], from: self).weekday
    }
}
