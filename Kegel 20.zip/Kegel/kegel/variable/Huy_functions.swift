//
//  Huy_functions.swift
//  kegel-exercise
//
//  Created by Huy Le on 31/5/26.
//
import Foundation
import UIKit
//import HealthKit
import SwiftUI
class Huy_functions {
    func setNotiDaily(mtitle: String, mcontent: String, gio: Int, phut: Int, myName: String) {
       removeNoti(myName: myName)
       
       //set noti repeat daily
       let notificationContent = UNMutableNotificationContent()
       notificationContent.title = mtitle
       notificationContent.body = mcontent
       let currentBadge = UIApplication.shared.applicationIconBadgeNumber
       let newBadge = currentBadge + 1
       notificationContent.badge = NSNumber(value: newBadge)
       notificationContent.sound = .default
                   
       var datComp = DateComponents()
       datComp.hour = gio
       datComp.minute = phut
       
       
       let trigger = UNCalendarNotificationTrigger(dateMatching: datComp, repeats: true)
       let request = UNNotificationRequest(identifier: myName, content: notificationContent, trigger: trigger)
              UNUserNotificationCenter.current().add(request) { (error : Error?) in
                  if let theError = error {
                      print(theError.localizedDescription)
                  }
              }
    }


    func getRatioScreen() -> Double {
       let screenSize: CGRect = UIScreen.main.bounds
       //print("ratio: \(screenSize.height / screenSize.width) - \(screenSize.height) - \(screenSize.width)")
       return screenSize.height / screenSize.width
    }
    func getWidthScreen() -> Int {
       let screenSize: CGRect = UIScreen.main.bounds
       return Int(screenSize.width)
    }
    func setNoti(mtitle: String, mcontent: String, nam: Int, thang: Int,  ngay: Int, gio: Int, phut: Int, myName: String) {
       removeNoti(myName: myName)
       
       //set noti repeat daily
       let notificationContent = UNMutableNotificationContent()
       notificationContent.title = mtitle
       notificationContent.body = mcontent
        let currentBadge = UIApplication.shared.applicationIconBadgeNumber
        let newBadge = currentBadge + 1
        notificationContent.badge = NSNumber(value: newBadge)

       notificationContent.sound = .default
                   
       var datComp = DateComponents()
       datComp.day = ngay
       datComp.month = thang
       datComp.year = nam
       datComp.hour = gio
       datComp.minute = phut
       
       let trigger = UNCalendarNotificationTrigger(dateMatching: datComp, repeats: false)
       let request = UNNotificationRequest(identifier: myName, content: notificationContent, trigger: trigger)
              UNUserNotificationCenter.current().add(request) { (error : Error?) in
                  if let theError = error {
                      print(theError.localizedDescription)
                  }
              }
    }

    func setNoti2(
       mtitle: String,
       mcontent: String,
       soNgayCong: Int,   // n ngày cộng thêm
       gio: Int,
       phut: Int,
       myName: String
    ) {
       removeNoti(myName: myName)

       let notificationContent = UNMutableNotificationContent()
       notificationContent.title = mtitle
       notificationContent.body = mcontent

       let currentBadge = UIApplication.shared.applicationIconBadgeNumber
       notificationContent.badge = NSNumber(value: currentBadge + 1)
       notificationContent.sound = .default

       let calendar = Calendar.current
       let today = Date()

       // 👉 Ngày hiện tại + n ngày
       guard let futureDate = calendar.date(byAdding: .day, value: soNgayCong, to: today) else {
           return
       }

       // 👉 Lấy year/month/day từ futureDate
       var datComp = calendar.dateComponents([.year, .month, .day], from: futureDate)

       // 👉 Giờ & phút do người dùng nhập
       datComp.hour = gio
       datComp.minute = phut

       let trigger = UNCalendarNotificationTrigger(
           dateMatching: datComp,
           repeats: false
       )

       let request = UNNotificationRequest(
           identifier: myName,
           content: notificationContent,
           trigger: trigger
       )

       UNUserNotificationCenter.current().add(request) { error in
           if let error = error {
               print(error.localizedDescription)
           }
       }
    }


    func removeNoti(myName: String) {
       //remove noti before
       UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [myName])
       UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [myName])
    }
    func setNotiChuaTap() {
        let timeNhacNho = Variable().getThoiGianNhacNho()
        
        setNoti2(mtitle: NSLocalizedString("titleNotiChuaTapNgay2", comment: ""), mcontent: NSLocalizedString("descNotiChuaTapNgay2", comment: ""),soNgayCong: 1, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay2")
        setNoti2(mtitle: NSLocalizedString("titleNotiChuaTapNgay3", comment: ""), mcontent: NSLocalizedString("descNotiChuaTapNgay3", comment: ""),soNgayCong: 2, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay3")
        setNoti2(mtitle: NSLocalizedString("titleNotiChuaTapNgay4", comment: ""), mcontent: NSLocalizedString("descNotiChuaTapNgay4", comment: ""),soNgayCong: 3, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay4")
        setNoti2(mtitle: NSLocalizedString("titleNotiChuaTapNgay5", comment: ""), mcontent: NSLocalizedString("descNotiChuaTapNgay5", comment: ""),soNgayCong: 4, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay5")
    }
    func setNotiDaTap() {
        let timeNhacNho = Variable().getThoiGianNhacNho()
        let randomNumber = Int.random(in: 1...5)
        setNoti2(mtitle: NSLocalizedString("tilteDaTap1Ngay\(randomNumber)", comment: ""), mcontent: NSLocalizedString("descDaTap1Ngay\(randomNumber)", comment: ""),soNgayCong: 1, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay2")
        setNoti2(mtitle: NSLocalizedString("tilteDaTap2Ngay\(randomNumber)", comment: ""), mcontent: NSLocalizedString("descDaTap2Ngay\(randomNumber)", comment: ""),soNgayCong: 2, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay3")
        setNoti2(mtitle: NSLocalizedString("tilteDaTap3Ngay\(randomNumber)", comment: ""), mcontent: NSLocalizedString("descDaTap3Ngay\(randomNumber)", comment: ""),soNgayCong: 3, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay4")
        setNoti2(mtitle: NSLocalizedString("tilteDaTap4Ngay\(randomNumber)", comment: ""), mcontent: NSLocalizedString("descDaTap4Ngay\(randomNumber)", comment: ""),soNgayCong: 4, gio: timeNhacNho[0], phut: timeNhacNho[1], myName: "nhactapngay5")
    }
}
