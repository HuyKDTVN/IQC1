//
//  ChonBaiTuTap.swift
//  kegel-exercise
//
//  Created by Huy Le on 19/5/26.
//

import SwiftUI

struct ChonBaiTuTap: View {
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    var body: some View {
        //NavigationView{
            VStack{
                HStack{
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("day", comment: "") + " \(variable.getNgayTap())")
                        .font(.system(size: 20).bold())
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                }.padding(.horizontal, 20)
                    .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                Spacer()
                ScrollView{
                    ForEach(variable.kegelTypes, id: \.self) { item in
                        NavigationLink{
                            ChonCuongDoTap(loaiBaiTap: item)
                        } label: {
                            HStack{
                                Circle()
                                    .stroke(myBgColor, lineWidth: 2)
                                    .frame(width: 10, height: 10, alignment: .trailing)
                                    .padding(.trailing, 0)
                                VStack (alignment: .leading) {
                                    Text("\(item) " + NSLocalizedString("tap", comment: "") + ", " + "\(item) " + NSLocalizedString("rest", comment: ""))
                                        .padding(.bottom, 2)
                                        .font(Font.system(size: 16.0, weight: .bold))
                                        .foregroundColor(.white)
                                }
                                .padding(.leading, 20)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .padding(.horizontal, 30)
                            .padding(.vertical, 30)
                            .background(
                                RoundedRectangle(cornerRadius: 50)
                                    .fill(Color.white.opacity(0.07))
                            )
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                Spacer()
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
//        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
    }
}

#Preview {
    ChonBaiTuTap().preferredColorScheme(.dark)
}
