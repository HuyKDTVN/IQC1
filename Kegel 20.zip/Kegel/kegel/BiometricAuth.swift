//
//  BiometricAuth.swift
//  kegel-exercise
//
//  Created by Huy Le on 12/6/26.
//

import LocalAuthentication

class BiometricAuth {

    static func authenticate(completion: @escaping (Bool) -> Void) {
        let context = LAContext()
        var error: NSError?

        if context.canEvaluatePolicy(.deviceOwnerAuthentication,
                                     error: &error) {

            context.evaluatePolicy(
                .deviceOwnerAuthentication,
                localizedReason: "Use Face ID to unlock the app"
            ) { success, error in

                DispatchQueue.main.async {
                    completion(success)
                }
            }

        } else {
            DispatchQueue.main.async {
                completion(false)
            }
        }
    }
}
