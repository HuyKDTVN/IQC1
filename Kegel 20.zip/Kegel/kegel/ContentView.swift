import SwiftUI

//import HealthKit
struct ContentView: View {
    //@Environment(\.scenePhase) private var scenePhase
    @State var isUnlocked = false
    @AppStorage(
        "gender",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var gender: Int = 0
    
    @State private var myBgColor: Color = Variable().getColorByGenderVar(gender: 0)
    @State private var myColor: Color = Variable().getForeColorByGenderVar(gender: 0)
    var variable:Variable = Variable()
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    @AppStorage(
        "showTinhTrangQH",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var showTinhTrangQH: Bool = Variable().getUserDefaultBool(name: "showTinhTrangQH")
    
    @AppStorage(
        "look",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var haveToLook: Bool = Variable().getUserDefaultBool(name: "look")
    
    @AppStorage(
        "showTinhTrangTri",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var showTinhTrangTri: Bool = Variable().getUserDefaultBool(name: "showTinhTrangTri")
    
    @AppStorage(
        "showTinhTrangSonTieu",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var showTinhTrangSonTieu: Bool = Variable().getUserDefaultBool(name: "showTinhTrangSonTieu")
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        //Group {
            //if isUnlocked == true || haveToLook == false{
                Group{
                    if (variable.getNgayTap() > 30 && variable.getUserDefaultInt(name: "chedotap") == 0) {
                        SelectCheDoTapDuyTri().navigationBarHidden(true)
                    }else{
                        NavigationView{
                            ScrollView(showsIndicators: false){
                                VStack{
                                    HStack(alignment: .top){
                                        NavigationLink {
                                            Setting().navigationBarHidden(true)
                                       } label: {
                                            Image(systemName: "slider.horizontal.3")
                                                .font(Font.system(size: 23))
                                                .foregroundColor(myBgColor)
                                                .frame(width: 45, height: 45)
                                                //.background(Color.white.opacity(0))
                                                .clipShape(Circle())
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 30)
                                                        .stroke(Color.white.opacity(0.2), lineWidth: 1)
                                                )
                                        }
                                        Spacer()
                                    }.padding(.horizontal, 20)
                                        .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                                    HomeGuide()
                                    HomeThanhTichHomNay()

                                    HomeThoiGianDaTap()
                                    HomeThanhTichTuanNay()
                                        .padding(.bottom, 20)
                                    if(showTinhTrangQH) {
                                        HomeTimeQH()
                                            .padding(.bottom, 20)
                                        HomeChartQH()
                                            .padding(.bottom, 20)
                                    }
                                    if(showTinhTrangSonTieu) {
                                        HomeChartSonTieu()
                                            .padding(.bottom, 20)
                                    }
                                    if(showTinhTrangTri) {
                                        HomeChartTri()
                                    }
                                }

                            }.onAppear(){
                                myBgColor = Variable().getColorByGenderVar(gender: gender)
                                myColor = Variable().getForeColorByGenderVar(gender: gender)
                                defaults?.set(true, forKey: "finishonboarding")
                                variable.clearThanhTichTuanTruoc()
                            }
                            .navigationBarHidden(true)
                            .ignoresSafeArea(.container, edges: .top)
                            .navigationBarBackButtonHidden(true)
                            .navigationViewStyle(StackNavigationViewStyle())
                            .transition(.move(edge: .trailing))
                        }
                    }
                }
            //} else {
                //LockScreen(isUnlocked: $isUnlocked)
            //}
        //}
        //.onChange(of: scenePhase) { phase in
//            if phase == .background {
//                isUnlocked = false
//            }
        //}
        
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}
