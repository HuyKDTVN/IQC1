//
//  Setting.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct Setting: View {
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    @State private var amThanh = true
    @State var showPrivacyPage: Bool = false
    @State var showTermsPage: Bool = false
    @State private var nhacTuMoi = true
    
    var ThoiGianNghiaGiuaHiep = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    
    @AppStorage(
        "ThoiGianNghiaGiuaHiep",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var selectThoiGianNghiaGiuaHiep: Int = 5
    
    @AppStorage(
        "chedotap",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var selectchedotap: Int = 0
    
    @AppStorage(
        "showTinhTrangQH",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var showTinhTrangQH: Bool = false
    @AppStorage(
        "rung",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var rung: Bool = false
    
    @AppStorage(
        "shownoti",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var shownoti: Bool = false

    var arrGender = ["man", "female", "khonggioitinh"]
   
    @AppStorage(
        "gender",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var gender: Int = 0
    
    @AppStorage(
        "showTinhTrangTri",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var showTinhTrangTri: Bool = false
    
    @AppStorage(
        "showTinhTrangSonTieu",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var showTinhTrangSonTieu: Bool = false
    
    @AppStorage(
        "thoigiannhacnho",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var selectThoiGianThongBaoTimestamp: Double = Date().timeIntervalSince1970

    private var selectThoiGianThongBaoBinding: Binding<Date> {
        Binding(
            get: {
                Date(timeIntervalSince1970: selectThoiGianThongBaoTimestamp)
            },
            set: {
                selectThoiGianThongBaoTimestamp = $0.timeIntervalSince1970
                if shownoti {
                    if(variable.getSoPhutTap() > 0) {
                        Huy_functions().setNotiDaTap()
                    }else{
                        Huy_functions().setNotiChuaTap()
                    }
                    print("da cai dat lai thoi gian hien thi noti")
                }
            }
        )
    }
    @AppStorage(
        "look",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var showLook: Bool = false
    
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //ScrollView {
            VStack{
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text("setting")
                        .font(.largeTitle.bold())
                        //.font(.system(size: 20).bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }.padding(.horizontal, 20)
                    .padding(.top, 0)
                
                //NavigationView {
                    
                    List{
//                        Section{
//                            HStack {
//                                Circle()
//                                    .strokeBorder(myBgColor,lineWidth: 2)
//                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
//                               
//                                Toggle(NSLocalizedString("Ngôn ngữ", comment: ""), isOn: $amThanh)
//                                     .toggleStyle(SwitchToggleStyle(tint: myBgColor))
//                                    .onChange(of: amThanh) { value in
//                                        defaults?.set(amThanh, forKey: "amThanh")
//                                       
//                                    }
//                                
//                               
//                            }
//                        }
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor, lineWidth: 2)
                                    .background(
                                        Circle()
                                            .foregroundColor(myBgColor.opacity(0.2))
                                    )
                                    .frame(width: 20, height: 20)

                                Picker(NSLocalizedString("gender", comment: ""), selection: $gender) {

                                    ForEach(arrGender.indices, id: \.self) { index in
                                        Text(NSLocalizedString(arrGender[index], comment: "")).tag(index)
                                    }
                                }
//                                .onChange(of: gender) { value in
//                                    defaults?.set(value, forKey: "gender")
//                                }
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                                Picker(NSLocalizedString("chedotap", comment: ""), selection: $selectchedotap) {

                                    ForEach(variable.arrCheDoTap.indices, id: \.self) { index in
                                        Text(NSLocalizedString(variable.arrCheDoTap[index], comment: "")).tag(index)
                                    }
                                }
                                .onChange(of: selectchedotap) { value in
                                    defaults?.set(value, forKey: "chedotap")
                                }
                                
                               
                               
                            }
                        }
                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                                Picker(NSLocalizedString("thoigiannghigiuahiep", comment: ""), selection: $selectThoiGianNghiaGiuaHiep) {
                                    ForEach(ThoiGianNghiaGiuaHiep, id: \.self) {
                                        Text("\($0)")
                                    }
                                }.onReceive([self.selectThoiGianNghiaGiuaHiep].publisher.first()) { (value) in
                                    defaults?.set(value, forKey: "ThoiGianNghiaGiuaHiep")
                                }
                               
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("rungkhitap", comment: ""), isOn: $rung)
                                     .toggleStyle(SwitchToggleStyle(tint: myBgColor))
                                    .onChange(of: rung) { value in
                                        defaults?.set(rung, forKey: "amThanh")
                                       
                                    }
                            }
                        }
                       
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("notitapluyen", comment: ""), isOn: $shownoti)
                                     .toggleStyle(SwitchToggleStyle(tint: myBgColor))
                                    .onChange(of: shownoti) { value in
                                        defaults?.set(shownoti, forKey: "shownoti")
                                        if shownoti == false{
                                            Huy_functions().removeNoti(myName: "nhactapngay2")
                                            Huy_functions().removeNoti(myName: "nhactapngay3")
                                            Huy_functions().removeNoti(myName: "nhactapngay4")
                                            Huy_functions().removeNoti(myName: "nhactapngay5")
                                        }
                                        else{
                                            if(variable.getSoPhutTap() > 0) {
                                                Huy_functions().setNotiDaTap()
                                            }else{
                                                Huy_functions().setNotiChuaTap()
                                            }
                                        }
                                    }
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor, lineWidth: 2)
                                    .background(
                                        Circle()
                                            .foregroundColor(myBgColor.opacity(0.2))
                                    )
                                    .frame(width: 20, height: 20)

                                DatePicker(
                                    NSLocalizedString("timeNoti", comment: ""),
                                    selection: selectThoiGianThongBaoBinding,
                                    displayedComponents: .hourAndMinute
                                )
                                
                                
                            }
                        }
                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("hienthitinhtrangquanhe", comment: ""), isOn: $showTinhTrangQH)
                                     .toggleStyle(SwitchToggleStyle(tint: myBgColor))
                                    .onChange(of: showTinhTrangQH) { value in
                                        defaults?.set(showTinhTrangQH, forKey: "showTinhTrangQH")
                                    }
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("hienthitinhtrangsontieu", comment: ""), isOn: $showTinhTrangSonTieu)
                                     .toggleStyle(SwitchToggleStyle(tint: myBgColor))
                                    .onChange(of: showTinhTrangSonTieu) { value in
                                        defaults?.set(showTinhTrangSonTieu, forKey: "showTinhTrangSonTieu")
                                    }
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("hienthitinhtrangtri", comment: ""), isOn: $showTinhTrangTri)
                                     .toggleStyle(SwitchToggleStyle(tint: myBgColor))
                                    .onChange(of: showTinhTrangTri) { value in
                                        defaults?.set(showTinhTrangTri, forKey: "showTinhTrangTri")
                                        if nhacTuMoi == false{

                                        }
                                       
                                    }
                            }
                            
                        }
//                        Section{
//                            HStack {
//                                Circle()
//                                    .strokeBorder(myBgColor,lineWidth: 2)
//                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
//                               
//                                Toggle(NSLocalizedString("lookapp", comment: ""), isOn: $showLook)
//                                     .toggleStyle(SwitchToggleStyle(tint: myBgColor))
//                                    .onChange(of: showLook) { value in
//                                        defaults?.set(showLook, forKey: "look")
//                                    }
//                            }
//                        }
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.2))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("rate5", comment: ""), destination: URL(string: variable.link_app)!).foregroundColor(.white)
                                
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("readmore", comment: ""), destination: URL(string: variable.link_dev)!).foregroundColor(.white)
                                
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(myBgColor,lineWidth: 2)
                                    .background(Circle().foregroundColor(myBgColor.opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("help&feedback", comment: ""), destination: URL(string: variable.link_facebook_message)!).foregroundColor(.white)
                            }
                            NavigationLink {
                                Privacy()
                            } label: {
                                HStack{
                                    Circle()
                                        .strokeBorder(myBgColor,lineWidth: 2)
                                        .background(Circle().foregroundColor(myBgColor.opacity(0.4))).frame(width: 20, height: 20)
                                    
                                    Text(NSLocalizedString("privacy", comment: ""))
                                        .foregroundColor(.white)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                            }
                            NavigationLink {
                                Terms()
                            } label: {
                                HStack{
                                    Circle()
                                        .strokeBorder(myBgColor,lineWidth: 2)
                                        .background(Circle().foregroundColor(myBgColor.opacity(0.4))).frame(width: 20, height: 20)
                                    
                                    Text(NSLocalizedString("term", comment: ""))
                                        .foregroundColor(.white)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                            }
                        }
                    }
                    
                }
                
              //  Spacer()
            //}
            .onAppear() {
                amThanh = defaults?.bool(forKey: "amThanh") ?? false
                nhacTuMoi = defaults?.bool(forKey: "nhacnhotapluyen") ?? false
            }
            .padding(.top, 70)
            //.padding()
            
            
        .edgesIgnoringSafeArea(.all)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                NavigationLink(destination: ContentView()) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color("textTim"))
                        .clipShape(Circle())
                }
            }
        }
    }
}

#Preview {
    Setting().preferredColorScheme(.dark)
}
