//
//  HomeChartQH.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//
import SwiftUI
struct HomeChartQH: View {
    @State private var data: [Int] = Variable().getTimeQH(name: "arrChatLuongQH")
    //@State private var data: [Int] = [1, 2, 3, 4, 5, 5 , 5]
    let days = ["1", "2", "3", "4", "5", "6", "7"]
    let variable = Variable()
    var body: some View {
        //NavigationView {
            NavigationLink{
                UpdateQuanHe()
            } label: {
                if variable.getUserDefaultArrInt1(name: "arrChatLuongQH").isEmpty {
                    VStack{
                        HStack{
                            Text("titleTinhTrangQH")
                                .foregroundColor(Color("xanh"))
                                .font(Font.system(size: 18).bold())
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                        }
                        Spacer()
                            .frame(height: 40)
                        Image(systemName: "plus")
                            .font(.system(size: 25).bold())
                            .padding(10)
                            .foregroundColor(Color.black)
                            .background(Color("xanh"))
                            .clipShape(Circle())
                        Spacer()
                            .frame(height: 40)
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(.horizontal, 20)
                } else {
                    VStack{
                        HStack{
                            Image(systemName: "plus")
                                .font(.system(size: 25).bold())
                                .padding(10)
                                .foregroundColor(Color.black)
                                .background(Color("xanh"))
                                .clipShape(Circle())
                                .opacity(0)
                            Text("titleTinhTrangQH")
                                .foregroundColor(Color("xanh"))
                                .font(Font.system(size: 18).bold())
                               
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                            Image(systemName: "plus")
                                .font(.system(size: 25).bold())
                                .padding(10)
                                .foregroundColor(Color.black)
                                .background(Color("xanh"))
                                .clipShape(Circle())
                        }
                        ZStack {
                            GeometryReader { geo in
                                let absMax = 4.0
                                let maxBarHeightTop: Double = 90
                               
                                VStack (spacing: 0){
                                    HStack(alignment: .bottom, spacing: 8) {
                                        ForEach(0..<7, id: \.self) { i in
                                            
                                            // scale chiều cao theo absMax
                                            let value = data[i]
                                            let barHeight = absMax == 0
                                                ? 0
                                                : (Double(value) / absMax) * maxBarHeightTop
                                            
                                            VStack {
                                                Spacer()
                                                RoundedRectangle(cornerRadius: 40)
                                                    .fill(Color("xanh"))
                                                    .frame(height: barHeight)
                                                    .padding(.horizontal, 7)
                                            }
                                            .frame(maxWidth: .infinity)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: (maxBarHeightTop + 30))
                                    //.background(.blue)
                                    HStack(alignment: .top, spacing: 8) {
                                        ForEach(0..<7, id: \.self) { i in
                                            VStack {
                                                Text(NSLocalizedString(days[i], comment: ""))
                                                .font(.caption.bold())
                                                .foregroundColor(Color.white)
                                            }
                                            .frame(maxWidth: .infinity)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                }
                            }
                            .frame(height: 120)
                            .padding()
                        }
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(.horizontal, 20)
                }
            }.onAppear(){
                //data = variable.getTinhTrang(name: "arrTinhTrangTri")
            }
       // }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
//
    }
}

#Preview {
    HomeChartQH().preferredColorScheme(.dark)
}
