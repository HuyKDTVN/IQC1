//
//  UpdateQuanHe.swift
//  kegel-exercise
//
//  Created by Huy Le on 9/5/26.
//

import SwiftUI
import Combine
import UIKit

struct UpdateQuanHe: View {
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    @State var data: [String] = []
    @State private var hasRedirect = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    //@State private var isPause = false
    @State private var seconds = 0
    @State private var randTitle = 1
    @State private var randDesc = 1
    @State private var randChucMung = 1
    @State private var isRunning = true
    let rung = UINotificationFeedbackGenerator()
    
    let timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
    //@State private var connection: Cancellable?
    
    @State private var showRatingPopup = false
    @State private var rating = 0
    
    var body: some View {
        //NavigationView {
            ZStack{
                VStack{
                    
                    HStack(alignment: .center){
//                        Button {
//                            dismiss()
//                        } label: {
//                            Image(systemName: "chevron.left")
//                                .font(Font.system(size: 18))
//                                .foregroundColor(.white)
//                                .frame(width: 45, height: 45)
//                                //.background(Color.white.opacity(0))
//                                .clipShape(Circle())
//                                .overlay(
//                                    RoundedRectangle(cornerRadius: 30)
//                                        .stroke(Color.white.opacity(0.2), lineWidth: 1)
//                                )
//                        }
                        Spacer()
                        Text(NSLocalizedString("ghinhanthoigianqh", comment: ""))
                            .font(.system(size: 18).bold())
                            .frame(maxWidth: .infinity, alignment: .center)
                            .multilineTextAlignment(.center)
                            .padding(.bottom, 0)
                        Spacer()
//                        Button {
//                            dismiss()
//                        } label: {
//                            Image(systemName: "chevron.left")
//                                .foregroundColor(.black)
//                                .padding(12)
//                                .background(Color.white.opacity(0.2))
//                                .clipShape(Circle())
//                        }.opacity(0)
                        
                    }.padding(.horizontal, 20)
                        .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                    
                    HStack{
                        ZStack{
                            Circle()
                                .fill(Color("xanh"))
                                .frame(width: 40, height: 40)
                                
                            Text("\(Int(seconds/60))")
                                .font(.system(size: 28).bold())
                                .foregroundColor(.black)
                        }
                        VStack{
                            Text(seconds/60 < 21 ? NSLocalizedString("title\(Int(seconds/60))p\(randTitle)", comment: "") : "")
                                .foregroundColor(Color.white)
                                .font(.system(size: 16).bold())
                                .padding(.leading, 5)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.bottom, 1)
                            Text(seconds/60 < 21 ? NSLocalizedString("desc\(Int(seconds/60))p\(randTitle)", comment: "") : "")
                                .foregroundColor(Color.white.opacity(0.7))
                                .font(.system(size: 14).bold())
                                .padding(.leading, 5)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        Spacer()
                        Image("firework\(randChucMung)")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 45, height: 45)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 15)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(.white.opacity(0.15))
                    )
                    .padding(.horizontal, 15)
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                    .opacity((seconds % 60 < 10 && seconds > 10 && seconds/60 < 21) ? 1 : 0)
                    ZStack{
                        Circle()
                            .stroke(!isRunning ? Color("yellow2") : Color("xanh"), lineWidth: 5)
                            .background(!isRunning ? Circle().fill(Color("yellow2").opacity(0.07)) : Circle().fill(Color("xanh").opacity(0.07)))
                            .frame(width: UIScreen.main.bounds.width * 0.7, height: UIScreen.main.bounds.width * 0.7)
                        Text(variable.formatTime(seconds))
                            .font(.system(size: 60))
                            .foregroundColor(.white)
                            .onReceive(timer) { _ in
                                if isRunning {
                                    seconds += 1
                                    if(seconds % 60 == 0 && seconds > 0) {
                                        rung.notificationOccurred(.error)
                                        randTitle = Int.random(in: 1...5)
                                        randDesc = Int.random(in: 1...5)
                                        randChucMung = Int.random(in: 1...8)
                                    }
                                }
                            }
                    }
                    Spacer()
                    HStack{
                        Spacer()
                        Button{
                            //save to DB
                            var arrData = variable.getUserDefaultArrInt1(name: "arrTimeQH")
                            arrData.append(Int(ceil(Double(seconds) / 60)))
                            print("arrData tinh trang tri tai arrTimeQH screen")
                            print(arrData)
                            defaults?.set(arrData, forKey: "arrTimeQH")
                            
                            rung.notificationOccurred(.success)
                            pauseTimer()
                            showRatingPopup = true
                            //hasRedirect = true
                            
                        } label: {
                            Image(systemName: "stop.fill")
                                .font(.system(size: 30))
                                .padding(30)
                                .foregroundColor(.black)
                                .background(.white.opacity(0.3))
                                .clipShape(Circle())
                        }
                        
                        Spacer()
                        Button{
                            rung.notificationOccurred(.success)
                            if(!isRunning) {
                                startTimer()
                            }else{
                                pauseTimer()
                            }
                          
                        } label: {
                            Image(systemName: !isRunning ? "play.fill" : "pause.fill")
                                .font(.system(size: 30))
                                .padding(30)
                                .foregroundColor(.black)
                                .background(!isRunning ? Color("yellow2").opacity(0.6) : .white.opacity(0.3))
                                .clipShape(Circle())
                        }
                        
                        Spacer()
                    }
                    NavigationLink("", isActive: $hasRedirect) {
                        ContentView().navigationBarHidden(true)
                    }
                }.onAppear {
                    UIApplication.shared.isIdleTimerDisabled = true
                }
                .onDisappear {
                    UIApplication.shared.isIdleTimerDisabled = false
                }
                
                // POPUP
                if showRatingPopup {

                    Color.black.opacity(0.4)
                        .ignoresSafeArea()

                    VStack(spacing: 20) {

                        Text("ratingsauQH")
                            .font(.headline)

                        HStack(spacing: 12) {

                            ForEach(1...5, id: \.self) { index in

                                Image(systemName:
                                        index <= rating
                                      ? "star.fill"
                                      : "star"
                                )
                                .font(.system(size: 32))
                                .foregroundColor(.yellow)
                                .onTapGesture {
                                    rating = index
                                }
                            }
                        }

                        HStack(spacing: 16) {

//                            Button("Huỷ") {
//                                showRatingPopup = false
//                            }

                            Button("send") {

                                //print("arrChatLuongQH =", rating)
                                var arrData = variable.getUserDefaultArrInt1(name: "arrChatLuongQH")
                                arrData.append(rating)
                                print("arrData tinh trang tri tai arrChatLuongQH screen")
                                print(arrData)
                                defaults?.set(arrData, forKey: "arrChatLuongQH")
                                
                                showRatingPopup = false
                                
                                hasRedirect = true
                            }
                            .foregroundColor(Color("xanh"))
                            .disabled(rating == 0)
                        }
                    }
                    .padding(24)
                    .background(Color("xam"))
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .padding(40)
                }
            }.animation(.easeInOut, value: showRatingPopup)
                .navigationBarHidden(true)
                .ignoresSafeArea(.container, edges: .top)
                .navigationBarBackButtonHidden(true)
                .navigationViewStyle(StackNavigationViewStyle())
                .transition(.move(edge: .trailing))
//        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
    }
    func startTimer() {
        isRunning = true
    }
    
    func pauseTimer() {
        isRunning = false
        //timer.upstream.connect().cancel()
    }
}

#Preview {
    UpdateQuanHe().preferredColorScheme(.dark)
}
