//
//  UpdateSontieu.swift
//  kegel-exercise
//
//  Created by Huy Le on 8/5/26.
//

import SwiftUI

struct UpdateSontieu: View {
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    @State var data: [String] = []
    @State private var hasRedirect = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //NavigationView {
            VStack{
                HStack(alignment: .center){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("titleTinhTrangSonTieu", comment: ""))
                        .font(.system(size: 20).bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }.padding(.horizontal, 20)
                    .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                Spacer()
                //ScrollView{
                    VStack(spacing: 0) {
                        ForEach(0...4, id: \.self) { index in
                            Button{
                                var arrData = variable.getUserDefaultArrInt1(name: "arrTinhTrangSonTieu")
                                arrData.append(index)
                                print("arrData tinh trang tri tai arrTinhTrangSonTieu screen")
                                print(arrData)
                                defaults?.set(arrData, forKey: "arrTinhTrangSonTieu")
                                hasRedirect = true
                            } label: {
                                HStack{
                                    Circle()
                                        .stroke(.black, lineWidth: 2)
                                        .frame(width: 15, height: 15)
                                    Text(NSLocalizedString("\(variable.arrTinhTrangTitle[index])", comment: ""))
                                        .padding(.leading, 10)
                                        .font(.system(size: 18).bold())
                                        .foregroundColor(.black)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    Spacer()
                                }
                                .padding(.horizontal, 20)
                                .padding(.vertical, 24)
                                .background(variable.arrTinhTrangColor[index])
                                .cornerRadius(9999)
                                .padding(.bottom, 15)
                            }
                        }
                    }
                    .padding()
                //}
                Spacer()
                NavigationLink("", isActive: $hasRedirect) {
                    ContentView().navigationBarHidden(true)
                }
            }.navigationBarHidden(true)
                .ignoresSafeArea(.container, edges: .top)
                .navigationBarBackButtonHidden(true)
                .navigationViewStyle(StackNavigationViewStyle())
                .transition(.move(edge: .trailing))
//        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
    }
}

#Preview {
    UpdateSontieu().preferredColorScheme(.dark)
}
