//
//  HomeThanhTichTuanNay.swift
//  kegel-exercise
//
//  Created by Huy Le on 19/5/26.
//

import SwiftUI

struct HomeThanhTichTuanNay: View {
    var variable:Variable = Variable()
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    let data: [Double] = Variable().getDataThanhTichTuanNay() // [4, 50, 0, 0, 0, 0, 0]
    let days = ["t2", "t3", "t4", "t5", "t6", "t7", "cn"]
    var body: some View {
        VStack{
            HStack{
                Text("thanhtichtuannay")
                    .foregroundColor(Color("tim 1"))
                    .font(Font.system(size: 18).bold())
                    .frame(maxWidth: .infinity, alignment: .center)
            }
            ZStack {
                GeometryReader { geo in
                    let absMax = Double(data.max()!) > 4 ? Double(data.max()!) : 4
                    let maxBarHeightTop: Double = 90
                    VStack (spacing: 0){
                        HStack(alignment: .bottom, spacing: 4) {
                            ForEach(0..<7, id: \.self) { i in
                                // scale chiều cao theo absMax
                                let value = data[i]
                                let barHeight = absMax == 0 ? 0 : (Double((value)) / absMax) * maxBarHeightTop
                                VStack {
                                    Spacer()
                                    Text(value > 0 ? String(format: "%.1f", value) : "")
                                    .font(.caption.bold())
                                    .foregroundColor(Color("tim 1"))
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(Color("tim 1"))
                                        .frame(height: barHeight)
                                        .padding(.horizontal, 7)
                                }
                                .frame(maxWidth: .infinity)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        //.frame(height: maxBarHeightTop + 30)
                        .padding(.bottom, 5)
                        //.background(.blue)
                        .frame(height: 130)
                        HStack(alignment: .top, spacing: 8) {
                            ForEach(0..<7, id: \.self) { i in
                                VStack {
                                    Text(NSLocalizedString(days[i], comment: ""))
                                    .font(.caption.bold())
                                    .foregroundColor(Color.white)
                                }
                                .frame(maxWidth: .infinity)
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .frame(height: 110)
                .padding(.top, 0)
                .padding(.bottom, 40)
                //.background(.green)
            }
        }
        .padding(.vertical, 15)
        .padding(.horizontal, 15)
        .background(
            RoundedRectangle(cornerRadius: 50)
                .fill(Color.white.opacity(0.07))
        )
        .padding(.horizontal, 20)
    }
}

#Preview {
    HomeThanhTichTuanNay().preferredColorScheme(.dark)
}
