//
//  HomeChartTri.swift
//  kegel-exercise
//
//  Created by Huy Le on 4/5/26.
//

import SwiftUI

struct HomeChartTri: View {
    @State private var data: [Double] = Variable().getTinhTrang(name: "arrTinhTrangTri")
    let days = ["1", "2", "3", "4", "5", "6", "7"]
    let variable = Variable()
    var body: some View {
        //NavigationView {
            NavigationLink{
                UpdateTri()
            } label: {
                if variable.getUserDefaultArrInt1(name: "arrTinhTrangTri").isEmpty {
                    VStack{
                        HStack{
                            Text("tinhtrangtri")
                                .foregroundColor(Color("xanhduong"))
                                .font(Font.system(size: 18).bold())
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                            
                        }
                        Spacer()
                            .frame(height: 40)
                        Image(systemName: "plus")
                            .font(.system(size: 25).bold())
                            .padding(10)
                            .foregroundColor(Color.black)
                            .background(Color("xanhduong"))
                            .clipShape(Circle())
                        Text("titleTinhTrangTri")
                            .foregroundColor(Color.white)
                            .font(Font.system(size: 14).bold())
                            .padding(.top, 5)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                            .frame(height: 40)
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(.horizontal, 20)
                    .padding(.vertical, 0)
                } else {
                    VStack{
                        HStack{
                            Image(systemName: "plus")
                                .font(.system(size: 25).bold())
                                .padding(10)
                                .foregroundColor(Color.black)
                                .background(Color("xanhduong"))
                                .clipShape(Circle())
                                .opacity(0)
                            Text("tinhtrangtri")
                                .foregroundColor(Color("xanhduong"))
                                .font(Font.system(size: 18).bold())
                                .frame(maxWidth: .infinity, alignment: .center)
                            Spacer()
                            Image(systemName: "plus")
                                .font(.system(size: 25).bold())
                                .padding(10)
                                .foregroundColor(Color.black)
                                .background(Color("xanhduong"))
                                .clipShape(Circle())
                        }
                        ZStack {
                            GeometryReader { geo in
                                let absMax = 4.0
                                let maxBarHeightTop: Double = 90
                                let maxBarHeightBot: Double = 30
                                
                                VStack (spacing: 0){
                                    HStack(alignment: .bottom, spacing: 8) {
                                        ForEach(0..<7, id: \.self) { i in
                                            
                                            // scale chiều cao theo absMax
                                            let value = data[i]
                                            let barHeight = absMax == 0
                                                ? 0
                                                : (abs(value) / absMax) * maxBarHeightTop
                                            
                                            VStack {
                                                if value >= 0 {
                                                    Spacer()
                                                    RoundedRectangle(cornerRadius: 40)
                                                        .fill(Color("xanhduong"))
                                                        .frame(height: barHeight)
                                                        .padding(.horizontal, 7)
                                                }
                                            }
                                            .frame(maxWidth: .infinity)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: maxBarHeightTop)
                                    //.background(.blue)
                                    HStack{
                                        
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 1)
                                    .background(Color.gray.opacity(0.5))
                                    .padding(.vertical, 3)
                                    HStack(alignment: .top, spacing: 8) {
                                        ForEach(0..<7, id: \.self) { i in
                                            let value = data[i]
                                            VStack {
                                                if value < 0 {
                                                    
                                                    RoundedRectangle(cornerRadius: 40)
                                                        .fill(Color("xanhduong"))
                                                        .frame(height: maxBarHeightBot)
                                                        .padding(.horizontal, 7)
                                                    Spacer()
                                                }
                                            }
                                            .frame(maxWidth: .infinity)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: maxBarHeightBot)
                                    //.background(.red)
                                    
                                    HStack(alignment: .top, spacing: 8) {
                                        ForEach(0..<7, id: \.self) { i in
                                            VStack {
                                                
                                                Text(NSLocalizedString(days[i], comment: ""))
                                                .font(.caption.bold())
                                                .foregroundColor(Color("xanhduong"))
                                            }
                                            .frame(maxWidth: .infinity)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                }
                            }
                            .frame(height: 120)
                            .padding()
                        }
                    }
                    .padding(.vertical, 15)
                    .padding(.horizontal, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.white.opacity(0.07))
                    )
                    .padding(.horizontal, 20)
                    .padding(.vertical, 0)
                }
            }.onAppear(){
                //data = variable.getTinhTrang(name: "arrTinhTrangTri")
            }
       // }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
//        
        
    }
}

#Preview {
    HomeChartTri().preferredColorScheme(.dark)
}
