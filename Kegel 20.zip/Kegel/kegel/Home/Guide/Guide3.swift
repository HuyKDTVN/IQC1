//
//  Onboarding2.swift
//  kegel-exercise
//
//  Created by Huy Le on 27/4/26.
//

import SwiftUI

struct Guide3: View {
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    @State private var hasRedirect = false
    //let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //NavigationView {
            VStack{
                HStack(alignment: .center){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("kegelloiich", comment: ""))
                        .font(.system(size: 20).bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }
                .padding(.horizontal, 20)
                .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                
                ScrollView(showsIndicators: false){
                    VStack(spacing: 0) {
                        Text(NSLocalizedString("voinu", comment: ""))
                            //.underline()
                            .padding(.horizontal, 10)
                            .lineSpacing(10)
                            .font(.system(size: 22).bold())
                            .foregroundColor(Color("tim"))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.bottom, 15)
                        Text(NSLocalizedString("guidedetail21", comment: ""))
                            .padding(.horizontal, 10)
                            .lineSpacing(10)
                            .font(.system(size: 16))
                            .foregroundColor(.white.opacity(0.9))
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text(NSLocalizedString("voinam", comment: ""))
                            //.underline()
                            .padding(.horizontal, 10)
                            .lineSpacing(10)
                            .font(.system(size: 22).bold())
                            .foregroundColor(Color("xanhnon"))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.top, 50)
                            .padding(.bottom, 15)
                        Text(NSLocalizedString("guidedetail21", comment: ""))
                            .padding(.horizontal, 10)
                            .lineSpacing(10)
                            .font(.system(size: 16))
                            .foregroundColor(.white.opacity(0.9))
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Spacer()
                            .frame(height: 100)
                        NavigationLink{
                            Guide2().navigationBarHidden(true)
                        } label: {
                            HStack{
                                
                                Text(NSLocalizedString("guidecorrect", comment: ""))
                                    .font(.system(size: 17).bold())
                                    .foregroundColor(myColor)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 24)
                            .background(myBgColor)
                            .cornerRadius(9999)
                            .padding(.horizontal, 30)
                            
                        }
                        
                        NavigationLink{
                            Guide1().navigationBarHidden(true)
                        } label: {
                            HStack{
                                
                                Text(NSLocalizedString("kegellagi", comment: ""))
                                    .font(.system(size: 17).bold())
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 24)
                            .background(.white.opacity(0.15))
                            .cornerRadius(9999)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 24)
                        }
                    }
                    .padding()
                }
                Spacer()
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
//        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
    }
}

#Preview {
    Guide3().preferredColorScheme(.dark)
}
