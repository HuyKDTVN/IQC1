//
//  Onboarding2.swift
//  kegel-exercise
//
//  Created by Huy Le on 27/4/26.
//

import SwiftUI

struct Guide1: View {
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    @State private var hasRedirect = false
    //let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //NavigationView {
            VStack{
                HStack(alignment: .center){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("kegellagi", comment: ""))
                        .font(.system(size: 20).bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }
                .padding(.horizontal, 20)
                .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                
                //ScrollView{
                    VStack(spacing: 0) {
                        Text(NSLocalizedString("guidedetail1", comment: ""))
                            .padding(.horizontal, 20)
                            .lineSpacing(10)
                            .font(.system(size: 16))
                            .foregroundColor(.white.opacity(0.9))
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Spacer()
                        NavigationLink{
                            Guide3().navigationBarHidden(true)
                        } label: {
                            HStack{
                                
                                Text(NSLocalizedString("kegelloiich", comment: ""))
                                    .font(.system(size: 17).bold())
                                    .foregroundColor(myColor)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 24)
                            .background(myBgColor)
                            .cornerRadius(9999)
                            .padding(.horizontal, 30)
                            
                        }
                        
                        NavigationLink{
                            Guide2().navigationBarHidden(true)
                        } label: {
                            HStack{
                                
                                Text(NSLocalizedString("guidecorrect", comment: ""))
                                    .font(.system(size: 17).bold())
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 24)
                            .background(.white.opacity(0.15))
                            .cornerRadius(9999)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 24)
                        }
                    }
                    .padding()
                //}
                Spacer()
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
//        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
    }
}

#Preview {
    Guide1().preferredColorScheme(.dark)
}
