//
//  HomeThoiGianDaTap.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct HomeThoiGianDaTap: View {
    let variable = Variable()
    var body: some View {
        HStack{
            VStack{
                Text("phuttap")
                    .foregroundColor(Color("do"))
                    .font(.system(size: 20).bold())
                    .padding(.bottom, 10)
                Text(variable.getSoPhutTap() > 0 ? String(format: "%.1f", variable.getSoPhutTap()) : "0")
                    .foregroundColor(Color.white)
                    .font(.system(size: 40).bold())
                    .padding(.bottom, 30)
                    .onAppear(){
                        
                    }
            }
            .padding(.vertical, 20)
            .padding(.horizontal, 20)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 40)
                    .fill(Color.white.opacity(0.1))
            )
            .padding(.trailing, 10)
            
            VStack{
                Text("songaytap")
                    .foregroundColor(Color("do"))
                    .font(.system(size: 20).bold())
                    .padding(.bottom, 10)
                Text("\(variable.getNgayTap())")
                    .foregroundColor(Color.white)
                    .font(.system(size: 40).bold())
                    .padding(.bottom, 30)
            }
            .padding(.vertical, 20)
            .padding(.horizontal, 20)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 40)
                    .fill(Color.white.opacity(0.1))
            )
            .padding(.leading, 10)
        }
        .padding()
    }
}

#Preview {
    HomeThoiGianDaTap()
        .preferredColorScheme(.dark)
}
