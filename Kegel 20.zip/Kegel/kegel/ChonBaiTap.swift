//
//  ChonBaiTap.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct ChonBaiTap: View {
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    let dataWorkout = Variable().getArrWorkoutToday()
    
    @State private var hasRedirect = false
    var body: some View {
        //NavigationView{
            VStack{
                HStack{
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 23))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    Text(NSLocalizedString("day", comment: "") + " \(variable.getNgayTap())")
                        .font(.system(size: 20).bold())
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                }.padding(.horizontal, 20)
                    .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                Spacer()
                ScrollView{
                    ForEach(dataWorkout, id: \.self) { item in
                        HStack{
                            Circle()
                                .stroke(myBgColor, lineWidth: 2)
                                .frame(width: 10, height: 10, alignment: .trailing)
                                .padding(.trailing, 0)
                            VStack (alignment: .leading) {
                                Text("\(item[0]) " + NSLocalizedString("tap", comment: "") + ", " + "\(item[0]) " + NSLocalizedString("rest", comment: ""))
                                    .padding(.bottom, 2)
                                    .font(Font.system(size: 16.0, weight: .bold))
                                    .foregroundColor(.white)
                                Text("x\(item[1])")
                                    .padding(.bottom, 2)
                                    .font(Font.system(size: 14.0))
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, 20)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding(.horizontal, 30)
                        .padding(.vertical, 30)
                        .background(
                            RoundedRectangle(cornerRadius: 50)
                                .fill(Color.white.opacity(0.07))
                        )
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                    }
                }
                Spacer()
                Button{
                   
                    hasRedirect = true
                }label: {
                    HStack {
                        Text("batdautap")
                            .font(.system(size: 18).bold())
                            .foregroundColor(myColor)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                        Image(systemName: "arrow.forward")
                            .font(.system(size: 25).bold())
                            .padding(13)
                            .foregroundColor(myColor)
                            .background(Color.black.opacity(0.25))
                            .clipShape(Circle())
                    }
                    .frame(width: 200)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(myBgColor)
    //                            .overlay(
    //                                RoundedRectangle(cornerRadius: 50)
    //                                    .stroke(Color("xanhnon").opacity(0.1), lineWidth: 1)
    //                            )
                    )
                }
                
                NavigationLink("", isActive: $hasRedirect) {
                    StartWorkout(doDaiBaiTap2: 0, loaiBaiTap2: 0, tapNhieuBai: true, arrTapTheoMucTieu: dataWorkout)
                }
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
//        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
    }
}
#Preview {
    ChonBaiTap().preferredColorScheme(.dark)
}
