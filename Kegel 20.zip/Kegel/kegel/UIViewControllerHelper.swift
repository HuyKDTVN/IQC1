import UIKit
import SwiftUI

struct ViewControllerHelper: UIViewControllerRepresentable {
    class Coordinator {
        var parent: ViewControllerHelper
        init(parent: ViewControllerHelper) { self.parent = parent }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIViewController {
        let viewController = UIViewController()
        
        return viewController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
}
