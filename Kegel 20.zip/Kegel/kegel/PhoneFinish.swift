//
//  PhoneFinish.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI

struct PhoneFinish: View {
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    var variable:Variable = Variable()
    @Environment(\.dismiss) var dismiss
    @State private var shake = false
    var body: some View {
        //NavigationView{
            ScrollView(showsIndicators: false){
                VStack{
                    Text("chucmung")
                        .font(.system(size: 25).bold())
                        .padding(.bottom, 20)
                    Image("cup")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .padding(.bottom, -30)
                    HomeThanhTichHomNay()
                    HomeThoiGianDaTap()
                    HomeThanhTichTuanNay()
                }
                .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                HStack {
                    NavigationLink(destination: ContentView().navigationBarHidden(true)) {
                        Image(systemName: "house")
                            .font(.system(size: 30))
                            .padding(18)
                            .foregroundColor(Color.white)
                            .background(Circle().foregroundColor(Color.white.opacity(0.2)))
                            //.frame(width: 50, height: 50)
                        
                    }
                    .buttonStyle(PlainButtonStyle())
                    
                    // Tuỳ chọn 2 → Màn hình C
                    
                    NavigationLink(destination: ContentView().navigationBarHidden(true)) {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 42).bold())
                            .padding(25)
                            .foregroundColor(myColor)
                            .background(Circle().foregroundColor(myBgColor))
                            
                            //.frame(width: 50, height: 50)
                        .padding()
                    }
                    .buttonStyle(PlainButtonStyle()) 
                }
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
//        }
//        .navigationBarHidden(true)
//        .ignoresSafeArea(.container, edges: .top)
//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .transition(.move(edge: .trailing))
    }
}

#Preview {
    PhoneFinish().preferredColorScheme(.dark)
}
