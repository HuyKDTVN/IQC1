//
//  StartWorkout.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/5/26.
//

import SwiftUI
//import HealthKit
import Combine
import AVFoundation
import MediaPlayer
import UIKit

struct StartWorkout: View {
    @State var doDaiBaiTap2: Int // default = 5
    @State var loaiBaiTap2: Int
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    @State var doDaiBaiTapTiepTheo: Int = 0
    @State var loaiBaiTapTiepTheo: Int = 0
    var tapNhieuBai: Bool
    var arrTapTheoMucTieu: [[Int]] = [[]]
    
    @State private var isAnimating = true
    @State private var isPrepare: Bool = true
    @State private var prepareSecond: Int = 3
    @State public var kegelSecond: Int = 5
    @State private var isPlay: Bool = true
    @State private var isRest: Bool = false
    @State private var closed: Bool = false
    @State private var finished: Bool = false
    @State private var timeRemainingPrepare: Double = 3
    @State private var timeRemainingMax: Double = 5
    @State private var timeRemaining: Double = 5
    @State private var timeRest = 5
    @State private var timer: Timer?
    @State private var type: Int = 0
    @State private var rep: Int = 2
    @State private var step: Int = 0
    @State private var baiTapThu: Int = 0
    
    // Đổi sang kiểu Double để đếm lùi mịn theo Timer (0.03s), không bị nhảy số
    @State private var restMax: Double = Double(Variable().getUserDefaultInt(name: "ThoiGianNghiaGiuaHiep"))
    @State private var restMaxOrigin: Double = Double(Variable().getUserDefaultInt(name: "ThoiGianNghiaGiuaHiep"))
    
    @State private var nghiGiuaHiep: Bool = false
    @State private var rotate = false
    
    @State var widthCircle: CGFloat = UIScreen.main.bounds.width * 0.65
    var widthCircleMax: CGFloat = UIScreen.main.bounds.width * 0.65
    
    @State var widthSmallCircle: Int = 10
    var widthSmallCircleMin: Int = 7
    var variable = Variable()
    @State var player: AVAudioPlayer = AVAudioPlayer()
    let rung = UINotificationFeedbackGenerator()
    @State private var redirect: Bool = false
    @State private var showAlert = false
    let allowRung = Variable().getUserDefaultBool(name: "rung")
    
    func finish() {
        stopTimer()
        var soGiayTap = loaiBaiTap2 * doDaiBaiTap2 * 2
        if tapNhieuBai {
            soGiayTap = 0
            for item in arrTapTheoMucTieu {
                soGiayTap = soGiayTap + item[0] * item[1] * 2
            }
        }
       
        variable.updateThanhTich(soGiayTap: soGiayTap)
        variable.savePhutTap(soGiayTap: soGiayTap)
        variable.saveThanhTichTuanNay(soGiayTap: soGiayTap)
        Huy_functions().setNotiDaTap()
        closed = true
        finished = true
    }
    
    func update() {}
    
    func startTimer() {
        isRest = false
        guard timer == nil else { return }
        isPlay = true
        timer = Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true) { t in
            
            // 1. TRẠNG THÁI CHUẨN BỊ (PREPARE)
            if isPrepare {
                timeRemainingPrepare -= 0.03
                if timeRemainingPrepare >= 0 {
                    if abs(timeRemainingPrepare - Double(Int(timeRemainingPrepare))) <= 0.03 {
                        prepareSecond = prepareSecond - 1
                        if prepareSecond == 0 {
                            isPrepare = false
                        }
                    }
                }
                return
            }
            
            // 2. TRẠNG THÁI NGHỈ GIỮA HIỆP (Xử lý độc lập bằng Double đếm mịn)
            if nghiGiuaHiep {
                isRest = true
                restMax -= 0.03
                
                if restMax <= 0 {
                    // Kết thúc nghỉ: Reset trạng thái và chuyển sang bài tập tiếp theo
                    nghiGiuaHiep = false
                    isRest = false
                    restMax = restMaxOrigin
                    
                    baiTapThu = baiTapThu - 1
                    
                    loaiBaiTap2 = arrTapTheoMucTieu[3 - baiTapThu][0]
                    doDaiBaiTap2 = arrTapTheoMucTieu[3 - baiTapThu][1]
                    
                    let ptTiepTheo: Int = 3 - baiTapThu + 1
                    if(arrTapTheoMucTieu.count > ptTiepTheo) {
                        loaiBaiTapTiepTheo = arrTapTheoMucTieu[ptTiepTheo][0]
                        doDaiBaiTapTiepTheo = arrTapTheoMucTieu[ptTiepTheo][1]
                    }
                    
                    kegelSecond = loaiBaiTap2
                    timeRemainingMax = Double(loaiBaiTap2)
                    timeRemaining = Double(loaiBaiTap2)
                    timeRest = loaiBaiTap2
                    rep = doDaiBaiTap2
                }
                return
            }
            
            // 3. TRẠNG THÁI TẬP CHÍNH
            timeRemaining -= 0.03
            if rep > 0 {
                if timeRemaining >= 0 {
                    let myT: Double = (timeRemainingMax)
                    let vanToc: Double = (widthCircleMax - 45.0)  / myT
                    let quangDuongNho: Double = vanToc * 0.03
                    let delta: Double = Double(step) * quangDuongNho
                    
                    if nghiGiuaHiep == false {
                        if isPlay {
                            withAnimation(.linear(duration: 0.03)) {
                                widthCircle = widthCircleMax - delta
                            }
                            if allowRung {
                                rung.notificationOccurred(.success)
                            }
                        } else {
                            withAnimation(.linear(duration: 0.03)) {
                                widthCircle = 45 + delta
                            }
                        }
                    } else {
                        withAnimation(.linear(duration: 0.7)) {
                            widthCircle = widthCircleMax
                        }
                    }

                    step = step + 1
                    
                    if abs(timeRemaining - Double(Int(timeRemaining))) <= 0.03 {
                        kegelSecond = kegelSecond - 1
                        if kegelSecond == timeRest - 1 && !isRest {
                            if isPlay {
                                widthSmallCircle = widthSmallCircleMin
                            } else {
                                widthSmallCircle = 10
                            }
                        }
                        if kegelSecond == 0 {
                            isPlay.toggle()
                            step = 0
                            if isPlay {
                                rep = rep - 1
                                if rep == 0 {
                                    if baiTapThu == 0 {
                                        finish()
                                    } else {
                                        if restMaxOrigin > 0 {
                                            nghiGiuaHiep = true
                                            restMax = restMaxOrigin
                                        } else {
                                            baiTapThu = baiTapThu - 1
                                            loaiBaiTap2 = arrTapTheoMucTieu[3 - baiTapThu][0]
                                            doDaiBaiTap2 = arrTapTheoMucTieu[3 - baiTapThu][1]
                                            rep = doDaiBaiTap2
                                        }
                                    }
                                }
                            }
                            timeRemaining = timeRemainingMax
                            kegelSecond = Int(timeRemainingMax)
                        }
                    }
                }
            } else {
                if baiTapThu == 0 {
                    finish()
                }
            }
        }
    }
    
    func pauseButton() {
        if isRest {
            if isPlay {
                pauseTimer()
            } else {
                startTimer()
            }
        } else {
            pauseTimer()
        }
    }
    
    func pauseTimer() {
        isRest = true
        timer?.invalidate()
        timer = nil
        isPlay = false
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil
        isPlay = false
    }
    
    var body: some View {
        VStack {
            HStack {
                Button {
                    pauseTimer()
                    showAlert = true
                } label: {
                    Image(systemName: "xmark")
                        .font(Font.system(size: 23))
                        .foregroundColor(myBgColor)
                        .frame(width: 45, height: 45)
                        .clipShape(Circle())
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.white.opacity(0.2), lineWidth: 1)
                        )
                }.alert(NSLocalizedString("exit", comment: ""), isPresented: $showAlert) {
                    Button(NSLocalizedString("cancel", comment: ""), role: .cancel) {
                        startTimer()
                    }
                    Button(NSLocalizedString("agree", comment: ""), role: .destructive) {
                        redirect = true
                    }
                } message: {
                    Text(NSLocalizedString("doyouwantexit", comment: ""))
                }
                
                Spacer()
                
                Text(nghiGiuaHiep ? "Next: \(loaiBaiTapTiepTheo) " + NSLocalizedString("tap", comment: "") + ", " + "\(loaiBaiTapTiepTheo) " + NSLocalizedString("rest", comment: "") : "\(loaiBaiTap2) " + NSLocalizedString("tap", comment: "") + ", " + "\(loaiBaiTap2) " + NSLocalizedString("rest", comment: ""))
                    .font(.system(size: 22).bold())
                    .padding(.bottom, 0)
                
                Spacer()
                
                Button {
                    pauseButton()
                } label: {
                    Image(systemName: isRest || nghiGiuaHiep ? "play" : "pause")
                        .font(Font.system(size: 25))
                        .foregroundColor(myBgColor)
                        .frame(width: 45, height: 45)
                        .clipShape(Circle())
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.white.opacity(0.2), lineWidth: 1)
                        )
                }
                
            }.padding(.horizontal, 20)
                .padding(.top, 60)
            
            Text(nghiGiuaHiep ? "0/\(doDaiBaiTapTiepTheo)" : doDaiBaiTap2 - rep + 1 > doDaiBaiTap2 ? "\(doDaiBaiTap2)/\(doDaiBaiTap2)" : "\(doDaiBaiTap2 - rep + 1)/\(doDaiBaiTap2)")
                .font(.system(size: 22).bold())
                .padding(.horizontal, 15)
                .padding(.vertical, 6)
                .background(
                    RoundedRectangle(cornerRadius: 50)
                        .fill(Color.white.opacity(0.1))
                )
                
            NavigationView {
                VStack(spacing: 20) {
                    Button(action: {
                        pauseButton()
                    }) {
                        VStack {
                            ZStack {
                                ZStack {
                                    ForEach((0...15), id: \.self) {
                                        Circle()
                                            .strokeBorder(myBgColor, lineWidth: 0)
                                            .background(
                                                Circle()
                                                    .foregroundColor(isRest || nghiGiuaHiep ? Color("yellow2") : myBgColor)
                                                    .frame(width: (widthCircle / 40 + 6), height: (widthCircle / 40 + 6))
                                            )
                                            .offset(
                                                x: CGFloat(widthCircle / 2) * sin(CGFloat(Int($0)) * .pi/(CGFloat(16) / 2)),
                                                y: (-CGFloat(widthCircle / 2)) * cos(CGFloat(Int($0)) * .pi/(CGFloat(16) / 2))
                                            )
                                    }
                                }
                                
                                if isPrepare {
                                    Text("\(prepareSecond)")
                                        .foregroundColor(Color.white)
                                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                                        .font(Font.system(size: 100.0, weight: .medium))
                                }
                                
                                // Đã sửa: Ép kiểu làm tròn lên (ceil) để hiển thị mượt mà đầy đủ 5, 4, 3, 2, 1
                                if nghiGiuaHiep {
                                    Text("\(Int(ceil(restMax)))")
                                        .foregroundColor(Color.white)
                                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                                        .font(Font.system(size: 100.0, weight: .medium))
                                }
                            }
                            .frame(width: widthCircleMax, height: widthCircleMax)
                            
                            HStack {
                                Spacer()
                                Image(systemName: "mug.fill")
                                    .font(.system(size: 23))
                                    .foregroundColor(Color.orange)
                                    .opacity(isRest || nghiGiuaHiep ? 1 : 0)
                            }
                            .padding(.top, 0)
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding()
                .padding(.bottom, 50)
                Spacer()
            }
            .onAppear() {
                if tapNhieuBai,
                   arrTapTheoMucTieu.count > 0,
                   arrTapTheoMucTieu[0].count > 1 {
                    loaiBaiTap2 = arrTapTheoMucTieu[0][0]
                    doDaiBaiTap2 = arrTapTheoMucTieu[0][1]
                    
                    loaiBaiTapTiepTheo = arrTapTheoMucTieu[1][0]
                    doDaiBaiTapTiepTheo = arrTapTheoMucTieu[1][1]
                    
                    baiTapThu = 3
                }
                kegelSecond = loaiBaiTap2
                timeRemainingMax = Double(loaiBaiTap2)
                timeRemaining = Double(loaiBaiTap2)
                timeRest = loaiBaiTap2
                
                rep = doDaiBaiTap2
                startTimer()
            }
          
            Spacer()
            
            if(tapNhieuBai) {
                HStack(alignment: .center, spacing: 8) {
                    ForEach(0..<4) { i in
                        Circle()
                            .fill(i == (3 - baiTapThu) ? myBgColor : Color.white.opacity(0.2))
                            .frame(width: i == 2 ? 15 : 10, height: i == (3 - baiTapThu) ? 15 : 10)
                    }
                }
            }
            
            NavigationLink("", isActive: $finished) {
                PhoneFinish().navigationBarHidden(true)
            }
            NavigationLink("", isActive: $redirect) {
                ContentView().navigationBarHidden(true)
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
}

#Preview {
    StartWorkout(doDaiBaiTap2: 5, loaiBaiTap2: 3, tapNhieuBai: false).preferredColorScheme(.dark)
}
