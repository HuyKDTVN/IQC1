//
//  LockScreen.swift
//  kegel-exercise
//
//  Created by Huy Le on 12/6/26.
//

import SwiftUI

struct LockScreen: View {
    @Environment(\.scenePhase) private var scenePhase
    @Binding var isUnlocked: Bool
    @State private var myBgColor: Color = Variable().getColorByGender()
    var body: some View {
        VStack(spacing: 20) {

            Image(systemName: "lock.fill")
                .font(.system(size: 80))
                //.foregroundColor(Color("tim"))

            Text(NSLocalizedString("ungdungdangkhoa", comment: ""))

            Button(NSLocalizedString("unlook", comment: "")) {
                unlock()
            }
            .foregroundColor(myBgColor)
        }
        .onAppear {
            unlock()
        }
        .onChange(of: scenePhase) { phase in
            switch phase {
            case .active:
                if !isUnlocked {
                    unlock()
                }

            default:
                break
            }
        }
    }

    private func unlock() {
        BiometricAuth.authenticate { success in
            isUnlocked = success
        }
    }
}
