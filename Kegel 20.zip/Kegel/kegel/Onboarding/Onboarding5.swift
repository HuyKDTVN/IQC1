//
//  Onboarding5.swift
//  kegel-exercise
//
//  Created by Huy Le on 1/6/26.
//
import SwiftUI

struct Onboarding5: View {
   
    @State private var show = false
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    @Environment(\.dismiss) var dismiss
    let variable = Variable()
    @State private var hasRedirect = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //NavigationView {
            VStack{
//                HStack(alignment: .top){
//                    Button {
//                        dismiss()
//                    } label: {
//                        Image(systemName: "chevron.left")
//                            .font(Font.system(size: 23))
//                            .foregroundColor(.white)
//                            .frame(width: 45, height: 45)
//                            //.background(Color.white.opacity(0))
//                            .clipShape(Circle())
//                            .overlay(
//                                RoundedRectangle(cornerRadius: 30)
//                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
//                            )
//                    }
//                    Spacer()
//                   
//                    
//                }.padding(.horizontal, 20)
//                    .padding(.top, 10)
//                Spacer()
                ZStack{
                    Image("iphonex")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        //.frame(width: .infinity)
                        
                    VStack{
                        if show {
                            VStack (alignment: .leading){
                                HStack{
                                    Image("logo")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 40)
                                        .padding(.leading, 10)
                                        .padding(.trailing, 7)
                                    Spacer()
                                        .frame(width: 3)
                                    VStack (alignment: .leading){
                                        Text(NSLocalizedString("tilteDaTap1Ngay3", comment: ""))
                                            .foregroundColor(.white)
                                            .font(.system(size: 14).bold())
                                            .padding(.bottom, 2)
                                        Text(NSLocalizedString("descDaTap1Ngay3", comment: ""))
                                            .foregroundColor(.white)
                                            .font(.system(size: 14))
                                        
                                    }
                                    Spacer()
                                }
                            }
                            
                            .padding(10)
                            .background(
                                RoundedRectangle(cornerRadius: 30)
                                    .fill(Color(.white).opacity(0.1))
                            )
                            .padding(.horizontal, Huy_functions().getRatioScreen() > 1.8 ? 20 : 30)
                            .padding(.top, 120)
                            .transition(.opacity)
                            
                            
                        }
                        
                        Spacer()
                    }.onAppear {
                        //withAnimation(.easeInOut(duration: 0.5).delay(1)) {
                            show = true
                       // }
                    }
                }
                .padding(.top, Huy_functions().getRatioScreen() < 1.8 ? -60 : 40)
                .padding(.horizontal, 50)
                .padding(.bottom, 15)
                //.padding(.horizontal, 20)
                    .frame(maxWidth: Huy_functions().getRatioScreen() < 1.53 ? CGFloat(Huy_functions().getWidthScreen()) * 0.65 : .infinity)
                Text(NSLocalizedString("titleAllowNoti", comment: ""))
                    .font(.system(size: 20).bold())
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 7)
                    .padding(.bottom, 7)
                Text(NSLocalizedString("descAllowNoti", comment: ""))
                    .font(.system(size: 14))
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 12)
                
                
                Button{
                    //defaults?.set(dataSelect, forKey: "arrcaithien")
                    Task {
                        let granted = await variable.requestNotificationPermission()
                        
                        print(granted)
                        hasRedirect = true
                    }
                    
                }label: {
                    HStack {
                        Text("allow")
                            .font(.system(size: 18).bold())
                            .foregroundColor(myColor)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                        Image(systemName: "arrow.forward")
                            .font(.system(size: 25).bold())
                            .padding(13)
                            .foregroundColor(myColor)
                            .background(Color.black.opacity(0.25))
                            .clipShape(Circle())
                    }
                    .frame(width: 200)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(myBgColor)
    //                            .overlay(
    //                                RoundedRectangle(cornerRadius: 50)
    //                                    .stroke(Color("xanh").opacity(0.1), lineWidth: 1)
    //                            )
                    )
                }.padding(.bottom, 0)
                
                NavigationLink("", isActive: $hasRedirect) {
                    ContentView().navigationBarHidden(true)
                }
                
            }.onAppear(){
                
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
        //}
        
    }
}


#Preview {
    Onboarding5().preferredColorScheme(.dark)
}
