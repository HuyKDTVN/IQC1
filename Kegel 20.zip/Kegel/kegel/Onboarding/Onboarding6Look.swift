//
//  Onboarding6-look.swift
//  kegel-exercise
//
//  Created by Huy Le on 13/6/26.
//

import SwiftUI

struct Onboarding6Lock: View {
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    let variable = Variable()
    @State private var hasRedirect = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //NavigationView {
            VStack{
                Image("privacy")
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(Color.black)
                    .frame(width: 200)
                    .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
                Text(NSLocalizedString("lookTitle", comment: ""))
                    .font(.system(size: 20).bold())
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
                    .padding(.top, 30)
                    .padding(.bottom, 7)
                Text(NSLocalizedString("lookDesc", comment: ""))
                    .font(.system(size: 14))
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 12)
                
                Spacer()
                
                Button{
                    defaults?.set(true, forKey: "look")
                    hasRedirect = true
                }label: {
                    HStack {
                        Text(NSLocalizedString("turnOnFaceID", comment: ""))
                            .font(.system(size: 18).bold())
                            .foregroundColor(myColor)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                        Image(systemName: "arrow.forward")
                            .font(.system(size: 25).bold())
                            .padding(13)
                            .foregroundColor(myColor)
                            .background(Color.black.opacity(0.25))
                            .clipShape(Circle())
                    }
                    .frame(width: 200)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 7)
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .fill(myBgColor)
    //                            .overlay(
    //                                RoundedRectangle(cornerRadius: 50)
    //                                    .stroke(Color("xanh").opacity(0.1), lineWidth: 1)
    //                            )
                    )
                }.padding(.bottom, 10)
                Button{
                    
                    hasRedirect = true
                }label: {
                    Text(NSLocalizedString("skip", comment: ""))
                        .font(.system(size: 18).bold())
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .center)
                }.padding(.bottom, 0)
                
                NavigationLink("", isActive: $hasRedirect) {
                    ContentView(isUnlocked: true).navigationBarHidden(true)
                }
                
            }.onAppear(){
                
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
        //}
        
    }
}

#Preview {
    Onboarding6Lock().preferredColorScheme(.dark)
}
