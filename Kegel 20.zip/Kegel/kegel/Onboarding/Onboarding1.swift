//
//  SwiftUIView.swift
//  kegel-exercise
//
//  Created by Huy Le on 27/4/26.
//

import SwiftUI

struct Onboarding1: View {
    @Environment(\.dismiss) var dismiss
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    @State private var hasRedirect = false
    @State private var gender: Int = 0
    var body: some View {
        NavigationView{
            VStack{
                HStack{
//                    Button {
//                        dismiss()
//                    } label: {
//                        Image(systemName: "chevron.left")
//                            .font(Font.system(size: 23))
//                            .foregroundColor(.white)
//                            .frame(width: 45, height: 45)
//                            //.background(Color.white.opacity(0))
//                            .clipShape(Circle())
//                            .overlay(
//                                RoundedRectangle(cornerRadius: 30)
//                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
//                            )
//                    }
//                    Spacer()
                    Text(NSLocalizedString("welcometo", comment: ""))
                        .font(.system(size: 20).bold())
                        .padding(.bottom, 0)
//                    Spacer()
//                    Button {
//                        dismiss()
//                    } label: {
//                        Image(systemName: "chevron.left")
//                            .foregroundColor(.black)
//                            .padding(12)
//                            .background(Color.white.opacity(0.2))
//                            .clipShape(Circle())
//                    }.opacity(0)
                    
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                    .padding(.bottom, -20)
                Text(NSLocalizedString("appname", comment: ""))
                    .font(.system(size: 50))
                    .foregroundColor(Color("xanhnon"))
                    .padding(.top, 0)
                Spacer()
                
                Button{
                    defaults?.set(0, forKey: "gender")
                    setUserDefault()
                    
                    gender = 1
                    hasRedirect = true
                    
                }label: {
                    HStack{
                        Image("nam")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(Color.black)
                            .frame(width: 35, height: 35)
                            
                        Text(NSLocalizedString("man", comment: ""))
                            .foregroundColor(Color.black)
                            .font(.system(size: 20).bold())
                            .padding(.leading, 10)
                        Spacer()
                        Circle()
                            .stroke(.black, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(30)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(Color("xanh"))
                    )
                    .padding(.horizontal, 40)
                    .padding(.bottom, 20)
                }
                
                Button{
                    defaults?.set(1, forKey: "gender")
                    setUserDefault()
                    gender = 2
                    hasRedirect = true
                    
                }label: {
                    HStack{
                        Image("nu")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(Color.white)
                            .frame(width: 35, height: 35)
                            
                        Text(NSLocalizedString("female", comment: ""))
                            .foregroundColor(Color.white)
                            .font(.system(size: 20).bold())
                            .padding(.leading, 10)
                        Spacer()
                        Circle()
                            .stroke(.white, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(30)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(Color("tim"))
                    )
                    .padding(.horizontal, 40)
                    .padding(.bottom, 20)
                }
                
                Button{
                    gender = 3
                    defaults?.set(2, forKey: "gender")
                    setUserDefault()
                    hasRedirect = true
                }label: {
                    HStack{
                        Image("non-binary")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(Color.black)
                            .frame(width: 35, height: 35)
                            
                        Text(NSLocalizedString("khonggioitinh", comment: ""))
                            .foregroundColor(Color.white)
                            .font(.system(size: 20).bold())
                            .padding(.leading, 10)
                            .multilineTextAlignment(.leading)
                        Spacer()
                        Circle()
                            .stroke(.white, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(30)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(Color("cam"))
                    )
                    .padding(.horizontal, 40)
                    
                }
                NavigationLink("", isActive: $hasRedirect) {
                    Onboarding2(gender: gender)
                }
                Spacer()
            }
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .transition(.move(edge: .trailing))
    }
    func setUserDefault() {
        defaults?.set(15, forKey: "ThoiGianNghiaGiuaHiep")
        defaults?.set(true, forKey: "rung")
        defaults?.set(true, forKey: "shownoti")
        
        var components = Calendar.current.dateComponents([.year, .month, .day], from: Date())
        components.hour = 20
        components.minute = 34
        components.second = 0
        let date = Calendar.current.date(from: components) ?? Date()
        defaults?.set(date.timeIntervalSince1970, forKey: "thoigiannhacnho")
        Huy_functions().setNotiChuaTap()
    }
}

#Preview {
    Onboarding1()
        .preferredColorScheme(.dark)
}
