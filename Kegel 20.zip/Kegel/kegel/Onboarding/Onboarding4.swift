//
//  Onboarding4.swift
//  kegel-exercise
//
//  Created by Huy Le on 4/5/26.
//

import SwiftUI

struct Onboarding4: View {
    @Environment(\.dismiss) var dismiss
    @State private var hasRedirect = false
    @State private var myBgColor: Color = Variable().getColorByGender()
    @State private var myColor: Color = Variable().getForeColorByGender()
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    let variable = Variable()
    var body: some View {
        NavigationView{
            VStack{
                HStack(alignment: .center){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(Font.system(size: 20))
                            .foregroundColor(.white)
                            .frame(width: 45, height: 45)
                            //.background(Color.white.opacity(0))
                            .clipShape(Circle())
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    }
                    Spacer()
                    
                    Text(NSLocalizedString("choncuongdotap", comment: ""))
                        .font(.system(size: 20).bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0)
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .padding(12)
                            .background(Color.white.opacity(0.2))
                            .clipShape(Circle())
                    }.opacity(0)
                    
                }.padding(.horizontal, 20)
                    .padding(.top, Huy_functions().getRatioScreen() > 1.8 ? 60 : 30)
               
                Spacer()
                
                Button{
                    defaults?.set(1, forKey: "chedotap")
                    hasRedirect = true
                }label: {
                    HStack{
                        ZStack{
                            Circle()
                                .fill(.black.opacity(0.15))
                                .frame(width: 50, height: 50)
                            Text("5")
                                .font(.system(size: 25).bold())
                                .foregroundColor(myColor)
                        }
                        VStack{
                            Text(NSLocalizedString(variable.arrCheDoTap[1], comment: ""))
                                .foregroundColor(myColor)
                                .font(.system(size: 20).bold())
                                .padding(.leading, 10)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.bottom, 1)
                            Text(NSLocalizedString("tap5pmoingayDesc", comment: ""))
                                .foregroundColor(myColor.opacity(0.6))
                                .font(.system(size: 17).bold())
                                .padding(.leading, 10)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        Spacer()
                        Circle()
                            .stroke(myColor, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 30)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(myBgColor)
                    )
                    .padding(.horizontal, 30)
                    .padding(.bottom, 20)
                }
                
                Button{
                    defaults?.set(2, forKey: "chedotap")
                    hasRedirect = true
                }label: {
                    HStack{
                        ZStack{
                            Circle()
                                .fill(.black.opacity(0.15))
                                .frame(width: 50, height: 50)
                                
                            Text("7")
                                .font(.system(size: 25).bold())
                                .foregroundColor(myColor)
                        }
                        VStack{
                            Text(NSLocalizedString(variable.arrCheDoTap[2], comment: ""))
                                .foregroundColor(myColor)
                                .font(.system(size: 20).bold())
                                .padding(.leading, 10)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.bottom, 1)
                            Text(NSLocalizedString("tap7pmoingayDesc", comment: ""))
                                .foregroundColor(myColor.opacity(0.6))
                                .font(.system(size: 17).bold())
                                .padding(.leading, 10)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        Spacer()
                        Circle()
                            .stroke(myColor, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 30)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(myBgColor)
                    )
                    .padding(.horizontal, 30)
                    .padding(.bottom, 20)
                }
                
                Button{
                    defaults?.set(3, forKey: "chedotap")
                    hasRedirect = true
                }label: {
                    HStack{
                        ZStack{
                            Circle()
                                .fill(.black.opacity(0.15))
                                .frame(width: 50, height: 50)
                                
                            Text("9")
                                .font(.system(size: 25).bold())
                                .foregroundColor(myColor)
                        }
                        VStack{
                            Text(NSLocalizedString(variable.arrCheDoTap[3], comment: ""))
                                .foregroundColor(myColor)
                                .font(.system(size: 20).bold())
                                .padding(.leading, 10)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.bottom, 1)
                            Text(NSLocalizedString("tap9pmoingayDesc", comment: ""))
                                .foregroundColor(myColor.opacity(0.6))
                                .font(.system(size: 17).bold())
                                .padding(.leading, 10)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        Spacer()
                        Circle()
                            .stroke(myColor, lineWidth: 2)
                            .frame(width: 15, height: 15)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 30)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(myBgColor)
                    )
                    .padding(.horizontal, 30)
                    .padding(.bottom, 20)
                }
                NavigationLink("", isActive: $hasRedirect) {
                    Onboarding5()
                }
                Spacer()
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.container, edges: .top)
            .navigationBarBackButtonHidden(true)
            .navigationViewStyle(StackNavigationViewStyle())
            .transition(.move(edge: .trailing))
        }
        
    }
}

#Preview {
    Onboarding4().preferredColorScheme(.dark)
}
