import HealthKit

class WorkoutManager: NSObject, HKWorkoutSessionDelegate {
    let healthStore = HKHealthStore()
    var session: HKWorkoutSession?

    // Gọi để xin quyền truy cập HealthKit
    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        // Các loại dữ liệu muốn ghi và đọc
        let typesToShare: Set = [
            HKObjectType.workoutType()
        ]
        
        let typesToRead: Set = [
            HKObjectType.workoutType()
        ]

        healthStore.requestAuthorization(toShare: typesToShare, read: typesToRead) { (success, error) in
            if let error = error {
                print("HealthKit authorization error: \(error.localizedDescription)")
            }
            completion(success)
        }
    }

    // Bắt đầu buổi tập luyện
    func startWorkout() {
        let configuration = HKWorkoutConfiguration()
        configuration.activityType = .traditionalStrengthTraining
        configuration.locationType = .outdoor
        
        do {
            session = try HKWorkoutSession(healthStore: healthStore, configuration: configuration)
            session?.delegate = self
            session?.startActivity(with: Date())
            print("Workout session started")
        } catch {
            print("Error starting workout session: \(error)")
        }
    }
    
    // Kết thúc buổi tập luyện
    func endWorkout() {
        guard let session = session else { return }
        session.stopActivity(with: Date())
        session.end()
        print("Workout session ending...")
    }

    // MARK: - HKWorkoutSessionDelegate

    func workoutSession(_ workoutSession: HKWorkoutSession, didChangeTo toState: HKWorkoutSessionState, from fromState: HKWorkoutSessionState, date: Date) {
        if toState == .ended {
            print("Workout session ended at \(date)")
            // Có thể lưu dữ liệu tập luyện tại đây nếu cần
        }
    }

    func workoutSession(_ workoutSession: HKWorkoutSession, didFailWithError error: Error) {
        print("Workout session failed with error: \(error)")
    }
}
