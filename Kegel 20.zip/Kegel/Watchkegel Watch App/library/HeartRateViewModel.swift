//
//  HeartRateViewModel.swift
//  sturdy-chest-abs-workout
//
//  Created by Huy Le on 16/5/25.
//  Copyright © 2025 huy. All rights reserved.
//

import SwiftUI
import HealthKit // Import HealthKit

// MARK: - HealthKitManager

class HealthKitManager: ObservableObject {
    let healthStore = HKHealthStore() // Thể hiện của HealthStore
    @Published var latestHeartRate: Double? // Giá trị nhịp tim gần nhất

    // Hàm yêu cầu quyền truy cập HealthKit
    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        // Chỉ yêu cầu quyền đọc dữ liệu nhịp tim
        guard let heartRateType = HKQuantityType.quantityType(forIdentifier: .heartRate) else {
            completion(false)
            return
        }
        let typesToRead: Set<HKObjectType> = [heartRateType]

        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { (success, error) in
            if let error = error {
                print("Lỗi cấp quyền HealthKit: \(error.localizedDescription)")
            }
            // Gọi completion handler trên luồng chính để đảm bảo cập nhật UI nếu cần
            DispatchQueue.main.async {
                completion(success)
            }
        }
    }

    // Hàm lấy giá trị nhịp tim gần nhất
    func fetchLatestHeartRate() {
        guard let heartRateType = HKQuantityType.quantityType(forIdentifier: .heartRate) else {
            print("Không thể tạo loại dữ liệu nhịp tim.")
            return
        }

        // Tạo predicate để lấy dữ liệu trong khoảng thời gian gần đây (ví dụ: 24 giờ qua)
        // Điều này giúp tránh lấy dữ liệu quá cũ nếu có.
        let now = Date()
        let oneDayAgo = Calendar.current.date(byAdding: .day, value: -1, to: now)!
        let predicate = HKQuery.predicateForSamples(withStart: oneDayAgo, end: now, options: .strictEndDate)

        // Sắp xếp theo ngày kết thúc giảm dần để lấy mẫu mới nhất đầu tiên
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)

        // Tạo truy vấn mẫu (sample query)
        let query = HKSampleQuery(sampleType: heartRateType,
                                  predicate: predicate,
                                  limit: 1, // Chỉ lấy 1 mẫu duy nhất (mới nhất)
                                  sortDescriptors: [sortDescriptor]) { [weak self] (query, samples, error) in
            guard let self = self else { return }

            if let error = error {
                print("Lỗi khi truy vấn nhịp tim: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.latestHeartRate = nil // Đặt nil nếu có lỗi
                }
                return
            }

            // Xử lý kết quả truy vấn
            DispatchQueue.main.async {
                if let sample = samples?.first as? HKQuantitySample {
                    let heartRateUnit = HKUnit.count().unitDivided(by: .minute())
                    self.latestHeartRate = sample.quantity.doubleValue(for: heartRateUnit)
                } else {
                    self.latestHeartRate = nil // Không có dữ liệu
                    print("Không tìm thấy dữ liệu nhịp tim gần nhất.")
                }
            }
        }
        
        // Thực thi truy vấn
        healthStore.execute(query)
    }
}
