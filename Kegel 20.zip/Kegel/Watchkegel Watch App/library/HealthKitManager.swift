//
//  HealthKitAWManager.swift
//  sturdy-chest-abs-workout
//
//  Created by Huy Le on 21/5/25.
//  Copyright © 2025 huy. All rights reserved.
//

import HealthKit

class HealthKitAWManager: ObservableObject {
    let healthStore = HKHealthStore()
    
    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(false)
            return
        }

        let typesToShare: Set = [
            HKObjectType.workoutType(),
            HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!
        ]
        
        let typesToRead: Set = [
            HKObjectType.quantityType(forIdentifier: .appleExerciseTime)!,
            HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!,
            HKObjectType.workoutType()
        ]

        healthStore.requestAuthorization(toShare: typesToShare, read: typesToRead) { success, error in
            completion(success)
        }
    }

    func saveWorkout(duration: TimeInterval, energy: Double, completion: @escaping (Bool, Error?) -> Void) {
        let endDate = Date()
        let startDate = endDate.addingTimeInterval(-duration)
        
        let energyBurned = HKQuantity(unit: .kilocalorie(), doubleValue: energy)
        let energyType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!
        
        let workout = HKWorkout(activityType: .traditionalStrengthTraining,
                                start: startDate,
                                end: endDate,
                                duration: duration,
                                totalEnergyBurned: energyBurned,
                                totalDistance: nil,
                                metadata: nil)
        
        healthStore.save(workout) { (success, error) in
            if success {
                let energySample = HKQuantitySample(type: energyType,
                                                    quantity: energyBurned,
                                                    start: startDate,
                                                    end: endDate)

                self.healthStore.save(energySample) { success, error in
                    completion(success, error)
                }
            } else {
                completion(false, error)
            }
        }
    }

}
