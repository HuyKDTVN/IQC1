//
//  WatchSessionManager.swift
//  sturdy-chest-abs-workout
//
//  Created by Huy Le on 4/5/25.
//  Copyright © 2025 huy. All rights reserved.
//

import Foundation
import WatchConnectivity

class WatchSessionManager: NSObject, ObservableObject, WCSessionDelegate {
    @Published var muctieuTitle: String = "..."
    @Published var muctieuTime: String = "..."
    @Published var muctieuTiLeHomNay: Double = 0
    @Published var muctieuTiLeAll: Double = 0
    
    @Published var hasMucTieu: Int = 0
    @Published var hasThuThach: Int = 0
    @Published var timeRest: Int = 0

    override init() {
        super.init()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
            
//            let context = session.receivedApplicationContext
//                DispatchQueue.main.async {
//                    if let text = context["muctieutitle"] as? String {
//                        self.muctieuTitle = text
//                    }
//                    if let text = context["muctieutime"] as? String {
//                        self.muctieuTime = text
//                    }
//                    if let text = context["muctieutileHomNay"] as? Double {
//                        self.muctieuTiLeHomNay = text
//                    }
//                    if let text = context["muctieutileAll"] as? Double {
//                        self.muctieuTiLeAll = text
//                    }
//                    if let text = context["hasmuctieu"] as? Int {
//                        self.hasMucTieu = text
//                    }
//                    if let text = context["hasthuthach"] as? Int {
//                        self.hasThuThach = text
//                    }
//                    if let text = context["timeRest"] as? Int {
//                        self.timeRest = text
//                    }
//                }
        }
    }
    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String : Any] = [:]) {
        DispatchQueue.main.async {
            if let text = userInfo["muctieutitle"] as? String {
                self.muctieuTitle = text
            }
            if let text = userInfo["muctieutime"] as? String {
                self.muctieuTime = text
            }
            if let text = userInfo["muctieutileHomNay"] as? Double {
                self.muctieuTiLeHomNay = text
            }
            if let text = userInfo["muctieutileAll"] as? Double {
                self.muctieuTiLeAll = text
            }
            if let text = userInfo["hasmuctieu"] as? Int {
                self.hasMucTieu = text
            }
            if let text = userInfo["hasthuthach"] as? Int {
                self.hasThuThach = text
            }
            if let text = userInfo["timeRest"] as? Int {
                self.timeRest = text
            }
        }
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print("Session kích hoạt: \(activationState.rawValue)")
    }

    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String : Any]) {
//            if let hasMucTieu = applicationContext["hasmuctieu"] as? Bool {
//                DispatchQueue.main.async {
//                    // Cập nhật giao diện hoặc lưu trạng thái tại đây
//                    print("Đã nhận hasmuctieu: \(hasMucTieu)")
//                    // Ví dụ: self.hasMucTieu = hasMucTieu
//                }
//            }
        
        DispatchQueue.main.async {
            if let text = applicationContext["muctieutitle"] as? String {
                self.muctieuTitle = text
            }
            if let text = applicationContext["muctieutime"] as? String {
                self.muctieuTime = text
            }
            if let text = applicationContext["muctieutileHomNay"] as? Double {
                self.muctieuTiLeHomNay = text
            }
            if let text = applicationContext["muctieutileAll"] as? Double {
                self.muctieuTiLeAll = text
            }
            if let text = applicationContext["hasmuctieu"] as? Int {
                self.hasMucTieu = text
            }
            if let text = applicationContext["hasthuthach"] as? Int {
                self.hasThuThach = text
            }
            if let text = applicationContext["timeRest"] as? Int {
                self.timeRest = text
            }
        }
    }
    
    func checkiOSAppStateFromWatch() -> Bool{
        if WCSession.default.isReachable {
            print("iOS app đang mở (foreground) – có thể gửi message.")
            return true
        } else {
            print("iOS app không mở hoặc không reachable – hãy dùng transferUserInfo.")
            return false
        }
        
//        if WCSession.default.activationState == .activated {
//            return true
//        }else {
//            print("WCSession chưa sẵn sàng.")
//            return false
//        }
    }
    func sendDataToiPhone(isTapTheoMucTieu: Bool, isTapTheoThuThach : Bool, loaiBaiTap: Int, dodaiBaiTap: Int) {
//        guard WCSession.default.activationState == .activated else {
//            print("WCSession chưa sẵn sàng.")
//            return
//        }

        var tapTheoMucTieuInt: Int = 0
        if isTapTheoMucTieu {
            tapTheoMucTieuInt = 1
        }
        
        var tapTheoThuThachInt: Int = 0
        if isTapTheoThuThach {
            tapTheoThuThachInt = 1
        }
        
        let dataToSend: [String: Any] = [
            "isTapTheoMucTieu": tapTheoMucTieuInt,
            "isTapTheoThuThach": tapTheoThuThachInt,
            "loaiBaiTap": loaiBaiTap,
            "dodaiBaiTap": dodaiBaiTap,
        ]
        do {
            try WCSession.default.updateApplicationContext(dataToSend)
            print("Gửi dữ liệu sang iPhone thành công.")
        } catch {
            print("Lỗi khi gửi dữ liệu sang iPhone: \(error.localizedDescription)")
        }
    }
    func sendDataToiPhone2(isTapTheoMucTieu: Bool, isTapTheoThuThach : Bool, loaiBaiTap: Int, dodaiBaiTap: Int) {
        
        // Chuyển đổi các biến boolean thành Int nếu cần
        let tapTheoMucTieuInt = isTapTheoMucTieu ? 1 : 0
        let tapTheoThuThachInt = isTapTheoThuThach ? 1 : 0

        // Tạo dictionary dữ liệu cần gửi
        let dataToSend: [String: Any] = [
            "isTapTheoMucTieu": tapTheoMucTieuInt,
            "isTapTheoThuThach": tapTheoThuThachInt,
            "loaiBaiTap": loaiBaiTap,
            "dodaiBaiTap": dodaiBaiTap,
            "timestamp": Date().timeIntervalSince1970 // giúp phân biệt từng bản ghi
        ]

        // Gửi dữ liệu qua transferUserInfo
        WCSession.default.transferUserInfo(dataToSend)
        print("Gửi dữ liệu sang iPhone bằng transferUserInfo.")
    }
}
