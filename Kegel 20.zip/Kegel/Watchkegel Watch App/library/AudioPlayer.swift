//
//  AudioPlayer.swift
//  kegel-exercise
//
//  Created by Huy Le on 29/6/25.
//

import Foundation
import AVFoundation

class AudioPlayer: ObservableObject {
    init() {
            //preloadSound(name) // Load trước khi cần phát
        }

    func preloadSound(name : String) {
            guard let url = Bundle.main.url(forResource: name, withExtension: "mp3") else {
                print("🔴 Không tìm thấy file âm thanh.")
                return
            }

            do {
                player = try AVAudioPlayer(contentsOf: url)
                player?.prepareToPlay() // ⚠️ Rất quan trọng để preload vào RAM
            } catch {
                print("🔴 Lỗi khi load âm thanh: \(error.localizedDescription)")
            }
        }
    
    var player: AVAudioPlayer?

    func playSound(name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "mp3") else {
            print("🔴 File not found: \(name)")
            return
        }
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            player?.play()
        } catch {
            print("🔴 Error playing sound: \(error.localizedDescription)")
        }
    }

    func stop() {
        player?.stop()
    }
}
