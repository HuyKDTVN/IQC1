//
//  SelectTime.swift
//  kegel-exercise
//
//  Created by Huy Le on 20/8/25.
//

import SwiftUI

struct SelectTime: View {
    var loaiBaiTap: Int = 0
    let variable = Variable()
    //@State var thoiGianTap = UserDefaults.standard.integer(forKey: "thoigiantap")
    var body: some View {
        NavigationStack {
            VStack{
                HStack {
                    Text(NSLocalizedString("timeTapLuyen", comment: ""))//myTitle
                        .foregroundColor(Color("xanhnon"))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 45)
                        .padding(.bottom, 5)
                        .font(Font.system(size: 14.0, weight: .bold))
                        .padding(.leading, 2)
                }
                
                let times = Array(variable.kegelTimes.enumerated())
                
                List(times, id: \.1) { index, item in
                    NavigationLink(
                        destination: StartWorkout(doDaiBaiTap2: item, loaiBaiTap2: loaiBaiTap)
                    ){
                        HStack{
                            Circle()
                                .stroke(Color("xanhnon"), lineWidth: 2)
                                .frame(width: 10, height: 10, alignment: .trailing)
                                .padding(.trailing, 0)
                                
                            }
                            .padding(.leading, 10)
                            .padding(.trailing, 10)
                            VStack {
                                Text("\(item) " + NSLocalizedString("time", comment: ""))
                                    .padding(.bottom, 2)
                                    .font(Font.system(size: 13.0, weight: .regular))
                                Text("\(item * loaiBaiTap * 2)s")
                                    .padding(.bottom, 2)
                                    .opacity(0.5)
                                    .font(Font.system(size: 13.0, weight: .regular))
                            }
                            Spacer()
                        Spacer()
                        ZStack{
                            Circle()
                                .trim(from: 0, to: Double(variable.percentCongThem(soGiayTap: item * loaiBaiTap * 2)) / 100)
                                .stroke(Color("xanhnon"), style: StrokeStyle(lineWidth: 3, lineCap: .round))
                                .frame(width: 40, height: 40)
                                .rotationEffect(.init(degrees: -90))
                            Text("+\(variable.percentCongThem(soGiayTap: item * loaiBaiTap * 2))%")
                                .padding(.bottom, 2)
                                .font(Font.system(size: 12.0))
                                .foregroundColor(Color("xanhnon"))
                            
                        }.frame(width: 40, height: 40)
                            //.padding(5)
                            //.padding(.leading, 2)
                        
                        //.frame(maxWidth: .infinity, alignment: .leading) // 👈 tăng chiều cao
                            //.background(Color.white)
                    }
                }
                .listStyle(.plain)
                .navigationTitle("")//.foregroundColor(Color("bgColorMain)
               .buttonStyle(PlainButtonStyle())
            }
            .padding()
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
        
    }
}

#Preview {
    SelectTime()
}
