//
//  WatchkegelApp.swift
//  Watchkegel Watch App
//
//  Created by Huy Le on 29/6/25.
//

import SwiftUI

@main
struct Watchkegel_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
