//
//  AW_functions.swift
//  kegel-exercise
//
//  Created by Huy Le on 25/8/25.
//

import Foundation
class AW_functions {
    
    func getThanhTich() -> [CGFloat] {
        //data sample
        //date++++soNgayTap++++percent1Day++++percentAll
        //25/8/2025++++4++++0.4++++0.7
        var result: [CGFloat] = [0, 0]
        let data = UserDefaults.standard.string(forKey: Variable().userDefaultThanhTich) ?? ""
        
        if !data.isEmpty {
            let arrData = data.split(separator: "++++")
            result[0] = CGFloat(Double(arrData[3]) ?? 0)
            result[1] = 0
            
            let date = Date()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy_MM_dd"
            let dataDate = dateFormatter.date(from:String(arrData[0]))!
            print("test date: \(dataDate)")
            if (Calendar.current.isDateInToday(dataDate)) {
                result[1] = CGFloat(Double(arrData[2]) ?? 0)
            }
        }
        return result // all, 1day
    }
    
    func updateThanhTich(soGiayTap: Int) {
        //data sample
        //date++++soNgayTap++++percent1Day++++percentAll
        //25/8/2025++++4++++0.4++++0.7
        
        let loaiMucTieu: Int = 2
        let date = Date()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy_MM_dd"
        
        var data = UserDefaults.standard.string(forKey: Variable().userDefaultThanhTich) ?? ""
        
        let mucTieu1Ngay:Double = Double(Variable().mucTieuValue[loaiMucTieu]) / Double(Variable().muctieuTimes[loaiMucTieu])
        var percent1Day:Double = Double(soGiayTap) / mucTieu1Ngay / 60
        
        var percentAll:Double = Double(soGiayTap) / Double(Variable().mucTieuValue[loaiMucTieu]) / 60
        
        if data.isEmpty { //ngay tap dau tien
            data = dateFormatter.string(from: date) + "++++1++++" + String(percent1Day) + "++++" + String(percentAll)
        } else{
            print("data:")
            print( data)
            print("data:")
            
            //da tung tap truoc do
            let arrData = data.split(separator: "++++")
            let dataDate = dateFormatter.date(from:String(arrData[0]))!
            
            percentAll = percentAll + (Double(arrData[3]) ?? 0)
            
            let soNgayDaTap: Int = Int(arrData[1]) ?? 0
            
            let soPhutConLai: Double = Double(Variable().mucTieuValue[loaiMucTieu]) - (percentAll * Double(Variable().mucTieuValue[loaiMucTieu]))
            
            let soPhutTap1Ngay = soPhutConLai / (Double(Variable().muctieuTimes[loaiMucTieu])  - Double(soNgayDaTap))
            
            
            if (Calendar.current.isDateInToday(dataDate)) {
                // hom nay da tung tap roi va gio tap them
                percent1Day = Double(soGiayTap) / 60 / soPhutTap1Ngay + (Double(arrData[2]) ?? 0)
                data = arrData[0] + "++++" + String(soNgayDaTap) + "++++" + String(percent1Day) + "++++" + String(percentAll)
            }else{
                //hom nay chua tung tap
                percent1Day = Double(soGiayTap) / 60 / soPhutTap1Ngay
                data = dateFormatter.string(from: date) + "++++" + String(soNgayDaTap + 1) + "++++" + String(percent1Day) + "++++" + String(percentAll)
            }
        }
        UserDefaults.standard.set(data, forKey: Variable().userDefaultThanhTich)
        
    }
}
