//
//  SelectType.swift
//  kegel-exercise
//
//  Created by Huy Le on 20/8/25.
//

import SwiftUI

struct SelectType: View {
    
    let variable = Variable()
    @State var thoiGianTap = UserDefaults.standard.integer(forKey: "thoigiantap")
    var body: some View {
        NavigationStack {
            VStack{
                HStack {
                    Text(NSLocalizedString("chonbaitap", comment: ""))//myTitle
                        .foregroundColor(Color("xanhnon"))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 45)
                        .padding(.bottom, 5)
                        .font(Font.system(size: 14.0, weight: .bold))
                        .padding(.leading, 2)
                    
                }
                
                List(Array(variable.kegelTypes.enumerated()), id: \.1) {index, item in
                    NavigationLink(destination: SelectTime(loaiBaiTap: item)) {
                        HStack{
                            Circle()
                                .stroke(Color("xanhnon"), lineWidth: 2)
                                .frame(width: 10, height: 10, alignment: .trailing)
                                .padding(.trailing, 0)
                                
                            }
                            .padding(.leading, 5)
                            .padding(.trailing, 5)
                          
                            VStack {
                                Text("\(item) " + NSLocalizedString("tap", comment: "") + ", " + "\(item) " + NSLocalizedString("rest", comment: ""))
                                    .padding(.bottom, 2)
                                    .font(Font.system(size: 14.0, weight: .bold))
                            }
                            .frame(maxWidth: .infinity, alignment: .leading) // 👈 tăng chiều cao
                            //.background(Color.white)
                    }
                }
                .listStyle(.plain)
                .navigationTitle("")//.foregroundColor(Color("bgColorMain)
               .buttonStyle(PlainButtonStyle())
            }
            .padding()
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
        
    }
    
}

#Preview {
    SelectType()
}
