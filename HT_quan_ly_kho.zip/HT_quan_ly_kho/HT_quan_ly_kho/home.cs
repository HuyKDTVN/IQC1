﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HT_quan_ly_kho
{
    public partial class home : Form
    {
        public string maNV;
        public string hoTen;
        public int phanQuyenInt;


        public home(string maCodeNV, string tenNV, int phanQuyen)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            maNV = maCodeNV;
            hoTen = tenNV;
            phanQuyenInt = phanQuyen;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            NhapKho f = new NhapKho(maNV, hoTen, phanQuyenInt, "nhap", "");
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            NhapKho f = new NhapKho(maNV, hoTen, phanQuyenInt, "tainhap", "");
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            XuatKho f = new XuatKho(maNV, hoTen, phanQuyenInt, true);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TraCuu f = new TraCuu(maNV, hoTen, phanQuyenInt, "");
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void home_Load(object sender, EventArgs e)
        {
            Button btn = new Button();
            btn.Size = new Size(150, 60);
            btn.Text = "Nhấn vào tôi";
            btn.Image = Properties.Resources.Untitled_1; // đường dẫn tới ảnh
            btn.TextImageRelation = TextImageRelation.ImageBeforeText; // Ảnh bên trái, chữ bên phải
            btn.ImageAlign = ContentAlignment.MiddleLeft;
            btn.TextAlign = ContentAlignment.MiddleRight;
            btn.FlatStyle = FlatStyle.Flat; // Tùy chọn: gọn gàng, không viền nổi
            btn.BackColor = Color.LightBlue; // Tùy chỉnh màu nền
            btn.ForeColor = Color.Black;

            this.Controls.Add(btn);


            mytitle.Text = "Hệ thống quản lý kho " + Variable.getTenCongTy(Variable.isTry);
            this.Text = Variable.getTenCongTy(Variable.isTry) + " - Phần mềm quản lý kho " + " (" + Variable.version + ")";
            helloText.Text = "Xin chào " + hoTen;
            //MessageBox.Show(phanQuyenInt + "");
            lblTonDuoiMucToiThieu.Text = "Số mã tồn dưới mức tồn kho tối thiểu: " + Huy_functions.getFileInFolder(Variable.pathTonKhoToiThieu);
            lblTonDuoiMucToiThieu.BackColor = Color.FromArgb(26, 117, 187);
            lblTonDuoiMucToiThieu.Location = new Point(
                lblTonDuoiMucToiThieu.Location.X,
                this.ClientSize.Height - lblTonDuoiMucToiThieu.Height - 15
            );

            //hide all button
            themVL.Visible = false;
            tinhTrangTonKho.Visible = false;
            nhapKho.Visible = false;
            taiNhap.Visible = false;
            xuatKho.Visible = false;
            huyVatLieu.Visible = false;

            phieuNhapKho.Visible = false;
            phieuXuatKho.Visible = false;

            bangNhatKy.Visible = false;
            bangGiaoDich.Visible = false;
            capNhatThanhVien.Visible = false;
            switch (phanQuyenInt)
            {
                case 2:
                    themVL.Visible = true;
                    nhapKho.Visible = true;
                    taiNhap.Visible = true;
                    xuatKho.Visible = true;
                    phieuNhapKho.Visible = true;
                    phieuXuatKho.Visible = true;
                    tinhTrangTonKho.Visible = true;
                    break;
                case 3:
                    themVL.Visible = true;
                    tinhTrangTonKho.Visible = true;
                    nhapKho.Visible = true;
                    taiNhap.Visible = true;
                    xuatKho.Visible = true;
                    huyVatLieu.Visible = true;

                    phieuNhapKho.Visible = true;
                    phieuXuatKho.Visible = true;
                    bangNhatKy.Visible = true;
                    bangGiaoDich.Visible = true;
                    capNhatThanhVien.Visible = true;
                    break;
                default:

                    break;
            }

            string newVersion = Huy_functions.checkNewVersion();
            if (newVersion != "")
            {
                lblMesUpdate.Visible = true;
                link.Visible = true;
                lblMesUpdate.Text = "Hãy cập nhật phiên bản: " + newVersion + " để tiếp tục sử dụng phần mềm.\n Phần mềm sẽ tự động đóng khi bạn nhấn vào link dưới đây.";

                btnDangXuat.Visible = false;
                helloText.Visible = false;
                mytitle.Visible = false;
                lblTonDuoiMucToiThieu.Visible = false;
                traCuuTonKho.Visible = false;
                nhapKho.Visible = false;
                xuatKho.Visible = false;
                taiNhap.Visible = false;
                huyVatLieu.Visible = false;
                themVL.Visible = false;

                bangvatlieu.Visible = false;
                bangTonKho.Visible = false;
                capNhatViTriDonVi.Visible = false;
                tinhTrangTonKho.Visible = false;
                phieuNhapKho.Visible = false;
                phieuXuatKho.Visible = false;
                capNhatThanhVien.Visible = false;
                bangNhatKy.Visible = false;
                bangGiaoDich.Visible = false;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            XuatKho f = new XuatKho(maNV, hoTen, phanQuyenInt, false);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tính năng đang được xây dựng");
        }

        private void lblTonDuoiMucToiThieu_Click(object sender, EventArgs e)
        {
            TKToiThieu f = new TKToiThieu(maNV, hoTen, phanQuyenInt);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void themVL_Click(object sender, EventArgs e)
        {
            themVL f = new themVL(maNV, hoTen, phanQuyenInt, "", false);
            f.FormClosed += (s, args) => this.Close();
            f.Show();
            this.Hide();
        }

        private void thayDoiVL_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tính năng đang được xây dựng");
            //capNhatVL f = new capNhatVL(maNV, hoTen, phanQuyenInt);
            //f.FormClosed += (s, args) => this.Close();
            //f.Show();
            //this.Hide();
        }

        private void img1_Click(object sender, EventArgs e)
        {

        }

        private void link_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("explorer.exe", Variable.folderNewVersion);
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Thư mục phần mềm mới không tồn tại. Hãy liên lạc người phụ trách!");
            }
        }

        private void bangTonKho_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\bang-ton-kho.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }



        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\in-QR-code.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {

        }

        private void bangvatlieu_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\bang-vat-lieu.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }



        private void button8_Click_2(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\thong-tin-giao-dich.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void button7_Click_2(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\bang-nhat-ky.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void capNhatViTriDonVi_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\vi-tri-gia_ncc.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void capNhatNCC_Click(object sender, EventArgs e)
        {

        }

        private void phieuNhapKho_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\phieu-nhap-kho.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void phieuXuatKho_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\phieu-xuat-kho.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void capNhatThanhVien_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\thanh-vien.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Variable.getRootPath(Variable.isProduction) + @"ht-quan-ly\bao-cao.xlsm",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở file!");
            }
        }

        private void mytitle_Click(object sender, EventArgs e)
        {

        }
    }
}
