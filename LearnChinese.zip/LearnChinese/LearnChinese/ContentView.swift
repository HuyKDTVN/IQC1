//
//  ContentView.swift
//  LearnChinese
//
//  Created by Huy Le on 23/12/25.
//

import SwiftUI

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    var variable:Variable = Variable()
    @State private var idSoTuKho = UUID()
    @State private var idDanhNgon = UUID()
    @State private var idPercentHSK1 = UUID()
    @State private var danhNgon = Variable().getUserDefaultBool(name: "danhNgon")
    @State private var firstOpenApp = Variable().getUserDefaultBool(name: "firstOpenApp")
    var body: some View {
        ZStack{
            if !firstOpenApp {
                OnBoardingView(firstOpen: $firstOpenApp)
                    .transition(.move(edge: .leading))
            }else{
                NavigationView {
                    VStack{
                        ScrollView(.vertical, showsIndicators: false) {

        //            HStack{
        //                        NavigationLink {
        //                            Setting()
        //                        } label: {
        //                            Image(systemName: "gearshape")
        //                                .foregroundColor(Color("bgTim"))
        //                                .padding(5)
        //                                .background(Color("bgTimMo"))
        //                                .clipShape(Circle())
        //                                .font(.system(size: 25))
        //                        }
        //                        Spacer()
        //                    }
        //                    .padding(.top, -130)
        //                    .padding(.leading, 20)
        //                    .padding(.bottom, 0)
        //                    .zIndex(999)
                            //header
                            ChuoiNgayView(isHome: true)
                                .padding(.top, 35)
                                
                            //quete
                            if(danhNgon) {
                                HStack
                                {
                                    Image(systemName: "quote.opening")
                                        .font(.system(size: 27))
                                        .foregroundColor(Color("bgTim"))
                                        .frame(width: 60)
                                    Text(variable.getDanhNgon())
                                        .padding(.trailing, 15)
                                        .foregroundColor(Color("textTim"))
                                        .font(.system(size: 16).italic())
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.top, 20)
                                .padding(.bottom, 20)
                                .background(
                                    RoundedRectangle(cornerRadius: 40)
                                        .fill(Color("bgTimMo"))
                                )
                                .padding(.leading, 20)
                                .padding(.trailing, 20)
                                .padding(.top, -10)
                                .padding(.bottom, 10)
        //                        .opacity(danhNgon ? 1 : 0)
        //                        .frame(height: danhNgon ? 200 : 0)
        //                        .id(idPercentHSK1)
        //                        .onAppear{
        //                            idPercentHSK1 = UUID()
        //
        //                        }
                            }
                            //cac button
                            GeometryReader { geo in
                                HStack(spacing: 0) {
                                    VStack{
                                        HStack{
                                            Text(NSLocalizedString("bothu", comment: ""))
                                                .textCase( .uppercase)
                                                .font(.system(size: 22).bold())
                                                .foregroundColor(.black)
                                            Spacer()
                                            NavigationLink {
                                                SelectBaiHoc(capDo: 7)
                                                    .navigationBarHidden(true)
                                            }label: {
                                                HStack(alignment: .center, spacing: 2){
                                                    Image(systemName: "arrow.right")
                                                        .foregroundColor(Color("textBlue"))
                                                        .padding(8)
                                                        .background(Color("bgBlue3"))
                                                        .clipShape(Circle())
                                                    Text("214")
                                                        .font(.system(size: 13))
                                                        .foregroundColor(Color("textBlue"))
                                                    Text(NSLocalizedString("bo", comment: ""))
                                                        .font(.system(size: 13))
                                                        .foregroundColor(Color("textBlue"))
                                                }
                                                .padding(.leading, 3)
                                                .padding(.trailing, 4)
                                                .padding(.top, 4)
                                                .padding(.bottom, 4)
                                                .background(
                                                    RoundedRectangle(cornerRadius: 40)
                                                        .fill(Color("bgBlue2"))
                                                )
                                            }
                                        }
                                        Spacer()
                                        NavigationLink {
                                            SelectBaiHoc(capDo: 8)
                                                .navigationBarHidden(true)
                                        }label: {
                                            HStack(alignment: .center, spacing: 2){
                                                Image(systemName: "arrow.right")
                                                    .foregroundColor(Color("textBlue"))
                                                    .padding(8)
                                                    .background(Color("bgBlue3"))
                                                    .clipShape(Circle())
                                                Text("50")
                                                    .font(.system(size: 23))
                                                    .foregroundColor(Color("textBlue"))
                                                Text(NSLocalizedString("bothongdung", comment: ""))
                                                    .font(.system(size: 14))
                                                    .foregroundColor(Color("textBlue"))
                                                Spacer()
                                            }
                                            .padding(.leading, 3)
                                            .padding(.trailing, 4)
                                            .padding(.top, 4)
                                            .padding(.bottom, 4)
                                            .background(
                                                RoundedRectangle(cornerRadius: 40)
                                                    .fill(Color("bgBlue2"))
                                            )
                                            .padding(.leading, 0)
                                        }
                                    }
                                    .padding(15)
                                    .background(
                                        RoundedRectangle(cornerRadius: 40)
                                            .fill(Color("bgBlue1").opacity(0.7))
                                    )
                                    .padding(.leading, 20)
                                    .padding(.trailing, 5)
                                    .frame(width: geo.size.width * 0.63)
                                    
                                   
                                    NavigationLink {
                                        if (variable.getTotalLinked() > 0) {
                                            TuKhoView()
                                            //
                                                .navigationBarHidden(true)
                                        }else {
                                            LikedNothing()
                                        }
                                        
                                    }label: {
                                        VStack{
                                            HStack{
                                                Image(systemName: "star.fill")
                                                    .foregroundColor(Color("textGreen").opacity(0.7))
                                                    .padding(7)
                                                    .background(Color("bgGreen2"))
                                                    .clipShape(Circle())
                                                Spacer()
                                            }
                                            HStack(alignment: .center, spacing: 2){
                                                
                                                Text("\(variable.getTotalLinked())")
                                                    .font(.system(size: 24))
                                                    .foregroundColor(Color("textGreen"))
                                                    .id(idSoTuKho)
                                                    .onAppear{
                                                        idSoTuKho = UUID()
                                                        
                                                    }
                                                    
                                                Text(NSLocalizedString("tukho", comment: ""))
                                                    .font(.system(size: 16))
                                                    .foregroundColor(Color("textGreen"))
                                            }
                                            .padding(.bottom, 0)
                                          
                                            HStack{
                                                Spacer()
                                                Image(systemName: "arrow.right")
                                                    .foregroundColor(Color("textGreen"))
                                                    .padding(10)
                                                    .background(Color("bgGreen2"))
                                                    .clipShape(Circle())
                                            }
                                            .padding(.top, -10)
                                        }
                                        .padding(10)
                                        
                                        .background(
                                            RoundedRectangle(cornerRadius: 40)
                                                .fill(Color("bgGreen1").opacity(0.7))
                                        )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 40)
                                                .stroke(Color("bgGreen1"), lineWidth: 2)
                                        )
                                        .padding(.trailing, 20)
                                        .padding(.leading, 5)
                                        .frame(width: geo.size.width * 0.37)
                                            
                                    }
                                }
                            }
                            .frame(height: 130) // Bắt buộc set height cho GeometryReader
                           
                            NavigationLink{
                                SelectBaiHoc(capDo: 1)
                                    .navigationBarHidden(true)
                            }label: {
                                HSKCard(myTitle: "HSK 1", soTu: "150", percent: variable.getPercentFinish(capDo: 1), colorText: "textTim", colorBg: "bgTimMo")
                                    .id(idPercentHSK1)
                                    .onAppear {
                                        idPercentHSK1 = UUID()
                                    }
                                    
                            }
                            NavigationLink{
                                SelectBaiHoc(capDo: 2)
                                    .navigationBarHidden(true)
                            }label: {
                                HSKCard(myTitle: "HSK 2", soTu: "174", percent: variable.getPercentFinish(capDo: 2), colorText: "textYellow", colorBg: "bgYellow")
                                    .id(idPercentHSK1)
                                    .onAppear {
                                        idPercentHSK1 = UUID()
                                    }
                            }
                            NavigationLink{
                                SelectBaiHoc(capDo: 3)
                                    .navigationBarHidden(true)
                            }label: {
                                HSKCard(myTitle: "HSK 3", soTu: "340", percent: variable.getPercentFinish(capDo: 3), colorText: "textRed", colorBg: "bgRed")
                                    .id(idPercentHSK1)
                                    .onAppear {
                                        idPercentHSK1 = UUID()
                                    }
                            }
                            Spacer()
                            //footer - button
            //                NavigationLink{
            //
            //
            //                    SelectBaiHoc()
            //                }
            //                label: {
            //                    Text("Học từ mới")
            //                        .padding(15)
            //                        .padding(.leading, 30)
            //                        .padding(.trailing, 30)
            //                        .font(.system(size: 20))
            //                        .foregroundColor(Color.white)
            //                        .background(
            //                            RoundedRectangle(cornerRadius: 23)
            //                                .fill(Color("bgTim"))
            //                        )
            //                }
            //                .tint(Color("bgTim"))
                            //.buttonStyle(.borderedProminent)
                        }
                        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
                        .overlay(
                            HStack {
                                NavigationLink {
                                    Setting()
                                } label: {
                                    Image(systemName: "gearshape")
                                        .foregroundColor(Color("bgTim"))
                                        .padding(8)
                                        .background(Color("bgTimMo"))
                                        .clipShape(Circle())
                                        .font(.system(size: 25))
                                }
                                Spacer()
                            }
                            .padding(.leading, 20)
                            .padding(.top, 0) // 👈 chỉnh sát top ở đây
                        , alignment: .top
                        )
                        //.ignoresSafeArea(.container, edges: .top)
                        //.navigationBarTitleDisplayMode(.inline)
                    }
                    .navigationBarHidden(true)
                    .padding(.top, 0)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                   
                    Spacer()
                }
                .navigationBarHidden(true)
                .ignoresSafeArea(.container, edges: .top)
                
                .onAppear(){
                  
                }
                .onChange(of: scenePhase) { newPhase in
                    if newPhase == .active {
                        UIApplication.shared.applicationIconBadgeNumber = 0
                    }
                }
                .navigationBarBackButtonHidden(true)
                .navigationViewStyle(StackNavigationViewStyle())
                .transition(.move(edge: .trailing))
                
            }
        }
        
        .animation(.easeInOut(duration: 0.4), value: firstOpenApp)
        
        
    }
    
}
#Preview {
    ContentView()
}
