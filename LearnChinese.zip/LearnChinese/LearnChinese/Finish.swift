//
//  Finish.swift
//  LearnChinese
//
//  Created by Huy Le on 2/1/26.
//

import SwiftUI
import StoreKit
struct Finish: View {
    let capDo: Int //HSK1
    let soBai: Int // bai 10
    let loaiBai: Int
    let updateChuoiNgay: Bool
    
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    let items = Array(1...3)
    
    let columns = [
        GridItem(.flexible())
    ]

    var arrDataHSK: [[Int]] = [[]]
    
    init(capDo: Int, soBai: Int, loaiBai: Int, updateChuoiNgay: Bool) {
        self.capDo = capDo
        self.soBai = soBai
        self.loaiBai = loaiBai
        self.updateChuoiNgay = updateChuoiNgay
        
        switch capDo {
            case 1:
                self.arrDataHSK = variable.getDataHSK1()
            case 2:
                self.arrDataHSK = variable.getDataHSK2()
            case 3:
                self.arrDataHSK = variable.getDataHSK3()
            case 8:
                self.arrDataHSK = variable.getDataBoThu50()
            case 7:
                self.arrDataHSK = variable.getDataBoThuAll()
            default:
                self.arrDataHSK = variable.getDataHSK1()
        }
     
    }
    
    var body: some View {
        ScrollView(.vertical, showsIndicators: false){
            VStack{
                HStack(alignment: .top){
                    
                    Spacer()
                    Text(variable.getTenCapDo(capDo: capDo))
                        .padding(10)
                        .font(.system(size: 18).bold())
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                        .foregroundColor(Color("textTim"))
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color("bgTimMo"))
                        )
                    Spacer()
                        //.bold()
                        
                }.padding(.horizontal, 20)
                    .padding(.top, 10)
                Text("Chúc mừng bạn!")
                    .font(.system(size: 30).bold())
                    .foregroundColor(Color.black.opacity(0.8))
                    .padding(0)
                    .padding(.top, 20)
                    .padding(.bottom, -5)
                
                if(updateChuoiNgay) {
                    ChuoiNgayView(isHome: false)
                }
                NavigationLink {
                    switch loaiBai
                    {
                    case 1:
                        HocFlashCard(capDo: capDo, soBai: soBai)
                            .navigationBarHidden(true)
                    case 2:
                        
                        HocFlashCard(capDo: capDo, soBai: soBai)
                            .navigationBarHidden(true)
                    case 3:
                        HocViet(capDo: capDo, soBai: soBai)
                            .navigationBarHidden(true)
                    default:
                        HocFlashCard(capDo: capDo, soBai: soBai)
                            .navigationBarHidden(true)
                    }
                    
                } label: {
                    VStack(spacing: 7) {
                        
                        HStack{
                            ZStack{
                                Image("\(Variable().loaiBaiHocIcon[loaiBai - 1])")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 50)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 100)
                            VStack{
                                if capDo != 9 {
                                    HStack(alignment: .top){
                                        
                                        Text(variable.getSoBai(soBai: soBai))
                                            .padding(10)
                                            .font(.system(size: 18).bold())
                                            .padding(.leading, 20)
                                            .padding(.trailing, 20)
                                            .foregroundColor(Color("textTim"))
                                            .background(
                                                RoundedRectangle(cornerRadius: 20)
                                                    .fill(Color("bgTimMo"))
                                            )
                                            //.bold()
                                            .padding(.trailing, 20)
                                            .padding(.top, 0)
                                        Spacer()
                                            //.frame(height: 10)
                                    }
                                }
                                HStack{
                                    Text("\(Variable().loaiBaiHoc[loaiBai - 1])")
                                        .foregroundColor(.black)
                                        .font(.system(size: 18).bold())
                                        .padding(.bottom, 10)
                                        .padding(.leading, 0)
                                        .padding(.trailing, 0)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .layoutPriority(5)
                                    Spacer()
                                        .layoutPriority(1)
                                }
                                
                                
                                if capDo != 9 {
                                    ZStack{
                                        HStack(spacing: 1) {
                                            ForEach(1...5, id: \.self) { i in
                                                Image(systemName: "star.fill")
                                                    .foregroundColor(.gray.opacity(0.5))
                                                    .padding(0)
                                                    .font(.system(size: 18))
                                            }
                                            Spacer()
                                        }
                                        let count = arrDataHSK[soBai - 1][loaiBai - 1]
                                        if count > 0 {
                                            HStack(spacing: 1) {
                                                
                                                ForEach(1...count, id: \.self) { i in
                                                    Image(systemName: "star.fill")
                                                        .foregroundColor(.yellow)
                                                        .padding(0)
                                                        .font(.system(size: 18))
                                                }
                                                Spacer()
                                            }
                                        }
                                    }
                                }
                            }
                           
                            Spacer()
                            
                        }
                        
                       
                        
                    }
                    .frame(maxWidth: .infinity)
                    //.frame(height: 150)
                    .cornerRadius(40)
                    .padding(.top, 15)
                    .padding(.bottom, 15)
                    .background(
                        RoundedRectangle(cornerRadius: 40)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 40)
                                    .stroke(Color("textTim"), lineWidth: 1)
                            )
                    )
                    .padding()
                }
                .buttonStyle(PlainButtonStyle()) // Giữ style gốc, không bị mặc định NavigationLink
                
                Spacer()
                    .frame(maxWidth: .infinity, minHeight: 120)
                HStack{
                    Spacer()
                    NavigationLink{
                        ContentView()
                    }label: {
                        Image(systemName: "house.fill")
                            .foregroundColor(.textTim)
                            .padding(30)
                            .background(.bgTimMo)
                            .clipShape(Circle())
                            .font(.system(size: 30))
                    }
                    
                    Spacer()
                    
                    NavigationLink{
                        switch loaiBai
                        {
                        case 1:
                            HocFlashCard(capDo: capDo, soBai: soBai)
                                .navigationBarHidden(true)
                        case 2:
                            HocTracNghiem(capDo: capDo, soBai: soBai)
                                .navigationBarHidden(true)
                        case 3:
                            HocViet(capDo: capDo, soBai: soBai)
                                .navigationBarHidden(true)
                        default:
                            HocFlashCard(capDo: capDo, soBai: soBai)
                                .navigationBarHidden(true)
                        }
                    }label: {
                        Image(systemName: "arrow.clockwise")
                            .foregroundColor(.textTim)
                            .padding(30)
                            .background(.bgTimMo)
                            .clipShape(Circle())
                            .font(.system(size: 30).bold())
                    }
                    Spacer()
                    if (capDo != 9){
                        NavigationLink{
                            switch loaiBai
                            {
                            case 1:
                                HocTracNghiem(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                            case 2:
                                HocViet(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                                
                            case 3:
                                HocFlashCard(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                            default:
                                HocFlashCard(capDo: capDo, soBai: soBai)
                                    .navigationBarHidden(true)
                            }
                        }label: {
                            Image(systemName: "arrow.forward")
                                .foregroundColor(.white)
                                .padding(30)
                                .background(Color("textTim"))
                                .clipShape(Circle())
                                .font(.system(size: 30).bold())
                        }
                        Spacer()
                    }
                    
                    
                    
//                    NavigationLink{
//                        switch loaiBai
//                        {
//                        case 1:
//                            HocFlashCard(capDo: capDo, soBai: soBai)
//                        case 2:
//                            HocTracNghiem(capDo: capDo, soBai: soBai)
//                        case 3:
//                            HocViet(capDo: capDo, soBai: soBai)
//                        default:
//                            HocFlashCard(capDo: capDo, soBai: soBai)
//                        }
//                    }label: {
//                        Image(systemName: "chevron.right")
//                            .foregroundColor(.textTim)
//                            .padding(30)
//                            .background(.bgTimMo)
//                            .clipShape(Circle())
//                            .font(.system(size: 30))
//                    }
                }
                .padding()
            }
            .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
        }
        .onAppear(){
            if !Variable().getUserDefaultBool(name: "showedRating"){
                if #available(iOS 10.3, *) {
                    SKStoreReviewController.requestReview()
                    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
                    defaults?.set(true, forKey: "showedRating")
                } else {
                    // Fallback on earlier versions
                }
            }
            
        }
        .padding(.top, 50)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .toolbar {
//            ToolbarItem(placement: .navigationBarLeading) {
//                Button {
//                    dismiss()
//                } label: {
//                    Image(systemName: "chevron.left")
//                        .foregroundColor(.white)
//                        .padding(10)
//                        .background(Color("textTim"))
//                        .clipShape(Circle())
//                }
//            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    Finish(capDo: 1, soBai: 1, loaiBai: 1, updateChuoiNgay: true)
}
