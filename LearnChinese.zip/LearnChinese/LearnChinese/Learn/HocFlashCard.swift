//
//  HocFlashCard.swift
//  LearnChinese
//
//  Created by Huy Le on 23/12/25.
//

import SwiftUI

struct HocFlashCard: View {
    let capDo: Int //HSK1
    let soBai: Int // bai 10
    var variable:Variable = Variable()
    @State private var enableButton = true
    @Environment(\.dismiss) var dismiss
    @State private var rotation: Double = 0
    @State private var isFlipped = false
    @State private var hasRedirect = false
    @State private var hasUpdateChuoiNgay = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    let amThanh = Variable().getUserDefaultBool(name: "amThanh")
    @State private var hsk: [Vocabulary] = []
    @State private var soTuToiDa : Int  = 10
    var turnOnSound: Bool = Variable().getUserDefaultBool(name: "amThanh")
    
    var turnOnVoid: Bool = Variable().getUserDefaultBool(name: "giongDoc")
    @State private var arrCauHoi: [Int] = Array(0...15).shuffled()
    
    let dataHSK: [[Int]] = []
    
    @State var arrDataHSK: [[Int]] = Array(repeating: Array(repeating: 0, count: 3), count: 100)
    @State private var step: Int = 0
    @State private var prevStep: Int = 0
    var body: some View {
        //NavigationView {
            VStack{
            
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text(variable.getTenCapDo(capDo: capDo))
                        .padding(10)
                        .font(.system(size: 18).bold())
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                        .foregroundColor(Color("textTim"))
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color("bgTimMo"))
                        )
                }.padding(.horizontal, 20)
                    .padding(.top, Variable().getRatioScreen() < 1.8 ? 0 : 10)
                //.background(Color.green.opacity(0.7))
                HStack {
                    Text(variable.getSoBai(soBai: soBai))
                        
                        .foregroundColor(Color("textTim"))
                        .font(.system(size: 30))
                        .bold()
                        .padding(.top, Variable().getRatioScreen() < 1.8 ? 0 : 20)
                }
                VStack{
                    ZStack(alignment: .leading) {
                        GeometryReader { geo in
                            // Thanh nền xám
                            RoundedRectangle(cornerRadius: 7)
                                .fill(Color("bgXam"))
                                .frame(height: 14) // chiều cao thanh
                            
                            
                            // Thanh tiến trình tím
                            RoundedRectangle(cornerRadius: 7)
                                .fill(Color("bgTim"))
                                .frame(width: geo.size.width  * CGFloat(step + 1) / CGFloat(soTuToiDa), height: 14)
                                .animation(.easeInOut(duration: 0.3), value: step + 1)
                            
                        }
                        .frame(height: Variable().getRatioScreen() < 1.8 ? 14 : 24) // 14 + padding 20 trên + 20 dưới
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, Variable().getRatioScreen() < 1.8 ? 0 : 20)
                    
                    ZStack {
                        if step < soTuToiDa {
                            if isFlipped {
                                BackView(
                                    nghia: hsk[arrCauHoi[step]].vietnamese,
                                    phienAm: hsk[arrCauHoi[step]].pinyin,
                                    viDu: hsk[arrCauHoi[step]].example, cauChuyen: hsk[arrCauHoi[step]].cauChuyen
                                ).rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                            } else {
//                                Text("www").onAppear(){
//                                    print("abc")
//                                    print(arrCauHoi[step])
//                                    print(arrDataHSK)
//                                    print(step)
//                                    print(hsk[arrCauHoi[step]].chinese)
//                                    print(capDo)
//                                    
//                                }
                                if step >= 0 && step < arrCauHoi.count && hsk.count > 0 {
                                    FrontView(chuHan:
                                                hsk[arrCauHoi[step]].chinese, speak: hsk[arrCauHoi[step]].speed, step: step, capDo: capDo, viTriTu: arrCauHoi[step] + 1, dataLiked: arrDataHSK).id(arrCauHoi[step])
                                }
                                
                            }
                        }
                    }
                    .rotation3DEffect(
                        .degrees(rotation),
                        axis: (x: 0, y: 1, z: 0),
                        perspective: 0.4
                    )
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.4)) {
                            rotation += isFlipped ? 180 : -180
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            isFlipped.toggle()
                        }
                    }
                    .onChange(of: step) { _ in
                        withAnimation(.none) {
                            isFlipped = false
                            rotation = 0
                        }
                    }
                    //Spacer()
                    HStack{
                        Spacer()
                        if(step > 0) {
                            
                            Button {
                                enableButton = false
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                    enableButton = true
                                }
                                if turnOnSound {
                                    SoundManager.shared.playSound(name: "hit")
                                }
                                if turnOnVoid {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                        if hsk[arrCauHoi[step]].speed != "" {
                                            SpeechManager.shared.speak(hsk[arrCauHoi[step]].speed)
                                        } else {
                                            SpeechManager.shared.speak(hsk[arrCauHoi[step]].chinese)
                                        }
                                        
                                    }
                                }
                                step = step - 1
                                //isFlipped = false
                                print("chu han thu: \(arrCauHoi[step])")
                                prevStep = step
                                
                            } label: {
                                Image(systemName: "chevron.left")
                                    .foregroundColor(Color("bgTim"))
                                    .padding(30)
                                    .background(enableButton ? Color("bgTimMo"): .gray.opacity(0.3))
                                    .clipShape(Circle())
                                    .font(.system(size: 30))
                            }
                            .disabled(!enableButton)
                        }
                        Spacer()
                        Button {
                            enableButton = false
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                enableButton = true
                            }
                            print("soTuToiDa: \(soTuToiDa)")
                            
                            let impact = UIImpactFeedbackGenerator(style: .rigid)
                            impact.impactOccurred()
                            if turnOnSound {
                                SoundManager.shared.playSound(name: "hit")
                            }
                            
                            
                            step = step + 1
                            
                            if(step == soTuToiDa) {
                                //get thanh tich hien tai
                                let thanhTichHienTai = arrDataHSK[soBai - 1][0]
                                
                                if thanhTichHienTai < 5 {
                                    //save Data to UserDefault
                                    arrDataHSK[soBai - 1][0] = thanhTichHienTai + 1
                                    variable.saveDataHSK(arrHsk: arrDataHSK, capDo: capDo)
                                }
                                
                                //luu cap do va so arrCauHoiGanNhat
                                
                                defaults?.set(arrCauHoi, forKey: "arrCauHoiGanNhat")
                                
                                HuyFunc().notiNhacTuMoiMoiNgay()
                                
                                //update chuoi ngay
                                hasUpdateChuoiNgay = variable.updateChuoiNgay()
                                let hasUpdateCapDoSoBai = variable.updateCapDoBaiHocCaoNhat(capDo: capDo, baiHoc: soBai)
                                HuyFunc().removeDefaultNoti()
                                switch variable.getChuoiNgay() {
                                case 1:
                                    HuyFunc().setNotiNgay2DaHoc()
                                case 2:
                                    HuyFunc().setNotiNgay3DaHoc()
                                case 3:
                                    HuyFunc().setNotiNgay4DaHoc()
                                case 4:
                                    HuyFunc().setNotiNgay5DaHoc()
                                case 5:
                                    HuyFunc().setNotiNgay6DaHoc()
                                default:
                                    HuyFunc().setNotiNgay6DaHoc()
                                }
                                hasRedirect = true
                            }else{
                                
                                if turnOnVoid {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                        if hsk[arrCauHoi[step]].speed != "" {
                                            SpeechManager.shared.speak(hsk[arrCauHoi[step]].speed)
                                        } else {
                                            SpeechManager.shared.speak(hsk[arrCauHoi[step]].chinese)
                                        }
                                    }
                                }
                                //isFlipped = false
                                print("step: \(step)")
                                print("capDo: \(capDo)")
                                print(arrCauHoi)
                                //print("chu han thu: \(arrCauHoi[step])")
                                prevStep = step
                                print("cap do: \(capDo) vi tri tu: \(arrCauHoi[step])")
                                isFlipped = false
                            }
                        } label: {
                            Image(systemName: "chevron.right")
                                .foregroundColor(.white)
                                .padding(30)
                                .background(enableButton ? Color("textTim") : .gray.opacity(0.3))
                                .clipShape(Circle())
                                .font(.system(size: 30))
                        }.disabled(!enableButton)
                        Spacer()
                        
                    }
                    .padding(.bottom, 0)
                    
                    //Spacer()
                    
                    NavigationLink("", isActive: $hasRedirect) {
                        Finish(capDo: capDo, soBai: soBai, loaiBai: 1, updateChuoiNgay: hasUpdateChuoiNgay)
                    }
                }
                .onAppear(){
                    if capDo == 9 {
                        
                        hsk = variable.getDataVocaLiked()
                    }else if capDo == 8{
                        hsk = variable.loadVocabulary(hsk: "bothu50")
                    }
                    else if capDo == 7{
                        hsk = variable.loadVocabulary(hsk: "bothuall")
                    }
                    else{
                        
                        hsk = variable.loadVocabulary(hsk: "hsk\(capDo)")
                    }
                    
                    print("hskab")
                    print(hsk)
                    switch capDo {
                        case 1:
                        arrDataHSK = variable.getDataHSK1()
                        case 2:
                        arrDataHSK = variable.getDataHSK2()
                        case 3:
                        arrDataHSK = variable.getDataHSK3()
                        case 8:
                        arrDataHSK = variable.getDataBoThu50()
                        case 7:
                        arrDataHSK = variable.getDataBoThuAll()
                        case 9:
                        arrDataHSK = variable.getDataLiked()
                        default:
                        arrDataHSK = variable.getDataHSK1()
                    }
                   
                   
                    if capDo == 9 { // hien thi tu kho
                        //print(hsk)
                        arrCauHoi = Array(0...hsk.count - 1).shuffled()
                    }else{
                        
                        arrCauHoi = variable.getArrBaiHoc(a: soBai, doDaiArray: hsk.count).shuffled()
                    }
                    
                    
                    if capDo == 9 || soBai == 99 {
                        soTuToiDa = hsk.count
                    }
                    else {
                        soTuToiDa = variable.soTuTrong1Bai
                        if soTuToiDa > arrCauHoi.count {
                            soTuToiDa = arrCauHoi.count
                        }
                    }
                    print("step:")
                    print(arrCauHoi)
                    if turnOnVoid {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            if hsk[arrCauHoi[step]].speed != "" {
                                SpeechManager.shared.speak(hsk[arrCauHoi[step]].speed)
                            } else {
                                SpeechManager.shared.speak(hsk[arrCauHoi[step]].chinese)
                            }
                        }
                    }
                        
                }
                .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
                
            //}
            //.background(Color.green.opacity(0.3))
            .navigationBarBackButtonHidden(true)
            //.ignoresSafeArea()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                }
            }
            
                
        }
        
        .padding(.top, Variable().getRatioScreen() < 1.8 ? 20 : 50)
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarTitleDisplayMode(.inline)
        
    }
        
}

#Preview {
    HocFlashCard(capDo: 1, soBai: 1)
}

struct FrontView: View {
    @State private var isPressed = false
    @State private var daDocLanDau = false
    @State private var showToast = false
    @State private var toastMessage = ""
    var variable:Variable = Variable()
    private var turnOnVoid: Bool {
        variable.getUserDefaultBool(name: "giongDoc")
    }
    let chuHan: String
    let speak: String
    let step: Int
    let capDo: Int
    let viTriTu: Int
    let dataLiked: [[Int]]
    @State private var liked: Bool
    init(chuHan: String, speak: String, step: Int, capDo: Int, viTriTu: Int, dataLiked: [[Int]] ) {
        self.chuHan = chuHan
        self.step = step
        self.capDo = capDo
        self.viTriTu = viTriTu
        self.dataLiked = dataLiked
        self.speak = speak
        _liked = State(initialValue: variable.hasHanziLiked(capDo: capDo, viTriTuCong1: viTriTu, dataLiked: dataLiked))
        print("cap do: \(capDo)")
        
        //print(variable.getDataLiked())
    }
    var body: some View {
        VStack {
            HStack{
                if capDo != 9 {
                    Button{
                        if liked == false {
                            //add
                            if variable.addDataLiked(capDo: capDo, viTriTuCong1: viTriTu) {
                                liked.toggle()
                                toastMessage = NSLocalizedString("addhanzi", comment: "") + " " + chuHan
                                
                            }else{
                                print("Khong the Insert them vi da co du 100 phan tu cua mang liked")
                                toastMessage = "Không thể thêm \(chuHan) vào danh sách từ khó. Hãy giảm bớt số lượng từ khó cần học."
                            }
                            showToast = true
                        }else {
                            //remove
                            
                            if variable.removeDataLiked(capDo: capDo, viTriTuCong1: viTriTu) {
                                toastMessage = "Đã loại bỏ \(chuHan) khỏi danh sách từ khó"
                                showToast = true
                            }
                            liked.toggle()
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            showToast = false
                        }
                        //                    print("liked")
                        //                    print(variable.getDataLiked())
                    }label: {
                        Image(systemName: liked ? "star.fill" : "star")
                            .foregroundColor(.textTim)
                            .padding(0)
                            .font(.system(size: 22))
                        
                    }
                    .padding(20)
                }
                Spacer()
                
                Button {
//                    enableButton = false
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//                        enableButton = true
//                    }
                    if speak != "" {
                        SpeechManager.shared.speak(speak)
                    }else{
                        SpeechManager.shared.speak(chuHan)
                    }
                    
                    isPressed = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                        isPressed = false
                    }
                } label: {
                    Image(systemName: "speaker.wave.2.fill")
                        .foregroundColor(Color("bgTim"))
                        .padding(15)
                        .background(Color("bgTimMo"))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                        .scaleEffect(isPressed ? 0.85 : 1)
                        .opacity(isPressed ? 0.6 : 1)
                        .animation(.easeInOut(duration: 0.15), value: isPressed)
                }
            }
            Spacer()
            
            Text(chuHan)
                .font(.system(size: Variable().getRatioScreen() < 1.8 ? 70 : 100))
                .foregroundColor(Color("textTim"))
                .onChange(of: chuHan) { newValue in
                    if !daDocLanDau && step == 0{
                        print("doc lan dau")
                        daDocLanDau = true
                        if turnOnVoid {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                SpeechManager.shared.speak(newValue)
                            }
                        }
                        
                    }
                    
                }
                        
            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 70)
                .fill(Color("bgTim2"))
        )
        .padding()
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.width > 50 {
                        print("Vuốt sang phải")
                    }
                    if value.translation.width < -50 {
                        print("Vuốt sang trai")
                    }
                }
        )
        .onAppear{
            print("cap do: \(capDo) vi tri tu: \(viTriTu)")
            if capDo == 9 {
                liked = variable.hasHanziLiked(capDo: capDo, viTriTuCong1: viTriTu, dataLiked: dataLiked)
            }
            
        }
        .overlay(
            Group {
                if showToast {
                    VStack {
                        Spacer()
                        ToastView(message: toastMessage)
                            .padding(.bottom, 40)
                            .transition(.opacity)
                    }
                }
            }
        )
        .animation(.easeInOut, value: showToast)
    }
}
struct BackView: View {
    let nghia: String
    let phienAm: String
    let viDu: String
    let cauChuyen: String
    var body: some View {
        VStack {
            Spacer()
            Text(nghia)
                .font(.system(size: Variable().getRatioScreen() < 1.8 ? 23 : 30))
                .foregroundColor(Color("textTim"))
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            Text("[\(phienAm)]")
                .font(.system(size: Variable().getRatioScreen() < 1.8 ? 20 : 26))
                .foregroundColor(Color.black.opacity(0.8))
                .padding(.top, 5)
                .padding(.bottom, Variable().getRatioScreen() < 1.8 ? 10 : 20)
                .padding(.horizontal)
            if cauChuyen != "" {
                Text(cauChuyen)
                    .font(.system(size: 17))
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.bgTimCauChuyen)
            }
            Text(viDu)
                .font(.system(size: 18))
                .padding(.horizontal)
            Spacer()
        }
        .padding(.vertical)
        .padding(.leading, 0)
        .padding(.trailing, 0)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 70)
                .fill(Color("bgTim2"))
        )
        .padding()
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.width > 50 {
                        print("Vuốt sang phải")
                    }
                    if value.translation.width < -50 {
                        print("Vuốt sang trai")
                    }
                }
        )
    }
}
