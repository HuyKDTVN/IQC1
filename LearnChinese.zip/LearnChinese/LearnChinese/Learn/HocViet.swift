//
//  HocViet.swift
//  LearnChinese
//
//  Created by Huy Le on 23/12/25.
//

import SwiftUI


struct HocViet: View {
    let capDo: Int //HSK1
    let soBai: Int // bai 10
    
    var variable:Variable = Variable()
    @Environment(\.dismiss) var dismiss
    @State private var text = ""
    @State private var hasRedirect = false
    @State private var isPressed = false
    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var hasUpdateChuoiNgay = false
    @FocusState private var isFocused: Bool
  
    @State private var liked: Bool = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    @State private var hsk: [Vocabulary] = []
    
    @State private var soTuToiDa : Int = 10
    var turnOnSound: Bool = Variable().getUserDefaultBool(name: "amThanh")
    
    var turnOnVoid: Bool = Variable().getUserDefaultBool(name: "giongDoc")
    @State private var arrCauHoi: [Int] = []
    @State private var dataHSK: [[Int]] = []
    @State private var arrDataHSK: [[Int]] = Array(repeating: Array(repeating: 0, count: 3), count: 15)
   
    @State private var step: Int = 0
    @State private var stepLoadingBar: Int = 0
    @State private var prevStep: Int = 0
    @State private var buttonDisable: Bool = true
    @State private var daTraLoiSai: Bool = false
    @State private var daTraLoiDung: Bool = false
    var body: some View {
        //NavigationView {
        VStack{
                HStack(alignment: .top){
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text(variable.getTenCapDo(capDo: capDo))
                        .padding(10)
                        .font(.system(size: 18).bold())
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                        .foregroundColor(Color("textTim"))
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color("bgTimMo"))
                        )
                        //.bold()
                        
                       
                    
                }.padding(.horizontal, 20)
                .padding(.top, 10)
                //.padding(.top, 50)
                //.ignoresSafeArea(.container, edges: .top)
                //.background(Color.green.opacity(0.7))
                .padding(.bottom, 0)
                HStack {
                    Text(variable.getSoBai(soBai: soBai))
                        
                        .foregroundColor(Color("textTim"))
                        .font(.system(size: 30))
                        .bold()
                        .padding(.top, 0)
                }
                //.ignoresSafeArea(.container, edges: .top)
                .padding(.top, 10)
                //.padding(.bottom, -190)
                
            VStack{
                ZStack(alignment: .leading) {
                    GeometryReader { geo in
                        // Thanh nền xám
                        RoundedRectangle(cornerRadius: 7)
                            .fill(Color("bgXam"))
                            .frame(height: 14) // chiều cao thanh
                            
                        
                        // Thanh tiến trình tím
                        RoundedRectangle(cornerRadius: 7)
                            .fill(Color("bgTim"))
                            .frame(width: geo.size.width  * CGFloat(stepLoadingBar) / CGFloat(soTuToiDa), height: 14)
                            .animation(.easeInOut(duration: 0.3), value: stepLoadingBar)
                            
                    }
                }
                .frame(height: 14)
                .padding(20)
                .padding(.top, 0)
                .padding(.bottom, -30)
                Spacer()
                VStack {
                    ScrollView(.vertical, showsIndicators: false){
                        NavigationLink("", isActive: $hasRedirect) {
                            Finish(capDo: capDo, soBai: soBai, loaiBai: 3, updateChuoiNgay: hasUpdateChuoiNgay)
                        }
                        ZStack{
                            if(daTraLoiDung) {
                                VStack{
                                    HStack{
                                        if capDo != 9 {
                                            Button{
                                                if liked == false {
                                                    //add
                                                    if variable.addDataLiked(capDo: capDo, viTriTuCong1: arrCauHoi[step] + 1) {
                                                        liked.toggle()
                                                        toastMessage = "Đã thêm \(hsk[arrCauHoi[step]].chinese) vào danh sách từ khó"
                                                        
                                                    }else{
                                                        print("Khong the Insert them vi da co du 100 phan tu cua mang liked")
                                                        toastMessage = "Không thể thêm \(hsk[arrCauHoi[step]].chinese) vào danh sách từ khó. Hãy giảm bớt số lượng từ khó cần học."
                                                    }
                                                    showToast = true
                                                }else {
                                                    //remove
                                                    
                                                    if variable.removeDataLiked(capDo: capDo, viTriTuCong1: arrCauHoi[step] + 1) {
                                                        toastMessage = "Đã loại bỏ \(hsk[arrCauHoi[step]].chinese) khỏi danh sách từ khó"
                                                        showToast = true
                                                    }
                                                    liked.toggle()
                                                }
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                                    showToast = false
                                                }
                                                print("liked")
                                                print(variable.getDataLiked())
                                            }label: {
                                                Image(systemName: liked ? "star.fill" : "star")
                                                    .foregroundColor(.textTim)
                                                    .padding(0)
                                                    .font(.system(size: 22))
                                                
                                            }
                                            .padding(0)
                                            .padding(.top, -30)
                                            .id(arrCauHoi[step] + 1)
                                            .onAppear{
                                                print("reload...")
                                                liked = variable.hasHanziLiked(capDo: capDo, viTriTuCong1: arrCauHoi[step] + 1, dataLiked: arrDataHSK)
                                            }
                                        }
                                        Spacer()
                                        Button {
                                            if hsk[arrCauHoi[step]].speed != "" {
                                                SpeechManager.shared.speak(hsk[arrCauHoi[step]].speed)
                                            } else {
                                                SpeechManager.shared.speak(hsk[arrCauHoi[step]].chinese)
                                            }
                                            isPressed = true
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                                                isPressed = false
                                            }
                                        } label: {
                                            Image(systemName: "speaker.wave.2.fill")
                                                .foregroundColor(Color("bgTim"))
                                                .padding(15)
                                                .background(Color("bgTimMo"))
                                                .clipShape(Circle())
                                                .font(.system(size: 30))
                                                .scaleEffect(isPressed ? 0.85 : 1)
                                                .opacity(isPressed ? 0.6 : 1)
                                                .animation(.easeInOut(duration: 0.15), value: isPressed)
                                                
                                        }
                                    
                                    .padding(.bottom, 30)}
                                    Text(hsk[arrCauHoi[step]].vietnamese)
                                        .font(.system(size: 30))
                                        .foregroundColor(Color("textTim"))
                                        .padding(.bottom, 15)
                                        .padding(.top, -30)
                                        .multilineTextAlignment(.center)
                                   
                                    Text(hsk[arrCauHoi[step]].chinese)
                                        .font(.system(size: 80))
                                        .foregroundColor(Color("textTim"))
                                        .padding(.bottom, 20)
                                        .padding(.top, -30)
                                        .multilineTextAlignment(.center)
                                    Text("[\(hsk[arrCauHoi[step]].pinyin)]")
                                        .font(.system(size: 30))
                                        .padding(.bottom, 20)
                                        .padding(.top, -30)
                                        .multilineTextAlignment(.center)
                                    Text(hsk[arrCauHoi[step]].example)
                                        .font(.system(size: 22))
                                        .padding(.bottom, 20)
                                        .padding(.top, -30)
                                        .multilineTextAlignment(.center)
                                    let hanziArray = hsk[arrCauHoi[step]].chinese.map { String($0) }
                                    ForEach(hanziArray, id: \.self) { hanzi in
                                        HanziCard(hanzi: hanzi)
                                                //.id(hanzi)
                                        if hsk[arrCauHoi[step]].cauChuyen != "" {
                                            Text(hsk[arrCauHoi[step]].cauChuyen)
                                                .font(.system(size: 26))
                                                .padding()
                                                //.background(.bgTimCauChuyen)
                                        }
                                    }
                                }
                            }
                            else {
                                if step >= 0 && step < arrCauHoi.count {
                                    VStack{
                                        Text(hsk[arrCauHoi[step]].vietnamese)
                                            .font(.system(size: 30))
                                            .foregroundColor(Color("textTim"))
                                            .padding(.bottom, 15)
                                            //.padding(.top, -30)
                                            .multilineTextAlignment(.center)
                                        HStack{
                                            Image("hints")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .frame(height: 60)
                                                .padding(.leading, 0)
                                                .padding(.bottom, 0)
                                                .onTapGesture {
                                                    text = hsk[arrCauHoi[step]].chinese
                                                }
                                            TextField("", text: $text)
                                                .padding(15)
                                                .focused($isFocused)
                                                .font(.system(size: 30))
                                                .background(
                                                    RoundedRectangle(cornerRadius: 20)
                                                        .stroke(daTraLoiSai ? Color.red: Color.gray.opacity(0.5), lineWidth: 1)
                                                )
                                                
                                                .onChange(of: text) { newValue in
                                                    if(newValue != "") {
                                                        buttonDisable = false
                                                    }else {
                                                        buttonDisable = true
                                                    }
                                                }
                                                
                                                .onSubmit {
                                                    let submitVal =  submitButton()
                                                }
                                            Button {
                                                let submitVal = submitButton()
                                            } label: {
                                                Image(systemName: "paperplane.fill")
                                                    .foregroundColor(.white)
                                                    .padding(17)
                                                    .background(text.isEmpty ? Color.gray : Color("textTim") )
                                                    .clipShape(Circle())
                                                    .font(.system(size: 30))
                                                    .padding(.leading, 10)
                                                
                                            }.disabled(buttonDisable)
                                            
                                        }
                                    }
                                }
                            }
                            
                        }
                        
                       
                    }
                    .padding(.top, 10)
                    //.ignoresSafeArea(.container, edges: .top)
                    //.background(.red)
                    
                    Spacer()
                    if(daTraLoiDung) {
                        HStack{
                            
                            Spacer()
//                            Button {
//                                print("da thuoc")
//
//                            } label: {
//                                Text("Đã thuộc")
//                                    .foregroundColor(Color("bgTim"))
//                                    .padding(20)
//                                    .frame(minWidth: 130)
//                                    .background(
//                                        RoundedRectangle(cornerRadius: 23)
//                                            .fill(Color("bgTimMo"))
//                                    )
//                                    .font(.system(size: 20))
//
//                            }
//                            Spacer()
//                            Button {
//                                daTraLoiSai = false
//                                daTraLoiDung = false
//                                text = ""
//                                step = step + 1
//                                if(step == 15) {
//                                    hasRedirect = true
//                                }else{
//                                    //isFlipped = false
//                                    print("step: \(step)")
//                                    print("chu han thu: \(arrCauHoi[step])")
//                                    prevStep = step
//                                }
//                            } label: {
//                                Text("Next")
//                                    .foregroundColor(Color.white)
//                                    .padding(20)
//                                    .frame(minWidth: 130)
//                                    .background(
//                                        RoundedRectangle(cornerRadius: 23)
//                                            .fill(Color("bgTim"))
//                                    )
//                                    .font(.system(size: 20))
//
//                            }
                            Button {
                                daTraLoiSai = false
                                daTraLoiDung = false
                                text = ""
                                step = step + 1
                                
                                
                                if(step == soTuToiDa) {
                                    //get thanh tich hien tai
                                    print("test hoc viet")
                                    print(arrDataHSK)
                                    let thanhTichHienTai = arrDataHSK[soBai - 1][2] // 2 - hoc viet
                                    
                                    if thanhTichHienTai < 5 {
                                        //save Data to UserDefault
                                        arrDataHSK[soBai - 1][2] = thanhTichHienTai + 1
                                        variable.saveDataHSK(arrHsk: arrDataHSK, capDo: capDo)
                                    }
                                    hasUpdateChuoiNgay = variable.updateChuoiNgay()
                                    
                                    //luu cap do va so arrCauHoiGanNhat
                                    
                                    defaults?.set(arrCauHoi, forKey: "arrCauHoiGanNhat")
                                    
                                    HuyFunc().notiNhacTuMoiMoiNgay()
                                    let hasUpdateCapDoSoBai = variable.updateCapDoBaiHocCaoNhat(capDo: capDo, baiHoc: soBai)
                                    HuyFunc().removeDefaultNoti()
                                    switch variable.getChuoiNgay() {
                                    case 1:
                                        HuyFunc().setNotiNgay2DaHoc()
                                    case 2:
                                        HuyFunc().setNotiNgay3DaHoc()
                                    case 3:
                                        HuyFunc().setNotiNgay4DaHoc()
                                    case 4:
                                        HuyFunc().setNotiNgay5DaHoc()
                                    case 5:
                                        HuyFunc().setNotiNgay6DaHoc()
                                    default:
                                        HuyFunc().setNotiNgay6DaHoc()
                                    }
                                    hasRedirect = true
                                    
                                    if step > arrCauHoi.count - 1 {
                                        step = arrCauHoi.count - 1
                                    }
                                    
                                }else{
                                    //isFlipped = false
                                    //print("step: \(step)")
                                    //print("chu han thu: \(arrCauHoi[step])")
                                    prevStep = step
                                }
                                
                            } label: {
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.white)
                                    .padding(30)
                                    .background(Color("textTim"))
                                    .clipShape(Circle())
                                    .font(.system(size: 30))
                            }
                            Spacer()
                            
                        }
                        .padding(.bottom, 0)
                    }
                }
                .padding()
                .padding(.top, 0)
                .frame(maxWidth: .infinity)
                
                .padding()
                .onAppear(){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        isFocused = true
                    }
                }
                
            }
            .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
                //.padding(.top, -200)
            
            
            //.background(Color.green.opacity(0.3))
            .navigationBarBackButtonHidden(true)
            
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color("textTim"))
                            .clipShape(Circle())
                    }
                }
            }
        }
        
        .padding(.top, 50)
        .ignoresSafeArea(.container, edges: .top)
        .onAppear(){
            
            
            if capDo == 9 {
                hsk = variable.getDataVocaLiked()
            }else if capDo == 8{
                hsk = variable.loadVocabulary(hsk: "bothu50")
            }else if capDo == 7{
                hsk = variable.loadVocabulary(hsk: "bothuall")
            }
            else{
                hsk = variable.loadVocabulary(hsk: "hsk\(capDo)")
            }
            
            switch capDo {
                case 1:
                arrDataHSK = variable.getDataHSK1()
                case 2:
                arrDataHSK = variable.getDataHSK2()
                case 8:
                arrDataHSK = variable.getDataBoThu50()
                case 7:
                arrDataHSK = variable.getDataBoThuAll()
                case 3:
                arrDataHSK = variable.getDataHSK3()
                case 9:
                arrDataHSK = variable.getDataLiked()
                default:
                arrDataHSK = variable.getDataHSK1()
                }
            liked = variable.hasHanziLiked(capDo: capDo, viTriTuCong1: 1, dataLiked: dataHSK)
            
            if capDo == 9 {
                arrCauHoi = variable.getArrBaiHoc(a: soBai, doDaiArray: variable.getTotalLinked()).shuffled()
            } else {
                arrCauHoi = variable.getArrBaiHoc(a: soBai, doDaiArray: hsk.count).shuffled()
            }
            if capDo == 9 || soBai == 99 {
                soTuToiDa = hsk.count
            }
            else {
                soTuToiDa = variable.soTuTrong1Bai
                if soTuToiDa > arrCauHoi.count {
                    soTuToiDa = arrCauHoi.count
                }
            }
        }
        .overlay(
            Group {
                if showToast {
                    VStack {
                        Spacer()
                        ToastView(message: toastMessage)
                            .padding(.bottom, 40)
                            .transition(.opacity)
                    }
                }
            }
        )
        .animation(.easeInOut, value: showToast)
        
    }
    private func submitButton() -> Bool {
        var result = false
        if text == hsk[arrCauHoi[step]].chinese {
            print("dung")
            if turnOnSound {
                SoundManager.shared.playSound(name: "hit")
            }
            let impact = UIImpactFeedbackGenerator(style: .rigid)
            impact.impactOccurred()
            if turnOnVoid {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    if hsk[arrCauHoi[step]].speed != "" {
                        SpeechManager.shared.speak(hsk[arrCauHoi[step]].speed)
                    } else {
                        SpeechManager.shared.speak(hsk[arrCauHoi[step]].chinese)
                    }
                }
            }
            stepLoadingBar = stepLoadingBar + 1
            daTraLoiDung = true
            
            result = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                isFocused = true              // 4️⃣ Tự động focus khi view xuất hiện
            }
        } else{
            let impact = UIImpactFeedbackGenerator(style: .heavy)
            impact.impactOccurred()
            if turnOnSound {
                SoundManager.shared.playSound(name: "crash2")
            }
            print("sai")
            daTraLoiSai = true
        }
        return result
    }
}

#Preview {
    HocViet(capDo: 1, soBai: 1)
}
