//
//  Setting.swift
//  LearnChinese
//
//  Created by Huy Le on 30/12/25.
//

import SwiftUI

struct Setting: View {
    @Environment(\.dismiss) var dismiss
    var variable:Variable = Variable()
    @State private var giaoDienNenToi = false
    @State private var amThanh = true
    //@State private var danhNgon = true
    @State private var giongDoc = true
    @State private var nhacTuMoi = true
    @State var showPrivacyPage: Bool = false
    @State var showTermsPage: Bool = false
    
    @AppStorage(
        "yourName",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    )
    private var username: String = Variable().getUserDefaultString(name: "yourName")
    
    @AppStorage(
        "danhNgon",
        store: UserDefaults(suiteName: Variable().userDefaultGroupName)
    ) private var danhNgon: Bool = Variable().getUserDefaultBool(name: "danhNgon")
    
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    var body: some View {
        //ScrollView {
            VStack{
                
                Text(NSLocalizedString("setting", comment: ""))
                    .font(.largeTitle.bold())
                //NavigationView {
                    
                    List{
//                        Section{
//                            HStack {
//                                Circle()
//                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
//                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
//                               
//                               Toggle(NSLocalizedString("Giao diện nền tối", comment: ""), isOn: $giaoDienNenToi)
//                                    .toggleStyle(SwitchToggleStyle(tint: Color("bgTim")))
//                                   .onChange(of: giaoDienNenToi) { value in
//                                      defaults?.set(giaoDienNenToi, forKey: "giaoDienNenToi")
//                                      
//                                   }
//                            }
////                            HStack {
////                                Circle()
////                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
////                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
////                               
////                               Toggle(NSLocalizedString("Màu sắc", comment: ""), isOn: $giaoDienNenToi)
////                                    .toggleStyle(SwitchToggleStyle(tint: Color("bgTim")))
////                                   .onChange(of: giaoDienNenToi) { value in
////                                      UserDefaults.standard.set(giaoDienNenToi, forKey: "giaoDienNenToi")
////                                      
////                                   }
////                            }
//                        }
                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
                               Text(NSLocalizedString("yourname", comment: ""))
                                TextField("", text: $username)
                            }
                        }
                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("sound", comment: ""), isOn: $amThanh)
                                     .toggleStyle(SwitchToggleStyle(tint: Color("bgTim")))
                                    .onChange(of: amThanh) { value in
                                        defaults?.set(amThanh, forKey: "amThanh")
                                       
                                    }
                                
                               
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
                               
                               Toggle(NSLocalizedString("voice", comment: ""), isOn: $giongDoc)
                                    .toggleStyle(SwitchToggleStyle(tint: Color("bgTim")))
                                   .onChange(of: giongDoc) { value in
                                       defaults?.set(giongDoc, forKey: "giongDoc")
                                      
                                   }
                            }
                        }
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("danhngon", comment: ""), isOn: $danhNgon)
                                     .toggleStyle(SwitchToggleStyle(tint: Color("bgTim")))
//                                    .onChange(of: danhNgon) { value in
//                                        defaults?.set(danhNgon, forKey: "danhNgon")
//                                       
//                                    }
                            }
                            
                        }
                        
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
                               
                                Toggle(NSLocalizedString("nhactumoi", comment: ""), isOn: $nhacTuMoi)
                                     .toggleStyle(SwitchToggleStyle(tint: Color("bgTim")))
                                    .onChange(of: nhacTuMoi) { value in
                                        defaults?.set(nhacTuMoi, forKey: "nhacnhotumoi")
                                        if nhacTuMoi == false{
                                            HuyFunc().removeNoti(myName: "nhactumoi1")
                                            HuyFunc().removeNoti(myName: "nhactumoi2")
                                            HuyFunc().removeNoti(myName: "nhactumoi3")
                                            HuyFunc().removeNoti(myName: "nhactumoi4")
                                            HuyFunc().removeNoti(myName: "nhactumoi5")
                                        }
                                       
                                    }
                            }
                            
                        }
                        Section{
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.2))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("rate", comment: ""), destination: URL(string: variable.link_app)!).foregroundColor(.black)
                                
                            }
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("readmore", comment: ""), destination: URL(string: variable.link_dev)!).foregroundColor(.black)
                                
                            }
                            
                            HStack {
                                Circle()
                                    .strokeBorder(Color("bgTim"),lineWidth: 2)
                                    .background(Circle().foregroundColor(Color("bgTim").opacity(0.4))).frame(width: 20, height: 20)
                                Link(NSLocalizedString("help", comment: ""), destination: URL(string: variable.link_facebook_message)!).foregroundColor(.black)
                            }
                            NavigationLink {
                                Privacy()
                            } label: {
                                HStack{
                                    Circle()
                                        .strokeBorder(Color("bgTim"),lineWidth: 2)
                                        .background(Circle().foregroundColor(Color("bgTim").opacity(0.4))).frame(width: 20, height: 20)
                                    
                                    Text(NSLocalizedString("privacy", comment: ""))
                                        .foregroundColor(.black)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                            }
                            NavigationLink {
                                Terms()
                            } label: {
                                HStack{
                                    Circle()
                                        .strokeBorder(Color("bgTim"),lineWidth: 2)
                                        .background(Circle().foregroundColor(Color("bgTim").opacity(0.4))).frame(width: 20, height: 20)
                                    
                                    Text(NSLocalizedString("term", comment: ""))
                                        .foregroundColor(.black)
                                        .frame(minWidth: 200, maxWidth: 250,alignment: .leading)
                                }
                            }
                        }
                    }
                    
                }
                
              //  Spacer()
            //}
            .onAppear() {
                amThanh = defaults?.bool(forKey: "amThanh") ?? false
                giongDoc = defaults?.bool(forKey: "giongDoc") ?? false
                //danhNgon = defaults?.bool(forKey: "danhNgon") ?? false
                nhacTuMoi = defaults?.bool(forKey: "nhacnhotumoi") ?? false
            }
            .padding(.top, 70)
            //.padding()
            
            
        .edgesIgnoringSafeArea(.all)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                NavigationLink(destination: ContentView()) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color("textTim"))
                        .clipShape(Circle())
                }
            }
        }

        
    }
}

#Preview {
    Setting()
}
