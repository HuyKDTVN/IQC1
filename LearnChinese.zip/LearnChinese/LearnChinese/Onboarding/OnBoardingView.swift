//
//  OnBoardingView.swift
//  LearnChinese
//
//  Created by Huy Le on 18/1/26.
//

import SwiftUI

struct OnBoardingView: View {
    @Binding var firstOpen: Bool
    @State private var page = 0
    @State var daTraLoiSai = false
    let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
    @State var text = ""
    var body: some View {
        VStack {
            TabView (selection: $page){
                Onboarding1(isActive: page == 0).tag(0)
                Onboarding2().tag(1)
                Onboarding3(isActive: page == 2).tag(2)
                Onboarding4(text: $text, daTraLoiSai: $daTraLoiSai).tag(3)
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            CustomPageIndicator(count: 4, current: page)
            HStack{
                Button {
                    if page < 3 {
                        if page == 1 {
                            Task {
                                _ = await Variable().requestNotificationPermission()

                                withAnimation(.easeInOut(duration: 0.3)) {
                                    page += 1
                                }
                            }
                        }else{
                            withAnimation(.easeInOut(duration: 0.3)) {
                                page += 1
                            }
                        }
                    }
                    else{
                        
                        submitBatDau()
                    }
                }label: {
                    Spacer()
                    Text(Variable().arrButtonOnboarding[page])
                        .foregroundColor(.white)
                        .font(.system(size: 20).bold())
                      
                        .frame(height: 30)
                        .padding(15)
                        .padding(.leading, 30)
                        .padding(.trailing, 30)
                        .background(
                            RoundedRectangle(cornerRadius: 40)
                                .fill(.bgTim )
    //                                .overlay(
    //                                    RoundedRectangle(cornerRadius: 40)
    //                                        .stroke(Color("textTim"), lineWidth: 1)
    //                                )
                        )
                        .padding(5)
                        //.padding(.leading, 20)
                        Spacer()
                }
                if page == 3 {
                    Button {
                        submitTen()
                    }label: {
                        Spacer()
                        Text(NSLocalizedString("andanh", comment: ""))
                            .foregroundColor(.textTim)
                            .font(.system(size: 20).bold())
                        
                            .frame(height: 30)
                            .padding(15)
                            .padding(.leading, 20)
                            .padding(.trailing, 20)
                            .background(
                                RoundedRectangle(cornerRadius: 40)
                                    .fill(.bgTimMo )
                                //                                .overlay(
                                //                                    RoundedRectangle(cornerRadius: 40)
                                //                                        .stroke(Color("textTim"), lineWidth: 1)
                                //                                )
                            )
                            .padding(5)
                        //.padding(.leading, 20)
                        Spacer()
                    }
                }
                
            }
        }
    }
    func submitTen() -> Void {
        defaults?.set(text, forKey: "yourName")
        firstOpen.toggle()
        
        Variable().setDefaultForData()
        let defaults = UserDefaults(suiteName: Variable().userDefaultGroupName)
        defaults?.set(true, forKey: "firstOpenApp")
        
        HuyFunc().setNotiDefault()
        
    }
    func submitBatDau() -> Void {
        if text != "" {
            daTraLoiSai = false
            submitTen()
        }else{
            daTraLoiSai = true
           
        }
        
        
    }
}

#Preview {
    @State var firstOpen: Bool = false
    OnBoardingView(firstOpen: $firstOpen)
}
struct CustomPageIndicator: View {
    let count: Int
    let current: Int

    var body: some View {
        HStack(spacing: 8) {
            ForEach(0..<count, id: \.self) { index in
                Circle()
                    .fill(index == current ? .bgTim : Color.gray.opacity(0.3))
                    .frame(
                        width: index == current ? 10 : 8,
                        height: 8
                    )
                    .animation(.easeInOut(duration: 0.25), value: current)
            }
        }
    }
}
