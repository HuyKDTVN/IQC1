//
//  Onboarding1.swift
//  LearnChinese
//
//  Created by Huy Le on 18/1/26.
//

import SwiftUI

struct Onboarding1: View {
    let isActive: Bool
    @State private var show: Bool = false
    var body: some View {
        VStack{
            Text(NSLocalizedString("chaomungbandenvoi", comment: ""))
                .font(.system(size: 23).bold())
                .padding(.top, 50)
                .padding(.bottom, 0)
            Text("Learn Chinese")
                .font(.system(size: 30).bold())
                .foregroundColor(.textTim)
            
            VStack{
                //if show {
                    VStack{
                        HStack{
                            ZStack{
                                Image("\(Variable().loaiBaiHocIcon[0])")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 30)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text(NSLocalizedString("flashcardsmart", comment: ""))
                            
                            Spacer()
                        }
                        HStack{
                            ZStack{
                                Image("\(Variable().loaiBaiHocIcon[1])")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 30)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text(NSLocalizedString("thuthachtrinhotucthi", comment: ""))
                            
                            Spacer()
                        }
                        HStack{
                            ZStack{
                                Image("\(Variable().loaiBaiHocIcon[2])")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 30)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text(NSLocalizedString("luyenvietchuyensau", comment: ""))
                            
                            Spacer()
                        }
                        HStack{
                            
                            ZStack{
                                Image("no-ads")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 30)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text(NSLocalizedString("no-ads", comment: ""))
                            
                            Spacer()
                        }
                        HStack{
                            ZStack{
                                Image("no-pro")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 30)
                                    .padding(.leading, 15)
                            }
                            .frame(width: 60)
                            Text(NSLocalizedString("noneedupdatepro", comment: ""))
                            
                            Spacer()
                        }
                    }
                    .padding()
                    .padding(.top, 20)
                    .padding(.bottom, 20)
                    .background(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color("bgTimMo").opacity(0.7))
                    )
                    .padding(.horizontal, 40)
                //}
            }
            
            
            VStack{
                if show {
                    HStack{
                        Spacer()
                        Image("avatar1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 200)
                            .padding(.trailing, 20)
                            .padding(.top, -30)
                    }
                    
                }
            }.onAppear{
                withAnimation(.easeInOut(duration: 0.5).delay(1)) {
                    show = true
                }
            }
            Spacer()
        }
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
    }
}

#Preview {
    Onboarding1(isActive: true)
}
