//
//  Onboarding3.swift
//  LearnChinese
//
//  Created by Huy Le on 18/1/26.
//

import SwiftUI

struct Onboarding3: View {
    let isActive: Bool
    @State private var show2 = false
    var body: some View {
        VStack {
            ZStack{
                Image("iphonex-frame")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                //.frame(width: .infinity)
                    
                VStack{
                    if show2 {
                        VStack{
                            HStack(alignment: .center){
                                VStack(alignment: .center){
                                    Text("你好")
                                        .foregroundColor(.textTim)
                                        .font(.system(size: 25).bold())
                                    Text("[Nǐ hǎo]")
                                        .font(.system(size:16))
                                        .foregroundColor(.black.opacity(0.8))
                                }
                                .frame(maxWidth: .infinity)
                                
                                Rectangle()
                                    .fill(Color.black.opacity(0.05))
                                    .frame(width: 2)
                                Text(NSLocalizedString("hello", comment: ""))
                                    .frame(maxWidth: .infinity)
                                    .font(.system(size:20).bold())
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .frame(height: 120)
                            .background(
                                RoundedRectangle(cornerRadius: 30)
                                    .fill(Color(.white))
                            )
                            
                            VStack(alignment: .center){
                                VStack(alignment: .center){
                                    Text("中国")
                                        .foregroundColor(.textTim)
                                        .font(.system(size: 25).bold())
                                        .padding(.top, 10)
                                        .padding(.bottom, 2)
                                    Text("[Zhōngguó]")
                                        .font(.system(size:16))
                                        .foregroundColor(.black.opacity(0.8))
                                        .padding(.bottom, 10)
                                }
                                .frame(maxWidth: .infinity)
                                
                                Rectangle()
                                    .fill(Color.black.opacity(0.05))
                                    .frame(height: 2)
                                Text(NSLocalizedString("chinese", comment: ""))
                                    .foregroundColor(.textTim)
                                    .frame(maxWidth: .infinity)
                                    .font(.system(size:20).bold())
                                    .padding(.bottom, 5)
                                    .padding(.top, 10)
                                Text("Ví dụ: 我要去中国。")
                                    .frame(maxWidth: .infinity)
                                    .font(.system(size:16))
                                Text(NSLocalizedString("gotochina", comment: ""))
                                    .frame(maxWidth: .infinity)
                                    .font(.system(size:16))
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            
                            .background(
                                RoundedRectangle(cornerRadius: 30)
                                    .fill(Color(.white))
                            )
                            .padding(.top, 20)
                            
                            Spacer()
                        }
                        .padding(.horizontal, Variable().getRatioScreen() > 1.8 ? 20 : 30)
                        .padding(.top, 90)
                        
                    }
                    
                }
                
            }.onAppear{//.onChange(of: isActive) { active in
                withAnimation(.easeInOut(duration: 0.5).delay(1)) {
                    show2 = true
                }
            }
            .padding(.top, Variable().getRatioScreen() > 1.8 ? 0 : -30)
            .padding(.horizontal, 45)
            
            Text(NSLocalizedString("learnwidget", comment: ""))
                .font(.system(size: 22).bold())
                .multilineTextAlignment(.center)
                .padding(.top, 20)
                .padding(.bottom, 5)
            Text(NSLocalizedString("learnwidget_desc", comment: ""))
                .multilineTextAlignment(.center)
                .font(.system(size: 16))
            Spacer()
        }
        .padding(.horizontal, 20) 
        .frame(maxWidth: Variable().getRatioScreen() < 1.53 ? CGFloat(Variable().getWidthScreen()) * 0.65 : .infinity)
    }
}

#Preview {
    Onboarding3(isActive: true)
}
